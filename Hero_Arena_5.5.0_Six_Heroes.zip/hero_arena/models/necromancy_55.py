"""Two individually targetable undead; legacy single summons remain unchanged."""
import random
from .character import Character,HERO_CLASSES
from .heroes_55 import NewHero,Special,game
from .skills import DamageSkill,SelfBuffSkill
from .effects import Effect,Shield,DodgeBuff,Stun,Announcement


class DecayMark(Effect):
    name,icon='Метка разложения','💚'
    def __init__(self,source_id):super().__init__(3,15);self.source_id=source_id
    def to_dict(self):return {**super().to_dict(),'source_id':self.source_id}


STATS={
 'skeleton':[(40,4,0,7),(36,5,0,7),(28,5,0,7)],
 'zombie':[(30,5,0,6),(26,4,0,6),(22,3,0,6),(18,2,0,6)],
 'homunculus':[(75,7,2,5),(60,6,1,5),(45,4,1,5)]}
NAMES={'skeleton':['Скелет-маг','Скелет-бомбер','Скелет'],
       'zombie':['Зомби']*4,'homunculus':['Гомункул']*3}


class Undead(Character):
    """A target with the complete Character combat protocol and a stable slot ID."""
    is_minion=True
    type_key='undead'
    hero_class='Нежить'
    def __init__(self,owner,kind,tier,slot):
        self.owner,self.kind,self.quality,self.slot=owner,kind,tier,slot
        hp,dmg,armor,life=STATS[kind][tier]
        scale=owner.power_scale()
        super().__init__(NAMES[kind][tier],max_hp=round(hp*scale),base_damage=round(dmg*scale*owner.summon_power()),
            armor=armor,speed=3,dodge=0,crit_chance=.05,energy_regen=0,start_energy=0)
        self.id=f's{owner.id}_{slot}'
        self._arena=True;self._battle=getattr(owner,'_battle',None)
        self.opponent=owner.opponent
        self.expires_round=getattr(self._battle,'round',0)+life
        self.lifetime=life;self.command_boost=0;self.command_pierce=0;self.command_expires=0
        self.intercept_chance=0;self._death_processed=False
        self.hp=self.max_hp
    def _create_skills(self):return [DamageSkill('attack','Удар нежити','Самостоятельная атака',
        accuracy=.95 if self.kind=='skeleton' and self.quality==0 else .8,
        ignore_armor=self.kind=='skeleton' and self.quality==0,icon='💀')]
    def take_damage(self,amount,ignore_armor=False,attacker=None):
        alive=self.is_alive();damage=super().take_damage(amount,ignore_armor,attacker)
        if alive and not self.is_alive() and not self._death_processed:
            self._death_processed=True;self.owner.on_minion_killed(self,attacker);self._events.extend(self.owner.pop_events())
        return damage
    def start_turn(self):
        alive=self.is_alive();logs,can_act=super().start_turn()
        if alive and not self.is_alive() and not self._death_processed:
            self._death_processed=True;self.owner.on_minion_killed(self,None);logs+=self.owner.pop_events()
        return logs,can_act
    def damage_multiplier(self):return super().damage_multiplier()*self.owner.damage_multiplier()
    def damage_vs(self,target):
        marked=any(isinstance(e,DecayMark) and e.source_id==self.owner.id for e in getattr(target,"get_effects",lambda:[])())
        return 1.15 if marked else 1
    def on_hit_landed(self,target,skill):
        if self.kind=='homunculus' and random.random()<( .2,.15,0)[self.quality]:
            if target.add_effect(Stun(1)):return [f'🧟 {self.name} оглушает {target.name}!']
        return []
    def act(self,target):
        logs,can_act=self.start_turn()
        if not self.is_alive() or not can_act:return logs
        round_=getattr(self._battle,'round',0)
        boost=self.command_boost if round_<self.command_expires else 0
        old_damage=self._base_damage;old_pierce=self.skills['attack'].armor_pierce
        self._base_damage=old_damage*(1+boost)
        self.skills['attack'].armor_pierce=self.command_pierce if boost else 0
        try:logs+=self.skills['attack'].execute(self,target)
        finally:self._base_damage=old_damage;self.skills['attack'].armor_pierce=old_pierce;self.command_boost=0
        if self.kind=='skeleton' and self.quality==0 and self.owner.is_alive():
            healed=self.owner.heal(round(3*self.owner.power_scale()))
            logs.append(f'💚 Скелет-маг лечит {self.owner.name}: +{healed} HP.')
        if self.kind=='zombie' and self.is_alive():
            healed=self.heal(round((6,4,3,2)[self.quality]*self.owner.power_scale()))
            logs.append(f'🧟 {self.name} срастается: +{healed} HP.')
        return logs+self.pop_events()
    def to_dict(self):
        return {'id':self.id,'slot':self.slot,'type':'Undead','kind':self.kind,'quality':self.quality,
            'name':self.name,'icon':{'skeleton':'💀','zombie':'🧟','homunculus':'🧬'}[self.kind],
            'hp':self.hp,'max_hp':self.max_hp,'damage':self.get_damage(),'armor':self.armor_total(),
            'dodge':self.get_dodge(),'alive':self.is_alive(),'lifetime':self.lifetime,
            'lifetime_unit':'round','expires_round':self.expires_round,'targetable':True,
            'effects':[e.to_dict() for e in self.get_effects()],
            'image':'/static/images/summons/getou_'+(('skeleton_mage','bomber','skeleton')[self.quality] if self.kind=='skeleton' else self.kind)+'.jpg',
            'about':('Лечит хозяина на 3 HP' if self.kind=='skeleton' and self.quality==0 else
                     'После убийства оставляет бомбу' if self.kind=='skeleton' and self.quality==1 else
                     'Восстанавливает здоровье после своей атаки' if self.kind=='zombie' else
                     'Может оглушить при попадании' if self.kind=='homunculus' and self.quality<2 else 'Самостоятельно атакует')}


class Getou(NewHero):
    """Гэтоу: чистый некромант. Два самостоятельных существа, управление и сохранение нежити."""
    hero_class,type_key,role,resource_name='Некромант','getou','light','мана'
    HP,DAMAGE,ARMOR,SPEED,DODGE=190,10,1,5,.08
    signature_skill='raise_bones'
    SOUL_MANA=8
    PASSIVE_NOTES=(lambda c:f'«Остаточная душа»: убийство своего призыва противником возвращает {c.SOUL_MANA} маны, не чаще раза за раунд; два разных существа одновременно',)
    def _on_reset(self):
        super()._on_reset();self.minions=[None,None];self._soul_round=-1
    def summon_power(self):
        unscaled=self._base_damage*(1+self.DMG_PER_LEVEL*(self.level-1))
        return self.get_damage()/max(1,unscaled)
    def living_minions(self):return [s for s in self.minions if s is not None and s.is_alive()]
    def can_summon(self,kind):
        pets=self.living_minions();return len(pets)<2 and not any(s.kind==kind for s in pets)
    def raise_minion(self,kind,tier):
        if not self.can_summon(kind):raise ValueError('Два слота заполнены или такой вид уже призван')
        slot=next(i for i,s in enumerate(self.minions) if s is None or not s.is_alive())
        self.minions[slot]=pet=Undead(self,kind,tier,slot)
        return [Announcement(f'{pet.to_dict()["icon"]} {self.name} поднимает {pet.name}: {pet.hp} HP, {pet.get_damage()} урона, {pet.lifetime} раундов.')]
    def on_minion_killed(self,pet,attacker):
        battle=getattr(self,'_battle',None);round_=getattr(battle,'round',self.turn_number)
        if self.is_alive() and round_!=self._soul_round:
            self._soul_round=round_;before=self.energy;self.restore_energy(self.SOUL_MANA)
            self._events.append(f'💚 Остаточная душа: {self.name} +{self.energy-before} маны.')
        if pet.kind=='skeleton' and pet.quality==1:
            killer=attacker if attacker is not None else self.opponent
            if killer is None:return
            clock=getattr(killer,'owner',killer)
            queue=getattr(clock,'_necro_bombs',[])
            queue.append({'due_turn':clock.turn_number+1,'target':killer,'source':self,
                          'power':round(12*self.power_scale())})
            clock._necro_bombs=queue
            self._events.append(Announcement(f'💣 {pet.name} оставляет бомбу: взрыв в конце следующего хода {clock.name}.'))
    def summon_act(self,target):
        logs=[]
        for s in self.living_minions():
            victim=target if target.is_alive() else self.opponent
            if victim is not None and victim.is_alive():logs+=s.act(victim)
        return logs+self.pop_events()
    def summon_value(self,game,target):
        kind={'raise_bones':'skeleton','raise_zombie':'zombie','build_homunculus':'homunculus'}[game]
        damage={'skeleton':4.5,'zombie':4,'homunculus':6}[kind]*self.power_scale()*self.summon_power()
        armor=target.armor_total()*(.5 if kind=='skeleton' else 1)
        survival=min(5,max(1,self.hp/max(1,target.get_damage()*1.1)))
        pressure=max(1,damage-armor)*.8*survival
        if kind=='skeleton':pressure+=min(self.max_hp-self.hp,9*self.power_scale())*.5
        if not self.living_minions():pressure*=1.5
        return pressure
    def state_data(self):return {'summons':[s.to_dict() for s in self.minions if s is not None], 'summon_capacity':2}
    def _create_skills(self):return [
        Special('attack','Воля повелителя','Командный ход: существа атакуют выбранную цель; сам некромант не наносит удар',
            icon='🕯',action=lambda u,t:[f'🕯 {u.name} направляет нежить на {t.name}.'],score=lambda u,t:.5),
        SelfBuffSkill('bone_shelter','Костяной заслон','Щит 20 поглощения на 2 хода',effects=[lambda:Shield(2,20)],cost=18,cooldown=4,icon='🦴'),
        SelfBuffSkill('grave_mist','Могильный туман','+20% уклонения на 2 хода',effects=[lambda:DodgeBuff(2,20)],cost=20,cooldown=5,icon='🌫'),
        Special('decay_mark','Метка разложения','Свои существа наносят цели на 15% больше урона, 3 хода цели',cost=14,cooldown=3,icon='💚',
            action=lambda u,t:mark_decay(u,t),score=lambda u,t:0 if not u.living_minions() or any(isinstance(e,DecayMark) and e.source_id==u.id for e in t.get_effects()) else sum(s.get_damage() for s in u.living_minions())*.4),
        game('raise_bones','Поднять кости','Три ступени: скелет, бомбер или скелет-маг; можно остановиться после ступени',game='raise_bones',cost=32,cooldown=6,icon='💀'),
        game('raise_zombie','Восставший зомби','Соберите душу регенерирующего зомби; противник может выбрать его целью',game='raise_zombie',cost=28,cooldown=5,icon='🧟'),
        game('build_homunculus','Сборка гомункула','Соберите мощного слугу: идеал 75 HP, броня 2, 20% оглушить',game='build_homunculus',cost=50,cooldown=9,icon='🧬'),
        game('puppet_threads','Нити господства','Распутайте связи: до +25% урона следующей атаке каждого призыва; идеал пробивает 35% брони',game='puppet_threads',cost=18,cooldown=3,icon='🕸'),
        game('flesh_stitch','Сшивание плоти','Каждый шов лечит существ на 4 HP; хозяину — половина реального лечения, до 8 HP',game='flesh_stitch',cost=25,cooldown=6,icon='🪡'),
]


def mark_decay(user,target):
    for victim in [user.opponent]+getattr(user.opponent,'minions',[]):
        if victim is not None:victim._effects=[e for e in victim.get_effects() if not(isinstance(e,DecayMark) and e.source_id==user.id)]
    target._effects.append(DecayMark(user.id));return [f'💚 {target.name}: Метка разложения, +15% урона от нежити {user.name}.']


def dismiss(user):
    slot=getattr(user,'_dismiss_slot',None)
    s=user.minions[slot] if isinstance(slot,int) and 0<=slot<2 else next(iter(user.living_minions()),None)
    if s is None or not s.is_alive():raise ValueError('В этом слоте нет живого существа')
    s.hp=0;s._death_processed=True
    return [f'✖ {user.name} рассеивает {s.name}.']


def finish_bombs(hero):
    logs=[];remaining=[]
    for bomb in getattr(hero,'_necro_bombs',[]):
        if hero.turn_number<bomb['due_turn']:remaining.append(bomb);continue
        target=bomb['target'] if bomb['target'].is_alive() else hero
        if target.is_alive():
            damage=target.take_damage(bomb['power'],ignore_armor=True,attacker=bomb['source'])
            logs.append(Announcement(f'💣 Посмертная бомба: {target.name} получает {damage} урона.'))
    hero._necro_bombs=remaining
    return logs


HERO_CLASSES[Getou.type_key]=Getou
