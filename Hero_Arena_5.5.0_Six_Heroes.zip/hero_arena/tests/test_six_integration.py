"""Actual API, save migration, campaign creation and the complete skin catalog."""
import hashlib,json,math,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from collections import Counter
from app import app,service
from services.game_service import GameService
from models import HERO_CLASSES,Battle
from models.effects import Bleed
from models.heroes_55 import TwoHitShield
from models.rituals_55 import intersections
from models.ai import threat

KEYS=('keltazar','feliss','cyclops','mersey','leon','getou')
GAME=Path(__file__).resolve().parents[1]


class SixIntegration(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.saved=dict(service.__dict__)
        service.__dict__.clear();service.__dict__.update(GameService(str(Path(self.temp.name)/'save.json')).__dict__)
        self.client=app.test_client()
    def tearDown(self):
        service.__dict__.clear();service.__dict__.update(self.saved);self.temp.cleanup()
    def prepared(self,actor_key='warrior',enemy_key='getou'):
        a=HERO_CLASSES[actor_key]('A');b=HERO_CLASSES[enemy_key]('B');battle=Battle(a,b,mode='manual');battle.start()
        battle.current=a;battle._order=[a,b];battle._index=0
        if not a.turn_number:a.start_turn()
        service._heroes[a.id]=a;service._heroes[b.id]=b;service._battles[battle.id]=battle
        return a,b,battle
    def test_api_targets_only_the_selected_enemy_minion(self):
        a,g,b=self.prepared();g.raise_minion('zombie',0);pet=g.minions[0]
        owner_hp=g.hp;pet_hp=pet.hp
        with patch('models.rng._random.random',return_value=0):
            result=self.client.post(f'/api/battles/{b.id}/turn',json={'skill':'attack','target_id':pet.id})
        self.assertEqual(result.status_code,200,result.get_json());self.assertEqual(g.hp,owner_hp);self.assertLess(pet.hp,pet_hp)
        final=result.get_json()['heroes'][1]['summons'][0]
        self.assertEqual(final['id'],pet.id);self.assertEqual(final['hp'],pet.hp)
    def test_api_invalid_target_rejected_before_cost_and_cooldown(self):
        a,g,b=self.prepared();before=a.energy
        result=self.client.post(f'/api/battles/{b.id}/turn',json={'skill':'heavy_strike','target_id':'s999_0'})
        self.assertEqual(result.status_code,400);self.assertEqual(a.energy,before);self.assertEqual(a.cooldown_left('heavy_strike'),0)
    def test_api_second_summon_works_and_third_is_rejected(self):
        g,t,b=self.prepared('getou','paladin');g.raise_minion('skeleton',0)
        result=self.client.post(f'/api/battles/{b.id}/turn',json={'skill':'raise_zombie'})
        self.assertEqual(result.status_code,200,result.get_json());data=result.get_json();o=data['pending']['options']
        choice={'placements':[{'part':i,'slot':slot} for i,slot in enumerate(o['slots'])],'elapsed_ms':0}
        result=self.client.post(f'/api/battles/{b.id}/react',json={'choice':choice})
        self.assertEqual(result.status_code,200,result.get_json());self.assertEqual(len(g.living_minions()),2)
        # Advance actual opponent turns until the necromancer can act again.
        while b.current is not g:
            self.assertEqual(self.client.post(f'/api/battles/{b.id}/turn',json={'skill':'attack'}).status_code,200)
        before=g.energy
        result=self.client.post(f'/api/battles/{b.id}/turn',json={'skill':'build_homunculus'})
        self.assertEqual(result.status_code,400);self.assertEqual(g.energy,before)
    def test_api_dismiss_consumes_turn_without_death_rewards(self):
        g,t,b=self.prepared('getou','paladin');g.raise_minion('skeleton',1);g.spend_energy(40);before=g.energy
        result=self.client.post(f'/api/battles/{b.id}/turn',json={'skill':'dismiss:0'})
        self.assertEqual(result.status_code,200,result.get_json());self.assertFalse(g.living_minions());self.assertEqual(g.energy,before)
        self.assertFalse(getattr(t,'_necro_bombs',[]));self.assertIs(b.current,t)
    def test_all_six_create_buy_equip_save_load_and_start_campaign(self):
        saved=[]
        for key in KEYS:
            p=service.create_player({'username':'player_'+key,'password':'testing550','gold':100000})
            a=service.create_hero({'type':key,'name':'Arena '+key,'player_id':p.id})
            s=service.create_hero({'type':key,'name':'Story '+key,'player_id':p.id,'story':True})
            service.shop_buy(a.id,{'item':'skin:astral','player_id':p.id});a.equip_skin('astral')
            a.wins=4;s.set_level(7);s.experience=11;s.story_flags['intro_seen']=True
            saved.append((key,a.id,s.id,p.id))
        service.save();service.load()
        for key,aid,sid,pid in saved:
            a=service.get_hero(aid);s=service.get_hero(sid)
            self.assertEqual(a.type_key,key);self.assertEqual(a.skin,'astral');self.assertIn('astral',a.skins)
            self.assertEqual(a.level,1);self.assertEqual(a.wins,4);self.assertEqual(s.level,7);self.assertEqual(s.experience,11)
            self.assertTrue(s.story_flags['intro_seen']);self.assertTrue(service.get_player(pid).owns_skin(key,'astral'))
            b=service.story_battle(sid,{'location':'slums','mode':'manual'})
            self.assertTrue(b.story);self.assertFalse(getattr(s,'_arena',False));b.cancel()
    def test_skin_counts_dimensions_uniqueness_and_names(self):
        from PIL import Image
        hashes=[]
        expected={'common':8,'rare':6,'epic':6,'legendary':5,'mythic':2}
        for key in KEYS:
            catalog=GameService.skin_catalog(key)
            self.assertEqual(Counter(s['rarity'] for s in catalog),expected)
            self.assertTrue(all(s['available'] and not s.get('coming_soon') for s in catalog))
            self.assertEqual(len({s['skin'] for s in catalog}),27)
            for s in catalog:
                p=GAME/s['image'].lstrip('/')
                with Image.open(p) as image:self.assertEqual(image.size,(512,512))
                hashes.append(hashlib.sha256(p.read_bytes()).hexdigest())
            with Image.open(GAME/'static/images'/f'{key}.jpg') as image:self.assertEqual(image.size,(512,512))
        self.assertEqual(len(set(hashes)),162)
    def test_poisoned_bomber_death_still_triggers_bomb_and_soul(self):
        g,t,b=self.prepared('getou','warrior');g.raise_minion('skeleton',1);pet=g.minions[0];pet.hp=1;g.spend_energy(40);before=g.energy
        pet.add_effect(Bleed(2,5));pet.act(t)
        self.assertFalse(pet.is_alive());self.assertEqual(g.energy,before+8);self.assertTrue(getattr(t,'_necro_bombs',[]))
    def test_keltazar_dot_is_amplified_but_hp_price_is_not(self):
        h=HERO_CLASSES['keltazar']('A');before=h.hp;Bleed(2,10).on_turn_start(h)
        self.assertEqual(before-h.hp,12)
        h.hp=100;h.skills['blood_feast'].pay(h);self.assertEqual(h.hp,85)
    def test_campaign_minion_damage_scales_once_and_follows_equipment(self):
        g=HERO_CLASSES['getou']('Story',level=9);g.story=True;g.raise_minion('homunculus',0)
        self.assertEqual(g.minions[0].get_damage(),round(7*g.power_scale()))
    def test_necromancer_threat_comes_from_living_army(self):
        g,t,b=self.prepared('getou','paladin');self.assertEqual(threat(g,t),0)
        g.raise_minion('skeleton',0);self.assertGreater(threat(g,t),0)
    def test_collinear_thread_overlap_is_not_a_solution(self):
        nodes=[[30+i*40,130] for i in range(8)];edges=[[i,(i+1)%8] for i in range(8)]
        self.assertGreater(intersections(nodes,edges),0)
    def test_necromancers_cannot_target_their_own_army_as_enemy(self):
        a,b,fight=self.prepared('getou','getou');a.raise_minion('zombie',0);b.raise_minion('skeleton',0)
        self.assertIs(fight._selected_target(a,b.minions[0].id,False),b.minions[0])
        with self.assertRaises(ValueError):fight._selected_target(a,a.minions[0].id,False)


if __name__=='__main__':unittest.main()
