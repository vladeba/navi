// Real Chromium component regression: render the production handlers with
// real hero data and representative historical HP snapshots.
const {chromium}=require('playwright');
const assert=require('assert/strict');
const fs=require('fs');
const output=process.env.HERO_TEST_OUTPUT||require('path').join(__dirname,'..','test-results');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 try{
  const page=await browser.newPage({viewport:{width:1280,height:900}});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(process.env.HERO_ARENA_URL||'http://127.0.0.1:5054/',{waitUntil:'networkidle'});
  await page.evaluate(()=>skipWelcome());
  const version=await page.evaluate(async()=>({api:await api('/api'),title:document.title,logo:document.getElementById('logo').textContent,tooltip:document.getElementById('logo').title}));
  assert.equal(version.api.version,'5.4.1');
  assert.equal(version.title,version.api.name);
  assert.equal(version.logo,'⚔ '+version.api.name);
  assert.equal(version.tooltip,version.api.name);
  await page.locator('nav [data-tab="battle"]').click();
  await page.waitForTimeout(100);
  const cases=await page.evaluate(async()=>{
    const all=await api('/api/heroes');
    const rider={...all.find(h=>h.type==='beastlord'),hp:2,kodo_alive:false,kodo_hp:0,rider_hp:2};
    rider.hp_bars=rider.hp_bars.map((bar,i)=>({...bar,hp:i?2:0}));
    const other=all.find(h=>h.type==='warrior');
    const b={id:-1,kind:'arena',heroes:[rider,other],ai_ids:[],current_hero_id:rider.id,round:1,status:'active'};
    battle=b;shownHp={};mountPanel('arena');
    document.getElementById('arenaPanel').style.display='block';
    const style=document.createElement('style');
    style.textContent='#arenaPanel *{transition:none!important;animation:none!important}';document.head.appendChild(style);
    renderFighters(b);
    const rows=[];
    for(const total of [300,250,100,75,2,0]){
      applyHp({[rider.id]:total,[other.id]:100},false);
      const bar=document.querySelector('#f0 .hpbar-split'),track=bar.querySelector('.hp-seg-track');
      const k=bar.querySelector('.hp-seg.kodo'),r=bar.querySelector('.hp-seg.rider');
      rows.push({total,label:bar.querySelector('span').textContent,width:bar.getBoundingClientRect().width,
        height:bar.getBoundingClientRect().height,track:track.getBoundingClientRect().width,
        background:getComputedStyle(track).backgroundImage,kodo:k.getBoundingClientRect().width,
        rider:r.getBoundingClientRect().width,riderOffset:r.getBoundingClientRect().left-track.getBoundingClientRect().left,
        legacyLabel:document.querySelector('#f1 .hpbar>span').textContent});
    }
    applyHp({[rider.id]:2},false);
    return rows;
  });
  for(const c of cases){
    const k=Math.max(0,c.total-100),r=Math.min(100,c.total);
    assert.equal(c.background,'none','no bright full-track gradient');
    assert.equal(c.height,20,'centered bar retains its intended height');
    assert(Math.abs(c.track-c.width)<1,'track never shrinks with the total HP');
    assert(Math.abs(c.kodo/c.width-k/300)<0.002,'mount fill reflects historical snapshot');
    assert(Math.abs(c.rider/c.width-r/300)<0.002,'rider fill reflects historical snapshot');
    assert(Math.abs(c.riderOffset/c.width-2/3)<0.002,'rider stays in its own zone when mount loses HP');
    assert(c.label.includes(`Кодой ${k}/200`)&&c.label.includes(`Наездник ${r}/100`),'historical labels ignore final dead-mount flag');
    assert(c.legacyLabel.startsWith('❤ 100/'),'ordinary HP bars still update');
  }
  fs.mkdirSync(output+'/screenshots',{recursive:true});
  await page.locator('#arenaPanel').scrollIntoViewIfNeeded();
  await page.screenshot({path:output+'/screenshots/fixed-hp-two.png'});
  const widths=[];
  for(const width of [1280,900,760,390]){
    await page.setViewportSize({width,height:900});
    await page.waitForTimeout(350);
    widths.push(await page.evaluate(()=>{const b=document.querySelector('#f0 .hpbar-split'),s=b.querySelector('span'),r=b.querySelector('.hp-seg.rider');return{width:innerWidth,bar:b.getBoundingClientRect().width,fill:r.getBoundingClientRect().width,center:getComputedStyle(s).alignItems,text:s.textContent}}));
  }
  for(const w of widths){assert.equal(w.center,'center');assert(Math.abs(w.fill/w.bar-2/300)<0.002)}
  const art=await page.request.get((process.env.HERO_ARENA_URL||'http://127.0.0.1:5054')+'/static/images/skins/catfolk_celestial_cat_cat.jpg');
  assert.equal(art.status(),200);assert(art.headers()['content-type'].includes('image/jpeg'));
  assert.deepEqual(errors,[]);
  const result={version,cases,widths,artStatus:art.status(),errors};
  fs.writeFileSync(output+'/ui_regression_result.json',JSON.stringify(result,null,2));
  console.log('PASS: shared API/UI version; 6 split-HP states incl historical mount death; fixed independent segments; normal bars; 4 viewport widths; mythic art served; no page errors.');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
