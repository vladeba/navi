"""Split-health regression coverage using real models and the Flask reaction path."""
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import app, service
from models import Battle, HERO_CLASSES, hp_journal
from models.effects import Antiheal, Shield
from services import GameService


class BeastLordHealthTests(unittest.TestCase):
    def setUp(self):
        self.hero = HERO_CLASSES["beastlord"]("HP regression")
        hp_journal.journal().clear()
        self.old_save = service.save_path
        self.temporary = TemporaryDirectory()
        service.save_path = str(Path(self.temporary.name) / "save.json")
        self.addCleanup(self.temporary.cleanup)
        self.addCleanup(setattr, service, "save_path", self.old_save)

    def assert_split(self, hero, total, kodo, rider):
        self.assertEqual(hero.hp, total)
        self.assertEqual(hero.kodo_hp, kodo)
        self.assertEqual(hero.rider_hp, rider)
        self.assertEqual(hero.hp, hero.kodo_hp + hero.rider_hp)
        self.assertEqual(hero.kodo_alive, kodo > 0)

    def hero_journal(self):
        return [value for key, value in hp_journal.journal() if key == str(self.hero.id)]

    def test_constructor_and_level_rounding_preserve_total(self):
        for level in range(1, 26):
            with self.subTest(level=level):
                hero = HERO_CLASSES["beastlord"]("Level regression", level=level)
                self.assert_split(hero, hero.max_hp, hero.kodo_max, hero.rider_max)
        self.hero.hp = 50
        self.hero.set_level(2)
        self.assert_split(self.hero, 307, 205, 102)

    def test_one_damage_assignment_creates_one_final_snapshot(self):
        self.assertEqual(self.hero.take_damage(19, ignore_armor=True), 19)
        self.assert_split(self.hero, 281, 181, 100)
        self.assertEqual(self.hero_journal(), [281])
        self.hero.take_damage(19, ignore_armor=True)
        self.assert_split(self.hero, 262, 162, 100)
        self.assertEqual(self.hero_journal(), [281, 262])

    def test_mount_death_spills_damage_and_announces_once(self):
        self.hero.take_damage(215, ignore_armor=True)
        self.assert_split(self.hero, 85, 0, 85)
        self.assertFalse(self.hero.skill_unlocked(self.hero.skills["kodo_charge"]))
        self.assertEqual(sum("Кодой" in str(x) and "пал" in str(x) for x in self.hero.pop_events()), 1)
        self.hero.take_damage(5, ignore_armor=True)
        self.assert_split(self.hero, 80, 0, 80)
        self.assertEqual(self.hero.pop_events(), [])
        self.assertEqual(self.hero_journal(), [85, 80])

    def test_armor_and_shield_are_applied_before_split_damage(self):
        self.assertEqual(self.hero.armor_total(), 2)
        self.hero.add_effect(Shield(3, 10))
        self.assertEqual(self.hero.take_damage(30), 18)
        self.assert_split(self.hero, 282, 182, 100)
        self.assertEqual(self.hero_journal(), [282])
        self.assertIn("поглощает 10", " ".join(map(str, self.hero.pop_events())))

    def test_healing_respects_antiheal_and_fatigue(self):
        self.hero.take_damage(100, ignore_armor=True)
        self.hero.add_effect(Antiheal(2))
        self.assertEqual(self.hero.heal(60), 0)
        self.assert_split(self.hero, 200, 100, 100)
        self.hero._effects.clear()
        self.hero.fatigue = 0.5
        self.assertEqual(self.hero.heal(60), 30)
        self.assert_split(self.hero, 230, 130, 100)

    def test_heal_cannot_resurrect_mount_or_overfill_rider(self):
        self.hero.take_damage(250, ignore_armor=True)
        self.assertEqual(self.hero.heal(1000), 50)
        self.assert_split(self.hero, 100, 0, 100)
        self.assertEqual(self.hero.heal(10), 0)
        self.assertFalse(self.hero.skill_unlocked(self.hero.skills["kodo_guard"]))

    def test_direct_hp_changes_and_monk_reflection_keep_pools_in_sync(self):
        monk = HERO_CLASSES["monk"]("Reflection target")
        monk.take_damage(50, ignore_armor=True, attacker=self.hero)
        self.assert_split(self.hero, 295, 195, 100)
        self.assertEqual(self.hero_journal(), [295])
        self.hero.take_damage(10, ignore_armor=True)
        self.assert_split(self.hero, 285, 185, 100)
        self.hero.hp -= 200
        self.assert_split(self.hero, 85, 0, 85)
        self.hero.take_damage(5, ignore_armor=True)
        self.assert_split(self.hero, 80, 0, 80)
        self.assertEqual(self.hero_journal(), [295, 285, 85, 80])

    def test_reset_restores_full_coherent_mount(self):
        self.hero.hp = 20
        self.hero.add_effect(Antiheal(2))
        self.hero.reset()
        self.assert_split(self.hero, 300, 200, 100)
        self.assertEqual(self.hero._effects, [])
        self.assertEqual(self.hero.pop_events(), [])

    def test_save_load_retains_existing_fresh_battle_health_contract(self):
        # Saves persist progression/gear, not combat HP. Loading is expected
        # to construct a healed hero, not silently invent combat persistence.
        with TemporaryDirectory() as folder:
            game = GameService(save_path=str(Path(folder) / "save.json"))
            hero = HERO_CLASSES["beastlord"]("Save regression", level=2)
            game._heroes[hero.id] = hero
            hero.hp = 40
            self.assert_split(hero, 40, 0, 40)
            game.save()
            game.load()
            restored = game.get_hero(hero.id)
            self.assert_split(restored, 307, 205, 102)
            self.assertEqual(restored.level, 2)

    def test_real_flask_multi_hit_and_bleed_snapshots_only_decrease(self):
        client = app.test_client()
        troll = HERO_CLASSES["bluetroll"]("HP Flask troll")
        battle = Battle(troll, self.hero, mode="manual")
        service._battles[battle.id] = battle
        self.addCleanup(service._battles.pop, battle.id, None)
        battle.start()
        while battle.current is not troll:
            battle.play_turn("attack")
        battle.play_turn("catch_return")
        self.assertEqual(battle.pending["skill"].key, "catch_return")
        with patch("random.random", return_value=0.99):
            response = client.post(f"/api/battles/{battle.id}/react", json={"choice": {"errors": [0, 0]}})
        self.assertEqual(response.status_code, 200)
        entries = response.get_json()["log"]
        attacks = [entry for entry in entries if entry["kind"] == "attack" and entry["text"].startswith("✋")]
        self.assertEqual(len(attacks), 2)
        values = [entry["hp_after"][str(self.hero.id)] for entry in entries]
        self.assertEqual(values, sorted(values, reverse=True))
        self.assertLess(attacks[1]["hp_after"][str(self.hero.id)], attacks[0]["hp_after"][str(self.hero.id)])
        self.assertEqual(values[-1], self.hero.hp)
        self.assertEqual(self.hero.hp, self.hero.kodo_hp + self.hero.rider_hp)


if __name__ == "__main__":
    unittest.main()
