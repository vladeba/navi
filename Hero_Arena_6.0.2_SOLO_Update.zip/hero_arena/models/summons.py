"""Призванные существа: базовый Summon и звери друида / водяной дух мага.

Существо сражается рядом с хозяином: после хода хозяина атакует врага,
а часть вражеских ударов может принять на себя (intercept_chance).
Его можно убить — тогда друид может призвать нового зверя после перезарядки.
"""
import random

from models import hp_journal

from .effects import Stun, Poison


class Summon:
    """Базовое призванное существо."""

    name = "Существо"
    icon = "🐾"
    about = ""
    weight = 1   # вес при случайном выборе зверя
    ARMOR_PIERCE = 0.0   # 4.4: хук — доля брони цели, которую игнорируют удары существа (выключено)

    def __init__(self, owner, max_hp, damage, armor=0, dodge=0.0, intercept_chance=0.2):
        self.owner = owner
        self.max_hp = max_hp
        self.__hp = max_hp               # приватный, как у героев
        self.damage = damage
        self.armor = armor
        self.dodge = dodge
        self.intercept_chance = intercept_chance   # шанс принять удар вместо хозяина
        self.crit_chance = 0.05
        self.crit_multiplier = 1.5
        self.lifetime = None             # 4.0: сколько ходов живёт (None — пока не убьют)
        self.accuracy = 0.9

    def scale_to(self, owner):
        """4.0: звери растут с уровнем хозяина."""
        k = owner.power_scale() if hasattr(owner, "power_scale") else 1.0
        if k != 1.0:
            self.max_hp = int(self.max_hp * k)
            self.hp = self.max_hp
            self.damage = max(1, int(round(self.damage * k)))
        return self

    def tick_life(self):
        """Уменьшить срок жизни. True — существо исчезло."""
        if self.lifetime is None:
            return False
        self.lifetime -= 1
        if self.lifetime <= 0:
            self.hp = 0
            return True
        return False

    # --- то же «лицо», что у героя, чтобы умения могли бить по зверю (полиморфизм) ---
    @property
    def hp(self):
        return self.__hp

    @hp.setter
    def hp(self, value):
        alive=self.__hp>0
        self.__hp = max(0, min(int(value), self.max_hp))
        if alive and self.__hp==0 and hasattr(self.owner,"on_summon_death"):self.owner.on_summon_death(self)
        hp_journal.record(f"s{self.owner.id}", self.__hp)

    def is_alive(self):
        return self.__hp > 0

    def get_dodge(self):
        return self.dodge

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        dmg = max(1, int(amount if ignore_armor else amount - self.armor))
        self.hp = self.__hp - dmg
        return dmg

    def death_note(self):
        return f" {self.icon} {self.name} принимает удар на себя" + (" и погибает!" if not self.is_alive() else ".")

    def pop_events(self):
        return []

    # --- поведение, которое переопределяют звери ---
    def attack(self, target):
        """Атака существа по вражескому герою. Возвращает список строк лога."""
        if random.random() > max(0.1, self.accuracy - target.get_dodge()):
            return [f"{self.icon} {self.name} промахивается по {target.name}."]
        raw = self.damage * self.boost_mult() * random.uniform(0.9, 1.1)
        if self.ARMOR_PIERCE and hasattr(target, "armor_total"):
            raw += target.armor_total() * self.ARMOR_PIERCE   # 4.4: клыки и когти частично обходят броню
        dmg = target.take_damage(int(raw), attacker=None)
        return [f"{self.icon} {self.name} атакует {target.name}: {dmg} урона."] + target.pop_events()

    def describe(self):
        return f"{self.icon} {self.name}: HP {self.hp}/{self.max_hp}, урон {self.damage}"

    # ----- 4.2: временное усиление («Зов леса» друида) -----
    def boost(self, percent, turns):
        self._boost, self._boost_turns = percent, turns

    def boost_mult(self):
        """4.3: множитель усиления; не тратится на удары (раньше «3 хода» сгорали за 3 попадания)."""
        if getattr(self, "_boost_turns", 0) <= 0:
            return 1.0
        return 1 + getattr(self, "_boost", 0) / 100

    def tick_boost(self):
        """4.3: один ход хозяина прошёл — усиление «Зова леса» на ход короче."""
        if getattr(self, "_boost_turns", 0) > 0:
            self._boost_turns -= 1

    def to_dict(self):
        return {"type": self.__class__.__name__, "name": self.name, "icon": self.icon,
                "hp": self.hp, "max_hp": self.max_hp, "damage": self.damage, "armor": self.armor,
                "dodge": self.dodge, "intercept_chance": self.intercept_chance, "lifetime": self.lifetime,
                "alive": self.is_alive(), "about": self.about}


class Bear(Summon):
    name, icon, weight = "Медведь", "🐻", 15
    about = "крепкий и сильный, иногда оглушает"

    def __init__(self, owner):  # 4.0: ослаблен — HP 110→85, урон 11→8, оглушение 20%→8%
        super().__init__(owner, max_hp=105 if getattr(owner,"type_key",None)=="druid" and not getattr(owner,"mob",False) else 85, damage=8, armor=2, intercept_chance=0.3)

    def attack(self, target):  # переопределение: 8% оглушить
        logs = super().attack(target)
        if "урона" in logs[0] and random.random() < 0.08 and target.add_effect(Stun(1)):
            logs.append(f"💫 Медведь оглушает {target.name}!")
        return logs


class Falcon(Summon):
    name, icon, weight = "Сокол", "🦅", 22
    about = "быстрый, бьёт дважды и уклоняется"

    def __init__(self, owner):  # 4.0: усилен — урон 5→6, HP 55→60
        super().__init__(owner, max_hp=70, damage=8, dodge=0.4, intercept_chance=0.1)

    def attack(self, target):  # переопределение: два удара клювом
        return super().attack(target) + super().attack(target)


class Snake(Summon):
    name, icon, weight = "Змея", "🐍", 20
    about = "кусает и отравляет"

    def __init__(self, owner):
        super().__init__(owner, max_hp=60, damage=6, dodge=0.15, intercept_chance=0.15)

    def attack(self, target):  # переопределение: яд при укусе
        logs = super().attack(target)
        if "урона" in logs[0] and not target.has_effect(Poison):
            target.add_effect(Poison(3, 2))
            logs.append(f"☠ Змея отравила {target.name}!")
        return logs


class Hamster(Summon):
    name, icon, weight = "Хомяк", "🐹", 25
    about = "маленький, но храбрый: отвлекает удары на себя, пока жив — друид +15% уклонения"
    OWNER_DODGE = 0.15  # 4.4: пока хомяк жив, хозяин уклоняется лучше

    def __init__(self, owner):  # 4.3: HP 100→75, перехват 30%; 4.4: HP 75→40 (самый хилый зверь), +15% уклонения друиду
        super().__init__(owner, max_hp=40, damage=7, intercept_chance=0.30)

    def describe(self):  # переопределение
        return super().describe() + " (очень храбрый)"


class WaterSpirit(Summon):
    name, icon = "Водяной дух", "💧"
    about = "бьёт сквозь броню, живёт 5 ходов"

    def __init__(self, owner):  # 4.0: живёт 5 ходов и больше не лечит
        super().__init__(owner, max_hp=60, damage=6, dodge=0.2, intercept_chance=0.15)
        self.lifetime = 5

    def attack(self, target):  # переопределение: волна сквозь броню
        dmg = target.take_damage(int(self.damage * random.uniform(0.9, 1.1)), ignore_armor=True)
        return [f"💧 Водяной дух окатывает {target.name}: {dmg} урона."] + target.pop_events()


class Deer(Summon):
    """4.0: Олень друида — бодает и каждый ход немного лечит хозяина."""

    name, icon, weight = "Олень", "🦌", 18
    about = "бодает рогами и лечит друида на 3 HP в ход"

    def __init__(self, owner):
        super().__init__(owner, max_hp=60, damage=6, armor=1, dodge=0.1, intercept_chance=0.2)

    def attack(self, target):  # переопределение: удар рогами + лечение хозяина
        logs = super().attack(target)
        healed = self.owner.heal(3)
        if healed:
            logs.append(f"🦌 Олень делится силой леса: {self.owner.name} +{healed} HP.")
        return logs


class Clone(Summon):
    """4.0: Клон ассасина — отвлекает удары и бьёт сам, живёт 4 хода."""

    name, icon = "Клон", "👥"
    about = "двойник ассасина: принимает удары на себя, живёт 4 хода"

    def __init__(self, owner):
        super().__init__(owner, max_hp=40, damage=5, dodge=0.2, intercept_chance=0.35)
        self.lifetime = 4


class SkeletonSquad(Summon):
    """4.0: «Призыв Плети» Мордреда — ДВА скелета, у каждого свои 30 HP, урон 4, точность 70%.
    Отряд хранит HP обоих: пока жив первый, удары идут в него, затем во второго. Живут 4 хода."""

    name, icon = "Скелеты Плети", "💀"
    about = "два скелета (по 38 HP, урон 4, броня 1, точность 70%), живут 4 хода"
    ONE_HP = 38  # 5.4: чуть живучее

    def __init__(self, owner):
        super().__init__(owner, max_hp=2 * self.ONE_HP, damage=4, armor=1, intercept_chance=0.28)  # 5.4
        self.accuracy = 0.7
        self.lifetime = 4

    def alive_count(self):
        return (self.hp + self.ONE_HP - 1) // self.ONE_HP

    def scale_to(self, owner):  # переопределение: у каждого скелета свои HP
        super().scale_to(owner)
        self.ONE_HP = self.max_hp // 2
        return self

    def attack(self, target):  # переопределение: бьёт каждый живой скелет
        logs = []
        for _ in range(self.alive_count()):
            logs.extend(super().attack(target))
        return logs

    def describe(self):
        return f"💀 Скелеты Плети: {self.alive_count()}/2, HP {self.hp}/{self.max_hp}"

    def to_dict(self):
        data = super().to_dict()
        data["alive_count"] = self.alive_count()
        return data


BEASTS = [Hamster, Falcon, Snake, Deer, Bear]


def random_beast(owner):
    """Случайный зверь друида (4.0): Хомяк 25%, Сокол 22%, Змея 20%, Олень 18%, Медведь 15%."""

    if owner.type_key == 'druid' and not getattr(owner, 'mob', False):
        seen = getattr(owner, '_beasts_seen', set())
        weights = [w * (0.25 if b.__name__ in seen else 1) for b,w in zip(BEASTS,[25,23,22,18,12])]
        cls = random.choices(BEASTS, weights=weights)[0]
        owner._beasts_seen = seen | {cls.__name__}
    else:
        cls = random.choices(BEASTS, weights=[b.weight for b in BEASTS])[0]
    return cls(owner)


# ======================= 4.2 =======================
class OwlNephews(SkeletonSquad):
    """«Племянники Совуха»: 1–2 мини-совуха (по 40 HP, урон 6, точность 80%) на 4 хода
    или слабый совёнок (25 HP, урон 4) на 2 хода."""

    name, icon = "Мини-совухи", "🦉"
    about = "племянники Совуха помогают в бою"

    def __init__(self, owner, count=2, weak=False):
        one = 25 if weak else 40
        Summon.__init__(self, owner, max_hp=count * one, damage=4 if weak else 6, armor=0, intercept_chance=0.25)
        self.ONE_HP, self.COUNT = one, count
        self.accuracy = 0.8
        self.lifetime = 2 if weak else 4
        if weak:
            self.name = "Слабый совёнок"
        elif count == 1:
            self.name = "Мини-совух"

    def scale_to(self, owner):
        Summon.scale_to(self, owner)
        self.ONE_HP = max(1, self.max_hp // self.COUNT)
        return self

    def describe(self):
        return f"🦉 {self.name}: {self.alive_count()}/{self.COUNT}, HP {self.hp}/{self.max_hp}, урон {self.damage}"

    def to_dict(self):
        data = super().to_dict()
        data["count"] = self.COUNT
        return data


class Decoy(Summon):
    """«Подмена» Газ-Лоу: двойник 30 HP, 35% перехватить удар, живёт 3 хода, при гибели взрывается на 8."""

    name, icon = "Двойник Газ-Лоу", "👥"
    about = "перехватывает удары (35%), при гибели взрывается на 8 урона"

    def __init__(self, owner):
        super().__init__(owner, max_hp=30, damage=3, intercept_chance=0.35)
        self.lifetime = 3
        self._boom = ""

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        dmg = super().take_damage(amount, ignore_armor, attacker)
        if not self.is_alive() and attacker is not None and not self._boom:
            boom = max(1, int(8 * (self.owner.power_scale() if hasattr(self.owner, "power_scale") else 1)))
            attacker.hp = attacker.hp - boom
            self._boom = f" 💥 Двойник взрывается: {attacker.name} получает {boom} урона!"
        return dmg

    def death_note(self):
        return super().death_note() + self._boom


class ForestSpirit(Summon):
    """«Лесной дух» Шибэка: HP 15–60, урон 0–6 в зависимости от сборки."""

    name, icon = "Лесной дух", "🌳"
    about = "дух леса, собранный из осколков"

    def __init__(self, owner, hp=60, damage=6):
        super().__init__(owner, max_hp=hp, damage=damage, intercept_chance=0.3 if damage else 0.45)
        self.lifetime = 5

    def attack(self, target):
        if self.damage <= 0:
            return [f"🌳 {self.name} кружит вокруг {target.name}, отвлекая его."]
        return super().attack(target)


# ======================= 5.4.1 Трейфус =======================
class BeastCompanion(Summon):
    """Зверь-спутник Трейфуса: волк / кабан / ястреб на несколько ходов.
    Пешком (кодой пал) — сильнее и живучее."""

    KINDS = {
        "wolf": ("Волк стаи", "🐺", "рвёт плоть рядом с наездником"),
        "boar": ("Боевой кабан", "🐗", "таран и толчок — перехват ударов"),
        "hawk": ("Боевой ястреб", "🦅", "бьёт с воздуха, высокий уклон"),
    }

    def __init__(self, owner, kind=None, empowered=False):
        import random as _r
        kind = kind or _r.choice(list(self.KINDS))
        self.kind = kind
        self.empowered = bool(empowered)
        name, icon, about = self.KINDS[kind]
        self.name, self.icon, self.about = name, icon, about
        if empowered:
            self.name = name + " (ярость)"
            self.about = about + " · усилен после гибели кодоя"
        # mounted vs dismounted stats
        if kind == "wolf":
            hp, dmg, dodge, intercept, life = (34, 5, 0.10, 0.18, 3)
        elif kind == "boar":
            hp, dmg, dodge, intercept, life = (44, 5, 0.04, 0.30, 3)
        else:  # hawk
            hp, dmg, dodge, intercept, life = (26, 6, 0.22, 0.10, 3)
        if empowered:
            hp = int(hp * 1.25)
            dmg = int(dmg * 1.20)
            intercept = min(0.45, intercept + 0.08)
            life += 1
        Summon.__init__(self, owner, max_hp=hp, damage=dmg, armor=1 if kind == "boar" else 0,
                        dodge=dodge, intercept_chance=intercept)
        self.accuracy = 0.82 if kind != "hawk" else 0.88
        self.lifetime = life

    def describe(self):
        tag = " · ярость" if self.empowered else ""
        return f"{self.icon} {self.name}{tag}: HP {self.hp}/{self.max_hp}, урон {self.damage}, ещё {self.lifetime} х."

    def to_dict(self):
        data = super().to_dict()
        data["kind"] = self.kind
        data["empowered"] = self.empowered
        return data
