"""4.2: общие «движки» новых мини-игр и мини-игры старых героев (друид, маг, Конан, Совух).

Новые типы интерфейса (static/v42.js): click_good_bad, order_click, timing_multi, dodge_pick, cups, arrows_seq.
Старые типы используются повторно: click_targets, memory, hold_zone, timing_ring, moving_target.
"""
import random
import time

from .effects import Announcement, Bleed, Stun, Slow, Shield
from .effects_42 import Distracted, Guard
from .skills import MiniGameSkill, DamageSkill, scale_effect


class CountGame(MiniGameSkill):
    """Мини-игра «сколько из N»: ответ {"hits": k}. BANDS — минимальные k для ступеней (от лучшей к худшей)."""

    COUNT_FIELD = "hits"
    MAX = 4
    BANDS = (4, 3, 2, 0)

    def tier_from(self, choice, options):
        k = choice.get(self.COUNT_FIELD, 0) if isinstance(choice, dict) else choice
        try:
            k = int(k)
        except (TypeError, ValueError):
            k = 0
        k = max(0, min(self.MAX, k))
        for i, low in enumerate(self.BANDS):
            if k >= low:
                return i
        return len(self.BANDS) - 1


class TargetGame(MiniGameSkill):
    """4.2: мини-игра, которую играет СОПЕРНИК (цель): «Куда увернуться?», «Столп света»…
    Ступень 0 — лучший исход для цели. ИИ-цель играет по TARGET_WEIGHTS, «идеальная» цель — всегда ступень 0."""

    reactor = "target"
    TARGET_WEIGHTS = (50, 50)

    def ai_tier(self, user, target):
        if getattr(target, "perfect", False):
            return 0
        return random.choices(range(len(self.TIERS)), weights=self.TARGET_WEIGHTS)[0]


# ======================= Друид: «Зов леса» =======================
class ForestCallSkill(CountGame):
    """«Зов леса» друида: за 5 с ловите светящихся лесных духов (10 штук).
    8+ — +20% HP и зверь +30% урона на 3 хода; 5–7 — +12% и +15%; 2–4 — +6%; 0–1 — +2%."""

    game, prompt = "click_targets", "Ловите светящихся лесных духов!"
    MG_ICON = "✨"
    MG_ACCENT = "#7ec8ff"
    TIME_LIMIT_MS = 5000
    MAX, BANDS = 10, (8, 5, 2, 0)
    TIERS = ("8+ духов", "5–7", "2–4", "0–1")
    AI_WEIGHTS = (25, 40, 25, 10)
    HEAL = (0.20, 0.12, 0.06, 0.02)
    BEAST = (30, 15, 0, 0)

    def game_params(self, user, target):
        return {"count": self.MAX, "icon": "✨", "spawn_ms": self.TIME_LIMIT_MS // (self.MAX + 1)}

    def apply(self, user, target, tier, data):
        healed = user.heal(int(user.max_hp * self.HEAL[tier]))
        logs = [f"🌲 {user.name} — «Зов леса» ({self.TIERS[tier]}): +{healed} HP."]
        if self.BEAST[tier] and user.summon and user.summon.is_alive():
            user.summon.boost(self.BEAST[tier], 3)
            logs.append(Announcement(f"🌲 Духи леса усиливают {user.summon.name}: +{self.BEAST[tier]}% урона на 3 хода!"))
        return logs

    def ai_score(self, user, target):
        from .ai import healing,horizon,tier_average
        pet=user.summon if user.summon and user.summon.is_alive() else None
        values=[]
        for heal,boost in zip(self.HEAL,self.BEAST):
            bonus=0
            if pet:
                incoming=max(1,pet.damage-target.armor_total())*max(.1,pet.accuracy-target.get_dodge())
                bonus=incoming*boost/100*horizon(user,target,3)
            values.append(healing(user,user.max_hp*heal)+bonus)
        return tier_average(self,user,values)


# ======================= Маг: «Руническая печать» =======================
# Public name retained for existing imports; the memory game has been replaced.
from .mage_skills import RuneWeaveSkill as RuneSealSkill


# ======================= Конан: «Парирование» =======================
class ParrySkill(CountGame):
    """«Парирование» Конана: враг делает 4 замаха — жмите ту же стрелку вовремя.
    4/4 — ответ ×2.2 и оглушение; 3 — ×1.6; 2 — ×1.0; 0–1 — ×0.5 и Конан теряет 5% HP."""

    game, prompt = "arrows_seq", "Повторяйте стрелку замаха — парируйте!"
    MG_ICON = "⚔"
    MG_ACCENT = "#c0c8d8"
    TIME_LIMIT_MS = 6000
    MAX, BANDS = 4, (4, 3, 2, 0)
    TIERS = ("4/4", "3/4", "2/4", "0–1/4")
    AI_WEIGHTS = (20, 35, 30, 15)
    TIER_VALUE = (2.2, 1.6, 1.0, 0.5)

    def game_params(self, user, target):
        dirs = ["up", "down", "left", "right"]
        return {"sequence": [random.choice(dirs) for _ in range(4)], "dirs": dirs, "window_ms": 900, "icon": "⚔"}

    def apply(self, user, target, tier, data):
        head = f"⚔ {user.name} — «Парирование» ({self.TIERS[tier]})!"
        logs = [Announcement(head) if tier == 0 else head]
        part, dmg = self.strike(user, target, self.TIER_VALUE[tier])
        logs += part
        if tier == 0 and dmg and target.is_alive() and target.add_effect(Stun(1)):
            logs.append(f"💫 {target.name} оглушён ответным ударом!")
        if tier == 3:
            loss = int(user.max_hp * 0.05)
            user.hp = user.hp - loss
            logs.append(f"🩸 {user.name} пропустил замахи: −{loss} HP.")
        return logs


# ======================= Совух: «Племянники Совуха», «Ночная охота» =======================
class NephewsSkill(CountGame):
    """«Племянники Совуха»: 6 совят мелькают по ~0.6 с — ловите кликом.
    5–6 — 2 мини-совуха (по 40 HP, урон 6, точность 80%) на 4 хода; 3–4 — 1 мини-совух; 1–2 — слабый совёнок
    (25 HP, 2 хода); 0 — никто не прилетел, −10% точности на 1 ход. С 3-го хода."""

    copyable = False
    game, prompt = "click_targets", "Ловите совят, пока они мелькают!"
    MG_ICON = "🦉"
    MG_ACCENT = "#c9a227"
    TIME_LIMIT_MS = 5000
    MAX, BANDS = 6, (5, 3, 1, 0)
    TIERS = ("5–6 совят", "3–4", "1–2", "0")
    AI_WEIGHTS = (25, 40, 25, 10)

    def game_params(self, user, target):
        return {"count": 6, "icon": "🦉", "spawn_ms": 600}

    def is_available(self, user):
        return super().is_available(user) and (user.summon is None or not user.summon.is_alive())

    def apply(self, user, target, tier, data):
        from .summons import OwlNephews
        if tier == 3:
            user.add_effect(Distracted(1, 10))
            return [f"🦉 Племянники не прилетели… {user.name} растерян: −10% точности на 1 ход."]
        user.summon = OwlNephews(user, count=(2, 1, 1)[tier], weak=tier == 2)
        user.summon.scale_to(user)
        s = user.summon
        return [Announcement(f"🦉 {user.name} зовёт племянников ({self.TIERS[tier]}): {s.describe()}!")]

    def ai_score(self, user, target):
        return 26


class NightHuntSkill(CountGame):
    """«Ночная охота» Совуха: экран темнеет, 3 раза мелькают глаза врага. Каждое попадание — удар ×0.9;
    3/3 — последний удар гарантированно критический и вызывает кровотечение."""

    copyable = False
    game, prompt = "click_targets", "Во тьме мелькают глаза врага — бейте!"
    MG_ICON = "👁"
    MG_ACCENT = "#a45cff"
    TIME_LIMIT_MS = 3600
    MAX, BANDS = 3, (3, 2, 1, 0)
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (25, 35, 28, 12)

    def game_params(self, user, target):
        return {"count": 3, "icon": "👁", "spawn_ms": 1000, "dark": True}

    def expected_value(self):
        return sum(w * (3 - i) * 0.9 for i, w in enumerate(self.AI_WEIGHTS)) / sum(self.AI_WEIGHTS) * 1.1

    def apply(self, user, target, tier, data):
        hits = 3 - tier
        logs = [f"🌙 {user.name} — «Ночная охота»: {hits}/3."]
        for i in range(hits):
            if not target.is_alive():
                break
            last_perfect = tier == 0 and i == hits - 1
            saved = self.crit_bonus
            if last_perfect:
                self.crit_bonus = 5.0
            try:
                part, dmg = self.strike(user, target, 0.9)
            finally:
                self.crit_bonus = saved
            logs += part
            if last_perfect and dmg and target.is_alive():
                target.add_effect(scale_effect(Bleed(3, 5), user))
                logs.append(Announcement(f"🌙 Идеальная охота: {target.name} истекает кровью!"))
        return logs


class GustSkill(DamageSkill):
    """«Ураганный взмах»: ×1.2, срывает с врага один бафф или щит, −2 скорости на 2 хода."""

    def _after_hit(self, user, target, damage):
        logs = super()._after_hit(user, target, damage)
        buffs = [e for e in target.get_effects() if e.positive]
        if buffs:
            gone = buffs[0]
            target._effects = [e for e in target.get_effects() if e is not gone]
            logs.append(f"🌪 Взмах срывает с {target.name}: {gone.name}.")
        return logs

    def ai_score(self, user, target):
        bonus = 8 if any(e.positive for e in target.get_effects()) else 0
        return super().ai_score(user, target) + bonus
