"""Solo review: explicit kit decisions and transparent, reversible pair rules.

This checkout is a solo candidate. No published 5.9 distribution is modified.
"""
import copy
import random
from .character import Character
from .skills import Skill, DamageSkill, MiniGameSkill, SelfBuffSkill
from .effects import (Effect, Shield, StoneSkin, Stun, StunWard, DodgeBuff,
                      Blinded, Bleed, Poison, Berserk, DamageReduction, Antiheal, Announcement)

ARMOR = {'mage':.4,'assassin':.4,'monk':-.3,'goblin':.7,'satyr':-.5,'orc':.2,
         'bluetroll':.4,'spiderqueen':.2,'feliss':.7,'cyclops':-.3,'getou':.5,'darkknight':.2,'mersey':.4,'gambler':.2}
DODGE = {'musketeer':.07,'darkknight':.06,'dwarf':.07,'bluetroll':.09,'catfolk':.18,'feliss':.20}
# Changes apply to existing IDs; descriptions of damage/cost/CD remain generated.
SKILLS = {
 'mage':{'attack':{'multiplier':1.05},'heal':{'cooldown':6},'ice_shield':{'cooldown':6},
         'fireball':{'cost':33},'dark_power':{'cost':28},'snowfall':{'cost':33},'rune_seal':{'cost':36},'lightning':{'cost':38}},
 'ogre':{'heavy_strike':{'accuracy':.8,'description':'×2.2 урона, точность 80%'}},
 'spartan':{'eagle_eye':{'multiplier':2.5,'description':'Раз за бой: ×2.5, не промахивается'}},
 'monk':{'weakness':{'multiplier':2.5,'description':'Мини-игра: нажмите 1→6; все — ×2.5, 4–5 — ×1.5, меньше — ×0.9'},'stone_skin':{'effects':[lambda:StoneSkin(3,34)],'description':'Щит на 34 урона на 3 хода'}},
 'darkelf':{'life_drain':{'multiplier':1.1,'steal':.68,'description':'×1.1, лечение 68% нанесённого урона'}},
 'musketeer':{'sniper_shot':{'cost':27},'musket_shot':{'cost':15,'multiplier':2.0,'armor_pierce':.4},'bayonet':{'effect_chance':.19}},
 'goblin':{'daggers':{'cost':15,'armor_pierce':.467,'description':'Два удара по ×0.7, пробитие 46.7% брони'}},
 'ghoul':{'hunt_leap':{'cost':45},'devour':{'lifesteal':.47,'description':'×1.2, лечение 47% урона; снимает Опустошение'},'attack':{'multiplier':1.05}},
 'rhino':{'ram':{'accuracy':.8,'stun_chance':.38,'description':'×1.5, точность 80%, шанс оглушения 38%'}},
 'bogatyr':{'shoulder_bash':{'cost':10},'living_water':{'cost':15},'shield_wall':{'cost':15},'bogatyr_swing':{'cost':30}},
 'dwarf':{'fusion':{'cost':55}},
 'aarakocra':{'cyclone':{'cost':25},'attack':{'multiplier':1}},
 'hunter':{'traps':{'cost':20}},
 'centaur':{'harp_shot':{'cost':20},'spirit_arrow':{'effect':lambda:Poison(4,4),'description':'×1.4 и яд 4 HP на 4 хода'}},
 'paladin':{'smite':{'cost':22,'multiplier':1.7},'attack':{'multiplier':1.03}},
 'beastlord':{'call_beast':{'cost':32}},
 'ranger':{'bleed_volley':{'cost':18},'quick_shots':{'cost':20,'multiplier':.6,'description':'Три удара по ×0.6 (всего ×1.8)'}},
 'pandaren':{'keg_smash':{'cost':20},'belly':{'multiplier':1.4,'effect_chance':.28}},
 'gambler':{'guard_card':{'cost':24},'bluff_card':{'cost':18}},
 'cyclops':{'watchful_eye':{'cost':12},'mountain_guard':{'effects':[lambda:DamageReduction(2,23)],'description':'−23% входящего урона на 2 хода'}},
 'getou':{'bone_shelter':{'effects':[lambda:Shield(2,25)],'description':'Щит на 25 урона на 2 хода'},'grave_mist':{'effects':[lambda:DodgeBuff(2,14.1)],'description':'+14.1% уклонения на 2 хода (база 8%, итог 22.1%)'}},
}
# Ordered, mutually exclusive opponent rules. No bonus leaks into another duel.
PAIR_RULES = {
 ('ogre','pagan'):{'hp':5,'shield_pierce':.22},
 ('druid','bogatyr'):{'hp':3},
 ('leon','mage'):{'hp':9},
 ('minotaur','goblin'):{'hp':15,'armor':.7},
 ('bogatyr','pagan'):{'hp':12},
 ('owlbeast','darkknight'):{'hp':5,'armor':.6},
 ('minotaur','gambler'):{'hp':15,'armor':1},
 ('minotaur','catfolk'):{'hp':7,'accuracy':('horns',.05)},
 ('bogatyr','minotaur'):{'hp':12,'armor':.7,'basic':1.1},
 ('leon','shade'):{'hp':6,'accuracy':('predator_instinct',.05)},
}
PAIR_RULES_ENABLED = True


def clear_pair(hero):
    prior = getattr(hero, '_pair_review', None)
    if not prior:return
    hero._armor -= prior.get('armor',0)
    hero.max_hp -= prior.get('hp',0)
    hero.hp = min(hero.hp,hero.max_hp)
    if 'shield_pierce' in prior:hero.shield_pierce=prior['old_shield_pierce']
    if 'accuracy' in prior:
        key,delta=prior['accuracy'];hero.skills[key].accuracy -= delta
    if 'basic' in prior:hero.skills['attack'].multiplier /= prior['basic']
    hero._pair_review=None


def configure_pair(battle):
    if battle.story or not PAIR_RULES_ENABLED:return
    for h in (battle.hero1,battle.hero2):
        enemy=h.opponent;rule=PAIR_RULES.get((h.type_key,enemy.type_key))
        h._match_notes=[]
        if not rule:continue
        p=dict(rule)
        if 'hp' in p:h.max_hp+=p['hp'];h.hp=h.max_hp
        h._armor+=p.get('armor',0)
        if 'shield_pierce' in p:
            p['old_shield_pierce']=getattr(h,'shield_pierce',0);h.shield_pierce=p['shield_pierce']
        if 'accuracy' in p:
            key,delta=p['accuracy'];h.skills[key].accuracy+=delta
        if 'basic' in p:h.skills['attack'].multiplier*=p['basic']
        h._pair_review=p
        text='Особые условия против %s: '%enemy.name+', '.join(
            x for x in [('+%s HP'%p['hp']) if 'hp' in p else '',
                         ('+%s брони'%p['armor']) if 'armor' in p else '',
                         'прорез щитов 22%' if 'shield_pierce' in p else '',
                         '+5% точности отдельного приёма' if 'accuracy' in p else '',
                         '+10% урона автоатаки' if 'basic' in p else ''] if x)
        h._match_notes=[text];battle._add_log(text)
    # Red-card coefficient is selected by the target, without changing saved skills.


class ColdEyes(StunWard):
    name='Холодные глаза';icon='👀'
    def __init__(self):super().__init__(2);self.heal_used=False

class NextBlind(Blinded):
    name='Сбитый прицел';icon='🌑'
    def __init__(self):super().__init__(2,10)

class LastStrikeBoost(Effect):
    name='Скрытая угроза';icon='👥';positive=True
    def __init__(self):super().__init__(3,10)


def sync_original(skill,attrs):
    for k,v in attrs.items():setattr(skill,k,v)
    for name in ('_original59','_original58'):
        original=getattr(skill,name,None)
        if original is not None:sync_original(original,attrs)


def install(classes):
    from .heroes_42 import (Dwarf,Satyr,Nefruit,ShadowStrike,ShadowTwins,Orc,WarCry)
    from .heroes_54 import BeastLord,Catfolk,RedCard
    from .heroes_new import Minotaur
    from .minigames import DrumsSkill
    from .necromancy_55 import STATS
    from .item import OrdinaryKatana,Yoshirin,Kyocherin,Masamune
    OrdinaryKatana.chance=35.5;Yoshirin.chance=27.5;Kyocherin.chance=27.5;Masamune.chance=9.5
    BeastLord.RIDER_HP=125
    STATS['skeleton'][0]=(42,4,0,10)
    # Base factories run after all older adapters. Copies prevent shared SPEC mutation.
    for key,cls in classes.items():
        original=cls._create_skills
        def factory(self,_old=original,_key=key):
            skills=_old(self)
            for sk in skills:
                if hasattr(sk,'SPEC'):sk.SPEC=copy.deepcopy(sk.SPEC)
                if hasattr(sk,'PERSONAL'):sk.PERSONAL=copy.deepcopy(sk.PERSONAL)
                sync_original(sk,SKILLS.get(_key,{}).get(sk.key,{}))
            if _key=='mersey':
                skills=[sk for sk in skills if sk.key!='shoulder_strike']
                sk=next(sk for sk in skills if sk.key=='cold_eyes');sk.effects=[ColdEyes];sk.description='Иммунитет к оглушению 2 хода; первый заблокированный стан лечит 17 HP'
            from .games_600 import adapt_games
            return adapt_games(self,skills)
        cls._create_skills=factory
        old_init=cls.__init__
        def init(self,*args,_old=old_init,_key=key,**kwargs):
            _old(self,*args,**kwargs)
            self._armor+=ARMOR.get(_key,0);self._default_armor=self._armor
            if _key in DODGE:self.dodge=DODGE[_key]
            if _key=='feliss':self._start_energy=85;self.spend_energy(max(0,self.energy-85))
            if _key=='musketeer':self.max_energy=70;self.dodge=.07
            if _key=='darkelf':self.shield_pierce=.332
            if _key=='monk':self.reflect=.115
            if _key=='beastlord':self._init_split()
        cls.__init__=init
    old_config=Character.configure_arena
    def config(self):clear_pair(self);return old_config(self)
    Character.configure_arena=config
    old_reset=Character.reset
    def reset(self):
        clear_pair(self);self._beasts_seen=set();self._damage_fraction=0
        old_reset(self)
    Character.reset=reset
    old_add=Character.add_effect
    def add_effect(self,effect):
        if isinstance(effect,Stun):
            ward=next((e for e in self.get_effects() if isinstance(e,ColdEyes) and e.duration>0),None)
            if ward:
                if not ward.heal_used:
                    ward.heal_used=True;healed=self.heal(17);self._events.append('👀 Холодные глаза: заблокировано оглушение, +%s HP.'%healed)
                return False
        return old_add(self,effect)
    Character.add_effect=add_effect
    # Single next attack blind is consumed even on a miss, not by a support action.
    old_perform=DamageSkill._perform
    def damage_perform(self,user,target):
        blind=next((e for e in user.get_effects() if isinstance(e,NextBlind)),None)
        extra=1
        if user.type_key=='centaur' and self.key=='attack' and user.has_effect(Antiheal):extra=1.1
        if user.type_key=='spartan' and self.key=='attack' and user.spear_lost:extra=1.15
        saved=self.multiplier;self.multiplier*=extra
        try:logs=old_perform(self,user,target)
        finally:
            self.multiplier=saved
            if blind in user._effects:user._effects.remove(blind)
        return logs
    DamageSkill._perform=damage_perform
    original_red=RedCard._card
    def red(self,user,target):
        if target.type_key!='minotaur' or not PAIR_RULES_ENABLED:return original_red(self,user,target)
        from .heroes_54 import _veil_combo,_veil_set_combo
        if not _veil_combo(user):return original_red(self,user,target)
        _veil_set_combo(user,_veil_combo(user)-1)
        crit=user.crit_multiplier;user.crit_multiplier=min(crit,1.4)
        try:return DamageSkill('_red','Красная','',multiplier=1.71,accuracy=.92)._perform(user,target)
        finally:user.crit_multiplier=crit
    RedCard._card=red
    original_dict=Character.to_dict
    def to_dict(self):
        d=original_dict(self);d['matchup_notes']=getattr(self,'_match_notes',[])
        from .games_600 import difficulty
        for sk in d['skills']:
            obj=self.skills.get(sk['key'])
            if getattr(obj,'reaction',None) in ('minigame','sequence'):
                stars=difficulty(self.type_key,sk['key']);sk['difficulty']=stars;sk['is_minigame']=True
                sk['difficulty_label']='Сложность: '+'★'*stars+'☆'*(5-stars)+' (%s/5)'%stars
        return d
    Character.to_dict=to_dict


def finish_install(classes):
    from .heroes_55 import Leon,NewHero
    from .effects import MeleeMode,DamageOverTime
    from .heroes_42 import ShadowStrike
    from .summons import ForestSpirit,Decoy
    from .effects_42 import Feint
    # One-turn accuracy penalty on a paid shadow touch, consumed by next attack.
    old_factory=classes['shade']._create_skills
    def shade_factory(self):
        skills=old_factory(self)
        touch=next(s for s in skills if s.key=='dark_touch')
        touch.effect=NextBlind;touch.description='×1.0, точность 90%; −10% точности следующей атаки врага, не складывается'
        return skills
    classes['shade']._create_skills=shade_factory
    old_after=Leon.after_action
    def after(self,target):
        if self._action_key=='composure' and self._combo_before:
            self.combo=self._combo_before
            NewHero.after_action(self,target)
        else:old_after(self,target)
    Leon.after_action=after
    # Long periods of defense can preserve a combo, never create or stack it.
    old_dict=Character.to_dict
    def character_dict(self):
        d=old_dict(self)
        if self.type_key=='leon':
            roles={'predator_instinct':'Открывает комбо. Чередование с Засадой доводит до 2.',
                   'predator_ambush':'Открывает комбо. Чередование с Инстинктом доводит до 2.',
                   'beast_king':'Продолжает открытое комбо до 2; без комбо удар слабее.',
                   'king_roar':'Сохраняет текущее комбо, не повышая его.',
                   'composure':'Сохраняет текущее комбо и готовит следующий крит.',
                   'royal_will':'Завершает комбо; при 2 следующий удар критический.',
                   'blade_fusion':'Завершает комбо; при 2 усиленный двойной удар.',
                   'pride_call':'Завершает комбо; сильнее против цели ниже 50% HP.'}
            for sk in d['skills']:
                sk['combo_help']=roles.get(sk['key'],'Сбрасывает комбо.')
                sk['description']+=' · '+sk['combo_help']
            d['combo_help']='Открыть → продолжить до 2 → сохранить или завершить. Пропуск хода сбрасывает комбо.'
        return d
    Character.to_dict=character_dict
    # Only the human-form autoattack is strengthened under actual antiheal.
    old_armor=classes['archer'].armor_total
    def archer_armor(self):return old_armor(self)+(1.4 if self.has_effect(MeleeMode) else 0)
    classes['archer'].armor_total=archer_armor
    # Requested spirit tiers all receive the same +10 HP / +2 damage.
    old_spirit=ForestSpirit.__init__
    def spirit(self,owner,hp=60,damage=6):old_spirit(self,owner,hp+10,damage+2)
    ForestSpirit.__init__=spirit
    old_decoy=Decoy.__init__
    def decoy(self,owner,*args,**kw):old_decoy(self,owner,*args,**kw);self.intercept_chance=.4
    Decoy.__init__=decoy
    # Dawn bonus is small and local to this fixed poison spell, not every poison.
    class SteadyPoison(Poison):
        grows=False
        def on_turn_start(self,owner):return DamageOverTime.on_turn_start(self,owner)
    old_centaur=classes['centaur']._create_skills
    def centaur(self):
        skills=old_centaur(self);next(s for s in skills if s.key=='spirit_arrow').effect=lambda:SteadyPoison(4,4)
        return skills
    classes['centaur']._create_skills=centaur
    # Cards keep matching effects; King's true resource gain is eighteen.
    from .minigames_54 import CardDrawSkill
    CardDrawSkill.CARD_EFFECTS['king']='🛡 щит 12% HP и +18 удачи'
    classes['owlbeast'].creatable=True

class OneHitCover(Effect):
    name='Защита напёрстков';icon='🥤';positive=True
    def __init__(self):super().__init__(3,50)
    def modify_incoming(self,owner,damage,attacker):
        if attacker is None or damage<=0:return damage,[]
        self.duration=0
        return max(0,round(damage*.5)),['🥤 Напёрстки ослабляют один прямой удар на 50%.']


def finish_details(classes):
    from .heroes_42 import CupsSkill
    def cups(self,user,target,tier,data):
        if tier:return ['🥤 Шарик не найден.']
        user.add_effect(OneHitCover());amount=min(11,target.energy);target.spend_energy(amount)
        return ['🥤 Защита от одного прямого удара 50%; противник теряет %s ресурса.'%amount]
    CupsSkill.apply=cups
    from .minigames_56 import Hunt56
    old_hunt=Hunt56.apply
    def hunt(self,user,target,tier,data):
        saved=getattr(user,'shield_pierce',0);user.shield_pierce=max(saved,.2)
        try:return old_hunt(self,user,target,tier,data)
        finally:user.shield_pierce=saved
    Hunt56.apply=hunt
    # Refresh every dynamic description affected by an approved number change.
    old_factory=classes['satyr']._create_skills
    def satyr(self,_old=old_factory):
        skills=_old(self)
        for s in skills:
            if s.key=='light_step':
                s.effects[0]=lambda:DodgeBuff(2,40);s.description='+40% уклонения на 2 хода, +20% крита следующему удару'
            if s.key=='forest_spirit':s.description='Четыре осколка: дух 70 HP/8 урона; частично слабее. Даже слабый дух атакует.'
        return skills
    classes['satyr']._create_skills=satyr
    old_factory=classes['goblin']._create_skills
    def goblin(self,_old=old_factory):
        skills=_old(self)
        next(s for s in skills if s.key=='cups').description='Угадайте стакан: следующий прямой удар слабее на 50%, −11 ресурса врагу.'
        return skills
    classes['goblin']._create_skills=goblin

KATANA_POWER={'OrdinaryKatana':.965,'Yoshirin':1.165,'Kyocherin':.9825,'Masamune':1.0}
def install_katana(classes):
    old=classes['samurai'].get_damage
    def damage(self):return old(self)*KATANA_POWER[type(self.katana).__name__]
    classes['samurai'].get_damage=damage


def refresh_descriptions(classes):
    from .minigames import DrumsSkill,BloodShieldSkill
    DrumsSkill.describe_for=lambda self,user:'Идеал: лечение 50 HP, снятие дебаффов и +3 наследия; 3–4 удара: 12% HP и +2; 1–2: 5% и +1. Повторите пять ударов ритма.'
    from .minigames_56 import Hunt56
    old=Hunt56.describe_for
    Hunt56.describe_for=lambda self,user:old(self,user)+' · 20% прямого урона проходит сквозь поглощающий щит.'
    for key,phrases in {
        'archer':{'craft_swap':'Пять ходов ближнего боя: +1.4 брони. С 8-го хода, раз за бой.'},
        'dwarf':{'fusion':'Форма секиры-молота на 2–4 хода; получаемый урон +23%.',},
        'darkelf':{'blood_shield':'Плата 6% максимальных HP; щит 22% HP на 3 хода.'},
        'centaur':{'attack':'Обычная атака; пока на вас запрет лечения, её урон выше на 10%.'},
    }.items():
        old_factory=classes[key]._create_skills
        def factory(self,_old=old_factory,_phrases=phrases):
            skills=_old(self)
            for s in skills:
                if s.key in _phrases:s.description=_phrases[s.key]
            return skills
        classes[key]._create_skills=factory
