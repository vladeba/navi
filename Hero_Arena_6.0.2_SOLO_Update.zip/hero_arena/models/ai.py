"""State-aware action values in expected HP, without rolling or changing combat state.

These are short-horizon estimates, not changes to skill execution. Resource
opportunity cost is applied once by Character.choose_action.
"""
from .effects import (Antiheal, Burn, Poison, DamageOverTime, Stun, Shield,
                      CalmShield, Regeneration, DamageReduction, ShellStance,
                      Contract, StoneShield, Invisibility)
from .effects_42 import Guard, ArmorBreak, Vulnerable
from functools import wraps
import threading

_local=threading.local()


def evaluating(method):
    """Cache repeated immutable forecasts only during one action selection."""
    @wraps(method)
    def wrapped(*args,**kwargs):
        previous=getattr(_local,'forecasts',None)
        _local.forecasts={}
        try:
            return method(*args,**kwargs)
        finally:
            _local.forecasts=previous
    return wrapped


def clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))


def healing(user, amount, missing=None):
    if user.has_effect(Antiheal):
        return 0.0
    cut = max(0.0, 1 - user.fatigue * user.FATIGUE_HEAL_CUT)
    missing = user.max_hp-user.hp if missing is None else missing
    return min(max(0, missing), max(0, amount)*cut)


def threat(user, target):
    """Typical next offensive turn, including current damage/accuracy modifiers."""
    cache=getattr(_local,'forecasts',None)
    key=(id(user),id(target))
    if cache is not None and key in cache:
        return cache[key]
    if user.type_key == 'getou':
        value = sum(threat(pet, target) / 1.45 for pet in user.living_minions())
        if cache is not None:
            cache[key] = value
        return value
    attack = user.skills.get('attack')
    accuracy = getattr(attack, 'accuracy', 0.9)
    from . import passives_56
    acc = accuracy + user.acc_bonus + sum(e.accuracy_bonus() for e in user.get_effects()) + (passives_56.accuracy(user,attack) if attack else 0)
    hit = clamp(max(user.MIN_HIT, acc-target.get_dodge()*(1-user.DODGE_PIERCE)))
    raw = user.get_damage()*user.damage_multiplier()*(1+user.fatigue)*1.45
    armor = 0 if getattr(attack, 'ignore_armor', False) else target.armor_total()
    value=max(1, raw-armor)*hit*(1+clamp(user.get_crit()+passives_56.crit(user,target))*(user.crit_multiplier-1))
    if cache is not None:
        cache[key]=value
    return value


def horizon(user, target, maximum=3):
    """Do not buy a long buff/debuff when either participant is about to fall."""
    return max(1.0, min(maximum, target.hp/max(1, threat(user,target)),
                        user.hp/max(1, threat(target,user))))


def strike_value(user, target, multiplier=1, hits=1, *, accuracy=0.95,
                 ignore_armor=False, pierce=0, crit_bonus=0, fixed_hit=None,
                 force=False, skill=None):
    if skill is not None:
        hit = fixed_hit if fixed_hit is not None else user.hit_chance(skill,target)
    else:
        acc = accuracy+user.acc_bonus+sum(e.accuracy_bonus() for e in user.get_effects())
        hit = fixed_hit if fixed_hit is not None else max(user.MIN_HIT, acc-target.get_dodge()*(1-user.DODGE_PIERCE))
    if force:
        hit = 1-target.get_dodge()*getattr(target,'FORCED_EVADE',0)
    if getattr(user,'miss_streak',0) >= getattr(user,'MAX_MISS_STREAK',99):
        hit = 1
    hit = clamp(hit)
    arm = target.armor_total()
    from . import passives_56
    pierce = clamp(pierce+float(getattr(user,'armor_pierce',0) or 0)+passives_56.pierce(user,skill,forecast=True))
    raw = user.get_damage()*multiplier*user.damage_multiplier()*(1+user.fatigue)
    raw *= user.damage_vs(target) if hasattr(user,'damage_vs') else 1
    bonus=0 if ignore_armor else arm*pierce+min(arm,getattr(user,'ARMOR_PIERCE_FLAT',0))
    if ignore_armor:
        raw *= 1-getattr(target,'MAGIC_GUARD',0)
    from . import passives_56
    crit = clamp(user.get_crit()+crit_bonus+passives_56.crit(user,target))
    # Armor is deducted separately from normal and critical hits, as in combat.
    per = (1-crit)*max(1,raw+bonus-(0 if ignore_armor else arm))
    per += crit*max(1,passives_56.critical_guard(target,raw*user.crit_multiplier)+bonus-(0 if ignore_armor else arm))
    guard=max((e.power for e in target.get_effects() if isinstance(e,Guard)),default=0)
    per *= 1-clamp(guard/100)
    for eff in target.get_effects():
        if isinstance(eff,DamageReduction):
            per *= 1-clamp(eff.power/100)
        elif isinstance(eff,ShellStance):
            per *= 1-eff.reduction(target)/100
        elif isinstance(eff,Contract):
            per *= 0.76
        elif isinstance(eff,StoneShield):
            per *= 0.75 if target.has_effect(Antiheal) else 0.5
        elif isinstance(eff,Vulnerable):
            per *= 1+eff.power/100
    return max(0,per)*hit*hits


def effect_value(user, target, eff):
    old = next((e for e in target.get_effects() if type(e) is type(eff)),None)
    turns = min(eff.duration,horizon(user,target))
    if isinstance(eff,Stun):
        if target.has_effect(Stun) or any(e.blocks_stun() for e in target.get_effects()):
            return 0
        return threat(target,user)*min(eff.duration,turns)
    value=0.0
    if isinstance(eff,DamageOverTime):
        scale=user.power_scale()
        power=eff.power*scale
        if isinstance(eff,Poison) and getattr(eff,"grows",True):
            # Recasting a weaker poison resets its growing power.
            new=sum(power+2*i for i in range(max(1,int(turns))))
            previous=sum(old.power+2*i for i in range(min(old.duration,max(1,int(turns))))) if old else 0
        else:
            new=power*turns
            previous=old.power*min(old.duration,turns) if old and not eff.stacks else 0
        value += max(0,new-previous)*(1-getattr(target,'DOT_RESIST',0))
    # Non-stun debuffs expire at turn start before that turn's attack.
    live=max(0,min(eff.duration-1,turns))
    if old and old.duration>=eff.duration and old.power>=eff.power and not eff.stacks:
        return value
    value += max(0,-eff.damage_bonus())*threat(target,user)*live
    value += max(0,-eff.accuracy_bonus())*target.get_damage()*1.45*live
    value += min(target.get_dodge(),max(0,-eff.dodge_bonus()))*user.get_damage()*1.45*live
    if isinstance(eff,ArmorBreak):
        stacks=old.power if old else 0
        value += max(0,min(target.armor_total(),eff.cap-stacks,eff.power))*live*0.85
    # Speed only changes initiative; it never grants an extra action.
    value += min(1.5,abs(eff.speed_bonus())*0.15*live)
    return value


def damage_score(skill,user,target):
    mult=skill.multiplier
    if skill.low_hp_bonus and target.hp<target.max_hp*0.35:
        mult *= 1+skill.low_hp_bonus
    dmg=strike_value(user,target,mult,skill.hits,accuracy=skill.accuracy,
                     ignore_armor=skill.ignore_armor,pierce=skill.armor_pierce,
                     crit_bonus=skill.crit_bonus,fixed_hit=skill.fixed_hit,skill=skill)
    score=dmg
    if skill.effect:
        hit=clamp(skill.fixed_hit if skill.fixed_hit is not None else user.hit_chance(skill,target))
        score += (1-(1-hit)**skill.hits)*skill.effect_chance*effect_value(user,target,skill.effect())
    steal=skill.lifesteal+getattr(skill,'steal',0)
    score += healing(user,dmg*steal)
    if dmg>=target.hp:
        score += min(12,target.hp)  # take a likely finishing hit before setup
    if user.type_key=='minotaur' and skill.key=='horns' and user.legacy<user.MAX_LEGACY:
        score += 0.03*threat(user,target)*horizon(user,target)
    return score


def buff_score(skill,user,target):
    value=0.0
    incoming=threat(target,user)
    own=threat(user,target)
    turns=horizon(user,target)
    for make in skill.effects:
        eff=make()
        old=next((e for e in user.get_effects() if type(e) is type(eff)),None)
        if old and old.duration>=eff.duration and old.power>=eff.power:
            continue
        live=min(eff.duration,turns)
        attacking=max(0,min(eff.duration-1,turns))
        if isinstance(eff,Shield):
            existing=old.power if old else 0
            value += max(0,min(eff.power*user.power_scale(),incoming*live)-existing)
            if isinstance(eff,CalmShield):
                value += min(eff.burst,incoming*live)*0.65
        elif isinstance(eff,Regeneration):
            value += healing(user,eff.power*live)
        elif isinstance(eff,(DamageReduction,Guard)):
            value += incoming*clamp(eff.power/100)*live
        elif isinstance(eff,StoneShield):
            value += incoming*0.35*live
        else:
            value += own*max(0,eff.damage_bonus())*attacking
            value += target.get_damage()*1.45*max(0,eff.dodge_bonus())*live
            value += max(0,eff.armor_bonus())*live
            value += own*max(0,eff.crit_bonus())*(user.crit_multiplier-1)*attacking
        if isinstance(eff,Invisibility):
            # Hiding consumes the following action in addition to setup.
            value -= own
    # Defensive setup matters more when it averts a probable lethal turn.
    if incoming>=user.hp:
        value *= 1.3
    return value


def summon_score(skill,user,target):
    from .summons import BEASTS,random_beast
    if user.summon and user.summon.is_alive():
        return 0
    if skill.summon_factory is random_beast:
        candidates=[(cls(user),cls.weight) for cls in BEASTS]
    elif isinstance(skill.summon_factory,type):
        candidates=[(skill.summon_factory(user),1)]
    else:
        # Special class factories keep their own score; do not roll a random
        # beast just to evaluate a candidate action.
        return 16
    values=[]
    for summon,weight in candidates:
        turns=horizon(user,target,min(4,summon.lifetime or 4))
        intercept=summon.intercept_chance*(1-getattr(target,'INTERCEPT_IGNORE',0))
        incoming=threat(target,user)
        turns=min(turns,summon.max_hp/max(1,incoming*intercept))
        raw=summon.damage*user.power_scale()
        ignore=getattr(summon,'IGNORE_ARMOR',False) or summon.__class__.__name__=='WaterSpirit'
        damage=max(1,raw-(0 if ignore else target.armor_total()))
        hit=max(0.1,summon.accuracy-target.get_dodge())
        protection=min(summon.max_hp,incoming*intercept*turns)
        values.append((weight,damage*hit*turns+protection))
    return sum(w*v for w,v in values)/sum(w for w,v in values)


def resource_price(user):
    return 0.12+0.25*(1-user.energy/max(1,user.max_energy))


def reserve_penalty(skill,user,target,scores=None):
    """Do not spend the resource needed for a better move next turn.

    In particular, cheap filler must not repeatedly postpone healing, a
    summon, or a stronger attack that is ready within the next two turns.
    """
    from math import ceil
    if not skill.cost or user.energy_regen<=0:
        return 0
    def raw(other):
        return scores[other.key] if scores is not None and other.key in scores else other.ai_score(user,target)
    attack=user.skills.get('attack')
    base=raw(attack) if attack else 0
    penalty=0
    for other in user.skills.values():
        if other is skill or not other.cost or other.key=='attack':
            continue
        slot = getattr(skill, 'exclusive_slot', None)
        if slot and slot == getattr(other, 'exclusive_slot', None):
            continue  # Casting this companion makes the alternative unavailable.
        if (user.cooldown_left(other.key)>2 or user.blocked_left(other.key)>2
                or not other.is_available(user) or not user.skill_unlocked(other)):
            continue
        ready=max(1,user.cooldown_left(other.key),user.blocked_left(other.key))
        free=max(ready,ceil(max(0,other.cost-user.energy)/user.energy_regen))
        paid=max(ready,ceil(max(0,other.cost-user.energy+skill.cost)/user.energy_regen))
        if free<=2 and paid>free:
            gain=max(0,raw(other)-other.cost*resource_price(user)-base)
            penalty=max(penalty,gain*0.8**free)
    return penalty


def action_score(skill,user,target,scores=None):
    value=scores[skill.key] if scores is not None else skill.ai_score(user,target)
    value -= skill.cost*resource_price(user)
    value -= reserve_penalty(skill,user,target,scores)
    if skill.key=='attack':
        gains={'warrior':15,'mage':5,'darkknight':10,'owlbeast':10}
        value += min(gains.get(user.type_key,0),user.max_energy-user.energy)*resource_price(user)
    return value


def tier_average(skill,user,values):
    from .skills import ai_weights
    if user.perfect:
        return values[0]
    weights=ai_weights(user,skill.AI_WEIGHTS)
    return sum(w*v for w,v in zip(weights,values))/sum(weights)
