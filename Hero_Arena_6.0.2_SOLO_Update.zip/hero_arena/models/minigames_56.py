"""Replayed physical inputs for selected legacy games and three new abilities."""
import copy,math,random,time
from .skills import MiniGameSkill,DamageSkill,scale_effect
from .effects import Announcement,Bleed
from .minigames import DeerHuntSkill,KnifeThrowSkill
from .minigames_42 import ForestCallSkill, NightHuntSkill, NephewsSkill
from .minigames_54 import SoulSiphonSkill
from .heroes_42 import StoneArmorSkill,SkullDarkSkill,LightPillar,LastDawn,StarArrowSkill,ConstellationSkill

def integer(x,lo=0,hi=100000):return x if isinstance(x,int) and not isinstance(x,bool) and lo<=x<=hi else -1
def number(x,default=-999,lo=-10000,hi=10000):
    return float(x) if isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and lo<=x<=hi else default
def records(c,key,maximum=500):
    v=c.get(key) if isinstance(c,dict) else None
    return v if isinstance(v,list) and len(v)<=maximum else []
def trace(c,o):
    out=[];last=-1
    for p in records(c,'points',600):
        if not isinstance(p,dict):return []
        t=integer(p.get('t'),hi=o['time_limit_ms']);x=number(p.get('x'),lo=0,hi=360);y=number(p.get('y'),lo=0,hi=260)
        if t<=last or x==-999 or y==-999:return []
        out.append((t,x,y));last=t
    return out
def at(path,t):
    if not path:return -999,-999
    if t<=path[0][0]:return path[0][1:]
    for a,b in zip(path,path[1:]):
        if t<=b[0]:
            f=(t-a[0])/max(1,b[0]-a[0]);return a[1]+f*(b[1]-a[1]),a[2]+f*(b[2]-a[2])
    return path[-1][1:]
def events(c,key,o,maximum):
    result=[];last=-1
    for a in records(c,key,maximum):
        if not isinstance(a,dict):return []
        ms=integer(a.get('ms'),hi=o['time_limit_ms'])
        if ms<=last or ms<o['prepare_ms']:return []
        result.append(a);last=ms
    return result
def near(a,b,r):return math.dist(a,b)<=r

class Replay:
    """The server derives quality from bounded events, never a claimed score."""
    PREP=900
    def public_options(self,user=None,target=None):return MiniGameSkill.public_options(self,user,target)
    def secret_pick(self,options=None):
        s=MiniGameSkill.secret_pick(self,options);s['started']=time.time();return s
    def params(self,user=None):
        limit=max(900,round(self.TIME_LIMIT_MS*getattr(self,'_time_multiplier',1)))
        f=limit/self.TIME_LIMIT_MS
        return {'prepare_ms':round(self.PREP*f),'factor':f,'hero_type':getattr(user,'type_key','')}
    def resolve(self,user,target,choice,secret):
        o=secret.get('options',{});limit=o.get('time_limit_ms',self.TIME_LIMIT_MS)
        good=isinstance(choice,dict)
        elapsed=integer(choice.get('elapsed_ms'),hi=limit) if good else -1
        wall=(time.time()-secret.get('started',time.time()))*1000
        if elapsed<0 or elapsed>wall+350 or time.time()>(secret.get('deadline') or float('inf')):good=False
        if good:
            for key in ('fire_ms','down_ms','up_ms'):
                if key in choice and integer(choice[key],hi=elapsed)<0:good=False
            for name in ('points','shots','clicks','actions','drags','cuts','holds','placements','rotations'):
                if name not in choice:continue
                raw=choice[name]
                if not isinstance(raw,list) or len(raw)>600:good=False;break
                for a in raw:
                    if not isinstance(a,dict):good=False;break
                    if name=='points' and (number(a.get('x'),lo=0,hi=360)==-999 or number(a.get('y'),lo=0,hi=260)==-999):good=False
                    for k in ('t','ms','down_ms','up_ms'):
                        if k in a and integer(a[k],hi=elapsed)<0:good=False
        tier=self.tier_from(choice,o) if good else len(self.TIERS)-1
        tier=max(0,min(len(self.TIERS)-1,int(tier)))
        return self.apply(user,target,tier,self.result_data(choice,o) if good else None)
    def result_data(self,c,o):return None

def moving_star(o,t):
    q=(t-o['prepare_ms'])/o['period']*2*math.pi
    if o.get('straight'):return 180+115*math.sin(q+o['phase']),105+28*math.sin(q*.5)
    return 190+105*math.sin(q+o['phase']),115+65*math.sin(q*1.6+.4)
def projectile_hits(c,o):
    shots=events(c,'shots',o,o['count']);hit=0
    for shot in shots:
        if shot['ms']+o['travel_ms']>min(o['time_limit_ms'],number(c.get('elapsed_ms'),0)):continue
        x=number(shot.get('x'),lo=0,hi=360);y=number(shot.get('y'),lo=0,hi=260)
        impact=(x+o['wind'],y)
        hit+=near(impact,moving_star(o,shot['ms']+o['travel_ms']),o['radius'])
    if any(b['ms']-a['ms']<round(250*o['factor']) for a,b in zip(shots,shots[1:])):return 0
    return hit

class Hunt56(Replay,DeerHuntSkill):
    game,prompt='hunt_lead_56','Цель движется: стреляйте с упреждением, пока стрела летит.'
    TIME_LIMIT_MS=6500
    def game_params(self,user,target):
        o=self.params(user);o.update(count=6,period=round(3400*o['factor']),phase=random.uniform(0,5),
            straight=True,wind=0,travel_ms=round(320*o['factor']),radius=32);return o
    def tier_from(self,c,o):return DeerHuntSkill.tier_from(self,{'hits':projectile_hits(c,o)},o)

class StarArrow56(Replay,StarArrowSkill):
    game,prompt='star_lead_56','Три стрелы: учтите движение звезды и снос солнечным ветром.'
    TIME_LIMIT_MS=7500
    def game_params(self,user,target):
        o=self.params(user);o.update(count=3,period=round(4100*o['factor']),phase=random.uniform(0,5),
            wind=random.choice((-24,-16,16,24)),travel_ms=round(440*o['factor']),radius=24);return o
    def tier_from(self,c,o):return StarArrowSkill.tier_from(self,{'hits':projectile_hits(c,o)},o)

class Knives56(Replay,KnifeThrowSkill):
    game,prompt='knife_flick_56','Бросайте ножи движением от руки внизу к пяти меткам.'
    TIME_LIMIT_MS=6000
    def game_params(self,user,target):
        o=self.params(user);o['targets']=[[65,75],[180,45],[295,75],[110,145],[250,145]];return o
    def tier_from(self,c,o):
        used=set();last=-1
        for cut in records(c,'cuts',5):
            if not isinstance(cut,dict):return self.TARGETS
            t0,t1=integer(cut.get('down_ms'),hi=o['time_limit_ms']),integer(cut.get('up_ms'),hi=o['time_limit_ms'])
            start=(number(cut.get('x0')),number(cut.get('y0')));end=(number(cut.get('x1')),number(cut.get('y1')))
            if t0<=last or t0<o['prepare_ms'] or not 70*o['factor']<=t1-t0<=1300*o['factor']:return self.TARGETS
            last=t1
            if not near(start,(180,232),45):continue
            for i,p in enumerate(o['targets']):
                if i not in used and near(end,p,25):used.add(i);break
        return KnifeThrowSkill.tier_from(self,{'hits':len(used)},o)

class Forest56(Replay,ForestCallSkill):
    game,prompt='spirit_guide_56','Перетяните лесных духов к дереву в центре.'
    TIME_LIMIT_MS=7000
    def game_params(self,user,target):
        o=self.params(user);o['spirits']=[[180+112*math.cos(i*math.pi/5),130+90*math.sin(i*math.pi/5)] for i in range(10)];return o
    def tier_from(self,c,o):
        used=set();last=-1
        for d in records(c,'drags',30):
            if not isinstance(d,dict):return len(self.TIERS)-1
            i=integer(d.get('node'),hi=9);t0=integer(d.get('down_ms'),hi=o['time_limit_ms']);t1=integer(d.get('up_ms'),hi=o['time_limit_ms'])
            if i<0 or t0<=last or t0<o['prepare_ms'] or t1<=t0:return len(self.TIERS)-1
            last=t1
            if near((number(d.get('x0')),number(d.get('y0'))),o['spirits'][i],28) and near((number(d.get('x')),number(d.get('y'))),(180,130),30):used.add(i)
        return ForestCallSkill.tier_from(self,{'hits':len(used)},o)

class Nephews56(Replay,NephewsSkill):
    game,prompt='nest_catch_56','Подставляйте гнездо под падающих совят; нажимать не нужно.'
    TIME_LIMIT_MS=6200
    def game_params(self,user,target):
        o=self.params(user);f=o['factor'];o['birds']=[{'x':random.randint(45,315),'land':round((1700+i*700)*f),'fall':round(1000*f)} for i in range(6)];return o
    def tier_from(self,c,o):
        p=trace(c,o);n=0
        elapsed=number(c.get('elapsed_ms'),0) if isinstance(c,dict) else 0
        for b in o['birds']:
            if elapsed<b['land']:continue
            n+=abs(at(p,b['land'])[0]-b['x'])<=30
        return NephewsSkill.tier_from(self,{'hits':n},o)

class Night56(Replay,NightHuntSkill):
    game,prompt='night_focus_56','Наведите свет на глаза, удержите фокус и нажмите.'
    TIME_LIMIT_MS=5100
    def game_params(self,user,target):
        o=self.params(user);f=o['factor'];o['eyes']=[{'x':random.randint(55,305),'y':random.randint(55,165),'start':round((1100+i*1200)*f),'end':round((2100+i*1200)*f)} for i in range(3)];return o
    def tier_from(self,c,o):
        p=trace(c,o);used=set()
        for click in events(c,'clicks',o,3):
            for i,e in enumerate(o['eyes']):
                t=click['ms'];xy=(e['x'],e['y'])
                if i in used or not e['start']<=t<e['end']:continue
                if not near((number(click.get('x')),number(click.get('y'))),xy,27):continue
                held=all(near(at(p,ms),xy,30) for ms in range(max(e['start'],t-round(160*o['factor'])),t+1,20))
                if held and t-e['start']>=round(140*o['factor']):used.add(i)
        return NightHuntSkill.tier_from(self,{'hits':len(used)},o)

class Souls56(Replay,SoulSiphonSkill):
    game,prompt='soul_tether_56','Ведите луч по душам: удержание связывает каждую душу.'
    TIME_LIMIT_MS=4400
    def game_params(self,user,target):
        o=self.params(user);o['souls']=[[70,75],[285,75],[180,145],[70,190],[285,190]];o['lock_ms']=round(220*o['factor']);return o
    def tier_from(self,c,o):
        p=trace(c,o);n=held=0
        end=min(o['time_limit_ms'],number(c.get('elapsed_ms'),0)) if isinstance(c,dict) else 0
        for t in range(o['prepare_ms'],int(end),40):
            if n==5:break
            held=held+40 if near(at(p,t),o['souls'][n],28) else 0
            if held>=o['lock_ms']:n+=1;held=0
        return SoulSiphonSkill.tier_from(self,{'hits':n},o)

class Stone56(Replay,StoneArmorSkill):
    TIERS=("4/4", "3/4", "1–2/4", "0/4")
    game,prompt='stone_stack_56','Сбрасывайте четыре плиты, когда они над выделенным местом панциря.'
    TIME_LIMIT_MS=6000
    def game_params(self,user,target):
        o=self.params(user);o.update(periods=[round(v*o['factor']) for v in (1100,1350,1500,1250)],phases=[random.randint(0,1000) for _ in range(4)],slots=[155,205,165,195]);return o
    def tier_from(self,c,o):
        drops=events(c,'clicks',o,4);n=0
        for i,a in enumerate(drops):
            x=180+110*math.sin(2*math.pi*(a['ms']+o['phases'][i])/o['periods'][i])
            n+=abs(x-o['slots'][i])<=25
        return 0 if n==4 else 1 if n==3 else 2 if n else 3

class Skull56(Replay,SkullDarkSkill):
    game,prompt='shadow_erase_56','Сотрите четыре печати тьмы движением указателя с зажатой кнопкой.'
    TIME_LIMIT_MS=6500
    def game_params(self,user,target):
        o=self.params(user);o['seals']=[[100,75],[260,75],[100,185],[260,185]];return o
    def tier_from(self,c,o):
        p=trace(c,o);held=records(c,'holds',10);n=0
        for x,y in o['seals']:
            cells=set()
            for t,px,py in p:
                if t<o['prepare_ms'] or not any(integer(a.get('down_ms'))<=t<=integer(a.get('up_ms')) for a in held if isinstance(a,dict)):continue
                if near((px,py),(x,y),35):cells.add((px>=x,py>=y))
            n+=len(cells)>=3
        return SkullDarkSkill.tier_from(self,{'hits':n},o)

def beam_path(o,bits):
    pos=list(o['start']);direction=list(o['direction']);path=[];seen=set()
    mirrors={tuple(p):i for i,p in enumerate(o['mirrors'])};visited=set()
    for _ in range(40):
        state=tuple(pos+direction)
        if state in seen:break
        seen.add(state);path.append(pos[:])
        if pos==o['goal']:return path,len(visited)==3
        i=mirrors.get(tuple(pos))
        if i is not None:
            visited.add(i);dx,dy=direction
            direction=[dy,dx] if bits[i] else [-dy,-dx]
        pos=[pos[0]+direction[0],pos[1]+direction[1]]
        if not all(0<=v<=4 for v in pos):break
    return path,False

def phase_error(t,period,phase=0):return abs(((t+phase)%period)-period/2)

class Pillar56(Replay,LightPillar):
    game,prompt='light_prism_56','Разверните три зеркала, направьте луч в цель и откройте затвор на вспышке.'
    TIME_LIMIT_MS,PREP=11000,1800
    def pick_reactor(self,user,target,is_human):return user
    def game_params(self,user,target):
        o=self.params(user);rot=random.randrange(4);flip=random.choice((False,True))
        def transform(p):
            x,y=p
            if flip:x=4-x
            for _ in range(rot):x,y=4-y,x
            return [x,y]
        start=transform([0,1]);tip=transform([1,1]);solution=[int(v)^int(flip)^int(rot%2) for v in (1,1,0)]
        bits=[random.randrange(2) for _ in range(3)]
        if bits==solution:bits[random.randrange(3)]^=1
        o.update(start=start,direction=[tip[0]-start[0],tip[1]-start[1]],mirrors=[transform(p) for p in ([1,1],[1,3],[3,3])],
                 goal=transform([3,0]),initial=bits,period=round(1800*o['factor']),phase=random.randint(0,1500))
        return o
    def tier_from(self,c,o):
        bits=o['initial'][:]
        for a in events(c,'clicks',o,30):
            if a['ms']>integer(c.get('fire_ms'),hi=o['time_limit_ms']):return 2
            i=integer(a.get('node'),hi=2)
            if i<0:return 2
            bits[i]^=1
        fire=integer(c.get('fire_ms'),hi=o['time_limit_ms']) if isinstance(c,dict) else -1
        if fire<o['prepare_ms'] or not beam_path(o,bits)[1]:return 2
        err=phase_error(fire,o['period'],o['phase'])/o['factor']
        return 0 if err<=70 else 1 if err<=190 else 2
    def apply(self,user,target,tier,data):return self._land(user,target,tier,False)

def star_positions(o,drags,t):
    positions=[]
    for i,p in enumerate(o['nodes']):
        last=next((a for a in reversed(drags) if a.get('node')==i and a['up_ms']<=t),None)
        base=[last['x'],last['y']] if last else p
        drift=max(0,t-last['up_ms']-800*o['factor'])/1000 if last else 0
        positions.append([base[0]+o['velocities'][i][0]*drift,base[1]+o['velocities'][i][1]*drift])
    return positions

class Constellation56(Replay,ConstellationSkill):
    game,prompt='star_pattern_56','Перенесите пять звёзд в одноимённые контуры и замкните узор, пока они не уплыли.'
    TIME_LIMIT_MS,PREP=9000,1000
    def game_params(self,user,target):
        o=self.params(user);slots=random.choice([[[115,60],[220,65],[295,125],[220,195],[115,200]],[[125,40],[260,75],[180,125],[270,205],[110,200]],[[170,45],[290,100],[250,210],[135,205],[105,100]]])
        o.update(nodes=[[38,38+i*45] for i in range(5)],slots=slots,
            velocities=[[random.choice((-1,1))*5/o['factor'],random.choice((-1,1))*3/o['factor']] for _ in range(5)])
        return o
    def tier_from(self,c,o):
        valid=[];last=-1
        for a in records(c,'drags',35):
            if not isinstance(a,dict):return 3
            i=integer(a.get('node'),hi=4);t0=integer(a.get('down_ms'),hi=o['time_limit_ms']);t1=integer(a.get('up_ms'),hi=o['time_limit_ms'])
            if i<0 or t0<=last or t0<o['prepare_ms'] or t1<=t0:return 3
            initial=star_positions(o,valid,t0)[i]
            if not near(initial,(number(a.get('x0')),number(a.get('y0'))),30):return 3
            if not(0<=number(a.get('x'))<=360 and 0<=number(a.get('y'))<=260):return 3
            valid.append(a);last=t1
        elapsed=number(c.get('elapsed_ms'),0,0,o['time_limit_ms']) if isinstance(c,dict) else 0
        n=sum(near(a,b,21) for a,b in zip(star_positions(o,valid,elapsed),o['slots']))
        return ConstellationSkill.tier_from(self,{'done':n},o)

def dawn_metrics(c,o):
    if not isinstance(c,dict):return 0,0,False
    down=integer(c.get('down_ms'),hi=o['time_limit_ms']);up=integer(c.get('up_ms'),hi=o['time_limit_ms'])
    p=trace(c,o)
    if down<o['prepare_ms'] or up<=down or not p:return 0,0,False
    charge=inside=total=0;over=False
    for t in range(down,up,40):
        hit=near(at(p,t),at(o['path'],t),o['radius']);total+=1;inside+=hit
        charge=max(0,charge+(40 if hit else -72));over|=charge>3600*o['factor']
    return charge/o['factor'],inside/max(1,total),over

class Dawn56(Replay,LastDawn):
    game,prompt='dawn_focus_56','Удерживайте луч на светящейся трещине и отпустите на зелёном заряде.'
    TIME_LIMIT_MS,PREP=7500,1000
    def pick_reactor(self,user,target,is_human):return user
    def game_params(self,user,target):
        o=self.params(user);f=o['factor'];o['radius']=24
        o['path']=[[round(t*f),180+80*math.sin(t/850),120+55*math.sin(t/1200+.8)] for t in range(0,8000,250)]
        return o
    def tier_from(self,c,o):
        charge,share,over=dawn_metrics(c,o)
        return 0 if not over and 2600<=charge<=3300 and share>=.9 else 1 if not over and charge>=1500 and share>=.6 else 2
    def apply(self,user,target,tier,data):return self._land(user,target,tier,False)

class RecallCut56(DamageSkill):
    copyable=False
    def is_available(self,user):
        return super().is_available(user) and any(m['turns']>1 for m in getattr(user,'thrown_machetes',[]))
    def _perform(self,user,target):
        logs=super()._perform(user,target)
        m=next((m for m in getattr(user,'thrown_machetes',[]) if m['turns']>1),None)
        if m:m['turns']-=1;logs.append(f'🪃 Зов клинка ускоряет возвращение мачете: осталось {m["turns"]} х.')
        return logs
    def ai_score(self,user,target):
        from .ai import strike_value
        return strike_value(user,target,.7,skill=self)+user.get_damage()*.48 if self.is_available(user) else 0

def blade_result(c,o):
    actions=events(c,'actions',o,4);used=set();perfect=good=0;bad_catches=0
    if any(sum(a.get('hand')==i for a in actions)>2 for i in (0,1)):return 3,2
    for e in o['events']:
        candidates=[(abs(a['ms']-e['ms']),j) for j,a in enumerate(actions) if j not in used and integer(a.get('hand'),hi=1)==e['hand']]
        err,j=min(candidates,default=(1e9,-1))
        if j>=0:used.add(j)
        p=(55 if e['catch'] else 65)*o['factor'];g=(130 if e['catch'] else 160)*o['factor']
        perfect+=err<=p;good+=err<=g
        if e['catch'] and err>g:bad_catches+=1
    tier=0 if perfect==4 else 1 if good>=3 else 2 if good>=2 else 3
    return tier,bad_catches

class MacheteCross56(Replay,MiniGameSkill):
    game,prompt='machete_route_56','Два броска и два перехвата: работайте левой и правой рукой в зелёных окнах.'
    TIME_LIMIT_MS,PREP=7600,1200
    TIERS=('Четыре идеала','Перехлёст','Рваный бросок','Упущенные клинки')
    AI_WEIGHTS=(10,25,40,25)
    TIER_VALUE=(2.55,1.65,.75,0)
    def game_params(self,user,target):
        o=self.params(user);f=o['factor'];j=random.randint(-100,100)
        o['events']=[{'hand':0,'ms':round((2700+j)*f),'catch':False},{'hand':1,'ms':round((3500-j)*f),'catch':False},
                     {'hand':0,'ms':round((5100+j)*f),'catch':True},{'hand':1,'ms':round((6250-j)*f),'catch':True}]
        return o
    def tier_from(self,c,o):return blade_result(c,o)[0]
    def result_data(self,c,o):return {'bad_catches':blade_result(c,o)[1]}
    def ai_choice(self,user,target,tier):return {'bad_catches':(0,0,1,2)[tier]}
    def apply(self,user,target,tier,data):
        logs=[Announcement(f'🪃 {user.name} — «{self.name}»: {self.TIERS[tier]}.')]
        n=2 if tier<2 else 1
        if self.TIER_VALUE[tier]:
            for _ in range(n):
                if target.is_alive():logs+=self.strike(user,target,self.TIER_VALUE[tier]/n,pierce=.25 if tier==0 else 0)[0]
        if tier==0 and target.is_alive():target.add_effect(scale_effect(Bleed(2,4),user))
        bad=data.get('bad_catches',(0,0,1,2)[tier]) if isinstance(data,dict) else (0,0,1,2)[tier]
        if bad:
            loss=max(1,round(user.max_hp*.03*bad));before=user.hp;user.hp-=loss
            logs.append(f'🩸 Пропущено возвратов: {bad}. Собственные клинки отнимают {before-user.hp} HP.')
        return logs
    def ai_score(self,user,target):
        from .ai import strike_value
        if user.hp<=round(user.max_hp*.06):return 0
        value=sum(w*strike_value(user,target,m,force=True,pierce=.25 if i==0 else 0) for i,(w,m) in enumerate(zip(self.AI_WEIGHTS,self.TIER_VALUE)))/100
        return max(0,value-user.max_hp*.03*(.4+.25*2)+.8)

def cut_tier(c,o):
    if not isinstance(c,dict):return 3
    down=integer(c.get('down_ms'),hi=o['time_limit_ms']);up=integer(c.get('up_ms'),hi=o['time_limit_ms'])
    p=[a for a in trace(c,o) if down<=a[0]<=up]
    if down<o['prepare_ms'] or not 220*o['factor']<=up-down<=1600*o['factor'] or len(p)<6:return 3
    start,end=o['entry'],o['exit'];dx,dy=end[0]-start[0],end[1]-start[1];length=math.hypot(dx,dy)
    ends=max(math.dist(p[0][1:],start),math.dist(p[-1][1:],end))
    dev=max(abs(dx*(y-start[1])-dy*(x-start[0]))/length for _,x,y in p)
    travel=sum(math.dist(a[1:],b[1:]) for a,b in zip(p,p[1:]));straight=length/max(length,travel)
    err=min(abs(up-t) for t in o['beats'])/o['factor']
    return 0 if ends<=11 and dev<=12 and straight>=.92 and err<=55 else 1 if ends<=23 and dev<=24 and straight>=.85 and err<=150 else 2 if ends<=38 and dev<=40 and straight>=.6 and err<=300 else 3

class VitalCut56(Replay,MiniGameSkill):
    game,prompt='vital_cut_56','Проведите точный разрез от первой метки ко второй и отпустите на вспышке сердца.'
    TIME_LIMIT_MS,PREP=6500,1000
    TIERS=('Смертельный крит','Точный разрез','Скользящий рез','Промах')
    AI_WEIGHTS=(18,32,30,20)
    TIER_VALUE=(1.6,1.25,.75,0)
    def game_params(self,user,target):
        o=self.params(user);y=random.randint(65,110);o.update(entry=[80,y],exit=[280,random.randint(150,190)],beats=[round(t*o['factor']) for t in (1700,2900,4100,5300)]);return o
    def tier_from(self,c,o):return cut_tier(c,o)
    def apply(self,user,target,tier,data):
        logs=[Announcement(f'🗡 {user.name} — «{self.name}»: {self.TIERS[tier]}.')]
        if tier==3:return logs
        saved=self.crit_bonus;self.crit_bonus=(1,.35,0)[tier]
        try:logs+=self.strike(user,target,self.TIER_VALUE[tier],pierce=.25 if tier==0 else 0)[0]
        finally:self.crit_bonus=saved
        return logs
    def ai_score(self,user,target):
        from .ai import strike_value
        return sum(w*strike_value(user,target,self.TIER_VALUE[i],force=True,crit_bonus=(1,.35,0,0)[i],pierce=.25 if i==0 else 0) for i,w in enumerate(self.AI_WEIGHTS))/100

REWARDS = {
 'hunt_lead_56':'До шести стрел, суммарно ×2.2 при 6 попаданиях.',
 'knife_flick_56':'Обычное попадание ×0.4; 5/5 — каждый нож ×0.7 и повышенный шанс кровотечения.',
 'spirit_guide_56':'8+ духов: лечение 20% HP и зверь +30% урона на 3 хода; 5–7: 12% и +15%; 2–4: 6%; 0–1: 2%.',
 'nest_catch_56':'5–6 совят: два мини-совуха; 3–4: один; 1–2: слабый; 0: штраф точности. С третьего хода.',
 'night_focus_56':'За каждое попадание удар ×0.9; 3/3 — последний удар критический и вызывает кровотечение.',
 'soul_tether_56':'Пять душ: удар ×1.4 и вампиризм 125%; меньше душ — слабее удар и лечение.',
 'stone_stack_56':'4/4: щит 22% HP и отражение 20% на 3 хода; 3/4: щит 15%; 1–2/4: 8%; 0/4: 3%.',
 'shadow_erase_56':'За каждую печать удар ×0.7 сквозь броню; 3+ — страх, 4 — ещё оглушение.',
 'light_prism_56':'Идеал ×2.16 сквозь броню, хорошее попадание ×1.68; ослепление −15% точности на 2 хода.',
 'star_lead_56':'Каждое попадание ×0.8; при 3/3 последняя стрела получает +60% к шансу крита.',
 'star_pattern_56':'5/5: лечение 12% HP и щит 10%; 3–4: лечение 10%; 1–2: 5%; 0: без лечения.',
 'dawn_focus_56':'Идеал ×2.52 сквозь броню, хороший фокус ×1.96; лечит на 20% урона по живой цели. Раз за бой при HP ниже 30%.',
}

ADAPTERS={
 ('archer','hunt'):Hunt56,('assassin','knives'):Knives56,('druid','forest_call'):Forest56,
 ('owlbeast','night_hunt'):Night56,('owlbeast','nephews'):Nephews56,('darkknight','soul_siphon'):Souls56,
 ('rhino','stone_armor'):Stone56,('shade','skull'):Skull56,('lightelf','light_pillar'):Pillar56,
 ('lightelf','star_arrow'):StarArrow56,('lightelf','constellation'):Constellation56,('lightelf','last_dawn'):Dawn56,
}

def install(classes):
    for key in {h for h,_ in ADAPTERS}|{'bluetroll','assassin'}:
        cls=classes[key];original=cls._create_skills
        def factory(self,_original=original,_key=key):
            result=[]
            for s in _original(self):
                adapter=ADAPTERS.get((_key,s.key))
                if adapter:
                    s=copy.copy(s);s.__class__=adapter;s.prompt=adapter.prompt
                    s.description=adapter.prompt+' '+REWARDS[adapter.game]
                result.append(s)
            if _key=='bluetroll':
                result += [RecallCut56('recall_cut','Зов клинка','Удар ×0.7; ускоряет возврат одного летящего мачете на ход, не раньше следующего собственного хода',multiplier=.7,cost=14,cooldown=3,icon='🪃'),
                           MacheteCross56('machete_cross','Перехлёст клинков','Четыре точных действия. Пропущенный возврат отнимает 3% максимальных HP; идеал ×2.55 и кровотечение',cost=30,cooldown=6,icon='🪃')]
            if _key=='assassin':result.append(VitalCut56('vital_cut','Точка смерти','Один точный разрез в ритм сердца: идеал ×1.6 с гарантированным критом и игнором 25% брони',cost=35,cooldown=6,icon='🗡'))
            return result
        cls._create_skills=factory
