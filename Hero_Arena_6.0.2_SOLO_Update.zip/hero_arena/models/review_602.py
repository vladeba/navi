"""Solo duel review. Static opponent rules, identical for players and AI.

No simulated result, seat, execution profile or live win rate is consulted here.
"""
import random
from .character import Character
from .effects import Shield, DamageReduction, DamageOverTime, Poison, Bleed, Stun
from .review_600 import sync_original

# Explicitly agreed decisions. Values are additive to the 6.0.1 arena baseline.
RULES = {
 ('ogre','shade'): {'attrs':{'GLANCING':.19}},
 ('shade','ogre'): {'hp':7},
 ('assassin','shade'): {'hp':9,'attrs':{'_twins_bypass':.65}},
 ('minotaur','bluetroll'): {'hp':15,'armor':1},
 ('paladin','bluetroll'): {'hp':5,'attrs':{'_divine_reduction':30},'skills':{'smite':{'multiplier':1.9}}},
 ('mersey','mage'): {'hp':10,'attrs':{'_magic_hit_resist':.087}},
 ('mersey','catfolk'): {'attrs':{'DODGE_PIERCE':.18}},
 ('catfolk','mersey'): {'hp':10},
 ('bogatyr','spartan'): {'hp':15,'attrs':{'MIGHT_CAP_PER_TURN':22}},
 ('leon','samurai'): {'hp':10,'armor':.5,'attrs':{'_confidence_floor':-1}},
 ('pagan','satyr'): {'hp':7,'attrs':{'_mokosh_fraction':.14},'skills':{'thunder':{'accuracy':.90},'attack':{'multiplier':1.04}}},
 ('bluetroll','leon'): {'hp':20,'armor':.3,'direct':1.073},
 ('ogre','satyr'): {'attrs':{'GLANCING':.25}},
 ('satyr','ogre'): {'hp':11},
 # Autonomous continuation approved after the first twelve pairs.
 ('spartan','assassin'): {'hp':8,'attrs':{'_assassin_dot_resist':.20}},
}


def active(hero, enemy):
    return getattr(hero,'_review602_active',False) and getattr(getattr(hero,'opponent',None),'type_key',None)==enemy


def clear(hero):
    previous=getattr(hero,'_review602_restore',None)
    if previous:
        hero.max_hp-=previous['hp'];hero.hp=min(hero.hp,hero.max_hp)
        hero._armor-=previous['armor']
        for key,(existed,value) in previous['attrs'].items():
            if existed:setattr(hero,key,value)
            elif key in hero.__dict__:delattr(hero,key)
        for skill,attrs in previous['skills']:
            sync_original(skill,attrs)
    hero._review602_restore=None;hero._review602_active=False
    hero._matchup_damage602=1.0


def install(classes):
    from . import review_600
    from .heroes_42 import ShadowTwins
    from .heroes_54 import Catfolk,DivineShieldSkill
    from .heroes_55 import Leon
    from .necromancy_55 import Undead
    from .tuning_602 import PAIR_DAMAGE

    prior_reset=Character.reset
    def reset(self):
        clear(self)
        return prior_reset(self)
    Character.reset=reset
    prior_config=Character.configure_arena
    def arena(self):
        clear(self)
        return prior_config(self)
    Character.configure_arena=arena

    prior_pair=review_600.configure_pair
    def pair(battle):
        prior_pair(battle)
        if battle.story or not review_600.PAIR_RULES_ENABLED:return
        for hero in (battle.hero1,battle.hero2):
            hero._review602_active=True
            key=(hero.type_key,hero.opponent.type_key)
            rule=RULES.get(key,{})
            state={'hp':rule.get('hp',0),'armor':rule.get('armor',0),'attrs':{},'skills':[]}
            hero._review602_restore=state
            hero.max_hp+=state['hp'];hero.hp=hero.max_hp
            hero._armor+=state['armor']
            for name,value in rule.get('attrs',{}).items():
                state['attrs'][name]=(name in hero.__dict__,getattr(hero,name,None))
                setattr(hero,name,value)
            for name,attrs in rule.get('skills',{}).items():
                skill=hero.skills[name]
                actual=dict(attrs)
                if name=='attack' and 'multiplier' in actual:actual['multiplier']*=skill.multiplier
                state['skills'].append((skill,{a:getattr(skill,a) for a in actual}))
                sync_original(skill,actual)
            if 'direct' in rule:
                hero._duel_damage=rule['direct']
                hero._match_notes=[msg for msg in hero._match_notes if not msg.startswith('Особенность дуэли против ')]
            hero._matchup_damage602=PAIR_DAMAGE.get(key,1.0)
            notes=[]
            if state['hp']:notes.append('+%s HP'%state['hp'])
            if state['armor']:notes.append('+%s брони'%state['armor'])
            labels={'GLANCING':'урон Тяжёлой руки','_twins_bypass':'обход теневых двойников',
                    '_divine_reduction':'снижение урона Эгидой света, %','_magic_hit_resist':'защита от прямых ударов сквозь броню',
                    'DODGE_PIERCE':'доля игнорируемого уклонения','MIGHT_CAP_PER_TURN':'лимит мощи за ход',
                    '_confidence_floor':'нижний предел уверенности','_mokosh_fraction':'щит Мокоши от HP',
                    '_assassin_dot_resist':'защита от яда и кровотечения Альтаира'}
            for name,value in rule.get('attrs',{}).items():
                shown=('%s%%'%round(value*100,2)) if name not in ('MIGHT_CAP_PER_TURN','_confidence_floor','_divine_reduction') else str(value)
                notes.append('%s: %s'%(labels[name],shown))
            for name,attrs in rule.get('skills',{}).items():
                for field,value in attrs.items():
                    if field=='accuracy':notes.append('точность «%s»: %s%%'%(hero.skills[name].name,round(value*100)))
                    elif field=='multiplier':notes.append(('урон обычной атаки +4%' if name=='attack' else 'урон «%s»: ×%s'%(hero.skills[name].name,value)))
            if 'direct' in rule:notes.append('бонус прямого урона заменён на +7,3%')
            if key==('getou','minotaur'):notes.append('неидеальная нежить игнорирует 1 брони обычными атаками')
            if hero._matchup_damage602!=1:notes.append('урон прямых атак ×%.4f'%hero._matchup_damage602)
            if notes:
                msg='Условия дуэли против %s: %s.'%(hero.opponent.name,'; '.join(notes))
                hero._match_notes.append(msg);battle._add_log(msg)
    review_600.configure_pair=pair

    # A failed own execution may be blocked by the ward, but is not an enemy
    # stun and must neither heal nor consume the one enemy-stun healing charge.
    prior_add=Character.add_effect
    def add_effect(self,effect):
        if isinstance(effect,Stun) and getattr(effect,'self_inflicted',False):
            ward=next((e for e in self.get_effects() if isinstance(e,review_600.ColdEyes) and e.duration>0),None)
            if ward:return False
        return prior_add(self,effect)
    Character.add_effect=add_effect

    prior_mult=Character.damage_multiplier
    def multiplier(self):return prior_mult(self)*getattr(self,'_matchup_damage602',1)
    Character.damage_multiplier=multiplier

    prior_twins=ShadowTwins.modify_incoming
    def twins(self,owner,damage,attacker):
        chance=getattr(attacker,'_twins_bypass',0)
        if chance and damage>0 and self.power>0 and random.random()<chance:
            return damage,['🗡 Альтаир распознаёт двойника и бьёт настоящую цель.']
        return prior_twins(self,owner,damage,attacker)
    ShadowTwins.modify_incoming=twins

    prior_undead=Undead.__init__
    def undead(self,owner,kind,tier,slot):
        prior_undead(self,owner,kind,tier,slot)
        if active(owner,'minotaur') and tier>0:
            self.ARMOR_PIERCE_FLAT=1
    Undead.__init__=undead

    prior_divine=DivineShieldSkill._perform
    def divine(self,user,target):
        result=prior_divine(self,user,target)
        power=getattr(user,'_divine_reduction',20)
        if power!=20:
            effect=next(e for e in reversed(user._effects) if isinstance(e,DamageReduction) and e.name=='Божественная защита')
            effect.power=power
            result=[s.replace('−20%','−%s%%'%power) for s in result]
        return result
    DivineShieldSkill._perform=divine

    def divine_score(self,user,target):
        from .ai import threat,horizon
        if user.has_effect(Shield):return 0
        turns=horizon(user,target);incoming=threat(target,user)
        return min(user.max_hp*.18,incoming*turns)+incoming*getattr(user,'_divine_reduction',20)/100*min(2,turns)
    DivineShieldSkill.ai_score=divine_score
    def divine_description(self,user):
        return 'Щит на 18%% максимальных HP на 3 хода; −%s%% входящего урона на 2 хода.'%getattr(user,'_divine_reduction',20)
    DivineShieldSkill.describe_for=divine_description
    from .skills import SelfBuffSkill
    prior_buff_description=SelfBuffSkill.describe_for
    def buff_description(self,user):
        if user.type_key=='pagan' and self.key=='mokosh_cover':
            return 'Щит на %s%% максимальных HP на 3 хода.'%round(getattr(user,'_mokosh_fraction',.1)*100)
        return prior_buff_description(self,user)
    SelfBuffSkill.describe_for=buff_description

    prior_take=Character.take_damage
    def take(self,amount,ignore_armor=False,attacker=None):
        if ignore_armor and attacker is not None and active(self,'mage'):
            amount*=1-getattr(self,'_magic_hit_resist',0)
        return prior_take(self,amount,ignore_armor,attacker)
    Character.take_damage=take

    prior_form=Catfolk.set_form
    def form(self,cat):
        bonus=(getattr(self,'_review602_restore',None) or {}).get('hp',0)
        if not bonus:return prior_form(self,cat)
        from .arena_rules import ARENA_HP,CATFOLK_WARRIOR_HP
        maximum=(CATFOLK_WARRIOR_HP if cat else ARENA_HP['catfolk'])+bonus
        hp=max(1,self.hp*maximum//self.max_hp) if self.hp else 0
        self.max_hp=maximum;self._raw_hp=maximum;self.hp=hp;self.cat_form=cat
    Catfolk.set_form=form

    prior_initiative=Leon.on_initiative
    def initiative(self,first):
        prior_initiative(self,first)
        self.confidence=max(getattr(self,'_confidence_floor',-2),self.confidence)
    Leon.on_initiative=initiative

    prior_factory=classes['pagan']._create_skills
    def pagan(self):
        skills=prior_factory(self)
        cover=next(s for s in skills if s.key=='mokosh_cover')
        cover.effects=[lambda:Shield(3,int(self.max_hp*getattr(self,'_mokosh_fraction',.10)/self.power_scale()))]
        return skills
    classes['pagan']._create_skills=pagan

    prior_dot=DamageOverTime.on_turn_start
    def dot(self,owner):
        resist=getattr(owner,'_assassin_dot_resist',0) if isinstance(self,(Poison,Bleed)) else 0
        if not resist:return prior_dot(self,owner)
        old=owner.DOT_RESIST
        owner.DOT_RESIST=1-(1-old)*(1-resist)
        try:return prior_dot(self,owner)
        finally:owner.DOT_RESIST=old
    DamageOverTime.on_turn_start=dot
