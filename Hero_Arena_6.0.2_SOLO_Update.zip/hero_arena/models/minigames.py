"""4.0: мини-игры героев (наследники MiniGameSkill) и особые умения новой версии.

У каждой мини-игры результат по шагам (tier 0 — лучший): частичный успех даёт частичный эффект.
Интерфейс получает параметры игры (pending.options.game), игрок присылает результат
(POST /api/battles/<id>/react {"choice": {...}}), сервер проверяет время и считает исход.
"""
import random

from .effects import (Announcement, Shield, StunWard, Berserk, Burn, Bleed, DamageReduction, Weakened,
                      MastBuff, Stun, CalmShield, GodGift, BeastForm, Chill, Slow, Antiheal)
from .skills import MiniGameSkill, ChoiceSkill, Skill, SelfBuffSkill, scale_effect


def _pct_shield(user, pct, turns=3, cls=Shield):
    eff = cls(turns, max(1, int(user.max_hp * pct)))
    user.add_effect(eff)
    return eff


# ---------------- Воин: «Доспех» ----------------
class ArmorCrossesSkill(MiniGameSkill):
    """«Доспех» воина: на броне 6 крестиков-трещин — стащите их мышкой за 4 с.
    6 — щит 13% HP и +1 броня/иммунитет к оглушению на 3 хода; 3–5 — щит 11.5%; 0–2 — щит 8%."""

    game, prompt = "drag_crosses", "Стащите мышкой крестики с брони!"
    MG_ICON = "✖"
    MG_ACCENT = "#e05555"
    TIME_LIMIT_MS = 4000
    TIERS = ("Крепость 6/6", "Починка 3–5", "Заплатка 0–2")
    AI_WEIGHTS = (35, 45, 20)
    CROSSES = 6

    def game_params(self, user, target):
        return {"crosses": [[random.randint(12, 82), random.randint(15, 80)] for _ in range(self.CROSSES)]}

    def tier_from(self, choice, options):
        k = int(choice.get("removed", 0)) if isinstance(choice, dict) else int(choice)
        return 0 if k >= self.CROSSES else 1 if k >= 3 else 2

    def apply(self, user, target, tier, data):
        pct = (0.13, 0.115, 0.08)[tier]
        eff = _pct_shield(user, pct)
        text = f"🛡 {user.name} чинит доспех ({self.TIERS[tier]}): щит на {eff.power} урона."
        if tier == 0:
            user.add_effect(StunWard(3, 1))
            return [Announcement(text + " Броня +1, оглушение не берёт!")]
        return [text]

    def ai_score(self, user, target):
        if user.has_effect(Shield):
            return 0
        return 16 if user.hp < user.max_hp * 0.7 else 7


# ---------------- Лучник: «Охота» ----------------
class DeerHuntSkill(MiniGameSkill):
    """«Охота» лучника: за 5 с появляются 6 голов оленей — кликайте по ним. Попадания — стрелы:
    1–4 оленя — по ×0.45, 5-й и 6-й — по ×0.2 (итого до ×2.2)."""

    game, prompt = "click_targets", "Кликайте по головам оленей!"
    MG_ICON = "🦌"
    MG_ACCENT = "#8b5a2b"
    TIME_LIMIT_MS = 3800  # 5.4
    TARGETS, ICON = 6, "🦌"
    TIERS = tuple(f"{k}/6" for k in range(6, -1, -1))
    AI_WEIGHTS = (8, 17, 25, 22, 14, 9, 5)
    PER_HIT = 0.45
    HIT_TOTAL = (0, 0.45, 0.9, 1.35, 1.8, 2.0, 2.2)    # суммарный множитель за k попаданий

    def game_params(self, user, target):
        return {"count": self.TARGETS, "icon": self.ICON, "spawn_ms": self.TIME_LIMIT_MS // (self.TARGETS + 1)}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice)
        return self.TARGETS - max(0, min(self.TARGETS, k))

    def expected_value(self):
        w = self.AI_WEIGHTS
        return sum(a * self.HIT_TOTAL[self.TARGETS - i] for i, a in enumerate(w)) / sum(w)

    def apply(self, user, target, tier, data):
        hits = self.TARGETS - tier
        logs = [f"🦌 {user.name} на охоте: {hits}/{self.TARGETS} попаданий!"]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, self.HIT_TOTAL[hits] / hits)
            logs.extend(part)
        if hits == 0:
            logs.append(f"🦌 Олени разбежались — {user.name} не попал ни разу.")
        return logs


# ---------------- Огр: «Пир людоеда» ----------------
class FeastSkill(MiniGameSkill):
    """«Пир людоеда» огра (5.4: быстрее): запомните 4 ингредиента и повторите. Перец 🌶 — ловушка (огненная отрыжка)!
    4/4 — +13% HP и Берсерк +12%; 2–3 — +10% HP; 0–1 — +5% HP; перец — горение врагу и −4% HP себе."""

    game, prompt = "memory", "Запомните ингредиенты и повторите по порядку!"
    MG_ICON = "🍖"
    MG_ACCENT = "#e08a3c"
    TIME_LIMIT_MS = 4500  # 5.4: было 7000
    TIERS = ("Пир 4/4", "Перекус 2–3", "Крошки 0–1", "🌶 Перец!")
    AI_WEIGHTS = (30, 40, 20, 10)
    FOOD = ["🍖", "🧀", "🍄", "🐟", "🥕", "🍗", "🥚"]

    def game_params(self, user, target):
        seq = random.sample(self.FOOD, 4)
        pool = seq + random.sample([f for f in self.FOOD if f not in seq], 2) + ["🌶"]
        random.shuffle(pool)
        return {"sequence": seq, "pool": pool, "show_ms": 1400}

    def tier_from(self, choice, options):
        picked = choice.get("picked", []) if isinstance(choice, dict) else []
        if "🌶" in picked:
            return 3
        seq = options.get("sequence", [])
        right = sum(1 for a, b in zip(picked, seq) if a == b)
        return 0 if right >= 4 else 1 if right >= 2 else 2

    def apply(self, user, target, tier, data):
        if tier == 3:
            burn = scale_effect(Burn(3, 6), user)
            target.add_effect(burn)
            user.hp = user.hp - int(user.max_hp * 0.04)
            return [Announcement(f"🌶 {user.name} съел перец! Огненная отрыжка поджигает {target.name} "
                                 f"({burn.power}/ход), но язык горит: −{int(user.max_hp * 0.04)} HP.")]
        healed = user.heal(int(user.max_hp * (0.13, 0.10, 0.05)[tier]))
        logs = [f"🍖 {user.name} пирует ({self.TIERS[tier]}): +{healed} HP."]
        if tier == 0:
            user.add_effect(Berserk(3, 12))
            logs.append(Announcement(f"😡 Сытый {user.name} в ярости: +12% урона на 3 хода!"))
        return logs

    def ai_score(self, user, target):
        return 18 if user.hp < user.max_hp * 0.6 else 4


# ---------------- Спартанец: «Стена щитов» и «Читай врага» ----------------
class ShieldWallSkill(MiniGameSkill):
    """«Стена щитов»: кольцо сжимается — нажмите, когда оно совпадёт с щитом.
    Точно (±90 мс) — −50% урона 2 хода и иммунитет к оглушению; рядом (±220 мс) — −35% 2 хода; мимо — −15% 1 ход."""

    game, prompt = "timing_ring", "Нажмите, когда кольцо совпадёт со щитом!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🛡", "#f5b942", "#4cd07d"
    MG_HINT = "Нажмите в любом месте поля, когда кольцо совпадёт со щитом"
    TIME_LIMIT_MS = 2800  # 5.4: быстрее, окно уже
    TIERS = ("Стена!", "Строй", "Брешь")
    AI_WEIGHTS = (25, 45, 30)

    def game_params(self, user, target):
        return {"period_ms": random.randint(700, 1000)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 70 else 1 if err <= 160 else 2

    def apply(self, user, target, tier, data):
        power, turns = ((45, 2), (35, 2), (15, 1))[tier]
        user.add_effect(DamageReduction(turns, power, stun_immune=tier == 0, title="Стена щитов"))
        text = f"🛡 {user.name} — «Стена щитов» ({self.TIERS[tier]}): −{power}% урона на {turns} х."
        return [Announcement(text) if tier == 0 else text]

    def ai_score(self, user, target):
        return 0 if user.has_effect(DamageReduction) else (15 if user.hp < user.max_hp * 0.75 else 8)


class ReadEnemy(DamageReduction):
    """Метка «Читай врага»: спартанец угадывает следующее действие врага."""

    name, icon = "Читай врага", "👁"

    def __init__(self, guess):
        super().__init__(2, 0)
        self.guess = guess

    def modify_incoming(self, owner, damage, attacker):
        return damage, []


class ReadEnemySkill(ChoiceSkill):
    """«Читай врага» спартанца: угадайте СЛЕДУЮЩЕЕ действие врага — атака, умение или защита.
    Угадал — Леонид бьёт первым (×1.0) и гасит 70% урона этого действия; не угадал — ничего."""

    game, prompt = "read_enemy", "Что сделает враг: атака, умение или защита?"
    MG_ICON = "👁"
    MG_ACCENT = "#4c8dff"
    CHOICES = {"attack": "⚔ Обычная атака", "skill": "✨ Умение", "defense": "🛡 Защита/предмет"}

    def game_params(self, user, target):
        return {"choices": self.CHOICES}

    def ai_choice(self, user, target, tier):
        has_skill = any(target.can_use(s) and hasattr(s, "multiplier") and s.key != "attack"
                        for s in target.skills.values())
        weights = {"attack": 30, "skill": 55 if has_skill else 10, "defense": 15}
        return random.choices(list(weights), weights=list(weights.values()))[0]

    def apply(self, user, target, tier, data):
        guess = data if data in self.CHOICES else random.choice(list(self.CHOICES))
        user.add_effect(ReadEnemy(guess))
        return [f"👁 {user.name} читает врага… (тайный выбор сделан)"]

    def ai_score(self, user, target):
        return 0 if user.has_effect(ReadEnemy) else 13


# ---------------- Самурай: «Шунпо» и «Спокойствие» ----------------
class ShunpoSkill(MiniGameSkill):
    """«Шунпо» самурая: на манекене по очереди вспыхивают 3 зоны (голова, корпус, ноги) — успейте нажать.
    Рывки с пробитием 50% брони: 3/3 — 3 × 0.58, 2/3 — 2 × 0.72, 1/3 — 1 × 0.9."""

    game, prompt = "zones", "Жмите на вспыхнувшую зону манекена!"
    MG_ICON = "⚡"
    MG_ACCENT = "#e05555"
    TIME_LIMIT_MS = 3000  # 5.4: было 4500 — темп как у броска ножей
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (20, 38, 28, 14)
    PER_HIT = 0.75
    TIER_PER_HIT = (0.58, 0.72, 0.9, 0.0)

    def game_params(self, user, target):
        return {"zones": ["head", "body", "legs"], "sequence": [random.choice(["head", "body", "legs"]) for _ in range(3)],
                "flash_ms": 550}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice)
        return 3 - max(0, min(3, k))

    def expected_value(self):
        w = self.AI_WEIGHTS
        return sum(a * (3 - i) * self.TIER_PER_HIT[i] for i, a in enumerate(w)) / sum(w)

    def ai_score(self, user, target):
        from .ai import strike_value,tier_average
        return tier_average(self,user,[strike_value(user,target,self.TIER_PER_HIT[i],3-i,pierce=0.5,force=True)
                                      for i in range(len(self.TIERS))])

    def apply(self, user, target, tier, data):
        hits = 3 - tier
        logs = [f"⚡ {user.name} — Шунпо: {hits}/3 рывка!"]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, self.TIER_PER_HIT[tier], pierce=0.5)
            logs.extend(part)
        return logs


# ---------------- Ассасин: «Бросок ножей», «Какой ты масти?» ----------------
class KnifeThrowSkill(DeerHuntSkill):
    """«Бросок ножей» ассасина: 5 крестиков за 3 с. 5.4: идеал награждает сильнее (×0.55 + bleed)."""

    game, prompt = "click_targets", "Попадите ножами по 5 крестикам!"
    MG_ICON = "🗡"
    MG_ACCENT = "#a0a8b8"
    TIME_LIMIT_MS = 3000
    TARGETS, ICON = 5, "✖"
    TIERS = tuple(f"{k}/5" for k in range(5, -1, -1))
    AI_WEIGHTS = (8, 18, 28, 22, 14, 10)  # 5.4: идеал реже у среднего ИИ
    PER_HIT = 0.4
    PER_HIT_PERFECT = 0.7  # 5/5

    def expected_value(self):
        w = self.AI_WEIGHTS
        return sum(a * (self.TARGETS - i) * self.PER_HIT for i, a in enumerate(w)) / sum(w)

    def apply(self, user, target, tier, data):
        hits = self.TARGETS - tier
        per = self.PER_HIT_PERFECT if hits >= self.TARGETS else self.PER_HIT
        bleed_chance = 0.45 if hits >= self.TARGETS else 0.2
        logs = [f"🔪 {user.name} бросает ножи: {hits}/{self.TARGETS} в цель!"]
        if hits >= self.TARGETS:
            logs = [Announcement(f"🔪 Идеальный град ножей {user.name}!")]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, dmg = self.strike(user, target, per)
            logs.extend(part)
            if dmg and target.is_alive() and random.random() < bleed_chance:
                target.add_effect(scale_effect(Bleed(3, 5 if hits >= self.TARGETS else 4), user))
                logs.append(f"🩸 Нож оставляет рану у {target.name}.")
        return logs


class MastSkill(Skill):
    """«Какой ты масти?» ассасина: 4 хода +35% урона по лёгким, +17% по воинам, +5% по танкам, +10% по ловкачам."""

    copyable = False

    BONUS = {"light": 35, "warrior": 17, "tank": 5, "monster": 5, "trickster": 10}

    def _perform(self, user, target):
        power = self.BONUS.get(getattr(target, "role", "warrior"), 10)
        user.add_effect(MastBuff(4, power))
        role = target.ROLE_NAMES.get(target.role, "") if hasattr(target, "ROLE_NAMES") else ""
        return [Announcement(f"🃏 {user.name}: «Какой ты масти?» — {target.name} ({role}): +{power}% урона на 4 хода!")]

    def ai_score(self, user, target):
        if user.has_effect(MastBuff):
            return 0
        return 6 + self.BONUS.get(getattr(target, "role", "warrior"), 10) * 0.5


# ---------------- Тёмный эльф: «Ритуал теней», «Ты слаб», «Кровавый щит» ----------------
class ShadowRitualSkill(MiniGameSkill):
    """«Ритуал теней» эльфа (риск): 5 рун рубашкой вверх, одна проклята. Открывайте руны по одной
    и остановитесь, когда хватит: каждая чистая руна +0.55 к удару (база ×0.9, сквозь броню; 5.4 mastery).
    Открыли проклятую — ритуал срывается: −8% HP себе и никакого урона."""

    game, prompt = "runes_risk", "Открывайте руны. Одна проклята — вовремя остановитесь!"
    MG_ICON = "ᚱ"
    MG_ACCENT = "#a45cff"
    TIME_LIMIT_MS = 5500  # 5.4: было 9000
    RUNES = 5
    TIERS = ("ритуал",)
    AI_WEIGHTS = (1,)

    def secret_pick(self, options=None):
        secret = super().secret_pick(options)
        secret["cursed"] = random.randrange(self.RUNES)
        return secret

    def game_params(self, user, target):
        return {"runes": self.RUNES}

    def resolve(self, user, target, choice, secret):
        flipped = choice.get("flipped", []) if isinstance(choice, dict) else []
        flipped = [int(x) for x in flipped if str(x).lstrip("-").isdigit() and 0 <= int(x) < self.RUNES]
        flipped = list(dict.fromkeys(flipped))
        late = secret.get("deadline") and __import__("time").time() > secret["deadline"]
        cursed = secret.get("cursed", 0)
        return self._ritual(user, target, flipped, cursed, timeout=choice == "timeout" or late)

    def _perform(self, user, target):  # ИИ: открывает 1–3 руны наугад
        k = random.choice([1, 2, 2, 3])
        order = random.sample(range(self.RUNES), k)
        return self._ritual(user, target, order, random.randrange(self.RUNES))

    def _ritual(self, user, target, flipped, cursed, timeout=False):
        if cursed in flipped:
            loss = int(user.max_hp * 0.08)
            user.hp = user.hp - loss
            return [Announcement(f"💀 {user.name} открыл проклятую руну! Ритуал срывается: −{loss} HP.")]
        k = 0 if timeout else len(flipped)
        logs = [f"🔮 {user.name} — Ритуал теней: чистых рун {k}."]
        part, _ = self.strike(user, target, 0.85 + 0.7 * k, ignore_armor=True)  # 5.4 mastery
        return logs + part

    def ai_score(self, user, target):
        return max(1, user.get_damage()) * 1.55


class BloodShieldSkill(Skill):
    """«Кровавый щит» эльфа: платит 10% своего HP — щит на 22% макс. HP на 3 хода."""

    copyable = False

    def is_available(self, user):
        return super().is_available(user) and user.hp > user.max_hp * 0.2

    def _perform(self, user, target):
        cost = int(user.max_hp * 0.06)
        user.hp = user.hp - cost
        eff = _pct_shield(user, 0.22)
        return [f"🩸 {user.name} — «Кровавый щит»: −{cost} HP, щит на {eff.power} урона."]

    def ai_score(self, user, target):
        if user.has_effect(Shield) or user.hp < user.max_hp * 0.35:
            return 0
        return 14 if user.hp < user.max_hp * 0.8 else 6


# ---------------- Мушкетёр: «Дуэльный выстрел» ----------------
class DuelShotSkill(MiniGameSkill):
    """«Дуэльный выстрел» Рейва: цель движется — нажмите туда, где она окажется (упреждение).
    Центр — ×2.6 сквозь всю броню, кольцо — ×1.9, промах — осечка. Ружьё после выстрела разряжено."""

    copyable = False

    game, prompt = "moving_target", "Возьмите упреждение и стреляйте!"
    MG_ICON = "🎯"
    MG_ACCENT = "#e05555"
    TIME_LIMIT_MS = 5000
    TIERS = ("в центр", "в кольцо", "осечка")
    AI_WEIGHTS = (20, 45, 35)
    TIER_VALUE = (2.6, 1.9, 0.0)

    def is_available(self, user):
        return super().is_available(user) and getattr(user, "loaded", True)

    def game_params(self, user, target):
        return {"speed": random.randint(140, 220), "center_r": 12, "ring_r": 30}

    def tier_from(self, choice, options):
        zone = choice.get("zone") if isinstance(choice, dict) else choice
        return {"center": 0, "ring": 1}.get(zone, 2)

    def apply(self, user, target, tier, data):
        user.loaded = False
        if tier == 2:
            return [f"🔫 {user.name} — «Дуэльный выстрел»: осечка! Ружьё разряжено."]
        mult = self.TIER_VALUE[tier]
        head = Announcement(f"🎯 {user.name} попадает {self.TIERS[tier]}!") if tier == 0 else f"🎯 {user.name} попадает {self.TIERS[tier]}."
        part, _ = self.strike(user, target, mult, ignore_armor=tier == 0)
        return [head] + part


# ---------------- Язычник: «Молитва» и «Оборотень» ----------------
class PrayerSkill(ChoiceSkill):
    """«Молитва» Даагаша: два случайных бога из четырёх — выберите одного, его дар действует 3 хода.
    Перун: +4 урона к удару. Велес: +20% уклонения, 20% урона в HP. Мокошь: +1 броня, лечение 2%/ход.
    Морена: +1 урон, удары замедляют на 2 и морозят (5 урона/ход)."""

    game, prompt = "prayer", "Выберите бога, чья милость снизойдёт на вас!"
    MG_ICON = "🙏"
    MG_ACCENT = "#ffe08a"
    GODS = {"perun": "⚡ Перун: +4 урона к каждому удару", "veles": "🐍 Велес: +20% уклонения, 20% урона в HP",
            "mokosh": "🌾 Мокошь: +1 броня, лечение 2%/ход", "morena": "❄ Морена: +1 урон, удары замедляют и морозят (5/ход)"}

    def game_params(self, user, target):
        gods = random.sample(list(self.GODS), 3)
        return {"gods": {g: self.GODS[g] for g in gods}}

    def _perform(self, user, target):  # ИИ: сам выбирает бога по ситуации
        gods = random.sample(list(self.GODS), 3)
        return self.apply(user, target, 0, self._ai_pick(user, target, gods))

    def _ai_pick(self, user, target, gods):
        order = (["mokosh", "veles", "perun", "morena"] if user.hp < user.max_hp * 0.5
                 else ["perun", "morena", "veles", "mokosh"])
        return min(gods, key=order.index)

    def resolve(self, user, target, choice, secret):
        gods = list(secret.get("options", {}).get("gods", {}) or self.GODS)
        god = choice if choice in gods else gods[0]
        return self.apply(user, target, 0, god)

    def apply(self, user, target, tier, god):
        god = god if god in self.GODS else "perun"
        user.add_effect(GodGift(god, 3, int(round(4 * user.power_scale()))))
        return [Announcement(f"🙏 {user.name} молится — {self.GODS[god]} (3 хода)!")]

    def ai_score(self, user, target):
        return 0 if user.has_effect(GodGift) else 17


class WerewolfSkill(MiniGameSkill):
    """«Оборотень» Даагаша: выберите зверя и за 4 с проведите по 5 точкам руны в нужном порядке.
    5 точек — полная сила 4 хода, 3–4 — 60%, 0–2 — 25% и форма держится 2 хода.
    Волк: +3 скорости, удар дважды ×0.7 с кровотечением. Медведь: щит 20% HP, +3 брони, удар ×1.5 (15% оглушить).
    Ворон: +20% уклонения, удар сквозь броню. С 3-го хода."""

    game, prompt = "rune_draw", "Выберите зверя и проведите по точкам руны!"
    MG_ICON = "🐺"
    MG_ACCENT = "#8b5a2b"
    TIME_LIMIT_MS = 4000
    TIERS = ("полная сила", "частичная сила", "провал")
    AI_WEIGHTS = (22, 45, 33)  # 5.4: средний ИИ реже идеален
    FORMS = {"wolf": "🐺 Волк", "bear": "🐻 Медведь", "raven": "🐦‍⬛ Ворон"}
    QUALITY = (1.4, 0.5, 0.2)  # 5.4 mastery

    def is_available(self, user):
        return super().is_available(user) and not user.has_effect(BeastForm)

    def game_params(self, user, target):
        pts = [[random.randint(15, 85), random.randint(15, 85)] for _ in range(5)]
        return {"forms": self.FORMS, "points": pts}

    def tier_from(self, choice, options):
        k = int(choice.get("points", 0)) if isinstance(choice, dict) else 0
        return 0 if k >= 5 else 1 if k >= 3 else 2

    def ai_choice(self, user, target, tier):
        if user.hp < user.max_hp * 0.5:
            return {"form": "bear"}
        if target.get_damage() >= 14:
            return {"form": "raven"}
        return {"form": "wolf"}

    def apply(self, user, target, tier, data):
        form = (data or {}).get("form") if isinstance(data, dict) else None
        form = form if form in self.FORMS else "wolf"
        q = self.QUALITY[tier]
        turns = 2 if tier == 2 else 4
        user.add_effect(BeastForm(form, turns, q))
        logs = [Announcement(f"🌕 {user.name} оборачивается: {self.FORMS[form]} ({self.TIERS[tier]}, {turns} х.)!")]
        if form == "bear":
            eff = _pct_shield(user, 0.20 * q, turns)
            logs.append(f"🐻 Медвежья шкура: щит на {eff.power} урона.")
        return logs

    def ai_score(self, user, target):
        return 22


# ---------------- Минотавр: «Барабаны предков» ----------------
class DrumsSkill(MiniGameSkill):
    """«Барабаны предков» Кэрна: ритм из 5 ударов с неравными паузами — повторите (±0.2 с).
    5 — «Хор предков»: +20% HP, снятие дебаффов, +3 заряда; 3–4 — +12%, +2; 1–2 — +5%, +1; 0 — +3%."""

    copyable = False

    game, prompt = "rhythm", "Слушайте ритм и повторите его!"
    MG_ICON = "🥁"
    MG_ACCENT = "#c9a227"
    TIME_LIMIT_MS = 5500  # 5.4: было 9000
    TIERS = ("Хор предков", "Голоса предков", "Шёпот", "Предки молчат")
    AI_WEIGHTS = (25, 35, 30, 10)
    HEAL = (0.20, 0.12, 0.05, 0.03)
    CHARGES = (3, 2, 1, 0)

    def game_params(self, user, target):
        t, beats = 0, [0]
        for _ in range(4):
            t += random.choice([200, 300, 400, 500])
            beats.append(t)
        return {"beats_ms": beats, "tolerance_ms": 180, "listen_pause_ms": 400}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice)
        return 0 if k >= 5 else 1 if k >= 3 else 2 if k >= 1 else 3

    def apply(self, user, target, tier, data):
        healed = user.heal(round(50 * user.power_scale()) if tier == 0 and user.type_key == 'minotaur' else int(user.max_hp * self.HEAL[tier]))
        logs = [f"🥁 {user.name} — «{self.TIERS[tier]}»: +{healed} HP."]
        if tier == 0:
            user._effects = [e for e in user.get_effects() if e.positive]
            logs[0] = Announcement(logs[0] + " Дебаффы сняты!")
        if hasattr(user, "add_legacy"):
            user.add_legacy(self.CHARGES[tier])
        return logs

    def ai_score(self, user, target):
        if user.has_effect(Antiheal):
            return 2
        return 24 if user.hp < user.max_hp * 0.55 else 5


# ---------------- Крок: «Смертельное вращение» и «Сборка панциря» ----------------
class DeathRollSkill(MiniGameSkill):
    """«Смертельное вращение» Крока: захват (85%), потом 4 с держите маркер в движущейся зелёной зоне.
    ≥80% времени — ×2.6, оглушение, +30 Сытости; 50–79% — ×2.21, +20; 20–49% — ×1.69, +10; <20% — ×1.04."""

    copyable = False

    game, prompt = "hold_zone", "Удерживайте маркер в зелёной зоне!"
    MG_ICON = "💀"
    MG_ACCENT = "#6a8a3a"
    MG_TARGET_COLOR = "#4cd07d"
    TIME_LIMIT_MS = 4000
    TIERS = ("Смертельное вращение", "Крепкий захват", "Рывок", "Добыча вырвалась")
    AI_WEIGHTS = (20, 35, 30, 15)
    TIER_VALUE = (2.6, 2.21, 1.69, 1.04)  # 5.4.1 balance: all tiers x1.3
    SATIETY = (30, 20, 10, 0)
    GRAB = 0.85

    def describe_for(self, user):
        tiers='/'.join('×'+format(v,'g') for v in self.TIER_VALUE)
        return (f'Мини-игра захвата. Урон по ступеням: {tiers}; шанс захвата 85% '
                '(снижается уклонением цели). Лучшая ступень оглушает; сытость +30/20/10/0.')

    def ai_score(self, user, target):
        from .ai import strike_value,tier_average,effect_value
        values=[strike_value(user,target,mult,force=True) for mult in self.TIER_VALUE]
        values[0] += effect_value(user,target,Stun(1))
        return max(0.1,self.GRAB-target.get_dodge()/2)*tier_average(self,user,values)

    def tier_from(self, choice, options):
        share = float(choice.get("in_zone", 0)) if isinstance(choice, dict) else float(choice)
        return 0 if share >= 0.8 else 1 if share >= 0.5 else 2 if share >= 0.2 else 3

    def apply(self, user, target, tier, data):
        if random.random() > max(0.1, self.GRAB - target.get_dodge() / 2):
            return [f"🐊 {user.name} бросается на {target.name}, но захват срывается!"]
        logs = [f"🐊 {user.name} — {self.TIERS[tier]}!"]
        part, dmg = self.strike(user, target, self.TIER_VALUE[tier])
        logs.extend(part)
        if dmg and tier == 0 and target.is_alive() and target.add_effect(Stun(1)):
            logs.append(f"💫 {target.name} оглушён вращением!")
        if hasattr(user, "feed"):
            user.feed(self.SATIETY[tier])
        return logs


class ShellPuzzleSkill(MiniGameSkill):
    """«Сборка панциря» Крока: за 6 с поверните 3 кольца, чтобы прорези совпали с отметкой.
    3 — −38% урона на 3 хода и иммунитет к оглушению; 2 — −30%; 0–1 — −20%. Сытость не нужна."""

    copyable = False

    game, prompt = "rings", "Поверните кольца — прорези к отметке!"
    MG_ICON = "🐚"
    MG_ACCENT = "#3ecfcf"
    TIME_LIMIT_MS = 6000
    TIERS = ("3/3", "2/3", "0–1/3")
    AI_WEIGHTS = (30, 40, 30)
    CUT = (38, 30, 20)

    def is_available(self, user):
        from .effects import ShellStance
        return super().is_available(user) and not user.has_effect(ShellStance)

    def game_params(self, user, target):
        return {"rings": [random.randint(1, 7) for _ in range(3)], "steps": 8}

    def tier_from(self, choice, options):
        k = int(choice.get("aligned", 0)) if isinstance(choice, dict) else int(choice)
        return 0 if k >= 3 else 1 if k == 2 else 2

    def apply(self, user, target, tier, data):
        from .effects import ShellStance
        user._effects = [e for e in user.get_effects() if not isinstance(e, Burn)]
        user.add_effect(ShellStance(3, fixed=self.CUT[tier], stun_immune=tier == 0))
        text = f"🐊 {user.name} собирает панцирь ({self.TIERS[tier]}): −{self.CUT[tier]}% урона на 3 хода."
        return [Announcement(text) if tier == 0 else text]

    def ai_score(self, user, target):
        if user.hp > user.max_hp * 0.7:
            return 3
        return 10 + (12 if getattr(user, "satiety", 0) < 50 else 0)


# ---------------- Тёмный рыцарь: «Закалка клинка» ----------------
class TemperSkill(MiniGameSkill):
    """«Закалка клинка» Мордреда: зажмите кнопку — шкала растёт; отпустите в узкой зелёной зоне.
    Идеально — ×1.85 сквозь броню, хорошо — ×1.7, мимо — ×1.3, передержал (шкала полная) — перегрев, −5% HP."""

    game, prompt = "hold_release", "Зажмите и отпустите в зелёной зоне!"
    MG_ICON = "🔥"
    MG_ACCENT = "#ff6a2a"
    MG_TARGET_COLOR = "#f5b942"
    TIME_LIMIT_MS = 5000
    TIERS = ("идеально", "хорошо", "мимо", "перегрев")
    AI_WEIGHTS = (25, 45, 22, 8)
    TIER_VALUE = (1.85, 1.7, 1.3, 0.3)

    def game_params(self, user, target):
        c = random.randint(60, 82) / 100
        return {"perfect": [round(c - 0.04, 2), round(c + 0.04, 2)], "good": [round(c - 0.13, 2), round(c + 0.13, 2)],
                "fill_ms": 1600}

    def tier_from(self, choice, options):
        x = float(choice.get("charge", 0)) if isinstance(choice, dict) else float(choice)
        p, g = options.get("perfect", [0.7, 0.78]), options.get("good", [0.6, 0.88])
        if x >= 1.0:
            return 3
        return 0 if p[0] <= x <= p[1] else 1 if g[0] <= x <= g[1] else 2

    def apply(self, user, target, tier, data):
        if tier == 3:
            loss = int(user.max_hp * 0.05)
            user.hp = user.hp - loss
            part, _ = self.strike(user, target, self.TIER_VALUE[3], force=False)
            return [f"🔥 Клинок {user.name} перегрелся! −{loss} HP."] + part
        head = f"🔥 {user.name} — «Закалка клинка»: {self.TIERS[tier]}!"
        part, _ = self.strike(user, target, self.TIER_VALUE[tier], ignore_armor=tier == 0, force=tier < 2)
        return [Announcement(head) if tier == 0 else head] + part
