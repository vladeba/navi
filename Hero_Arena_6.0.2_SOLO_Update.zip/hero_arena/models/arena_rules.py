"""Arena stats are independent of campaign progression.

HP bands are reference ranges; explicit reviewed hero exceptions override them.
the campaign keeps its existing constructors and tuning.
"""

ROLE_HP_BANDS = {
    "trickster": (150, 175),
    "light": (185, 210),
    "warrior": (220, 250),
    "tank": (265, 300),
}

ARENA_HP = {
    "keltazar": 185, "feliss": 179, "cyclops": 285, "mersey": 235, "leon": 230, "getou": 178,
    "warrior": 240, "mage": 200, "archer": 200, "ogre": 290,
    "spartan": 242, "assassin": 175, "samurai": 225, "druid": 195,
    "monk": 240, "darkelf": 185, "owlbeast": 300, "musketeer": 200,
    "pagan": 230, "minotaur": 265, "croc": 295, "darkknight": 260,
    "goblin": 160, "satyr": 165, "ghoul": 175, "rhino": 295,
    "bogatyr": 275, "orc": 245, "dwarf": 255, "lightelf": 185,
    "shade": 190, "aarakocra": 195, "hunter": 230, "gnoll": 175,
    "centaur": 195, "bluetroll": 180, "paladin": 280, "catfolk": 175,
    "beastlord": 325, "spiderqueen": 165, "ranger": 195,
    "pandaren": 245, "gambler": 160,
}

# Arena-only multipliers; subsequent review modules apply measured 43-hero tuning.
ARENA_DAMAGE = {
    "keltazar": 0.9, "feliss": 0.96, "cyclops": 0.725, "mersey": 0.734453, "leon": 1.039454, "getou": 2.617188,
    "warrior": 0.93213,
    "mage": 0.73515,
    "archer": 0.995,
    "ogre": 0.75945,
    "spartan": 0.91017,
    "assassin": 1.26577,
    "samurai": 0.39734,
    "druid": 0.50466,
    "monk": 0.8255,
    "darkelf": 0.90071,
    "owlbeast": 0.89188,
    "musketeer": 1.018797,
    "pagan": 0.8597,
    "minotaur": 0.74193,
    "croc": 0.91695,
    "darkknight": 0.9216,
    "goblin": 1.17066,
    "satyr": 1.12623,
    "ghoul": 1.1467,
    "rhino": 0.7849,
    "bogatyr": 0.79085,
    "orc": 0.93727,
    "dwarf": 0.98616,
    "lightelf": 0.89621,
    "shade": 1.02555,
    "aarakocra": 1.035,
    "hunter": 1.0,
    "gnoll": 1.22196,
    "centaur": 1.01483,
    "bluetroll": 1.38446,
    "paladin": 0.836218,
    "catfolk": 1.06886,
    "beastlord": 0.99815,
    "spiderqueen": 1.22059,
    "ranger": 1.01464,
    "pandaren": 0.88723,
    "gambler": 1.62201
}

# Catfolk changes combat role as well as appearance. Each form has its own HP
# maximum. Wounds are carried over as a fraction, rounded down on conversion.
CATFOLK_WARRIOR_HP = 215
