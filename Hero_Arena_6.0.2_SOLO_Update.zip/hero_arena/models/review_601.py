"""Second solo review: agreed decisions; further tuning is explicit arena data."""
from .character import Character
from .review_600 import sync_original

# Absolute arena HP; fixed values and deltas refer to the measured 6.0 candidate.
HP = {'mage':185,'paladin':280,'darkknight':255,'monk':240,'minotaur':275,
      'owlbeast':286,'beastlord':315,'archer':209,'spartan':250,'musketeer':210,
      'pagan':238,'goblin':165,'rhino':305,'bogatyr':283,'orc':253,'lightelf':196,
      'hunter':240,'gnoll':183,'centaur':207,'ranger':199,'pandaren':260,
      'gambler':165,'keltazar':189,'cyclops':291,'mersey':245,'leon':237,
      'spiderqueen':158,'warrior':245,'assassin':170,'getou':174,'druid':198}
BASIC = {'archer':1.08,'rhino':1.05,'pagan':1.05,'hunter':1.05,'gnoll':1.04,
         'centaur':1.04,'pandaren':1.04}
# Extra support is mechanical and displayed, never a forced outcome or AI tier.
# Tuning multipliers are ordinary arena damage, applied equally to humans and AI.
def install(classes):
    from .arena_rules import ARENA_HP
    from .heroes_54 import BeastLord
    BeastLord.RIDER_HP=115
    from .skills import WeaknessSkill
    from .minigames_58 import SPECS
    from .heroes_55 import Keltazar
    ARENA_HP.update(HP)
    WeaknessSkill.FULL=2.5
    # These specs drive damage AND ai_score/descriptions from the same values.
    for pair,factors in {( 'lightelf','star_arrow'):(1.08,1.08,1.08,1),
                          ('bluetroll','machete_cross'):(.91,1,1,1),
                          ('aarakocra','dive'):(.95,1,1,1),
                          ('spiderqueen','web_trap'):(.95,1,1,1),
                          ('spiderqueen','spiderlings'):(.95,1,1,1),
                          ('spiderqueen','queen_bite'):(.95,1,1,1)}.items():
        s=SPECS[pair];s['mults']=tuple(x*f for x,f in zip(s['mults'],factors))
        m=s['mults']
        details={('lightelf','star_arrow'):'Три попадания: три стрелы по ×0.864; у последней +60% к шансу крита. Два попадания — две стрелы, одно — одна.',
                 ('bluetroll','machete_cross'):'Идеал: два удара суммарно ~×1.91 и кровотечение 3 HP на 2 хода. Хорошо: ×1.65; частично: ×0.75. Пропущенный мачете отнимает 3% максимальных HP.',
                 ('aarakocra','dive'):'Четыре просвета: ~×2.04, пробой 40% брони и кровотечение 3 HP на 3 хода. Частично: ×1.5 или ×0.65.',
                 ('spiderqueen','web_trap'):'Идеальная сеть: ×1.14, яд, замедление и оглушение на ход; неполная сеть слабее.',
                 ('spiderqueen','spiderlings'):'Четыре кокона: ×1.52 и яд 3 HP на 2 хода; меньше коконов — слабее укус.',
                 ('spiderqueen','queen_bite'):'Идеал: ~×1.57, пробитие 40% брони и яд 4 HP на 3 хода. Хорошо: ×1.25; частично: ×0.55.'}
        s['reward']=details[pair]
    for key,cls in classes.items():
        old=cls._create_skills
        def factory(self,_old=old,_key=key,_details=details):
            skills=_old(self)
            for s in skills:
                if s.key=='attack' and _key in BASIC:sync_original(s,{'multiplier':s.multiplier*BASIC[_key]})
                if _key=='mage' and s.key=='heal':
                    s.percent*=.966;s.description='Восстанавливает здоровье.'
                if (_key,s.key) in _details:
                    def reward(sk):
                        for field in ('SPEC','PERSONAL'):
                            if hasattr(sk,field):getattr(sk,field)['reward']=_details[_key,s.key]
                        for field in ('_original58','_original59'):
                            if hasattr(sk,field):reward(getattr(sk,field))
                    reward(s)
                if _key=='archer' and s.key=='aimed_shot':
                    if hasattr(s,'SPEC'):s.SPEC['mults']=tuple(x*1.1 for x in s.SPEC['mults'])
                    elif hasattr(s,'original600'):s.original600.multiplier*=1.1
                    else:sync_original(s,{'multiplier':s.multiplier*1.1})
            return skills
        cls._create_skills=factory
    old_reset=Character.reset
    def reset(self):
        old_reset(self);self._blood_mock_turn=None
    Character.reset=reset
    def on_miss(self,attacker):
        actor=getattr(attacker,'owner',None) or attacker
        token=(actor.id,actor.turn_number)
        if self.type_key!='keltazar' or not self.is_alive() or getattr(self,'_blood_mock_turn',None)==token:return
        self._blood_mock_turn=token
        restored=self.heal(3)
        self._events.append('🩸 %s: «И это всё?» +%s HP.'%(self.name,restored))
    Character.on_enemy_miss=on_miss
    Keltazar.PASSIVE_NOTES=Keltazar.PASSIVE_NOTES+(lambda c:'«И это всё?»: промах направленной атаки противника восстанавливает 3 HP, максимум раз за ход противника; антихил действует.',)

    # Aimed-shot wrapper delegates to its original damage skill, already scaled.
    from .arena_rules import ARENA_DAMAGE
    from .tuning_601 import POWER,PAIR_POWER
    from . import tuning_601
    for key,delta in getattr(tuning_601,'HP_DELTA',{}).items():ARENA_HP[key]+=delta
    BeastLord.RIDER_HP+=getattr(tuning_601,'HP_DELTA',{}).get('beastlord',0)
    from . import arena_rules
    arena_rules.CATFOLK_WARRIOR_HP+=getattr(tuning_601,'HP_DELTA',{}).get('catfolk',0)
    for key,value in POWER.items():ARENA_DAMAGE[key]*=value
    from . import review_600
    old_pair=review_600.configure_pair
    def pair(battle):
        old_pair(battle)
        if battle.story or not review_600.PAIR_RULES_ENABLED:return
        for h in (battle.hero1,battle.hero2):
            h._duel_damage=PAIR_POWER.get((h.type_key,h.opponent.type_key),1)
            if h._duel_damage!=1:
                msg='Особенность дуэли против %s: урон прямых атак ×%.3f.'%(h.opponent.name,h._duel_damage)
                h._match_notes.append(msg);battle._add_log(msg)
    review_600.configure_pair=pair
    prior_reset=Character.reset
    def clean_reset(self):
        self._duel_damage=1;self._match_notes=[]
        prior_reset(self)
    Character.reset=clean_reset
    old_multiplier=Character.damage_multiplier
    def multiplier(self):return old_multiplier(self)*getattr(self,'_duel_damage',1)
    Character.damage_multiplier=multiplier
