"""Automatic innates. 5.8 removes duplicate resource rebates in favour of distinct rules."""
from .effects import Shield,GodGift,Slow,Blinded,Poison,Effect

class SparePlanDodge(Effect):
    name,icon,positive='Запасной план','💨',True
    def dodge_bonus(self):return .04

NEW = {
 'archer':('Пристрелка','попадания обычной стрелой дают +2% точности следующей обычной стреле (до +6%); промах или другое действие сбрасывает серию'),
 'darkelf':('Тёмный прорез','33.2% прямого урона проходит сквозь поглощающие щиты; это постоянное свойство героя, а не отдельное умение'),
 'musketeer':('Прикрытие прикладом','пока оружие разряжено, броня +1; после перезарядки бонус исчезает'),
 'pagan':('Отголосок дара','когда дар бога заканчивается, получает щит на 4% максимальных HP до следующего собственного хода, если другого щита нет'),
 'goblin':('Запасной план','первый собственный промах за ход даёт +4% уклонения до следующего собственного хода; не складывается сам с собой'),
 'ghoul':('Живучая падаль','первый удар с реальным уроном за свой ход лечит 2 HP, если собственные HP ниже 50%; запрет лечения действует'),
 'aarakocra':('Попутный ветер','скорость +1, пока собственные HP выше 75%'),
 'hunter':('Смена арсенала','платная атакующая способность, отличная от предыдущей платной атаки, дополнительно пробивает 15% брони'),
 'gnoll':('Чутьё слабости','крит +4% по цели с HP ниже 35%'),
 'centaur':('След предков','каждый третий собственный ход снимает с себя одно замедление или ослепление'),
 'bluetroll':('Возвратная хватка','первый вернувшийся мачете, который реально ранил врага за ход, лечит хозяина на 2 HP; запрет лечения действует'),
 'paladin':('Долг хранителя','раз за бой в начале своего хода при HP ниже 35% получает щит на 4% максимальных HP на 2 хода, если другого щита нет'),
 'spiderqueen':('Ядовитый хитин','броня +1, пока основной соперник отравлен'),
 'pandaren':('Хмельная закалка','яд, кровотечение, горение и другой периодический урон слабее на 12%'),
 'gambler':('Козырь в рукаве','первый полученный критический удар за бой наносит на 20% меньше урона; не работает вместо погибшего призыва'),
}
PRESERVED = {
 'warrior':'«Вальхалла»: раз за бой при HP ниже 30% с шансом 67% блокирует 1–2 умения врага на 2 хода; обычная атака возвращает 15 ярости',
 'samurai':'«Судьба клинка»: в начале боя получает случайную катану; свойства катаны действуют автоматически, включая легендарную Масамунэ',
 'darkknight':'«Последняя клятва»: раз за бой после прямого урона при HP ниже 25% получает несмертие на 2 хода; получение удара восстанавливает тьму',
 'rhino':'«Толстая шкура»: пока есть щит, броня +1',
 'orc':'«Кровожадность»: удары топором возвращают 8% нанесённого урона в HP, под Боевым рёвом — 18%',
 'dwarf':'«Запал»: повторные удары топором копят запал и со второго ранят дворфа; удар молотом сбрасывает запал',
 'lightelf':'«Сияние»: +10% к множителю урона, пока HP выше 70%',
 'shade':'«Ускользание»: даже точный приём мини-игры может промахнуться с шансом 75% от уклонения Тени; периодический урон сильнее на 15%; после уклонения усилен Удар из тени',
 'catfolk':'«Смена такта»: первый удар после смены формы усилен; долгое пребывание в одной форме снижает урон; свойства человеческой и кошачьей форм действуют автоматически',
 'beastlord':'«Ярость наездника»: после гибели кодоя личный урон +15%, усиливается призыв стаи; кодой не воскрешается обычным лечением',
 'ranger':'«Углубление ран»: обычная атака, стрела кровоточия и удар копьём увеличивают силу уже имеющегося кровотечения на 1',
}


def install(classes):
    for key,(title,text) in NEW.items():
        cls=classes[key]
        if key=='pandaren':cls.DOT_RESIST=.12
        else:cls.PASSIVE_NOTES=tuple(getattr(cls,'PASSIVE_NOTES',()))+(f'«{title}»: {text}',)
    for key,text in PRESERVED.items():
        cls=classes[key];cls.PASSIVE_NOTES=tuple(getattr(cls,'PASSIVE_NOTES',()))+(text,)

def state(h):
    if not hasattr(h,'_passive56'):h._passive56={}
    return h._passive56

def reset(h):
    if h.type_key in NEW:h._passive56={}

def turn_start(h):
    k=h.type_key
    if k not in NEW or not h.is_alive():return []
    if k=='pagan':
        s=state(h);gift=h.has_effect(GodGift);ended=s.get('gift_seen',False) and not gift;s['gift_seen']=gift
        if ended and not h.has_effect(Shield):
            n=max(1,round(h.max_hp*.04));h.add_effect(Shield(1,n));return [f'🛡 Отголосок дара: {h.name} получает щит {n} до следующего собственного хода.']
    if k=='centaur' and h.turn_number%3==0 and state(h).get('cleanse_turn')!=h.turn_number:
        e=next((e for e in h.get_effects() if isinstance(e,(Slow,Blinded))),None)
        if e:state(h)['cleanse_turn']=h.turn_number;h._effects.remove(e);return [f'🍃 След предков снимает с {h.name} эффект «{e.name}».']
    if k=='paladin' and h.hp<h.max_hp*.35 and not h.has_effect(Shield) and not state(h).get('ward_used'):
        state(h)['ward_used']=True;n=max(1,round(h.max_hp*.04));h.add_effect(Shield(2,n))
        return [f'🛡 Долг хранителя: {h.name} получает щит {n}, один раз за бой.']
    return []

def paid(h,skill):
    k=h.type_key
    if k not in NEW:return
    s=state(h);s['action']=skill.key
    if k=='archer' and skill.key!='attack':s['precision']=0
    if k=='hunter' and _paid_attack(skill):
        previous=s.get('weapon');s['weapon']=skill.key
        s['variety']=(h.turn_number,skill.key) if previous and previous!=skill.key else None
        if s['variety']:h._events.append('🏹 Смена арсенала: этот приём дополнительно пробивает 15% брони.')

def _paid_attack(skill):
    return skill is not None and skill.key!='attack' and skill.cost>0 and hasattr(skill,'multiplier') and getattr(skill,'deals_damage',True)

def attack_noted(h,hit):
    k=h.type_key
    if k=='archer':
        s=state(h)
        if s.get('action')=='attack':s['precision']=min(3,s.get('precision',0)+1) if hit else 0
    if k=='goblin' and not hit:
        s=state(h)
        if s.get('miss_turn')!=h.turn_number:
            s['miss_turn']=h.turn_number;h.add_effect(SparePlanDodge(1,4));h._events.append('💨 Запасной план: +4% уклонения до следующего собственного хода.')

def accuracy(h,skill):return .02*getattr(h,'_passive56',{}).get('precision',0) if h.type_key=='archer' and skill.key=='attack' else 0

def speed(h):return 1 if h.type_key=='aarakocra' and h.hp>h.max_hp*.75 else 0

def armor(h):
    if h.type_key=='musketeer' and not getattr(h,'loaded',True):return 1
    if h.type_key=='spiderqueen' and any(isinstance(e,Poison) for e in getattr(getattr(h,'opponent',None),'_effects',[])):return 1
    return 0

def crit(h,victim):return .04 if h.type_key=='gnoll' and victim.hp<victim.max_hp*.35 else 0

def pierce(h,skill,forecast=False):
    if h.type_key!='hunter' or not _paid_attack(skill):return 0
    s=getattr(h,'_passive56',{})
    if forecast:return .15 if s.get('weapon') and s['weapon']!=skill.key else 0
    return .15 if s.get('variety')==(h.turn_number,skill.key) else 0

def critical_guard(h,damage,consume=False):
    if getattr(h,'type_key',None)!='gambler' or getattr(h,'_passive56',{}).get('crit_guard_used'):return damage
    if consume:state(h)['crit_guard_used']=True;h._events.append('🃏 Козырь в рукаве ослабляет первый полученный крит на 20%.')
    return damage*.8

def landed(h,victim,skill,hp_lost):
    if hp_lost<=0 or h.type_key!='ghoul' or not h.is_alive():return
    s=state(h)
    if s.get('hit_turn')==h.turn_number:return
    if h.hp<h.max_hp*.5:
        s['hit_turn']=h.turn_number;got=h.heal(max(1,round(2*h.power_scale())))
        if got:h._events.append(f'✦ Живучая падаль: {h.name} +{got} HP.')

def returned(h,hp_lost):
    if h.type_key!='bluetroll' or hp_lost<=0 or not h.is_alive():return []
    s=state(h)
    if s.get('return_turn')==h.turn_number:return []
    s['return_turn']=h.turn_number;got=h.heal(max(1,round(2*h.power_scale())))
    return [f'🪃 Возвратная хватка: {h.name} +{got} HP.'] if got else []
