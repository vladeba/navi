// ===================== Хиро арена 4.2 =====================
// Роль «Монстр» переименована в «Танк»; новые мини-игры для 9 героев 4.2 и новых умений старых героев.
ROLE_ICON.tank = "🛡"; ROLE_ICON.monster = "🛡";

Object.assign(MINIGAMES, {
  // Газ-Лоу: напёрстки
  cups(o, head) {
    const n = o.cups || 3;
    openBox(head + `<div class="mg-area" id="mgA" style="height:180px">${[...Array(n)].map((_, i) =>
      `<div class="mg-tok cup" id="cup${i}" data-i="${i}" style="left:${20 + i * 30}%;top:55%;font-size:52px;transition:left ${(o.swap_ms||700)*.00075}s">🥤</div>`).join("")}
      <div class="mg-tok" id="ball" style="left:${20 + o.start * 30}%;top:85%;font-size:22px">⚪</div></div><div class="muted" id="mgHint">Запомните шарик…</div>` + timerBar);
    let pos = [...Array(n).keys()];           // pos[cup] = место
    const place = () => pos.forEach((p, c) => document.getElementById("cup" + c).style.left = (20 + p * 30) + "%");
    mgStart(o, () => ({cup: -1}));
    let k = 0;
    mg.timers.push(setTimeout(() => { const b = document.getElementById("ball"); if (b) b.remove(); }, Math.max(0,(o.show_ms||1000)-100)));
    const step = () => {
      if (mg.done) return;
      if (k >= o.swaps.length) {
        document.getElementById("mgHint").textContent = "Где шарик? Кликните по стакану.";
        document.querySelectorAll(".cup").forEach(el => el.onpointerdown = () => mgFinish({cup: pos[+el.dataset.i]}));
        return;
      }
      const [a, b] = o.swaps[k++];
      const ca = pos.indexOf(a), cb = pos.indexOf(b); pos[ca] = b; pos[cb] = a; place();
      mg.timers.push(setTimeout(step, o.swap_ms || 700));
    };
    mg.timers.push(setTimeout(step, o.show_ms||1000));
  },
  // Шкала с бегунком: несколько нажатий в зону (отмычка, бросок топора, руны)
  timing_multi(o, head) {
    const P = o.period_ms, Z = o.zone, pw = o.perfect_w, gw = o.good_w;
    openBox(head + `<div style="position:relative;height:34px;background:#222;border-radius:8px;margin:14px 0">
      <div style="position:absolute;left:${(Z - gw) * 100}%;width:${gw * 200}%;height:100%;background:#3c7a3c"></div>
      <div style="position:absolute;left:${(Z - pw) * 100}%;width:${pw * 200}%;height:100%;background:var(--gold)"></div>
      <div id="tmK" style="position:absolute;top:-4px;width:4px;height:42px;background:#fff"></div><div style="position:absolute;right:6px;top:4px">${o.icon || ""}</div></div>
      <button class="btn" id="tmB">Нажать (<span id="tmN">0</span>/${o.presses})</button>
      <div class="muted">${(o.labels || []).join(" → ")} Жёлтая зона — идеально, зелёная — хорошо.</div>` + timerBar);
    let hits = 0, perfect = 0, n = 0;
    const x = () => { const t = ((performance.now() - mg.t0) % (2 * P)) / P; return t < 1 ? t : 2 - t; };
    const loop = () => { if (mg.done) return; document.getElementById("tmK").style.left = (x() * 100) + "%"; mg.raf = requestAnimationFrame(loop); };
    mgStart(o, () => ({hits, perfect, ms: 9999}));
    loop();
    document.getElementById("tmB").onclick = () => {
      const d = Math.abs(x() - Z); n++;
      if (d <= pw) { perfect++; hits++; } else if (d <= gw) hits++;
      document.getElementById("tmN").textContent = n;
      if (n >= o.presses) mgFinish({hits, perfect, ms: Math.round(performance.now() - mg.t0)});
    };
  },
  // Шибэк (листья/шипы) и Нефруит/«Поймай тень» (выбрать одну)
  click_good_bad(o, head) {
    openBox(head + timerBar + `<div class="mg-area" id="mgA"></div><div class="muted">Хорошо: <b id="mgG">0</b> · ошибок: <b id="mgB">0</b></div>`);
    let good = 0, bad = 0, i = 0;
    const area = document.getElementById("mgA");
    mgStart(o, () => ({good, bad}));
    const mk = it => {
      const t = document.createElement("div");
      t.className = "mg-tok"; t.textContent = it.icon; t.style.left = rnd(10, 90) + "%"; t.style.top = rnd(12, 88) + "%";
      if(o.pick_one){t.style.textShadow="none";t.style.color="#08080b";t.style.fontFamily="Arial, sans-serif";if(it.good)t.textContent="☠︎";}
      t.onpointerdown = () => { t.remove(); it.good ? good++ : bad++;
        document.getElementById("mgG").textContent = good; document.getElementById("mgB").textContent = bad;
        if (o.pick_one) mgFinish({good, bad}); };
      area.appendChild(t);
      if (!o.together) mg.timers.push(setTimeout(() => t.remove(), o.life_ms));
    };
    if (o.together) o.items.forEach(mk);
    else { const sp = () => { if (mg.done || i >= o.items.length) return; mk(o.items[i++]); mg.timers.push(setTimeout(sp, o.spawn_ms)); }; sp(); }
  },
  // Конан «Парирование», Шибэк — повторить стрелки
  arrows_seq(o, head) {
    const L = {up: "⬆️", down: "⬇️", left: "⬅️", right: "➡️"};
    openBox(head + `<div style="font-size:60px;margin:14px" id="asA">…</div><div>${o.dirs.map(d => `<button class="btn dodge-btn" data-d="${d}">${L[d]}</button>`).join("")}</div>
      <div class="muted">Успели: <b id="mgCnt">0</b>/${o.sequence.length} (клавиши-стрелки тоже работают)</div>` + timerBar);
    let hits = 0, k = -1, answered = true;
    const press = d => { if (mg.done || answered || k < 0) return; answered = true; if (d === o.sequence[k]) { hits++; document.getElementById("mgCnt").textContent = hits; }
      document.getElementById("asA").textContent = d === o.sequence[k] ? "✅" : "❌"; };
    document.querySelectorAll("#modalBox [data-d]").forEach(b => b.onclick = () => press(b.dataset.d));
    document.onkeydown = e => { const m = {ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right"}[e.code]; if (m) press(m); };
    mgStart({time_limit_ms: o.sequence.length * o.window_ms + 800}, () => ({hits}));
    const next = () => { if (mg.done) return; k++; if (k >= o.sequence.length) return mgFinish({hits});
      answered = false; document.getElementById("asA").textContent = (o.icon || "") + L[o.sequence[k]]; mg.timers.push(setTimeout(next, o.window_ms)); };
    mg.timers.push(setTimeout(next, 500));
  },
  // Гуль / Каэль: клики по точкам в порядке 1 → N
  order_click(o, head) {
    openBox(head + timerBar + `<div class="mg-area" id="mgA">${o.points.map((p, i) =>
      `<div class="mg-tok" data-i="${i}" style="left:${p[0]}%;top:${p[1]}%">${o.icon}<sub>${i + 1}</sub></div>`).join("")}</div><div class="muted">Собрано: <b id="mgCnt">0</b>/${o.points.length}</div>`);
    let done = 0;
    mgStart(o, () => ({done}));
    document.querySelectorAll("#mgA [data-i]").forEach(el => el.onpointerdown = () => {
      if (+el.dataset.i !== done) return mgFinish({done});
      el.style.opacity = .3; done++; document.getElementById("mgCnt").textContent = done;
      if (done >= o.points.length) mgFinish({done}); });
  },
  // Удар богатыря / прицел светлого эльфа — выбрать направление уклонения
  dodge_pick(o, head) {
    const lab = o.labels || {};
    openBox(head + `<p class="muted">Безопасных сторон: ${o.safe_count || 1}. Решайте быстро!</p>` +
      o.dirs.map(d => `<button class="btn dodge-btn" onclick="mgFinish({dir:'${d}'})">${esc(lab[d] || d)}</button>`).join("") + timerBar);
    mgStart(o, () => ({dir: null}));
  },
});

// click_targets: режим «во тьме» — фон тёмный, цели видны только вспышкой
const _ct = MINIGAMES.click_targets;
MINIGAMES.click_targets = function (o, head, me, foe) {
  _ct(o, head, me, foe);
  if (o.dark) { const a = document.getElementById("mgA"); if (a) { a.style.background = "radial-gradient(#111,#000)"; a.style.filter = "brightness(.8)"; } }
};

// Мини-игры, где играет ЦЕЛЬ (Дуррила, «Поймай тень»): подпись, что реагирует противник
const _sp42 = showPending;
showPending = function (b) {
  const p = b.pending;
  _sp42(b);
  if (p && p.type === "minigame" && p.hero_id !== p.attacker_id && !b.ai_ids.includes(p.hero_id)) {
    const box = document.getElementById("modalBox");
    if (box && !box.querySelector(".foe-note")) box.insertAdjacentHTML("afterbegin", `<div class="muted foe-note">⚠ Это умение противника — реагируете вы!</div>`);
  }
};
