// ===================== 4.4: окно героя, имена и лор =====================
(function () {
  const st = document.createElement("style");
  st.textContent = `
  #heroInfo{position:fixed;inset:0;background:#000c;display:none;align-items:center;justify-content:center;z-index:60;padding:12px}
  #heroInfo .hi-box{position:relative;background:var(--panel2,#221c2b);border:2px solid var(--gold,#f5b942);border-radius:14px;max-width:760px;width:100%;max-height:92vh;overflow:auto;box-shadow:0 0 40px #f5b94255;display:grid;grid-template-columns:240px 1fr;gap:16px;padding:18px;text-align:left}
  #heroInfo .hi-close{position:absolute;top:8px;right:10px;background:none;border:0;color:#fff;font-size:22px;cursor:pointer}
  #heroInfo img{width:100%;border-radius:10px;aspect-ratio:1;object-fit:cover}
  #heroInfo h3{margin:0 0 4px;color:var(--gold,#f5b942);font-size:22px}
  #heroInfo .hi-lore{font-style:italic;color:#ddd;margin:8px 0;line-height:1.45}
  #heroInfo .hi-stats{display:grid;grid-template-columns:repeat(2,1fr);gap:4px 10px;font-size:13px;margin:8px 0}
  #heroInfo .hi-skill{border-top:1px solid #ffffff1a;padding:6px 0;font-size:13px}
  #heroInfo .hi-skill .facts{color:#9fd3ff;font-size:12px}
  #heroInfo .hi-mg{display:inline-block;background:#6b3fa033;border:1px solid #b98cff66;border-radius:6px;padding:0 5px;font-size:11px;margin-left:4px}
  @media (max-width:640px){#heroInfo .hi-box{grid-template-columns:1fr}}
  .hero-info-btn{position:absolute;top:6px;right:6px;background:#000a;border:1px solid #f5b94288;color:#f5b942;border-radius:50%;width:26px;height:26px;cursor:pointer;font-weight:bold;z-index:2}
  .hero{position:relative}
  .lore-under{font-style:italic;color:#ccc;margin:6px 0;line-height:1.4}`;
  document.head.appendChild(st);
  const d = document.createElement("div");
  d.id = "heroInfo"; d.onclick = e => { if (e.target === d) closeHeroInfo(); };
  d.innerHTML = `<div class="hi-box" id="heroInfoBox"></div>`;
  document.body.appendChild(d);
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeHeroInfo(); });
})();
const _cardCache = {};
async function classCard(type) {
  if (!_cardCache[type]) _cardCache[type] = await api(`/api/classes/${type}`);
  return _cardCache[type];
}
function closeHeroInfo() { const m = document.getElementById("heroInfo"); if (m) m.style.display = "none"; }
async function openHeroInfo(type, heroId) {
  const c = await classCard(type); if (!c) return;
  const h = heroId ? (allHeroes || []).find(x => x.id === heroId) : null;
  const displayedSkills = c.skills.map(k => h && h.type === "mage" ? {...k, ...(h.skills || []).find(x => x.key === k.key)} : k);
  const s = h || c, pct = x => Math.round((x || 0) * 100) + "%";
  const name = h ? h.name : c.hero_name;
  const atk = ((c.skills.find(k => k.key === "attack") || {}).facts || []).join(" ").match(/точность (\d+)/);
  const acc = atk ? +atk[1] : 95;
  const skills = displayedSkills.map(k => {
    const mg = k.is_minigame || (k.facts || []).some(f => f.startsWith("мини-игра")) || /Мини-игра/i.test(k.description);
    const cost = k.cost ? `${k.cost} ${esc(c.resource_name || "")}` : "бесплатно";
    const cd = k.cooldown ? ` · перезарядка ${k.cooldown}` : "";
    return `<div class="hi-skill">${k.icon} <b>${esc(k.name)}</b>${mg ? `<span class="hi-mg">🎮 мини-игра</span>` : ""}${k.once_per_battle ? ` <span class="muted">(раз за бой)</span>` : ""}
      <div class="muted">${cost}${cd}</div><div>${esc(k.description)}</div>${k.difficulty_label ? `<div class="muted">${esc(k.difficulty_label)}</div>` : ""}${(k.facts || []).length ? `<div class="facts">📐 ${esc(k.facts.join(" · "))}</div>` : ""}</div>`;
  }).join("");
  const games = displayedSkills.filter(k => (k.facts || []).some(f => f.startsWith("мини-игра")) || /Мини-игра/i.test(k.description)).map(k => esc(k.name));
  document.getElementById("heroInfoBox").innerHTML = `<button class="hi-close" onclick="closeHeroInfo()" title="Закрыть (Esc)">✕</button>
    <div><img src="${h ? h.image : c.image}" alt="${esc(name)}"><div class="muted" style="margin-top:6px;text-align:center">${esc(c.hero_class)}${h && h.story ? `, ур. ${h.level}` : ""}</div></div>
    <div><h3>${esc(name)}</h3><div>${roleBadge(c)} <span class="badge">${esc(c.hero_class)}</span></div>
      <div class="hi-lore">${esc(c.lore || "")}</div>
      <div class="hi-stats"><span>❤ HP: <b>${s.max_hp}</b></span><span>⚔ Урон: <b>${s.damage}</b></span>
        <span>🛡 Броня: <b>${s.armor}</b></span><span>⚡ Скорость: <b>${s.speed}</b></span>
        <span>💨 Уклонение: <b>${pct(s.dodge)}</b></span><span>💥 Крит: <b>${pct(s.crit_chance)} ×${s.crit_multiplier || 1.5}</b></span>
        <span>🎯 Точность атаки: <b>${acc}%</b></span><span>🔷 Ресурс: <b>${esc(c.resource_name || "энергия")} ${c.max_energy}</b></span></div>
      <div><b>✨ Пассивка и особенности:</b> ${esc(c.passive ? c.passive + ". " : "")}<span class="muted">${esc(c.about || "")}</span></div>
      <div style="margin-top:8px"><b>🎮 Мини-игры:</b> ${games.length ? games.join(", ") : "нет"}</div>
      <div style="margin-top:8px"><b>📜 Умения (${displayedSkills.length})</b>${skills}</div></div>`;
  document.getElementById("heroInfo").style.display = "flex";
}
// карточки героев: ℹ на всех, у соперников арены — клик по всей карточке
function _decorateHeroCards() {
  document.querySelectorAll("#heroList .hero, #myHeroList .hero, #myStoryList .hero").forEach(el => {
    const id = +el.dataset.id || +((el.getAttribute("onclick") || "").match(/\d+/) || [0])[0] ||
      +(((el.innerHTML.match(/heal\((\d+)\)/) || [])[1]) || 0) ||
      +(((el.innerHTML.match(/openHeroInfo\('[^']+',\s*(\d+)/) || [])[1]) || 0);
    const h = (allHeroes || []).find(x => x.id === id || String(x.id) === String(id));
    if (!h) return;
    el.dataset.id = h.id;
    el.dataset.type = h.type;
    if (!el.querySelector(".hero-info-btn")) {
      const b = document.createElement("button"); b.className = "hero-info-btn"; b.textContent = "i"; b.title = "О герое";
      b.onclick = e => { e.stopPropagation(); openHeroInfo(h.type, h.id); };
      el.appendChild(b);
    }
    if (el.closest("#heroList")) {
      el.style.cursor = "pointer";
      el.onclick = e => { if (e.target.closest("button,select,input")) return; openHeroInfo(h.type, h.id); };
    }
  });
}
const _loadHeroes44 = loadHeroes;
loadHeroes = async function () { await _loadHeroes44(); _decorateHeroCards(); };
// лобби: имя, лор и описание из кода под карточкой выбранного класса
const _pick44 = pick;
pick = function (type) {
  _pick44(type);
  const c = classes.find(x => x.type === type); if (!c) return;
  const box = document.getElementById("pickedInfo"); if (!box) return;
  const lock = isLocked(c) ? ` <b style="color:var(--gold)">🔒 Откроется после ${c.required_wins} побед игрока (арена или сюжет).</b>` : "";
  const secret = c.secret ? ` <b style="color:#b98cff">🦉 Секретный герой — вы его нашли!</b>` : "";
  box.innerHTML = `<div><b style="font-size:17px">${esc(c.hero_name || c.hero_class)}</b> · ${esc(c.hero_class)} ${roleBadge(c)}
      <button class="btn small ghost" onclick="openHeroInfo('${c.type}')">ℹ Подробнее</button>${secret}${lock}</div>
    <div class="lore-under">${esc(c.lore || "")}</div>
    <div>${c.passive ? `<b>✨ ${esc(c.passive)}.</b> ` : ""}<span class="muted">${esc(c.about || "")}</span></div>
    <div class="muted">❤ ${c.max_hp} HP · ⚔ ${c.damage} урона · 🛡 броня ${c.armor} · ⚡ скорость ${c.speed} · уклон ${Math.round(c.dodge*100)}% · крит ${Math.round(c.crit_chance*100)}%</div>
    <ul class="skill-list">${c.skills.map(s => `<li>${s.icon} <b>${esc(s.name)}</b> — ${esc(s.description)}${s.cost ? ` <span class="muted">(${s.cost} ${c.resource_name})</span>` : ""}${s.cooldown ? ` <span class="muted">· перезарядка ${s.cooldown}</span>` : ""}${(s.facts||[]).length ? ` <span style="color:#9fd3ff;font-size:12px">📐 ${esc(s.facts.join(" · "))}</span>` : ""}</li>`).join("")}</ul>`;
};
// сюжет: имя и лор под карточками классов; Монах доступен, когда открыт
if (typeof renderStoryClassCards === "function") {
  const _rsc44 = renderStoryClassCards;
  renderStoryClassCards = function () {
    _rsc44();
    const c = classes.find(x => x.type === storyPickedClass);
    const el = document.getElementById("storyClassAbout");
    if (c && el) el.innerHTML = `<b>${esc(c.hero_name || c.hero_class)}</b> · ${esc(c.hero_class)} (${esc(c.role_name)}) <button class="btn small ghost" onclick="openHeroInfo('${c.type}')">ℹ</button><div class="lore-under">${esc(c.lore || "")}</div>`;
  };
}
