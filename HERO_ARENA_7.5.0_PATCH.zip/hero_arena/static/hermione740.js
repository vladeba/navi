/* Staged custom games; not registered until integration is complete. */
(function(){'use strict';const {setup,circle,line,text}=window.arenaMiniUI;
const near=(p,q,r)=>Math.hypot(p.x-q[0],p.y-q[1])<=r;
function target(o,t){const q=(t-o.prepare_ms)/o.period*Math.PI*2;return[180+75*Math.sin(q),125+36*Math.sin(q*.7)]}
window.hermioneTarget740=target;
window.startHermioneGame740=function(o,h){
 const button=o.mode==='sustain'?'<button class="btn" id="tension740">Удерживать нить / Пробел</button>':'';
 const r=setup(o,h,esc(o.instruction),button);r.state.actions=[];r.state.holds=[];r.state.cuts=[];r.state.engaged_ms=null;
 let held=null,drag=null,finished=0;
 function ready(){return r.elapsed()>=o.prepare_ms}
 const move=r.svg.onpointermove;r.svg.onpointermove=e=>{move(e);if(ready()&&o.mode==='gaze')r.state.engaged_ms??=r.elapsed()};
 r.svg.onpointerdown=e=>{e.preventDefault();if(!ready())return;const p=r.pos(e),t=r.elapsed();r.svg.setPointerCapture(e.pointerId);r.setCursor(p);if(o.mode==='gaze')r.state.engaged_ms??=t;if(o.mode==='claws'&&finished<3&&near(p,o.start[finished],o.radius))drag={p,t,i:finished}};
 r.svg.onpointerup=e=>{if(!drag)return;const p=r.pos(e),t=r.elapsed(),a=drag;drag=null;r.state.cuts.push({down_ms:a.t,up_ms:t,x0:a.p.x,y0:a.p.y,x1:p.x,y1:p.y});finished++;if(finished===3)r.finish()};r.svg.onpointercancel=()=>{drag=null};
 function down(){if(!ready()||held!==null)return;held=r.elapsed();r.state.holds.push({down_ms:held,up_ms:held})}
 function up(){if(held===null)return;const last=r.state.holds.at(-1);last.up_ms=r.elapsed();held=null}
 if(o.mode==='sustain'){const btn=document.getElementById('tension740');btn.onpointerdown=e=>{e.preventDefault();btn.setPointerCapture(e.pointerId);down()};btn.onpointerup=up;btn.onpointercancel=up;r.svg.onkeydown=e=>{if(e.code==='Space'){e.preventDefault();if(!e.repeat)down()}};r.svg.onkeyup=e=>{if(e.code==='Space'){e.preventDefault();up()}};r.svg.onblur=up;r.svg.focus()}
 r.animate(t=>{let out='';
  if(o.mode==='gaze'){const [x,y]=target(o,t),d=Math.hypot(r.cursor.x-x,r.cursor.y-y);out=text(180,23,'УДЕРЖИВАЙТЕ ВЗГЛЯД',14)+`<ellipse cx="${x}" cy="${y}" rx="52" ry="28" fill="#642e6e77" stroke="#eeacd8" stroke-width="3"/>`+circle(x,y,13,'#dc78b9','#ffe6f7')+circle(r.cursor.x,r.cursor.y,o.radius,d<=o.radius?'#e8a8d144':'#73527544',d<=o.radius?'#ffe2f4':'#b39abd')+line(r.cursor.x-8,r.cursor.y,r.cursor.x+8,r.cursor.y,'#fff0f8',2)+line(r.cursor.x,r.cursor.y-8,r.cursor.x,r.cursor.y+8,'#fff0f8',2)+text(180,235,'ВЕДИТЕ ЗЕРКАЛО ЗА ГЛАЗОМ',13);r.status('Удерживайте контур на движущемся взгляде');if(t>o.samples.at(-1)+150)r.finish()}
  if(o.mode==='sustain'){if(held!==null)r.state.holds.at(-1).up_ms=t;let v=.5,step=Math.max(1,Math.round(25*o.factor));for(let ms=o.prepare_ms;ms<Math.min(t,o.prepare_ms+o.duration);ms+=step){const active=r.state.holds.some(z=>z.down_ms<=ms&&ms<z.up_ms);v=Math.max(0,Math.min(1,v+(active?o.gain:-o.decay)*step))}
   out=text(180,23,'УДЕРЖИТЕ НИТЬ ОЧАРОВАНИЯ',13)+line(50,110,310,110,'#6c526e',9)+line(50+260*o.target[0],110,50+260*o.target[1],110,'#b4d49a',15)+circle(50+260*v,110,15,'#df91c5','#fff0f8')+text(180,195,held!==null?'НАТЯЖЕНИЕ РАСТЁТ':'НАТЯЖЕНИЕ ПАДАЕТ',14)+text(180,230,'ДЕРЖИТЕ НИТЬ В СВЕТЛОЙ ЗОНЕ',12);r.status('Зажимайте и отпускайте: удерживайте нить в зелёной зоне');if(t>o.prepare_ms+o.duration){up();r.finish()}}
  if(o.mode==='claws'){let i=Math.min(2,finished),a=o.start[i],z=o.end[i],p=drag?[r.cursor.x,r.cursor.y]:a;out=text(180,23,`ВЫПАД ${i+1}/3`,15)+line(...a,...z,'#bb91a988',8)+circle(...a,o.radius,'#744c7077','#dcbcd9')+circle(...z,o.radius,'#a85c8666','#ffd2ec')+text(a[0],a[1]+8,'🐾',28)+text(z[0],z[1]+8,'✦',26)+line(...a,...p,'#f1b9da',3)+text(180,245,'ЗАЖМИТЕ У ЛАПЫ И ПРОВЕДИТЕ К ЦЕЛИ',12);r.status('Три направления: начните у лапы, отпустите у сияния')}
  r.svg.innerHTML=out;if(!ready())r.status('Приготовьтесь…');
 });
};
})();
MINIGAMES.hermione740=startHermioneGame740;
