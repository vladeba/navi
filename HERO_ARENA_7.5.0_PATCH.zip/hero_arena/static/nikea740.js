/* Prototype: refraction minigame. This script is not loaded in the public game yet. */
(function(){'use strict';
const{setup,circle,line,text}=window.arenaMiniUI;
function ray(o,t,aim){let drift=0;return [35,110,180,250,330].map((x,i)=>{if(i>=1&&i<=3)drift+=14*Math.sin((t-o.prepare_ms)/o.period*Math.PI*2+o.phases[i-1]);return [x,200+(aim-200)*(x-35)/295+drift]})}
window.nikeaRay740=ray;
window.startNikeaShot740=function(o,h){
 const r=setup(o,h,esc(o.instruction));r.state.actions=[];let aim=110;
 const move=r.svg.onpointermove;r.svg.onpointermove=e=>{move(e);aim=Math.max(20,Math.min(240,r.pos(e).y))};
 r.svg.onpointerdown=e=>{e.preventDefault();if(r.elapsed()<o.prepare_ms||r.state.actions.length)return;aim=Math.max(20,Math.min(240,r.pos(e).y));r.state.actions.push({ms:r.elapsed(),y:aim});r.finish()};
 r.animate(t=>{const ps=ray(o,t,aim);let out=text(180,23,'ПЛАЗМА ПРОХОДИТ ЧЕРЕЗ ТРИ ЗАВЕСЫ',12);[110,180,250].forEach((x,i)=>{const dy=14*Math.sin((t-o.prepare_ms)/o.period*Math.PI*2+o.phases[i]);out+=`<rect x="${x-6}" y="35" width="12" height="190" rx="6" fill="#8b77bf44" stroke="#d4bff1"/>`+text(x,55+(dy+14)*5,'✧',17)});for(let i=1;i<ps.length;i++)out+=line(...ps[i-1],...ps[i],'#e9c7ff',3);out+=circle(35,200,16,'#bd9af3','#ffddfa')+text(35,207,'✦',20)+circle(330,o.target_y,o.radius,'#b773ad55','#ffcaef')+circle(330,o.target_y,o.radius*.45,'#e8a6d877','#fff0fa');r.svg.innerHTML=out;r.status(t<o.prepare_ms?'Приготовьтесь…':'Наведите плазменный луч и нажмите для выстрела.')})
};
})();
(function(){'use strict';
const {setup,circle,line,text}=window.arenaMiniUI;
function swings(o,t){const q=(t-o.prepare_ms)/o.period*Math.PI*2+o.phase;return [-.25,0,.25].map(d=>40*Math.sin(q+d))}
window.nikeaBells740=swings;
window.startNikeaBells740=function(o,h){
 const r=setup(o,h,esc(o.instruction));r.state.engaged_ms=null;
 const move=r.svg.onpointermove;r.svg.onpointermove=e=>{move(e);if(r.elapsed()>=o.prepare_ms)r.state.engaged_ms??=r.elapsed()};
 r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);r.setCursor(r.pos(e));if(r.elapsed()>=o.prepare_ms)r.state.engaged_ms??=r.elapsed()};
 r.animate(t=>{const vals=swings(o,t),offset=Math.max(-75,Math.min(75,r.cursor.x-180));let out=text(180,24,'ПРИГЛУШИТЕ ТРИ КОЛОКОЛЬЧИКА',12);
  vals.forEach((v,i)=>{let x=90+i*90+v+offset,y=150;out+=line(90+i*90,50,x,y,'#d5c7dd',3)+line(90+i*90,55,90+i*90,200,'#bca5cf44',1)+circle(x,y,19,Math.abs(v+offset)<=26?'#b69b61':'#82758b','#f7dc9c')+text(x,y+8,'🔔',22)});
  const next=o.samples.find(x=>x>t);out+=text(180,230,next?`Звон через ${Math.max(0,(next-t)/1000).toFixed(1)} с`:'Мелодия завершена',14);r.svg.innerHTML=out;r.status(t<o.prepare_ms?'Приготовьтесь…':'Ведите ладонь против движения, чтобы колокольчики оказались у светлых линий.');if(t>o.samples.at(-1)+150)r.finish()})
};
})();
(function(){'use strict';
const {setup,circle,line,text}=window.arenaMiniUI;
function ring(o,points,elapsed){let sum=0,last=null;for(const p of points){if(p.t<o.prepare_ms||p.t>elapsed)continue;const dx=p.x-o.center[0],dy=p.y-o.center[1],rad=Math.hypot(dx,dy);if(Math.abs(rad-o.ring_radius)>o.ring_width){last=null;continue}const a=Math.atan2(dy,dx);if(last!==null){let d=((a-last+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;if(Math.abs(d)<=.55)sum=Math.max(0,sum+d)}last=a}return sum}
function weave(o,points){points=points.filter(p=>p.t>=o.prepare_ms);let i=0;for(let n=1;n<points.length&&i<o.gates.length;n++){const a=points[n-1],b=points[n],[x,y]=o.gates[i];if(a.x<=x&&x<=b.x&&b.x>a.x){const yy=a.y+(b.y-a.y)*(x-a.x)/(b.x-a.x);if(Math.abs(yy-y)<=o.radius)i++}}return i}
window.nikeaRing740=ring;window.nikeaWeave740=weave;
window.startNikeaVeil740=function(o,h){const r=setup(o,h,esc(o.instruction));r.state.engaged_ms=null;const move=r.svg.onpointermove;r.svg.onpointermove=e=>{move(e);if(r.elapsed()>=o.prepare_ms)r.state.engaged_ms??=r.elapsed()};r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);r.setCursor(r.pos(e));if(r.elapsed()>=o.prepare_ms)r.state.engaged_ms??=r.elapsed()};
 r.animate(t=>{const p=ring(o,r.state.points,t),fraction=Math.min(1,p/(o.turns*2*Math.PI));let out=text(180,25,'УКРОЙТЕ СОН ЗАЩИТНЫМ КРУГОМ',12)+circle(180,130,o.ring_radius,'none','#aa9cc8')+circle(180,130,40,'#74618f88','#dcd0ec')+text(180,140,'☾',37)+text(180,238,Math.round(fraction*100)+'%',17);const c=r.cursor;out+=circle(c.x,c.y,8,'#eed9fc','#fff2fc');r.svg.innerHTML=out;r.status(t<o.prepare_ms?'Приготовьтесь…':'Ведите по кольцу по часовой стрелке');if(fraction>=1)r.finish()})};
window.startNikeaThreads740=function(o,h){const r=setup(o,h,esc(o.instruction));r.state.engaged_ms=null;const move=r.svg.onpointermove;r.svg.onpointermove=e=>{move(e);if(r.elapsed()>=o.prepare_ms)r.state.engaged_ms??=r.elapsed()};r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);r.setCursor(r.pos(e));if(r.elapsed()>=o.prepare_ms)r.state.engaged_ms??=r.elapsed()};
 r.animate(t=>{const n=weave(o,r.state.points);let out=text(180,25,'СОТКИТЕ НИТЬ СНОВИДЕНИЯ',12);o.gates.forEach(([x,y],i)=>{out+=line(x,45,x,215,'#5c4d70',5)+circle(x,y,o.radius,i<n?'#8aa77c77':'#bd96dd55','#ead1f0')+text(x,y+6,i<n?'✓':String(i+1),17)});const p=r.state.points.filter(p=>p.t>=o.prepare_ms);if(p.length>1)out+=`<polyline points="${p.map(v=>`${v.x},${v.y}`).join(' ')}" fill="none" stroke="#f7d7ff" stroke-width="4"/>`;out+=text(25,220,'СТАРТ',11)+text(335,220,'ФИНИШ',11);r.svg.innerHTML=out;r.status(t<o.prepare_ms?'Приготовьтесь…':`Проведите нить через проходы слева направо: ${n}/4`);if(n===o.gates.length)r.finish()})};
})();
(function(){'use strict';const{setup,circle,line,text}=window.arenaMiniUI;
window.startNikeaTrail740=function(o,h){const r=setup(o,h,esc(o.instruction));r.state.actions=[];const rings=o.rings.slice(),radii=[35,68,101];r.svg.onpointerdown=e=>{e.preventDefault();if(r.elapsed()<o.prepare_ms||r.state.actions.length>=o.max_moves)return;const p=r.pos(e),dist=Math.hypot(p.x-180,p.y-130);let best=0;for(let i=1;i<3;i++)if(Math.abs(dist-radii[i])<Math.abs(dist-radii[best]))best=i;if(Math.abs(dist-radii[best])>20)return;rings[best]=(rings[best]+1)%4;r.state.actions.push({ms:r.elapsed(),ring:best});if(rings.every(a=>a===0))r.finish()};
 r.animate(t=>{let out=text(180,23,'СОЕДИНИТЕ ТРОПУ СНОВИДЕНИЯ',12)+circle(180,130,12,'#f9d8ef','#fff5e7');radii.forEach((rad,i)=>{out+=circle(180,130,rad,'none','#84779c');const q=rings[i]*Math.PI/2-Math.PI/2;out+=line(180+Math.cos(q)*(rad-15),130+Math.sin(q)*(rad-15),180+Math.cos(q)*(rad+15),130+Math.sin(q)*(rad+15),rings[i]===0?'#f6e8ad':'#cba2ed',7)});out+=text(180,245,'↑ Путь должен вести к звезде ↑',13);r.svg.innerHTML=out;r.status(t<o.prepare_ms?'Приготовьтесь…':'Нажимайте на кольца, чтобы повернуть их')})};
window.startNikeaNightmare740=function(o,h){const r=setup(o,h,esc(o.instruction));r.state.actions=[];const pos=[[90,90],[270,90],[90,185],[270,185]],ready=o.prepare_ms+o.reveal_ms+o.sequence.length*o.flash_ms;
 r.svg.onpointerdown=e=>{e.preventDefault();let t=r.elapsed();if(t<ready||r.state.actions.length>=3)return;const p=r.pos(e);let i=pos.findIndex(([x,y])=>Math.hypot(p.x-x,p.y-y)<=43);if(i<0)return;r.state.actions.push({ms:t,tile:i});if(i!==o.sequence[r.state.actions.length-1]||r.state.actions.length===3)r.finish()};
 r.animate(t=>{let idx=Math.floor((t-o.prepare_ms-o.reveal_ms)/o.flash_ms),show=t>=o.prepare_ms+o.reveal_ms&&idx>=0&&idx<3&&((t-o.prepare_ms-o.reveal_ms)%o.flash_ms)<o.flash_ms*.7;let out=text(180,24,t<ready?'ЗАПОМНИТЕ ВСПЫШКИ':'ПОГАСИТЕ КОШМАР ПО ПАМЯТИ',12);pos.forEach(([x,y],i)=>{const active=show&&o.sequence[idx]===i;out+=circle(x,y,40,active?'#d178a6':'#44394f','#d7b2d3')+text(x,y+9,active?'✦':'☾',25)});r.svg.innerHTML=out;r.status(t<ready?'Запомните три вспышки':'Повторите порядок: '+r.state.actions.length+'/3')})};
})();
MINIGAMES.nikea740=(o,h)=>({bells:startNikeaBells740,veil:startNikeaVeil740,trail:startNikeaTrail740,threads:startNikeaThreads740,nightmare:startNikeaNightmare740,shot:startNikeaShot740})[o.mode](o,h);
