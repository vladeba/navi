/* A dedicated shop tab reuses the existing account-wide purchase and equip flow. */
(function(){'use strict';
const nav=document.querySelector('header nav'),main=document.querySelector('main'),panel=document.getElementById('shopPanel');
const tab=document.createElement('section');tab.id='skinStore750';tab.className='tab';tab.appendChild(panel);main.appendChild(tab);
const button=document.createElement('button');button.dataset.tab='skinStore750';button.textContent='🎨 Магазин скинов';nav.querySelector('[data-tab="top"]').before(button);
const previous=renderShop;renderShop=async function(...args){await previous(...args);const body=document.getElementById('shopBody'),h=body?.querySelector(':scope > h3');if(h&&h.textContent.includes('Расходники')){const grid=h.nextElementSibling;body.appendChild(h);if(grid)body.appendChild(grid)}else{const p=body?.querySelector(':scope > p.muted');if(p&&p.textContent.includes('Расходники покупают'))body.appendChild(p)}};
function open(){document.querySelectorAll('nav button,.tab').forEach(el=>el.classList.remove('active'));button.classList.add('active');tab.classList.add('active');renderShop();window.scrollTo({top:0,behavior:'smooth'})}
button.addEventListener('click',open);
const cards=document.querySelector('#home605 .mode-grid605');if(cards){const card=document.createElement('button');card.className='mode-card605';card.innerHTML='<span class="mode-icon605">🎨</span><h3>Магазин скинов</h3><p>Выбирай облики для любимых героев.</p><span class="mode-link605">ОТКРЫТЬ МАГАЗИН →</span>';card.addEventListener('click',open);cards.appendChild(card)}
})();
