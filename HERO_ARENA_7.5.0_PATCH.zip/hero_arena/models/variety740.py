"""Distinct physical controls for previously repetitive easy games."""
import math,random
from .minigames_56 import events,integer,trace,at,records,number,near
from . import heroes730

def crane_x(o,t,i):
 return 180+115*math.sin((t-o['prepare_ms'])/o['period']*math.tau+o['phases'][i])

def net_target(o,t):
 q=(t-o['prepare_ms'])/o['period']*math.tau+o['phase']
 return 180+110*math.sin(q),105+24*math.sin(q*.7)

def install():
 C=heroes730.CONFIG
 C['pagan','thunder']=('storm_circuit',14000,'Зажгите все четыре проводника Перуна: нажатие переключает выбранную плиту и две соседние.')
 C['cyclops','stone_flesh']=('stone_slide',18000,'Соберите каменную плиту: нажимайте соседние с пустым местом части, пока узор и числа не встанут по порядку.')
 C['croc','mud_shell']=('mud_paint',9000,'Зажмите и распределите грязь по панцирю: закрасьте светлые участки широкой кистью.')
 C['hunter','net']=('net_cast',8000,'Проведите сеть от руки к бегущей добыче: бросок нужно направить на её положение в момент отпускания.')
 C['minotaur','bone_wall']=('bone_crane',11000,'Опустите три кости на подсвеченные опоры: большая зона засчитывает попадание.')
 C['beastlord','kodo_guard']=('kodo_cover',6500,'Передвигайте щит кодоя к стороне, откуда летит стрела. Три широких направления.')
 C['ghoul','devour']=('devour_hunt',6900,'Передвигайте гуля под мясом, избегая костей. Каждый пойманный кусок укрепляет атаку.')
 old_params=heroes730.HeroGame.game_params;old_tier=heroes730.HeroGame.tier_from
 def params(self,u,t):
  o=old_params(self,u,t);f=o['factor'];mode=o['mode']
  if mode=='storm_circuit':
   masks=[7,11,13,14];state=15
   for i in random.sample(range(4),random.choice((1,2,3))):state^=masks[i]
   o.update(circuit=state,masks=masks)
  if mode=='stone_slide':
   board=list(range(1,9))+[0];empty=8;last=-1
   for _ in range(6):
    adjacent=[i for i in range(9) if abs(i%3-empty%3)+abs(i//3-empty//3)==1 and i!=last]
    n=random.choice(adjacent);board[empty],board[n]=board[n],board[empty];last,empty=empty,n
   if board==list(range(1,9))+[0]:board[7],board[8]=board[8],board[7]
   o['board']=board
  if mode=='mud_paint':o.update(patches=[[x,y] for y in (80,130,180) for x in (105,180,255)],brush=40,step_ms=max(1,round(35*f)))
  if mode=='net_cast':o.update(period=round(3500*f),phase=random.random()*math.tau,start=[180,225],start_radius=45,radius=38)
  if mode=='bone_crane':o.update(period=round(2900*f),phases=[random.random()*math.tau for _ in range(3)],slots=[80,180,280],radius=40)
  if mode=='kodo_cover':o.update(shots=[dict(ms=round((1850+i*1450)*f),x=x) for i,x in enumerate(random.choice(([85,275,180],[275,85,180],[180,85,275],[85,180,275])))],radius=52)
  if mode=='devour_hunt':
   vals=random.choice(([85,245,165,280,105,200],[255,95,180,70,270,165],[165,260,85,180,95,275]));o.update(drops=[dict(ms=round((1500+i*800)*f),x=x,good=i not in (2,5)) for i,x in enumerate(vals)],radius=43)
  return o
 def tier(self,c,o):
  if not isinstance(c,dict):return 3
  mode=o['mode'];elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);prep=o['prepare_ms'];f=o['factor']
  if mode not in ('bone_crane','kodo_cover','devour_hunt','mud_paint','net_cast','stone_slide','storm_circuit'):return old_tier(self,c,o)
  if elapsed<prep:return 3
  if mode=='storm_circuit':
   state=o['circuit'];actions=events(c,'actions',o,20)
   if not actions:return 3
   for a in actions:
    i=integer(a.get('switch'),hi=3)
    if i<0:return 3
    state^=o['masks'][i]
   lit=bin(state).count('1')
   return 0 if lit==4 else 1 if lit==3 else 2 if lit==2 else 3
  if mode=='stone_slide':
   board=o['board'][:];actions=events(c,'actions',o,60)
   if not actions:return 3
   for a in actions:
    i=integer(a.get('tile'),hi=8);empty=board.index(0)
    if i<0:return 3
    if abs(i%3-empty%3)+abs(i//3-empty//3)==1:board[i],board[empty]=board[empty],board[i]
   correct=sum(v==i+1 for i,v in enumerate(board[:8]))
   return 0 if board==list(range(1,9))+[0] else 1 if correct>=6 else 2 if correct>=3 else 3
  if mode=='mud_paint':
   pts=trace(c,o);holds=[]
   for a in records(c,'holds',50):
    if not isinstance(a,dict):return 3
    down=integer(a.get('down_ms'),lo=prep,hi=elapsed);up=integer(a.get('up_ms'),lo=prep,hi=elapsed)
    if down<0 or up<down or (holds and down<holds[-1][1]):return 3
    holds.append((down,up))
   if not pts or not holds:return 3
   touched=set()
   for t in range(prep,elapsed+1,o['step_ms']):
    if any(a<=t<b for a,b in holds):
     p=at(pts,t)
     for i,q in enumerate(o['patches']):
      if near(p,q,o['brush']):touched.add(i)
   return 0 if len(touched)>=8 else 1 if len(touched)>=6 else 2 if len(touched)>=3 else 3
  if mode=='net_cast':
   cuts=records(c,'cuts',1)
   if len(cuts)!=1 or not isinstance(cuts[0],dict):return 3
   a=cuts[0];down=integer(a.get('down_ms'),lo=prep,hi=elapsed);up=integer(a.get('up_ms'),lo=prep,hi=elapsed)
   if down<0 or up-down<100*f:return 3
   if not near((number(a.get('x0')),number(a.get('y0'))),o['start'],o['start_radius']):return 3
   q=net_target(o,up);d=math.dist((number(a.get('x1')),number(a.get('y1'))),q)
   return 0 if d<=o['radius']*.5 else 1 if d<=o['radius'] else 2 if d<=o['radius']*1.5 else 3
  if mode=='bone_crane':
   acts=events(c,'actions',o,3);good=0
   for i,a in enumerate(acts):good+=abs(crane_x(o,a['ms'],i)-o['slots'][i])<=o['radius']
   return 0 if good==3 else 1 if good==2 else 2 if good else 3
  pts=trace(c,o);engaged=integer(c.get('engaged_ms'),hi=elapsed)
  if not pts or engaged<prep:return 3
  if mode=='kodo_cover':
   good=sum(e['ms']<=elapsed and abs(at(pts,e['ms'])[0]-e['x'])<=o['radius'] for e in o['shots'])
   return 0 if good==3 else 1 if good==2 else 2 if good else 3
  meat=bad=0
  for e in o['drops']:
   hit=e['ms']<=elapsed and abs(at(pts,e['ms'])[0]-e['x'])<=o['radius']
   meat+=hit and e['good'];bad+=hit and not e['good']
  score=meat-bad
  return 0 if score>=4 else 1 if score>=3 else 2 if score>=1 else 3
 heroes730.HeroGame.game_params=params;heroes730.HeroGame.tier_from=tier
