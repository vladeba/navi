"""Arsteyd's form and resource prototype; not yet registered as playable."""
from .character import Character
from .skills import Skill,DamageSkill,SelfBuffSkill
from .effects import Shield,Burn
from .hero_states740 import DragonState

class ClawStrike740(DamageSkill):
 copyable=False
 def _perform(self,user,target):
  old=self.multiplier
  self.multiplier=1.10 if user.dragon.turns_left else 1.0
  try:logs=super()._perform(user,target)
  finally:self.multiplier=old
  if not user.dragon.turns_left:user.dragon.gain(12);logs.append('🐉 Сила дракона: %d/100.'%user.dragon.power)
  return logs

class FlameEdge740(DamageSkill):
 copyable=False
 def _perform(self,user,target):
  logs=super()._perform(user,target);user.dragon.gain(18);logs.append('🐉 Сила дракона: %d/100.'%user.dragon.power);return logs

class GatherGuard740(Skill):
 copyable=False
 def _perform(self,user,target):
  shield=round(user.max_hp*.08);user.add_effect(Shield(2,shield));user.dragon.gain(16)
  return ['🛡 Драконья стойкость: щит %d; сила дракона %d/100.'%(shield,user.dragon.power)]

class BecomeDragon740(Skill):
 copyable=False
 def ai_score(self,user,target):return 60 if user.dragon.power>=100 else 0
 def is_available(self,user):return super().is_available(user) and user.dragon.power>=100 and not user.dragon.turns_left
 def _perform(self,user,target):
  if not user.dragon.transform():return ['Недостаточно силы дракона.']
  user._skip_dragon_decrement=True
  return ['🐉 %s превращается в дракона на восемь собственных действий.'%user.name]

class Arsteyd(Character):
 hero_class,type_key,resource_name,role='Драконорождённый','arsteyd','драконья сила','warrior'
 PASSIVE_NOTES=('Удары и приёмы человека накапливают силу дракона. При 100 можно сменить форму на восемь собственных действий; здоровье сохраняется.',)
 def __init__(self,name,level=1):
  self.dragon=DragonState();self._skip_dragon_decrement=False
  super().__init__(name,max_hp=230,base_damage=13,armor=2.0,level=level,speed=6,dodge=.06,crit_chance=.10,max_energy=100,energy_regen=10,start_energy=60)
 def _create_skills(self):
  from .arsteyd_games740 import DragonFire740,DragonFlight740,EmberRunes740,SwordDuel740,DragonTrail740
  return [ClawStrike740('attack','Коготь дракона','Базовый удар меняется в форме дракона.',icon='🐉'),
   FlameEdge740('flame_edge','Жар крови','Удар и накопление драконьей силы.',multiplier=1.15,effect=lambda:Burn(2,3),cost=18,cooldown=2,icon='🔥'),
   GatherGuard740('dragon_guard','Драконья стойкость','Небольшой щит и накопление силы дракона.',cost=20,cooldown=4,icon='🛡'),
   BecomeDragon740('transform','Пробуждение дракона','При 100 силе сменить облик на восемь действий.',icon='🐲'),
   DamageSkill('tail_sweep','Взмах хвоста','Атака дракона.',multiplier=1.3,cost=18,cooldown=2,icon='🐲'),
   DamageSkill('dragon_flame','Пламя дракона','Наносит урон и накладывает горение.',multiplier=1.1,effect=lambda:Burn(2,3),cost=20,cooldown=3,icon='🔥'),
   SelfBuffSkill('scale_shield','Щит чешуи','Защита дракона на два хода.',effects=[lambda:Shield(2,22)],cost=20,cooldown=4,icon='🛡'),
   DragonFire740('dragon_fire','Огненное дыхание','Прожгите четыре пластины дыханием.',cost=28,cooldown=3,icon='🔥'),
   DragonFlight740('dragon_dive','Полёт сквозь скалы','Управляйте высотой инерционного полёта через просветы.',cost=24,cooldown=3,icon='🐉'),
   EmberRunes740('ember_runes','Печать драконьей крови','Сложите значения трёх рун до нужного числа.',cost=18,cooldown=3,icon='✴'),
   SwordDuel740('claw_duel','Поединок когтя','Два раза отразите выпад и ответьте мечом.',cost=20,cooldown=3,icon='⚔'),
   DragonTrail740('dragon_trail','Путь углей','Соберите угли и обойдите движущуюся тень.',cost=17,cooldown=4,icon='🔥')]
 def skill_unlocked(self,skill):
  if skill.key=='attack':return True
  return (skill.key in ('tail_sweep','dragon_flame','scale_shield','dragon_dive','dragon_fire')) if self.dragon.turns_left else skill.key not in ('tail_sweep','dragon_flame','scale_shield','dragon_dive','dragon_fire')
 def after_action(self,target):
  if self._skip_dragon_decrement:self._skip_dragon_decrement=False;return
  if self.dragon.turns_left and self.dragon.finish_dragon_turn():self._events.append('🐉 %s возвращается в облик человека.'%self.name)
 def on_skip(self):
  if self.dragon.turns_left and self.dragon.finish_dragon_turn():self._events.append('🐉 %s возвращается в облик человека.'%self.name)
 def _on_reset(self):self.dragon=DragonState();self._skip_dragon_decrement=False
 @property
 def image(self):
  if self.dragon.turns_left:return '/static/images/skins/arsteyd_'+self.skin+'_dragon.jpg' if self.skin else '/static/images/arsteyd_dragon.jpg'
  return Character.image.fget(self)
 def to_dict(self):
  d=super().to_dict();d.update(dragon_power=self.dragon.power,dragon_turns=self.dragon.turns_left);return d
