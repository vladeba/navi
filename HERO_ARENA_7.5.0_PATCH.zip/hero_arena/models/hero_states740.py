"""Turn-state rules, kept separate so they can be verified before battle integration."""
from dataclasses import dataclass

@dataclass
class DragonState:
    power: int = 0
    turns_left: int = 0
    def gain(self, amount):
        if self.turns_left==0:self.power=max(0,min(100,self.power+max(0,int(amount))))
    def transform(self):
        if self.turns_left or self.power<100:return False
        self.power=0;self.turns_left=8;return True
    def finish_dragon_turn(self):
        if self.turns_left:self.turns_left-=1
        return self.turns_left==0
    def revert(self):self.turns_left=0

@dataclass
class CharmState:
    remaining: int = 0
    casts: int = 0
    immunity: int = 0
    def begin(self):
        if self.immunity or self.remaining:return False
        self.casts=1;self.remaining=1;return True
    def maintain(self):
        if not self.casts or self.casts>=3 or self.immunity or self.remaining:return False
        self.casts+=1;self.remaining=1;return True
    def consume_turn(self):
        if not self.remaining:return False
        self.remaining-=1;return True
    def finish(self):
        if self.casts:self.immunity=2
        self.casts=0;self.remaining=0
    def on_target_turn_end(self):
        if self.immunity:self.immunity-=1

@dataclass
class DreamState:
    phase: str = 'idle'
    self_sleep_turns: int = 0
    def apply(self, action, success=True):
        """Non-combo actions remain selectable; wrong combo steps cause self sleep."""
        paths={'sleep':('idle','asleep'),'maintain':('asleep','maintained'),
               'prepare':('maintained','ready'),'shot':('ready','idle')}
        if action not in paths:return 'free'
        expected,nxt=paths[action]
        if not success or self.phase!=expected:
            self.phase='idle';self.self_sleep_turns=1;return 'failed'
        self.phase=nxt;return 'success'
    def rest(self):self.self_sleep_turns=3
    def consume_sleep_turn(self):
        if not self.self_sleep_turns:return False
        self.self_sleep_turns-=1;return True
