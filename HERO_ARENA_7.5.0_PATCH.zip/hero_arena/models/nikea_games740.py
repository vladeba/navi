"""Nikeya's six dream games: measured inputs; no trusted client scores.
Staged until UI, complete battle behavior, and balance are validated.
"""
import math,random
from .skills import MiniGameSkill
from .minigames_56 import Replay,events,number,integer,records,near,trace,at

class NikeaGame740(Replay,MiniGameSkill):
 copyable=False
 game='nikea740';PREP=600;reactor='user';TIME_LIMIT_MS=7200
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(50,35,10,5)
 MODE='bells';hero_target=True
 def pick_reactor(self,user,target,is_human):return user
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(mode=self.MODE,hero_type='nikea',instruction=self.prompt)
  if self.MODE=='bells':o.update(period=round(3600*f),phase=random.random()*math.tau,samples=[round((1800+i*1300)*f) for i in range(3)])
  elif self.MODE=='veil':o.update(center=[180,130],ring_radius=72,ring_width=24,turns=1.5)
  elif self.MODE=='trail':o.update(rings=[random.randint(1,3) for _ in range(3)],max_moves=12)
  elif self.MODE=='threads':o.update(gates=[[95,80],[150,180],[210,80],[265,180]],radius=34)
  elif self.MODE=='nightmare':o.update(sequence=[random.randrange(4) for _ in range(3)],flash_ms=round(700*f),reveal_ms=round(1100*f))
  elif self.MODE=='shot':o.update(period=round(3800*f),phases=[random.random()*math.tau for _ in range(3)],target_y=110,radius=22)
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);prep=o['prepare_ms'];f=o['factor'];mode=o['mode']
  if elapsed<prep:return 3
  if mode=='bells':
   p=trace(c,o);engaged=integer(c.get('engaged_ms'),hi=elapsed)
   if not p or engaged<prep:return 3
   good=perfect=0
   for t in o['samples']:
    x,_=at(p,t);offset=max(-75,min(75,x-180));swings=bell_swings(o,t)
    worst=max(abs(v+offset) for v in swings)
    if t<=elapsed:perfect+=worst<=15;good+=worst<=26
   return 0 if perfect==3 else 1 if good>=2 else 2 if good else 3
  if mode=='veil':
   p=trace(c,o);engaged=integer(c.get('engaged_ms'),hi=elapsed)
   if not p or engaged<prep:return 3
   progress=ring_progress(o,p,elapsed)
   return 0 if progress>=o['turns']*math.tau else 1 if progress>=math.tau else 2 if progress>=math.pi else 3
  if mode=='trail':
   acts=events(c,'actions',o,o['max_moves']);rings=o['rings'][:]
   for action in acts:
    i=integer(action.get('ring'),hi=2)
    if i<0:return 3
    rings[i]=(rings[i]+1)%4
   good=sum(x==0 for x in rings)
   return 0 if good==3 else 1 if good==2 else 2 if good else 3
  if mode=='threads':
   p=trace(c,o);engaged=integer(c.get('engaged_ms'),hi=elapsed)
   if not p or engaged<prep:return 3
   good=weave_progress(o,p)
   return 0 if good==4 else 1 if good==3 else 2 if good>=1 else 3
  if mode=='nightmare':
   acts=events(c,'actions',o,3);good=0
   ready=o['prepare_ms']+o['reveal_ms']+len(o['sequence'])*o['flash_ms']
   for i,action in enumerate(acts):
    if action['ms']<ready or integer(action.get('tile'),hi=3)<0:return 3
    if action['tile']!=o['sequence'][i]:break
    good+=1
   return 0 if good==3 else 1 if good==2 else 2 if good else 3
  if mode=='shot':
   acts=events(c,'actions',o,1)
   if not acts:return 3
   a=acts[0];aim=number(a.get('y'),lo=20,hi=240)
   if aim==-999:return 3
   points=dream_ray(o,a['ms'],aim);dist=abs(points[-1][1]-o['target_y'])
   if any(y<15 or y>245 for _,y in points):return 3
   return 0 if dist<=o['radius']*.45 else 1 if dist<=o['radius'] else 2 if dist<=o['radius']*1.5 else 3
  return 3
 def apply(self,u,t,tier,data):
  if self.MODE in ('bells','veil','threads','shot'):
   stage={'bells':'sleep','veil':'maintain','threads':'prepare','shot':'shot'}[self.MODE]
   good=tier<2
   if stage=='shot' and u.dream.phase!='ready':
    logs=u.resolve_combo_stage(stage,t,False);return logs+['✨ Незавершённый выстрел не наносит существенного урона.']
   logs=u.resolve_combo_stage(stage,t,good)
   if good and stage=='shot':
    hit,_=self.strike(u,t,(7.0,5.5,.5,0)[tier],ignore_armor=True);logs+=hit
   return logs
  if tier==3:return ['🌙 Приём не удался.']
  mult={'trail':(.9,.7,.4,0),'nightmare':(1.0,.75,.4,0)}[self.MODE][tier]
  logs,_=self.strike(u,t,mult);return logs
 def ai_score(self,u,t):
  expected={'bells':'idle','veil':'asleep','threads':'maintained','shot':'ready'}
  if self.MODE in expected:return 40 if u.dream.phase==expected[self.MODE] else -50
  return 14

def ring_progress(o,points,elapsed):
 """Count deliberate clockwise turns within the protective ring."""
 pts=[p for p in points if o['prepare_ms']<=p[0]<=elapsed]
 total=0.;last=None
 for _,x,y in pts:
  dx=x-o['center'][0];dy=y-o['center'][1];radius=math.hypot(dx,dy)
  if abs(radius-o['ring_radius'])>o['ring_width']:last=None;continue
  angle=math.atan2(dy,dx)
  if last is not None:
   delta=(angle-last+math.pi)%(2*math.pi)-math.pi
   if abs(delta)<=.55:total=max(0.,total+delta)
  last=angle
 return total

def weave_progress(o,points):
 """Cross each loom gate from left to right, alternating over and under."""
 index=0
 points=[p for p in points if p[0]>=o['prepare_ms']]
 for a,b in zip(points,points[1:]):
  if index>=len(o['gates']):break
  gx,gy=o['gates'][index]
  if a[1]<=gx<=b[1] and b[1]>a[1]:
   y=a[2]+(b[2]-a[2])*(gx-a[1])/(b[1]-a[1])
   if abs(y-gy)<=o['radius']:index+=1
 return index

def bell_swings(o,t):
 q=(t-o['prepare_ms'])/o['period']*math.tau+o['phase']
 return [40*math.sin(q+delta) for delta in (-.25,0,.25)]

def dream_ray(o,t,aim_y):
 """A plasma ray refracts at three moving dream veils; shared with the client."""
 xs=(35,110,180,250,330);result=[];drift=0
 for i,x in enumerate(xs):
  if 1<=i<=3:drift+=14*math.sin((t-o['prepare_ms'])/o['period']*math.tau+o['phases'][i-1])
  result.append((x,200+(aim_y-200)*(x-35)/295+drift))
 return result

def game(key,name,prompt,mode,cost,cd):
 g=NikeaGame740(key,name,prompt,cost=cost,cooldown=cd,icon='🌙');g.MODE=mode;g.prompt=prompt;return g

def skills():
 return [game('lullaby','Колыбельный звон','Ведите ладонь против раскачивания, чтобы три колокольчика затихли к моментам проверки.','bells',18,3),
  game('hold_dream','Хрупкий сон','Обведите спящую луну по часовой стрелке, удерживая палец на защитном кольце.','veil',14,2),
  game('dream_path','Тропа сновидений','Поверните три кольца карты сна так, чтобы светлая тропа соединилась от центра к краю.','trail',16,3),
  game('dream_knot','Узел грёзы','Протяните нить слева направо через четыре чередующихся прохода ткацкого станка.','threads',20,3),
  game('nightmare','Пробуждение кошмара','Запомните три вспышки кошмара, затем погасите их в том же порядке.','nightmare',20,4),
  game('precise_shot','Точный выстрел','Наведите луч через три движущиеся завесы и выстрелите в центр цели.','shot',28,4)]
