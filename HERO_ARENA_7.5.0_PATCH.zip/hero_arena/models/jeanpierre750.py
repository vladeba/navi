"""Jean-Pierre, rat king: orders, targetable swarm and bespoke trials."""
import math,random
from .character import Character
from .effects import Effect,DodgeBuff,Blinded
from .skills import Skill,DamageSkill,MiniGameSkill
from .minigames_56 import Replay,events,records,integer,number,near

class RatSwarm(Character):
 is_minion=True;type_key='rat_swarm';hero_class='Крысиная стая';kind='rat_swarm'
 def __init__(self,owner,tier):
  self.owner=owner;self.quality=tier;self.slot=0
  hp=(58,45,32)[tier];damage=(8,6,4)[tier]
  super().__init__('Королевская стая',max_hp=round(hp*owner.power_scale()),base_damage=damage*owner.power_scale(),armor=.5,speed=5,dodge=.05,crit_chance=.05,energy_regen=0,start_energy=0)
  self.id=f's{owner.id}_0';self._arena=True;self._battle=getattr(owner,'_battle',None);self.opponent=owner.opponent
  self.expires_round=getattr(self._battle,'round',0)+5;self.lifetime=5;self.rat_count=(6,4,2)[tier]
 def _create_skills(self):return [DamageSkill('attack','Укус стаи','Стая атакует после действия короля.',accuracy=.9,icon='🐀')]
 def act(self,target):
  logs,can=self.start_turn()
  if can and self.is_alive() and target.is_alive():logs+=self.skills['attack'].execute(self,target)
  return logs+self.pop_events()
 def to_dict(self):
  return dict(id=self.id,slot=0,type='RatSwarm',kind=self.kind,name=self.name,icon='🐀'*self.rat_count,image='/static/images/rat_swarm750.jpg',hp=self.hp,max_hp=self.max_hp,damage=self.get_damage(),armor=self.armor_total(),dodge=self.get_dodge(),alive=self.is_alive(),lifetime=self.lifetime,lifetime_unit='round',expires_round=self.expires_round,targetable=True,effects=[e.to_dict() for e in self.get_effects()],about=f'{self.rat_count} крыс; атакует после хода короля')

class RatBasic(DamageSkill):
 copyable=False
 def _perform(self,u,t):
  logs=super()._perform(u,t);u.gain_order(1);return logs+[f'👑 Приказы: {u.orders}/3.']
class RatMock(Skill):
 def _perform(self,u,t):
  t.add_effect(Blinded(3,15));return [f'👑 {t.name}: точность −15% на два хода.']
class RatTheft(DamageSkill):
 copyable=False
 def _after_hit(self,u,t,damage):
  logs=super()._after_hit(u,t,damage);n=6
  if u.orders:n+=5;u.orders-=1
  stolen=min(n,t.energy);t.spend_energy(stolen);u.restore_energy(stolen)
  return logs+[f'🐀 {u.name} похищает {stolen} ресурса; приказы {u.orders}/3.']
class RoyalDecree(DamageSkill):
 copyable=False
 def _perform(self,u,t):
  used=u.orders;u.orders=max(0,u.orders-(max(0,used-1) if u.protected_order else used));u.protected_order=False
  old=self.multiplier;self.multiplier=.7+.36*used
  try:logs=super()._perform(u,t)
  finally:self.multiplier=old
  if used and u.swarm_alive() and t.is_alive():
   # The normal post-action swarm attack still happens once: command boosts it.
   u.minions[0]._royal_bonus=used
   logs.append(f'🐀 Стая готовит совместный выпад: сила +{used*20}%.')
  return logs+[f'👑 Приказы: {u.orders}/3.']

class RatGame(Replay,MiniGameSkill):
 copyable=False;game='ratking750';reactor='user';hero_target=True;PREP=600;TIME_LIMIT_MS=8500
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(28,42,22,8);MODE='gather'
 def pick_reactor(self,u,t,is_human):return u
 def is_available(self,u):return super().is_available(u) and (self.MODE!='gather' or not u.swarm_alive())
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(mode=self.MODE,hero_type='jeanpierre',instruction=self.prompt)
  if self.MODE=='gather':o.update(duration=round(6500*f),cycle=round(1800*f),dark=round(1200*f),step=max(1,round(25*f)),goal=round(2800*f))
  elif self.MODE=='crown':o.update(waves=[dict(ms=round((1900+i*1900)*f),danger=random.randrange(3)) for i in range(3)])
  else:
   solution=[0,0,1];initial=[random.randrange(2) for _ in range(3)]
   if initial==solution:initial[random.randrange(3)]^=1
   o.update(initial=initial,solution=solution)
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);prep=o['prepare_ms'];f=o['factor']
  if elapsed<prep:return 3
  if self.MODE=='gather':
   holds=[]
   for a in records(c,'holds',40):
    if not isinstance(a,dict):return 3
    down=integer(a.get('down_ms'),lo=prep,hi=elapsed);up=integer(a.get('up_ms'),lo=prep,hi=elapsed)
    if down<0 or up<down or (holds and down<holds[-1][1]):return 3
    holds.append((down,up))
   progress,exposure=rat_gather(o,holds,elapsed)
   score=progress-max(0,exposure*2)
   return 0 if score>=o['goal'] else 1 if score>=o['goal']*.65 else 2 if score>=o['goal']*.3 else 3
  if self.MODE=='crown':
   moves=[];current=1;last=prep-1;xs=[80,180,280]
   for a in records(c,'cuts',12):
    if not isinstance(a,dict):return 3
    down=integer(a.get('down_ms'),lo=prep,hi=elapsed);up=integer(a.get('up_ms'),lo=prep,hi=elapsed)
    lane=integer(a.get('lane'),hi=2)
    if lane<0 or down<=last or up-down<80*f:return 3
    last=up
    if near((number(a.get('x0')),number(a.get('y0'))),(xs[current],150),42) and near((number(a.get('x1')),number(a.get('y1'))),(xs[lane],150),42):current=lane;moves.append((up,lane))
   good=0
   for wave in o['waves']:
    choices=[v for v in moves if wave['ms']-1100*f<=v[0]<=wave['ms']]
    good+=bool(choices and choices[-1][1]!=wave['danger'] and elapsed>=wave['ms'])
   return 0 if good==3 else 1 if good==2 else 2 if good==1 else 3
  states=o['initial'][:];acts=events(c,'actions',o,18)
  if not acts:return 3
  for a in acts:
   i=integer(a.get('mirror'),hi=2)
   if i<0:return 3
   states[i]^=1
  correct=sum(a==b for a,b in zip(states,o['solution']))
  return 0 if correct==3 else 1 if correct==2 else 2 if correct==1 else 3
 def apply(self,u,t,tier,data):
  if self.MODE=='gather':
   if tier==3:return ['🐀 Разведчик не собрал стаю.']
   u.raise_swarm(tier);u.gain_order(2 if tier<2 else 1);u.restore_energy((10,7,3)[tier]);return [f'🐀 Собрано {u.minions[0].rat_count} крыс; приказы {u.orders}/3.']
  if self.MODE=='crown':
   if tier==3:return ['👑 Корона не спасена.']
   u.add_effect(DodgeBuff(3,(18,12,6)[tier]));u.protected_order=tier<2;return ['👑 Уклонение повышено.'+(' Следующий указ сохранит один приказ.' if u.protected_order else '')]
  if tier==3:return ['💎 Луч не достиг цели.']
  boost=bool(u.orders);u.orders-=int(boost);logs,_=self.strike(u,t,(1.9,1.4,.7,0)[tier]+(.25 if boost else 0),ignore_armor=True);return logs+[f'👑 Приказы: {u.orders}/3.']
 def ai_score(self,u,t):
  if self.MODE=='gather':return 35 if not u.swarm_alive() else -20
  if self.MODE=='crown':return 12 if u.hp>u.max_hp*.4 else 21
  return 19+u.orders*2

def rat_gather(o,holds,elapsed):
 progress=exposure=0
 for tm in range(o['prepare_ms'],min(elapsed,o['prepare_ms']+o['duration'])+1,o['step']):
  if any(a<=tm<b for a,b in holds):
   if (tm-o['prepare_ms'])%o['cycle']<o['dark']:progress+=o['step']
   else:exposure+=o['step']
 return progress,exposure

def game(k,n,p,mode,cost,cd):
 g=RatGame(k,n,p,cost=cost,cooldown=cd,icon='🐀' if mode=='gather' else '👑' if mode=='crown' else '💎');g.MODE=mode;g.prompt=p;return g

class JeanPierre(Character):
 hero_class,type_key,resource_name,role='Крысиный король','jeanpierre','хитрость','trickster'
 signature_skill='decree'
 PASSIVE_NOTES=('Король помоек: один раз при падении ниже 40% HP получает 15 ресурса и +20 п.п. уклонения на два своих хода.',)
 def __init__(self,name,level=1):
  self.orders=0;self.protected_order=False;self.minions=[None];self._rat_passive=False
  super().__init__(name,max_hp=165,base_damage=14,armor=.5,level=level,speed=9,dodge=.17,crit_chance=.1,max_energy=100,energy_regen=12,start_energy=65)
 def _create_skills(self):return [
  RatBasic('attack','Удар скипетром','Обычный удар; +1 приказ, максимум 3.',icon='👑'),
  RatMock('mock','Королевская наглость','Снижает точность врага на 15% на два хода.',cost=14,cooldown=3,icon='😼'),
  RatTheft('theft','Из-под плаща','Удар и кража 6 ресурса; один приказ усиливает кражу до 11.',multiplier=1.15,cost=16,cooldown=2,icon='🐾'),
  RoyalDecree('decree','Королевский указ','Расходует приказы, усиливая удар. Живая стая проводит совместную атаку.',cost=24,cooldown=3,icon='📜'),
  game('summon_rats','Созыв королевской стаи','Зажмите движение в темноте; отпускайте, когда загорается фонарь. Разведчик собирает стаю.','gather',28,5),
  game('hide_crown','Украденная корона','Прячьте корону в одной из двух безопасных ниш, пока рука обыскивает третью.','crown',18,4),
  game('ruby_staff','Рубиновый скипетр','Поворачивайте три зеркала, чтобы провести луч от рубина к цели.','ruby',24,3)]
 def gain_order(self,n):self.orders=min(3,max(0,self.orders+n))
 def swarm_alive(self):return bool(self.minions and self.minions[0] and self.minions[0].is_alive())
 def raise_swarm(self,tier):self.minions=[RatSwarm(self,tier)]
 def summon_act(self,target):
  if not self.swarm_alive() or not target.is_alive():return []
  pet=self.minions[0];boost=getattr(pet,'_royal_bonus',0);old=pet._base_damage;pet._base_damage=old*(1+.2*boost);pet._royal_bonus=0
  try:return pet.act(target)
  finally:pet._base_damage=old
 def take_damage(self,amount,ignore_armor=False,attacker=None):
  damage=super().take_damage(amount,ignore_armor,attacker);self._check_passive();return damage
 def _check_passive(self,duration=3):
  if self.is_alive() and not self._rat_passive and self.hp<self.max_hp*.4:
   self._rat_passive=True;self.restore_energy(15);self.add_effect(DodgeBuff(duration,20));self._events.append('🐀 Король помоек: +15 ресурса и уклонение +20 п.п.')
 def start_turn(self):
  logs,can=super().start_turn();self._check_passive(2);return logs,can
 def _on_reset(self):self.orders=0;self.protected_order=False;self.minions=[None];self._rat_passive=False
 def to_dict(self):
  d=super().to_dict();d.update(orders=self.orders,protected_order=self.protected_order,summons=[s.to_dict() for s in self.minions if s is not None],summon_capacity=1);return d
