"""Hermione prototype: not registered until the custom client games are complete."""
import math
from .character import Character
from .skills import Skill,DamageSkill,SelfBuffSkill,MiniGameSkill
from .effects import Effect,DodgeBuff
from .dream_effects740 import Charm740
from .charm_rules740 import CharmCombo740
from .minigames_56 import Replay,trace,at,events,integer,number,records,near

class DesireMark740(Effect):
 name,icon='Метка соблазна','💗'
 def __init__(self):super().__init__(2,0)

class MarkSkill740(Skill):
 def _perform(self,u,t):t.add_effect(DesireMark740());return ['💗 %s оставляет метку соблазна.'%u.name]

class HermioneGame740(Replay,MiniGameSkill):
 copyable=False
 game='hermione740';reactor='user';hero_target=True;PREP=600;TIME_LIMIT_MS=6500
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,43,25,10);MODE='gaze'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(mode=self.MODE,hero_type='hermione',instruction=self.prompt)
  if self.MODE=='gaze':o.update(samples=[round((1500+i*900)*f) for i in range(5)],period=round(3400*f),radius=36 if t and t.has_effect(DesireMark740) else 28)
  elif self.MODE=='sustain':o.update(duration=round(4300*f),target=[.32,.7],gain=.00034/f,decay=.00016/f)
  elif self.MODE=='claws':o.update(start=[(80,195),(280,195),(180,225)],end=[(270,65),(90,65),(180,50)],radius=38)
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);prep=o['prepare_ms'];f=o['factor']
  if elapsed<prep:return 3
  if o['mode']=='gaze':
   pts=trace(c,o);engaged=integer(c.get('engaged_ms'),hi=elapsed)
   if not pts or engaged<prep:return 3
   hits=sum(t<=elapsed and near(at(pts,t),gaze_target(o,t),o['radius']) for t in o['samples'])
   return 0 if hits==5 else 1 if hits>=4 else 2 if hits>=2 else 3
  if o['mode']=='sustain':
   holds=records(c,'holds',30);parsed=[]
   for h in holds:
    if not isinstance(h,dict):return 3
    down=integer(h.get('down_ms'),lo=prep,hi=elapsed);up=integer(h.get('up_ms'),lo=prep,hi=elapsed)
    if down<0 or up<down or (parsed and down<parsed[-1][1]):return 3
    parsed.append((down,up))
   v=.5;good=total=0;step=max(1,round(25*f));end=min(elapsed,prep+o['duration'])
   for t in range(prep,end,step):
    active=any(a<=t<b for a,b in parsed);v=max(0,min(1,v+(o['gain'] if active else -o['decay'])*step))
    good+=o['target'][0]<=v<=o['target'][1];total+=1
   ratio=good/max(1,round(o['duration']/step))
   return 0 if ratio>=.9 else 1 if ratio>=.72 else 2 if ratio>=.45 else 3
  if o['mode']=='claws':
   cuts=records(c,'cuts',3);hits=0;last=prep-1
   for i,a in enumerate(cuts):
    if not isinstance(a,dict):return 3
    down=integer(a.get('down_ms'),lo=prep,hi=elapsed);up=integer(a.get('up_ms'),lo=prep,hi=elapsed)
    if down<=last or up-down<100*f:return 3
    last=up
    p=(number(a.get('x0')),number(a.get('y0')));q=(number(a.get('x1')),number(a.get('y1')))
    hits+=near(p,o['start'][i],o['radius']) and near(q,o['end'][i],o['radius'])
   return 0 if hits==3 else 1 if hits==2 else 2 if hits else 3
  return 3
 def apply(self,u,t,tier,data):
  if self.MODE=='gaze':
   if tier>=2 or not u.charm_combo.start(t):return ['💘 Очарование не сработало или цель защищена.']
   t._effects=[e for e in t.get_effects() if not isinstance(e,DesireMark740)]
   return ['💘 %s очарован(а): пропускает ход.'%t.name]
  if self.MODE=='sustain':
   if tier<2 and u.charm_combo.extend(t):return ['💘 Очарование продлено: %d/3.'%u.charm_combo.count]
   u.charm_combo.finish();return ['💘 Нить очарования оборвалась.']
  had=u.charm_combo.count>0;u.charm_combo.finish()
  if tier==3:return ['🦋 Выпад не удался.']
  mult=(1.9,1.5,.8,0)[tier]*(1.15 if had else 1);logs,_=self.strike(u,t,mult);return logs
 def ai_score(self,u,t):
  from .dream_effects740 import CharmWard740
  if self.MODE=='gaze':return 35 if not u.charm_combo.count and not t.has_effect(CharmWard740) else -50
  if self.MODE=='sustain':return 42 if u.charm_combo.count and u.charm_combo.count<3 and not t.has_effect(Charm740) else -50
  return 23 if u.charm_combo.count else 13

def gaze_target(o,t):
 q=(t-o['prepare_ms'])/o['period']*math.tau;return 180+75*math.sin(q),125+36*math.sin(q*.7)
def game(k,n,p,mode,cost,cd):
 s=HermioneGame740(k,n,p,cost=cost,cooldown=cd,icon='💘');s.MODE=mode;s.prompt=p;return s
class Hermione(Character):
 hero_class,type_key,resource_name,role='Суккуб','hermione','обаяние','trickster'
 PASSIVE_NOTES=('Игра с добычей: первое очарование в серии восстанавливает 10 ресурса. Серия длится не более трёх пропусков; после комбо урон −20%, уклонение +15 п.п. на два хода.',)
 def __init__(self,name,level=1):
  self.charm_combo=CharmCombo740(self);self._last_charm_key=None
  super().__init__(name,max_hp=160,base_damage=12.5,armor=.4,level=level,speed=10,dodge=.20,crit_chance=.12,max_energy=100,energy_regen=12,start_energy=65)
 def _create_skills(self):return [
  DamageSkill('attack','Удар когтями','Обычный удар когтями.',accuracy=.94,icon='🐾'),
  MarkSkill740('desire_mark','Манящий взгляд','Оставляет метку на два хода: зона удержания взгляда шире. При очаровании метка расходуется.',cost=12,cooldown=3,icon='💗'),
  DamageSkill('tail_strike','Удар хвостами','Два удара заострёнными хвостами.',multiplier=.7,hits=2,cost=18,cooldown=2,icon='🦂'),
  SelfBuffSkill('veil','Покров суккуба','Уклонение на два хода.',effects=[lambda:DodgeBuff(2,18)],cost=20,cooldown=4,icon='🌫'),
  game('charm','Запретный взгляд','Удерживайте взгляд на движущемся глазе.','gaze',25,4),
  game('charm_hold','Нити искушения','Удерживайте натяжение в безопасной зоне.','sustain',20,0),
  game('charm_finish','Поцелуй тьмы','Проведите когтями и хвостами по трём направлениям.','claws',22,4)]
 def begin_action(self,skill,target):self._last_charm_key=skill.key
 def after_action(self,target):
  if self.charm_combo.count and self._last_charm_key not in ('charm','charm_hold'):
   self.charm_combo.finish()
 def on_skip(self):
  if self.charm_combo.count:self.charm_combo.finish();self._events.append('💘 Серия прервана: Гермиона пропустила действие.')
 def _on_reset(self):self.charm_combo=CharmCombo740(self);self._last_charm_key=None
 def to_dict(self):
  d=super().to_dict();d['charm_combo']=self.charm_combo.count;return d
