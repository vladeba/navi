"""Battle effects for sleep and charm. Not installed until heroes and UI are ready."""
import math
from .effects import Effect

class DreamSleep740(Effect):
    """Nikeya's rest ends after three *opponent actions*, not on her third start."""
    name,icon,positive='Сон Никеи','💤',True
    def __init__(self):
        super().__init__(3,75)
        self.healed=0
        self._pending_heal=0
    def prevents_action(self):return True
    def on_turn_start(self,owner):return [f'💤 {owner.name} спит и пропускает действие.']
    def tick(self):pass
    def enemy_action_finished(self,owner):
        if self.duration>0:self.duration-=1
    def modify_incoming(self,owner,damage,attacker):
        # Applied to combat damage at this effect's position in the effect chain.
        amount=max(0,damage);limit=max(0,round(owner.max_hp*.18)-self.healed)
        self._pending_heal=min(limit,round(amount*.10))
        reduced=math.ceil(amount*.25)
        return reduced,[f'💤 Сон ослабляет удар: {reduced} урона.']
    def after_incoming(self,owner,damage,attacker):
        heal=self._pending_heal;self._pending_heal=0
        if not owner.is_alive() or heal<=0:return []
        healed=owner.heal(heal);self.healed+=healed
        return [f'💤 Сон восстанавливает {healed} HP.'] if healed else []


class SleepFailure740(Effect):
    name,icon='Сорванная грёза','💤'
    def __init__(self):super().__init__(1,0)
    def prevents_action(self):return True
    def on_turn_start(self,owner):return [f'💤 {owner.name} уснула после ошибки и пропускает ход.']

class Charm740(Effect):
    name,icon='Очарование','💘'
    def __init__(self,source):super().__init__(1,0);self.source=source
    def prevents_action(self):return True
    def on_turn_start(self,owner):return [f'💘 {owner.name} очарован(а) и пропускает действие.']
    def on_expire(self,owner):
        combo=getattr(self.source,'charm_combo',None)
        if combo and combo.target is owner and combo.count>=3:
            combo.finish();return ['💘 Очарование рассеялось; цель получает защиту на два хода.']
        return []

class CharmWard740(Effect):
    name,icon,positive='Ясный разум','🧠',True
    def __init__(self):super().__init__(2,0)
