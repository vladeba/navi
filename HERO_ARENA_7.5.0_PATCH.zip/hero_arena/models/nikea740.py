"""Nikeya's sleep/combo prototype. Do not register until her games are complete."""
from .character import Character
from .skills import Skill,DamageSkill
from .effects import Effect
from .dream_effects740 import DreamSleep740,SleepFailure740
from .hero_states740 import DreamState
class EnemyDream740(Effect):
 name,icon='Сон','💤'
 def __init__(self,source):super().__init__(1,0);self.source=source
 def prevents_action(self):return True
 def on_turn_start(self,owner):return ['💤 %s погружается в сон и пропускает ход.'%owner.name]
class Rest740(Skill):
 copyable=False
 def is_available(self,user):return super().is_available(user) and not user.has_effect(DreamSleep740)
 def _perform(self,user,target):
  user.dream=DreamState();user.add_effect(DreamSleep740());return ['💤 %s засыпает на три хода соперника.'%user.name]
class Nikeya(Character):
 hero_class,type_key,resource_name,role='Хранительница снов','nikea','дрёма','light'
 PASSIVE_NOTES=('Во сне защищена от части урона. Правильная последовательность: сон, поддержание, подготовка, выстрел; неправильный этап усыпляет Никею.',)
 def __init__(self,name,level=1):
  self.dream=DreamState();self.dream_target=None
  super().__init__(name,max_hp=185,base_damage=12,armor=.5,level=level,speed=8,dodge=.13,crit_chance=.10,max_energy=100,energy_regen=12,start_energy=65)
 def _create_skills(self):
  from .nikea_games740 import skills
  return [DamageSkill('attack','Тихий звон','Небольшой плазменный удар.',multiplier=.65,icon='🔔'),Rest740('rest','Сон','Спит три полных хода соперника, получает уменьшенный урон и небольшое лечение.',cost=24,cooldown=8,icon='💤')]+skills()
 def take_dot_damage(self,amount):
  sleep=next((e for e in self.get_effects() if isinstance(e,DreamSleep740)),None)
  if sleep is None:
   self.hp=self.hp-amount;return amount
  damage,logs=sleep.modify_incoming(self,amount,None);self._events.extend(logs);self.hp=self.hp-damage
  self._events.extend(sleep.after_incoming(self,damage,None));return damage
 def _on_reset(self):self.dream=DreamState();self.dream_target=None
 def resolve_combo_stage(self,stage,target,success):
  if self.dream_target is not None and target is not self.dream_target and stage!='sleep':success=False
  result=self.dream.apply(stage,success)
  if result=='failed':
   if self.dream_target:self.dream_target._effects=[e for e in self.dream_target.get_effects() if not (isinstance(e,EnemyDream740) and e.source is self)]
   self.dream_target=None;self.add_effect(SleepFailure740());return ['💤 Комбинация сорвана: Никея засыпает на ход.']
  if result=='success':
   if stage in ('sleep','maintain','prepare'):
    self.dream_target=target;target.add_effect(EnemyDream740(self));return ['🌙 Этап сна выполнен: %s.'%stage]
   if stage=='shot':
    target._effects=[e for e in target.get_effects() if not (isinstance(e,EnemyDream740) and e.source is self)]
    self.dream_target=None;return ['✨ Комбинация завершена точным выстрелом.']
  return []
 def on_opponent_action_finished(self,opponent):
  if opponent is self.dream_target and self.dream.phase!='idle':
   self.dream=DreamState();self.dream_target=None;self._events.append('🌙 Противник проснулся: подготовка сна рассеялась.')
 def to_dict(self):
  d=super().to_dict();d['dream_phase']=self.dream.phase;return d
