"""Bounded charm-combo bookkeeping; integration and custom games pending."""
from .effects import Effect
from .dream_effects740 import Charm740,CharmWard740
class SpentCharm740(Effect):
 name,icon,positive='Ускользающая тень','🦋',True
 def __init__(self):super().__init__(2,0);self._first_turn=True
 def tick(self):
  if self._first_turn:self._first_turn=False
  else:super().tick()
 def damage_bonus(self):return -.20
 def dodge_bonus(self):return .15
class CharmCombo740:
 def __init__(self,source):self.source=source;self.target=None;self.count=0
 def start(self,target):
  if self.count or target.has_effect(CharmWard740) or target.has_effect(Charm740):return False
  self.target=target;self.count=1;target.add_effect(Charm740(self.source));self.source.restore_energy(10);return True
 def extend(self,target):
  if target is not self.target or not self.count or self.count>=3 or target.has_effect(CharmWard740) or target.has_effect(Charm740):return False
  self.count+=1;target.add_effect(Charm740(self.source));return True
 def finish(self):
  if not self.count:return False
  if self.target:
   self.target._effects=[e for e in self.target.get_effects() if not (isinstance(e,Charm740) and e.source is self.source)]
   self.target.add_effect(CharmWard740())
  if self.count>=2:self.source.add_effect(SpentCharm740())
  self.target=None;self.count=0;return True
