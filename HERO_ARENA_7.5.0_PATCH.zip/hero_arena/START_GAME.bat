@echo off
setlocal
cd /d "%~dp0"
py -3 --version >nul 2>&1
if not errorlevel 1 (
  set "GAME_PYTHON=py -3"
  goto run_game
)
python --version >nul 2>&1
if not errorlevel 1 (
  set "GAME_PYTHON=python"
  goto run_game
)
echo Python 3 was not found. Install Python 3.8 or newer and enable the Python launcher.
pause
exit /b 1
:run_game
%GAME_PYTHON% -c "import flask" >nul 2>&1
if errorlevel 1 (
  echo Flask is missing. Installing the game requirements for this Python...
  %GAME_PYTHON% -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Could not install requirements. Check the internet connection and Python pip installation.
    pause
    exit /b 1
  )
)
%GAME_PYTHON% app.py
if errorlevel 1 pause
endlocal
