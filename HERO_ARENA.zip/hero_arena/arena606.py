"""Desktop arena presentation, local accounts and explicit manual save workflow."""
import os,json,tempfile,uuid
from flask import request,jsonify
from services import GameService,BusyError
from models import Character,Item,Player,HERO_CLASSES
BACKGROUNDS=('classic','pit','volcano','snow','ruins')

def install(app,get_service):
 def state():return app.extensions['storage606']
 def idle():
  if any(not b.finished for b in get_service()._battles.values()):
   raise BusyError('Сначала завершите или отмените текущий бой')
 def load_from(path):
  s=get_service();candidate=GameService(path);candidate.load();candidate.save_path=s.save_path
  s.__dict__.update(candidate.__dict__)
  state().update(error=None,dirty=False,last_saved=None)
  return dict(message='Сохранение загружено',players=[p.to_dict() for p in s.list_players()])
 def load_local():
  idle();path=get_service().save_path
  if not os.path.exists(path):path=os.path.join(os.path.dirname(path),'save.json')
  return jsonify(load_from(path))
 app.view_functions['load_state']=load_local
 def save_local():
  idle()
  if not get_service().list_players():raise ValueError('Сначала создайте или загрузите аккаунт')
  return jsonify(message='Прогресс сохранён',**get_service().save())
 app.view_functions['save_state']=save_local
 def restore_backup():
  idle();path=get_service().save_path+'.bak'
  if not os.path.exists(path):path=os.path.join(os.path.dirname(path),'save.json.bak')
  result=load_from(path);state()['dirty']=True
  result['message']='Резервная копия загружена. Нажмите «Сохранить», чтобы записать её.'
  return jsonify(result)
 app.view_functions['restore605']=restore_backup

 @app.post('/api/accounts')
 def create_account():
  d=request.get_json() or {};p=get_service().create_player(dict(username=d.get('username'),password=uuid.uuid4().hex,gold=100))
  return jsonify(p.to_dict()),201
 @app.patch('/api/accounts/<int:pid>/appearance')
 def appearance(pid):
  p=get_service().get_player(pid);d=request.get_json() or {}
  if 'animations_enabled' in d and type(d['animations_enabled']) is not bool:raise ValueError('Настройка анимаций должна быть включена или выключена')
  if 'background' in d and d['background'] not in BACKGROUNDS:raise ValueError('Неизвестная арена')
  if 'animations_enabled' in d:p.animations_enabled=d['animations_enabled']
  if 'background' in d:
   if d['background'] not in BACKGROUNDS:raise ValueError('Неизвестная арена')
   p.arena_background=d['background']
  if d.get('welcomed') is True:p.arena_welcomed=True
  return jsonify(p.to_dict())
 @app.post('/api/accounts/import')
 def import_accounts():
  idle();d=(request.get_json() or {}).get('save')
  if not isinstance(d,dict) or not isinstance(d.get('players'),list) or not d['players']:
   raise ValueError('Выберите JSON-сохранение HERO ARENA с аккаунтом')
  ids=(Character._next_id,Item._next_id,Player._next_id)
  with tempfile.TemporaryDirectory() as folder:
   path=os.path.join(folder,'import.json')
   with open(path,'w',encoding='utf-8') as f:json.dump(d,f,ensure_ascii=False)
   try:result=load_from(path)
   except Exception:
    Character._next_id,Item._next_id,Player._next_id=ids;raise
  state()['dirty']=True
  return jsonify(result)
 @app.get('/api/accounts/export')
 def export_accounts():
  idle()
  # Snapshot in a disposable file; the main save is never touched by export.
  s=get_service();original=s.save_path
  with tempfile.TemporaryDirectory() as folder:
   try:
    s.save_path=os.path.join(folder,'export.json');s.save()
    with open(s.save_path,encoding='utf-8') as f:data=json.load(f)
   finally:s.save_path=original
  response=jsonify(data);response.headers['Content-Disposition']='attachment; filename="HERO_ARENA_SAVE.json"';return response
 @app.before_request
 def guard_account606():
  if request.path=='/api/heroes' and request.method=='POST':
   d=request.get_json(silent=True) or {}
   if d.get('player_id') is None:raise ValueError('Сначала создайте или загрузите аккаунт')
  if request.path=='/api/battles' and request.method=='POST':
   d=request.get_json(silent=True) or {};pid=d.get('player_id')
   if pid is not None:
    p=get_service().get_player(int(pid));h=get_service().get_hero(int(d['hero1_id']))
    if not p.dev_mode and getattr(h,'owner_id',None)!=p.id:
     raise PermissionError('Выберите героя текущего аккаунта')
 @app.after_request
 def decorate606(response):
  if response.status_code>=300 or not response.is_json:return response
  data=response.get_json()
  def visit(value):
   if isinstance(value,dict):
    if 'heroes' in value and 'mode' in value and 'status' in value:
     b=get_service()._battles.get(value.get('id'));rules=getattr(b,'arena_rules','items')
     value['arena_rules']=rules
     if rules=='normal':value['available_items']=[]
    for v in value.values():
     if isinstance(v,(dict,list)):visit(v)
   elif isinstance(value,list):
    for v in value:visit(v)
  visit(data);response.set_data(app.json.dumps(data));return response
