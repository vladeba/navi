"""Rikz: a high-risk evasion kit with replayed upkeep and free enemy Focus windows."""
import math,random
from .character import Character
from .skills import Skill,DamageSkill,MiniGameSkill
from .effects import Effect,Announcement
from .minigames_56 import Replay,events,records,integer,number,near

class UnmaskedGuard(Effect):
    name,icon,positive='Передышка без маски','🎭',True
    def armor_bonus(self):return self.power
class ExposedRhythm(Effect):
    name,icon='Фокус: ритм раскрыт','🎯'
    def dodge_bonus(self):return -self.power
class FalseTrail(Effect):
    name,icon='Ложный след','🌫'
    def accuracy_bonus(self):return -self.power

def schedule(mode):
    good={'flurry':10,'fan':8,'focus':11}[mode]
    bad={'flurry':3,'fan':8,'focus':0}[mode]
    flags=[True]*good+[False]*bad;random.shuffle(flags)
    # All targets have separate cells, including the new red decoys.
    cells=random.sample([(52+85*x,45+52*y) for x in range(4) for y in range(4)],len(flags))
    out=[]
    for i,(flag,(x,y)) in enumerate(zip(flags,cells)):
        if mode=='fan':ms=500+(i//4)*850;life=850
        elif mode=='focus':ms=500+i*220;life=700
        else:ms=500+i*245;life=850
        out.append(dict(id=i,x=x+random.randint(-5,5),y=y+random.randint(-2,2),start=ms,end=ms+life,good=flag))
    return out

def segment_distance(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];q=dx*dx+dy*dy
    t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/q)) if q else 0
    return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)

def gallery_result(choice,o):
    used=set();good=bad=0;mode=o['mode']
    if mode=='fan':
        inputs=events(choice,'cuts',o,300)
        for e in inputs:
            a=(number(e.get('x0'),lo=0,hi=360),number(e.get('y0'),lo=0,hi=260));b=(number(e.get('x1'),lo=0,hi=360),number(e.get('y1'),lo=0,hi=260))
            if -999 in a+b:return 0,0
            for target in o['targets']:
                if target['id'] in used or not target['start']<=e['ms']<=target['end']:continue
                if segment_distance((target['x'],target['y']),a,b)<=o['radius']:
                    used.add(target['id']);good+=int(target['good']);bad+=int(not target['good'])
    else:
        for e in events(choice,'clicks',o,40):
            target=next((t for t in o['targets'] if t['id']==e.get('id')),None)
            if not target or target['id'] in used or not target['start']<=e['ms']<=target['end']:continue
            x,y=number(e.get('x'),lo=0,hi=360),number(e.get('y'),lo=0,hi=260)
            if near((x,y),(target['x'],target['y']),o['radius']):
                used.add(target['id']);good+=int(target['good']);bad+=int(not target['good'])
    return good,bad

class Targets609(Replay,MiniGameSkill):
    game='rikz_targets';PREP=450;TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(26,43,24,7)
    TIER_VALUE=(3.2,2.2,1.0,0);MODE='flurry';TIME_LIMIT_MS=4800
    def game_params(self,user,target):
        factor=max(.2,getattr(self,'_time_multiplier',1))
        targets=schedule(self.MODE)
        for item in targets:
            item['start']=round(item['start']*factor);item['end']=round(item['end']*factor)
        return dict(mode=self.MODE,prepare_ms=round(self.PREP*factor),targets=targets,radius=18 if self.MODE=='focus' else 19 if self.MODE=='flurry' else 23,hero_type=user.type_key if user else 'rikz',instruction=self.prompt)
    def tier_from(self,c,o):
        good,bad=gallery_result(c,o);score=good-2*bad
        total=sum(bool(t['good']) for t in o['targets'])
        good_min=math.ceil(total*.72);partial_min=math.ceil(total*.4)
        return 0 if score>=total else 1 if score>=good_min else 2 if score>=partial_min else 3
    def result_data(self,c,o):return dict(zip(('hits','errors'),gallery_result(c,o)))

class Flurry609(Targets609):
    AI_WEIGHTS=(24,42,26,8)
    HIT_COUNTS=(4,4,3,0);MULTS=(.70,.62,.50,0)
    prompt='Нажимайте золотые метки 👊. Красные ловушки ✕ не трогайте: каждая отнимает два попадания.'
    def apply(self,u,t,tier,data):
        hits=self.HIT_COUNTS[tier];logs=[f'👊 «Град ударов»: {hits} отдельных ударов.']
        for _ in range(hits):
            if not t.is_alive():break
            part,_=self.strike(u,t,self.MULTS[tier],pierce=.65);logs+=part
        return logs
    def ai_score(self,u,t):
        from .ai import tier_average,strike_value
        return tier_average(self,u,[n*strike_value(u,t,m,pierce=.65,force=True) for n,m in zip(self.HIT_COUNTS,self.MULTS)])
class Fan609(Targets609):
    AI_WEIGHTS=(20,41,28,11)
    HIT_COUNTS=(4,4,3,0);MULTS=(.75,.66,.50,0)
    MODE='fan';prompt='Зажмите мышь и проведите через золотые метки 👊. Красные двойники ✕ — ловушки. Четыре быстрые волны: 8 целей 👊 и 8 красных ловушек ✕.'
    def apply(self,u,t,tier,data):
        hits=self.HIT_COUNTS[tier];logs=[f'🌪 «Призрачный шквал»: {hits} ударов.']
        for _ in range(hits):
            if not t.is_alive():break
            part,_=self.strike(u,t,self.MULTS[tier],pierce=.65);logs+=part
        return logs
    def ai_score(self,u,t):
        from .ai import tier_average,strike_value
        return tier_average(self,u,[n*strike_value(u,t,m,pierce=.65,force=True) for n,m in zip(self.HIT_COUNTS,self.MULTS)])
class Focus609(Targets609):
    AI_WEIGHTS=(18,40,30,12)
    MODE='focus';TIME_LIMIT_MS=3600;deals_damage=False;TIER_VALUE=(1,1,1,0)
    prompt='Фокус: попадите по 11 золотым меткам, чтобы раскрыть уклонения Рикза. Не расходует ход и ресурс.'
    def apply(self,u,t,tier,data):
        power=(.45,.30,.15,0)[tier]
        if not getattr(t,'mask_active',False):return ['🎯 Маска уже снята: Фокус завершён.']
        if power:t.add_effect(ExposedRhythm(3,power))
        return [f'🎯 Фокус {u.name}: уклонение Рикза −{power*100:g} п.п. на 2 его хода. Маска остаётся.' if power else f'🎯 {u.name} не раскрыл ритм Рикза.']
    def ai_score(self,u,t):return 0

class Rhythm609(Replay,MiniGameSkill):
    game='rikz_rhythm';PREP=500;TIME_LIMIT_MS=4500;TIERS=('Ритм удержан','Маска сорвана');AI_WEIGHTS=(85,15);TIER_VALUE=(1,0);deals_damage=False
    prompt='Скоростной режим: нажимайте 1 / 2 / 3, когда кружок касается золотой зоны. Можно нажимать по дорожкам или большим кнопкам снизу. Все шесть — маска остаётся; ошибка или пропуск снимают её.'
    def is_available(self,u):return False
    def game_params(self,u,t):
        level=min(8,getattr(u,'mask_level',0)+1);interval=620-(level-1)*50;window=280-(level-1)*22
        notes=[dict(lane=random.randrange(3),ms=1000+i*interval) for i in range(6)]
        return dict(level=level,prepare_ms=500,notes=notes,window=window,note_radius=17,pixels_per_ms=.16,time_limit_ms=notes[-1]['ms']+window+200,hero_type='rikz',instruction=self.prompt)
    def tier_from(self,c,o):
        presses=events(c,'actions',o,8)
        if len(presses)!=6:return 1
        return 0 if all(a.get('lane')==n['lane'] and abs(a['ms']-n['ms'])<=o['window'] for a,n in zip(presses,o['notes'])) else 1
    def ai_tier(self,u,t):
        if getattr(u,'perfect',False):return 0
        chance=max(.80,.99-.025*min(7,u.mask_level))
        return 0 if random.random()<chance else 1
    def apply(self,u,t,tier,data):
        if not u.mask_active:return ['🎭 Маска уже снята.']
        if tier:return u.drop_mask()
        u.mask_level=min(8,u.mask_level+1)
        return [f'💨 {u.name}: скоростной режим {u.mask_level}/8; уклонение {u.get_dodge()*100:.0f}%, скорость {u.get_speed():g}.']
    def to_dict(self,u=None):
        d=super().to_dict(u);d['available']=False;d['unavailable_reason']='Запускается автоматически после каждого вашего действия в маске';return d
    def ai_score(self,u,t):return 0

class Mask609(Skill):
    copyable=False
    def is_available(self,u):return u.mask_active or super().is_available(u)
    def pay(self,u):
        if not u.mask_active:super().pay(u)
    def _perform(self,u,t):
        if u.mask_active:return u.drop_mask()
        u.mask_active=True;u.mask_level=0;u.focus_clock=0
        return [f'🎭 {u.name} надевает Маску призрака. Скоростной режим: после каждого действия нужно удерживать ритм.']
    def to_dict(self,u=None):
        d=super().to_dict(u)
        if u and u.mask_active:d.update(name='Снять Маску призрака',cost=0,cooldown_left=0,available=u.can_use(self),description='Снять маску: +7 HP и +0.4 брони на 2 собственных хода без накопления; маска уходит на перезарядку.')
        return d
    def ai_score(self,u,t):return 0 if u.mask_active else 32 if u.cooldown_left(self.key)==0 else 0

class Rikz(Character):
    FORCED_EVADE=.8
    hero_class,type_key,resource_name,role='Трюкач','rikz','ритм','trickster'
    PASSIVE_NOTES=('«Скоростной режим»: высокая скорость и уклонение в маске держатся только при успешном ритме после каждого действия. Восемь ступеней ускорения. Противник получает бесплатный Фокус после каждых четырёх своих действий.',)
    def __init__(self,name,level=1):
        self.mask_active=False;self.mask_level=0;self.focus_clock=0
        super().__init__(name,max_hp=148,base_damage=13.5,armor=.3,level=level,speed=12,dodge=.27,crit_chance=.13,max_energy=100,energy_regen=12,start_energy=70)
    def _create_skills(self):
        return [DamageSkill('attack','Быстрый джеб','Одиночный удар кастетом',accuracy=.93,icon='👊'),
            Mask609('ghost_mask','Маска призрака','Высокое уклонение и скорость; уклоняется также от 80% своей доли уклонения против точных мини-игр. После каждого действия автоматически проверяется ритм. Срыв: +7 HP и +0.4 брони на 2 хода, без накопления.',cost=20,cooldown=5,icon='🎭'),
            DamageSkill('needle_lunge','Скользящий удар','×1.4, пробивает 65% брони',multiplier=1.4,armor_pierce=.65,accuracy=.95,cost=14,cooldown=2,icon='🥊'),
            DamageSkill('false_trail','Ложный след','×0.85; точность врага −8% на его следующий ход',multiplier=.85,effect=lambda:FalseTrail(2,.08),cost=12,cooldown=4,icon='🌫'),
            Flurry609('trick_flurry','Град ударов','10 золотых целей 👊 и 3 ловушки: идеал — четыре удара по ×0.7 с пробитием 65% брони.',cost=26,cooldown=3,icon='✨'),
            Fan609('spectral_fan','Призрачный шквал','Проведите мышью по восьми золотым целям в четырёх быстрых волнах, обходя восемь красных ловушек. Идеал — четыре удара по ×0.75 с пробитием 65% брони.',cost=30,cooldown=4,icon='🌪'),
            Rhythm609('ghost_rhythm','Призрачный ритм','Автоматическая мини-игра после каждого действия в маске: 6 точных нажатий, 8 ступеней. Ошибка снимает маску.',icon='💨')]
    def _on_reset(self):self.mask_active=False;self.mask_level=0;self.focus_clock=0
    def _can_use_strict(self,s):
        if s.key=='ghost_mask' and self.mask_active:
            return self.blocked_left(s.key)==0
        return super()._can_use_strict(s)
    def skill_visible(self,s):
        if s.key=='ghost_rhythm':return self.mask_active
        return super().skill_visible(s)
    def get_speed(self):return super().get_speed()+(2+self.mask_level*.25 if self.mask_active else 0)
    def get_dodge(self):
        # Clamp once, after the mask and all debuffs: Focus and roots must reduce the mask too.
        pet=getattr(self,'summon',None)
        cover=getattr(pet,'OWNER_DODGE',0) if pet and pet is not self and pet.is_alive() else 0
        mask=.38+self.mask_level*.01 if self.mask_active else 0
        return max(0,min(.75,self.dodge+cover+mask+sum(e.dodge_bonus() for e in self.get_effects())))
    def drop_mask(self):
        if not self.mask_active:return ['🎭 Маска уже снята.']
        self.mask_active=False;self.mask_level=0;self.focus_clock=0;self.set_cooldown('ghost_mask',3)
        self.add_effect(UnmaskedGuard(3,.4));healed=self.heal(round(7*self.power_scale()))
        return [f'🎭 {self.name} возвращается в базовый режим: +{healed} HP, +0.4 брони на 2 собственных хода (без накопления).']
    def to_dict(self):
        d=super().to_dict();d['speed']=round(self.get_speed(),2);d['rikz_mode']=dict(mask=self.mask_active,level=self.mask_level,focus_in=4-self.focus_clock,dodge=round(self.get_dodge(),2));return d


def run_post_action(b):
    context=b._post_action609
    if b.finished:b._post_action609=None;return
    while context['tasks']:
        skill,user,target=context['tasks'].pop(0)
        if not user.is_alive() or not target.is_alive():continue
        if isinstance(skill,Rhythm609) and not user.mask_active:continue
        if isinstance(skill,Focus609) and not getattr(target,'mask_active',False):continue
        if b.is_human(user):
            options=skill.public_options(user,target)
            b.pending=dict(skill=skill,actor=user,target=target,reactor=user,options=options,secret=skill.secret_pick(options),post_action609=True)
            b._add_log(f'{skill.icon} {user.name}: {skill.prompt}',kind='info',actor=user,target=target)
            return
        b._log_many(skill._perform(user,target),user,target)
    b._post_action609=None;b._index+=1;b._advance()

def post_action(b,actor,target):
    tasks=[];foe=b.opponent(actor)
    if isinstance(actor,Rikz) and actor.mask_active:tasks.append((actor.skills['ghost_rhythm'],actor,foe))
    if isinstance(foe,Rikz) and foe.mask_active:
        foe.focus_clock+=1
        if foe.focus_clock>=4:
            foe.focus_clock=0;tasks.append((Focus609('foe_rikz_focus','Фокус: раскрыть Рикза','11 попаданий: уклонение Рикза −45 п.п. на два его хода; 8–10: −30; 5–7: −15. Дополнительное действие без расхода хода.',icon='🎯'),actor,foe))
    if not tasks:return False
    b._post_action609=dict(actor=actor,tasks=tasks);run_post_action(b);return True

def install(classes):
    classes['rikz']=Rikz
    from .tuning_609 import PAIR_DAMAGE as new_pairs
    from .tuning_602 import PAIR_DAMAGE
    PAIR_DAMAGE.update(new_pairs)
    from .arena_rules import ARENA_HP,ARENA_DAMAGE
    ARENA_HP['rikz']=148;ARENA_DAMAGE['rikz']=1
    from .lore import NAMES,LORE
    NAMES['rikz']='Рикз';LORE['rikz']='Улыбку Рикза никто не видел. В его маске живёт чужой ритм: пока кулаки и тени послушны ему, даже опытный воин бьёт по пустоте. Один сбитый такт — и за призраком снова оказывается хрупкий человек.'
    from .skin_themes import SKIN_THEMES
    SKIN_THEMES['rikz']=[('common',
      'slate',
      'Серый переулок',
      'Та же поза; серый сланец и железные кольца, за спиной крыши и колокольня в вечерней дымке.'),
     ('common',
      'navy',
      'Синий час',
      'Синий час у морской гавани: мачты кораблей, открытая вода и фонари причала.'),
     ('common',
      'burgundy',
      'Винный бархат',
      'Бордовые рукава и медные кольца; тёплый винный погреб с дубовыми бочками и свечами.'),
     ('common',
      'olive',
      'Тихая тропа',
      'Оливковая ткань и коричневая кожа; заросшие лесные руины, папоротники и зелёный сумрак.'),
     ('common', 'sand', 'Пыль дорог', 'Песочные рукава и бронза; караванный двор среди дюн под закатным небом.'),
     ('rare',
      'silver_stitch',
      'Серебряный шов',
      'Серебряные швы, многослойный воротник, застёжка плаща и шестигранные рунические кольца; заснеженное '
      'горное святилище.'),
     ('rare',
      'copper',
      'Медный фокус',
      'Тиснёные наручи, бронзовые застёжки и угловатые медные кастеты с гравировкой; кузнечная мастерская с '
      'жаровней.'),
     ('rare',
      'violet',
      'Сумеречный шёлк',
      'Фиолетовый шёлк, парчовые рукава, аметистовая застёжка и овальные вставки на кольцах; тайная библиотека '
      'гильдии.'),
     ('rare',
      'moon_thread',
      'Лунная нить',
      'Лунная вышивка, короткая наплечная накидка и кольца-полумесяцы; лесной пруд, ивы и древние камни.'),
     ('epic',
      'relic_ghost',
      'Лик старого призрака',
      'Старинная призрачная маска, цельное пепельное церемониальное облачение и кольца-печати; мраморная '
      'усыпальница в тумане.'),
     ('epic',
      'mirror',
      'Зеркальный обман',
      'Гранёная зеркальная маска, асимметричный серебристый камзол, зеркальные наручи и квадратные кастеты; зал '
      'разбитых зеркал.'),
     ('epic',
      'embers',
      'Пепельный фокусник',
      'Обсидиановая маска с тлеющими швами, багровый жилет, пояс и бронзовые огненные кастеты; пепельные '
      'вулканические руины.'),
     ('legendary',
      'clockwork',
      'Похититель мгновений',
      'Бронзовая маска-механизм, часовой жилет с фалдами и кастеты-шестерни; внутренность башенных часов с '
      'огромными маятниками.'),
     ('legendary',
      'masquerade',
      'Последний маскарад',
      'Асимметричная театральная маска, придворный камзол арлекина и ромбовидные золотые кастеты; бархатная '
      'сцена маскарада.'),
     ('mythic',
      'between_seconds',
      'Между ударами сердца',
      'Маска из звёздного стекла, многослойная небесная мантия, созвездия на наручах и парящие звёздные кастеты; '
      'космический разлом времени.')]
    from .games_600 import STARS
    STARS.update({('rikz','trick_flurry'):3,('rikz','spectral_fan'):4,('rikz','ghost_rhythm'):5,('rikz','foe_rikz_focus'):3})
