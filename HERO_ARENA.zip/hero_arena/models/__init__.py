"""Пакет моделей (классов предметной области)."""
from .item import (Item, Weapon, Potion, Katana, OrdinaryKatana, Yoshirin, Kyocherin, Masamune, KATANAS,
                   Consumable, Kunai, HealingPotion, EnergyPotion, Bomb, CONSUMABLES, SKINS)
from .inventory import Inventory
from .character import (Character, Warrior, Mage, Archer, Ogre, Spartan, Assassin,
                        Samurai, Druid, Monk, DarkElf, Owlbeast, HERO_CLASSES)
from .effects import (Announcement, Effect, DamageOverTime, Burn, Bleed, DeepBleed, Poison, Acid,
                      DarkCurse, Stun, Regeneration, Shield, StoneSkin, StoneShield, Berserk,
                      Evasion, Invisibility, CounterStance, Contract, Antiheal, Intimidated)
from .skills import (Skill, DamageSkill, HealSkill, SelfBuffSkill, BackstabSkill, LifestealSkill,
                     SummonSkill, ReactionSkill, ContractSkill, WeaknessSkill, DebuffSkill)
from .summons import Summon, Bear, Falcon, Snake, Hamster, WaterSpirit, BEASTS, random_beast
from .player import Player
from .battle import Battle
from .heroes_new import (Musketeer, Pagan, Minotaur, Croc, DarkKnight, Wolf, GhostCat, BloodBear, GreatDeer, DruidBoss,
                         Mob, NEW_HEROES, MOBS)
from .skills import MiniGameSkill, ChoiceSkill
from .summons import Deer, Clone, SkeletonSquad, BeastCompanion
from .item import (SmokeBomb, StunWardCharm, CleansingScroll, RegenElixir, PoisonVial, Whetstone, HunterNet,
                   LuckTalisman, RARITIES)
from .skin_themes import SKIN_THEMES
from .story import STORY, Location, Stage, StoryBattle
from .heroes_42 import (GazLow, Satyr, Ghoul, Rhino, Durrila, Orc, Dwarf, LightElf, Nefruit, NEW_HEROES_42,
                        CatchShadowSkill, BogatyrStrike, AimDodgeSkill)
from .heroes_54 import (Aarakocra, Hunter, Gnoll, Centaur, BlueTroll, Paladin, Catfolk, BeastLord,
                        SpiderQueen, Ranger, Pandaren, Gambler, NEW_HEROES_54, DEFAULT_NAMES_54)
from .summons import OwlNephews, Decoy, ForestSpirit


# 4.3: случайность моделей — через прокси (генератор конкретного боя, см. models/rng.py)
from . import rng as _rng, battle as _b, character as _c, heroes_42 as _h42, heroes_new as _hn, item as _it, \
    minigames as _mg, minigames_42 as _mg42, skills as _sk, summons as _su, story as _st
from . import heroes_54 as _h54, minigames_54 as _mg54, mage_skills as _mage
from .heroes_55 import Keltazar,Feliss,Cyclops,Mersey,Leon
from .necromancy_55 import Getou
from . import heroes_55 as _h55, rituals_55 as _r55, necromancy_55 as _n55
_rng.install(_b, _c, _h42, _hn, _h54, _it, _mg, _mg42, _mg54, _mage, _h55, _r55, _n55, _sk, _su, _st)

from . import passives_56 as _p56
_p56.install(HERO_CLASSES)

from . import minigames_56 as _mg56
_rng.install(_mg56)
_mg56.install(HERO_CLASSES)

from . import minigames_58 as _mg58, rework_58 as _rw58
_rng.install(_mg58)
_rw58.install(HERO_CLASSES)

from . import minigames_59 as _mg59
_rng.install(_mg59)
_mg59.install(HERO_CLASSES)

from . import review_600 as _review600
_rng.install(_review600)
_review600.install(HERO_CLASSES)
from . import games_600 as _games600
_rng.install(_games600)
_games600.install_updates()
_review600.finish_install(HERO_CLASSES)
_review600.finish_details(HERO_CLASSES)
_review600.install_katana(HERO_CLASSES)
_review600.refresh_descriptions(HERO_CLASSES)

from . import review_601 as _review601
_review601.install(HERO_CLASSES)

from . import review_602 as _review602
_rng.install(_review602)
_review602.install(HERO_CLASSES)


from .arena_rules import ARENA_HP as _hp605
_hp605['mage']=181
from .mage_skills import IceAssemblySkill as _ice605
_ice605.ABSORB=[27,23,18,9]

def _install_readable605():
    for kind,C in HERO_CLASSES.items():
        factory=C._create_skills
        def create(self,_factory=factory,_kind=kind):
            skills=_factory(self)
            for sk in skills:
                if (_kind,sk.key) in {('warrior','armor_fix'),('ogre','feast'),('spartan','read_enemy'),('druid','forest_call'),('owlbeast','nephews'),('pagan','prayer'),('pagan','werewolf'),('croc','shell_puzzle'),('goblin','cups'),('goblin','lockpick'),('satyr','dance'),('satyr','forest_spirit'),('rhino','mud_bath'),('lightelf','constellation'),('shade','twins'),('pandaren','douse')}:
                    actual=getattr(sk,'original600',sk);actual.deals_damage=False
                if _kind=='mage' and sk.key=='ice_shield':
                    sk.description='Мини-игра плетения контура: щит 27/23/18/9 урона; идеал держится 3 хода'
                if _kind=='musketeer' and sk.key=='musket_shot':
                    sk.description=f"×{sk.multiplier:g}, точность {sk.accuracy*100:g}%, пробивает {sk.armor_pierce*100:g}% брони. Нужен заряд"
                if _kind=='musketeer' and sk.key=='bayonet':
                    sk.description=f"×{sk.multiplier:g}, шанс замедления {sk.effect_chance*100:g}% на 2 хода"
                if _kind=='shade' and sk.key=='twins':
                    sk.description='Три укрытия: выбирайте тёмное перед вспышкой. Три успеха — два двойника; два успеха — один.'
                    if hasattr(sk,'original600'):sk.original600.description=sk.description
                if sk.key=='read_enemy' and _kind=='spartan':
                    sk.describe_for=lambda user,sk=sk:sk.description+f' · перезарядка {sk.cooldown} х.'
            return skills
        C._create_skills=create
_install_readable605()
