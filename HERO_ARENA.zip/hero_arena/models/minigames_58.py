"""Readable physical minigames. Public geometry and server grades use one model."""
import copy,math,random
from .skills import Skill,DamageSkill,MiniGameSkill,scale_effect
from .effects import Announcement,Shield,Bleed,Burn,Poison,Slow,Stun,Blinded,Antiheal
from .minigames_56 import Replay,integer,number,records,events,trace,at,near

SPECS={}
def spec(hero,key,mode,mults=(0,0,0,0),**kw):
    SPECS[hero,key]=dict(mode=mode,mults=mults,**kw)
# Existing skill IDs remain stable; controls and stated rewards change together.
spec('assassin','vital_cut','stop',(1.6,1.25,.75,0),crit=(1,.35,0,0),pierce=.25,title='Точка смерти',verb='Ударить',hint='Нажмите «Ударить», когда метка в золотом центре. Зелёная область тоже даёт хороший удар. Никаких разрезов или скрытого ритма.',reward='Золото: ×1.6, гарантированный крит и пробитие 25% брони. Зелёное: ×1.25 и +35% крита.',width=.10)
spec('samurai','shunpo','zones',(2.25,1.6,1.0,0),hits=(3,2,1,0),pierce=.60,limit=2400,prep=300,hint='На манекене загораются голова, корпус и ноги. Нажимайте подсвеченную область: три быстрых рывка.',reward='3/3: три удара по ×0.75, 2/3: два по ×0.8, 1/3: ×1.0; пробитие 60% брони.')
spec('darkelf','ritual','runes',(1.7,1.2,.65,0),ignore=True,limit=4300,hint='Нажимайте только зелёную руну. Три подсказки, по одной попытке. Ошибка не отнимает HP.',reward='Три верные руны: ×1.7 сквозь броню; две: ×1.2; одна: ×0.65. Бездействие не наносит урон.')
spec('musketeer','duel_shot','aim',(2.0,1.65,0,0),ammo=True,ignore_best=True,shots=1,radius=48,center=25,hint='Нажмите прямо по видимой мишени. Красный центр — лучший выстрел, внешний круг — обычное попадание. Упреждение не нужно.',reward='Центр: ×2.0 сквозь броню; кольцо: ×1.65. После попытки нужна перезарядка.')
spec('ghoul','hunt_leap','stop',(2.2,1.6,.8,0),period=1300,width=.06,hint='Нажмите «Прыгнуть», когда движущаяся метка войдёт в зелёную зону. Золотой центр уже обычного.',verb='Прыгнуть',bleed=(2,2),reward='Идеал ×2.2 и кровотечение 2 HP на 2 хода; хороший прыжок ×1.6.')
spec('lightelf','star_arrow','aim',(2.4,1.6,.8,0),shots=3,radius=35,center=20,last_crit=.6,limit=6500,hint='Три раза нажмите по большой видимой звезде. Попадание считается во всём светлом круге. Ветра и задержки полёта нет.',reward='Три попадания: три стрелы по ×0.8, у последней +60% к шансу крита; два: две стрелы; одно: одна.')
spec('aarakocra','talon','path',(1.55,1.35,.9,0),bleed=(3,2),hint='Зажмите у птицы и проведите по светлой дуге до врага. Отпустите на цели.',reward='Лучший маршрут: ×1.55 и кровотечение 2 HP на 3 хода.')
spec('aarakocra','dive','steer',(2.15,1.5,.65,0),bleed=(3,3),pierce=.4,hint='Ведите птицу влево и вправо через зелёные просветы. Три препятствия; нажимать на них не нужно.',reward='Три просвета: ×2.15 и кровотечение 3 HP на 3 хода; две: ×1.5.')
spec('hunter','traps','lanes',(1.25,.9,.5,0),slow=(2,2),hint='След идёт к одному из трёх капканов. Нажмите кнопку нужной дорожки, когда след в зелёной полосе. Три попытки.',reward='Три верных капкана: ×1.25 и замедление −2 на 2 хода. Оглушения нет.')
spec('hunter','mark_shot','focus',(1.85,1.3,.65,0),pierce=.25,hint='Следуйте прицелом за большой мишенью, пока шкала не заполнится. Держать кнопку не нужно; на телефоне ведите палец.',reward='Хорошее сопровождение: ×1.85 и пробитие 25% брони; частичное: ×1.3 или ×0.65.')
spec('gnoll','hyena_laugh','echo',(1.2,.9,.4,0),steal=(18,12,5,0),slow=(1,2),limit=5000,hint='Запомните три стрелки, затем повторите их кнопками. Во время показа нажимать не нужно.',reward='Три ответа: ×1.2, кража до 18 ресурса и замедление на ход; два: ×0.9 и до 12 ресурса.')
spec('centaur','totem_pulse','circuit',heal=(.10,.08,.04,0),shield=(.06,.04,0,0),poison=(2,3),hint='Зажмите первую точку и соедините пронумерованные тотемы по контуру. Вернитесь к первой точке.',reward='Полный круг: лечение 10% HP, щит 6% HP и яд 3 HP на 2 хода. Частичный круг даёт меньше.')
spec('centaur','harp_curse','rhythm',(1.2,.8,.35,0),slow=(2,1),blind=(2,15),anti_best=1,hint='Три ноты приближаются к золотой линии. Нажимайте «Струна», когда нота на линии. Все ноты видны заранее.',verb='Струна',reward='Три точные ноты: ×1.2, −15% точности на 2 хода, замедление и запрет лечения на 1 ход.')
spec('bluetroll','machete_cross','machete',(2.1,1.65,.75,0),hits=(2,2,1,0),bleed=(2,3),bleed_best=True,limit=6100,hint='Мачете вылетают сами. Поймайте сначала левый, затем правый: нажмите нужную руку, когда клинок в зелёной зоне. Всего два действия.',reward='Два идеальных перехвата: ×2.1 и кровотечение 3 HP на 2 хода. Пропущенный мачете отнимает 3% максимальных HP.')
spec('catfolk','pounce','path',(1.85,1.2,.7,0),pierce=.3,hint='Зажмите у кошки и проведите по светлой дуге до добычи. Отпустите в круге цели.',reward='Полная дуга: ×1.85 с пробитием 30% брони; частичная: ×1.2 или ×0.7.')
spec('beastlord','kodo_charge','steer',(2.0,1.3,.45,0),slow=(2,2),mounted=True,hint='Ведите кодоя через три зелёных прохода между камнями. Двигайте указатель или палец, нажимать на камни не нужно.',reward='Три прохода: ×2.0 и замедление −2 на 2 хода. Работает только пока кодой жив.')
spec('beastlord','axe_storm','flick',(1.8,1.35,.9,0),shots=4,onfoot=True,hint='Зажмите топор внизу, проведите к очередной большой метке и отпустите. Четыре броска, по одному на метку.',reward='Четыре попадания: ×1.8 суммарно; после гибели кодоя урон этой игры на 20% выше.',limit=7500)
spec('ranger','bleed_volley','focus',(1.4,1.0,.6,0),bleed=(2,2),hint='Сопровождайте мишень прицелом, пока натягивается тетива. Чем дольше цель в круге, тем точнее залп.',reward='Полное сопровождение: ×1.4 и одно кровотечение 2 HP на 2 хода; без многократного наложения за залп.')
spec('ranger','spear_throw','hold',(1.9,1.3,.65,0),pierce=.35,bleed=(2,3),hint='Зажмите «Натянуть» и отпустите в зелёной области силы. Золотой участок — идеальный бросок.',reward='Идеал ×1.9, пробитие 35% брони и кровотечение 3 HP на 2 хода; хорошие попадания слабее.')
spec('spiderqueen','web_trap','circuit',(1.2,.85,.4,0),slow=(2,2),poison=(2,3),stun_best=True,hint='Зажмите первую точку и проведите паутину через остальные по номерам. Замкните сеть в первой точке.',reward='Полная сеть: ×1.2, яд 3 HP на 2 хода, замедление и оглушение на ход.')
spec('spiderqueen','spiderlings','catch',(1.6,1.2,.6,0),poison=(2,3),hint='Двигайте паутинную корзину под падающими коконами. Четыре кокона; щёлкать по ним не нужно.',reward='Четыре кокона: ×1.6 и яд 3 HP на 2 хода; меньше коконов — слабее укус.')
spec('spiderqueen','queen_bite','hold',(1.65,1.25,.55,0),poison=(3,4),pierce=.4,hint='Зажмите «Наполнить клыки» и отпустите в зелёной области яда. Не передерживайте после красной отметки.',verb='Наполнить клыки',reward='Идеал ×1.65 с пробитием 40% брони и яд 4 HP на 3 хода; хорошие результаты дают меньше яда.')
spec('feliss','prey_pulse','focus',(1.3,1.0,.6,0),mark=True,crit=(.35,0,0,0),hint='Ведите большой прицел за добычей. Шкала показывает, достаточно ли вы удерживали цель.',reward='Полное сопровождение: ×1.3 и +35% к шансу крита. Любое попадание открывает единственное Слабое место.')
spec('feliss','scale_breach','path',(2.0,1.5,.9,0),pierce=.4,hint='Проведите копьё по светлой дуге к цели. Удерживайте кнопку до конца пути, затем отпустите.',reward='Точная дуга: ×2.0 и пробитие 40% брони. Предварительно копить метки не нужно.')
spec('feliss','opening_sting','stop',(2.1,1.55,.9,0),pierce=.25,width=.10,hint='Нажмите «Уколоть», когда метка в золотом центре. Зелёная область тоже даёт хороший укол.',verb='Уколоть',reward='Точный укол ×2.1 и пробитие 25% брони; работает без накопления меток.')
spec('orc','axe_throw','aim',(1.85,1.4,.8,0),shots=1,radius=45,center=24,pierce=.5,bleed=(2,3),hint='Нажмите прямо по видимой мишени. Центр усиливает бросок, внешний круг тоже считается попаданием. Саморазоружения за промах нет.',reward='Центр: ×1.85, пробитие 50% брони и кровотечение 3 HP на 2 хода; кольцо: ×1.4.')
spec('darkknight','plague','summon',limit=8000,rounds=3,hint='Остановите метку в зелёной зоне до трёх раз. После каждого успеха можно призвать существо сейчас или продолжить к следующему уровню.',reward='1 успех: скелет. 2: вурдалак с лечением. 3: костяной дракон с замедлением и однократной заморозкой.')
# New skills requested by the user.
spec('spartan','spear_challenge','hold',(1.65,1.25,.7,0),new=True,title='Копьё спартанца',cost=28,cd=5,icon='🔱',pierce=.2,hint='Зажмите «Натянуть» и отпустите в зелёной области силы. Золотой участок даёт лучший бросок.',reward='Идеал ×1.65 с пробитием 20% брони; хороший бросок ×1.25.')
spec('darkelf','ash_sigil','circuit',(.55,.4,.2,0),new=True,title='Печать пепла',cost=26,cd=5,icon='🔥',burn=(3,3),hint='Проведите по четырём точкам огненной печати и замкните контур. Удерживайте кнопку или палец.',reward='Полная печать: ×0.55 и горение 3 HP на 3 хода. Частичная слабее; платы HP нет.')
spec('monk','breaking_palm','hold',(1.65,1.15,.6,0),new=True,title='Разрушающая ладонь',cost=30,cd=5,icon='🖐',pierce=.30,shield_pierce=.20,hint='Зажмите «Собрать ци» и отпустите в зелёной зоне силы. Золотой участок даёт лучший удар.',verb='Собрать ци',reward='Идеал ×1.65, пробитие 30% брони и 20% щитов; хороший удар ×1.15.')
spec('musketeer','sniper_shot','sniper',(2.2,1.5,.65,0),new=True,title='Снайперский выстрел',cost=32,cd=5,icon='🔭',ammo=True,pierce=.4,hint='Наведите на видимую мишень и нажмите, когда она зелёная. Подсветка повторяется; один выстрел. После попытки нужна перезарядка.',reward='Зелёный центр ×2.2 с пробитием 40% брони; зелёное кольцо ×1.5; ранний выстрел слабее.')
spec('minotaur','bulwark_charge','steer',(1.65,1.15,.6,0),new=True,title='Натиск хранителя',cost=28,cd=5,icon='🐂',shield=(.08,.05,.02,0),hint='Проведите минотавра через зелёные проходы между тремя преградами. Успех усиливает удар и защиту.',reward='Три прохода: ×1.65 и щит 8% HP; два: ×1.15 и щит 5%; один: ×0.6 и щит 2%.')
spec('paladin','dawn_circle','circuit',(1.45,1.0,.5,0),new=True,title='Круг рассвета',cost=27,cd=5,icon='☀',shield=(.06,.04,.02,0),hint='Зажмите первую точку и замкните светлый контур по номерам. Удар светом прикроет вас щитом.',reward='Полный круг: ×1.45 и щит 6% HP; частичный контур даёт меньше урона и защиты.')
spec('orc','rage_axe','hold',(1.65,1.2,.7,0),new=True,title='Топор ярости',cost=30,cd=5,icon='🪓',bleed=(2,2),hint='Зажмите «Замахнуться» и отпустите в зелёной области. Золотая середина усиливает удар.',verb='Замахнуться',reward='Идеал ×1.65 и кровотечение 2 HP на 2 хода; хороший замах ×1.2.')


def aim_position(o,t,index=0):
    q=(t-o['prepare_ms'])/o['period']*2*math.pi+o['phase']+index*1.4
    return 180+75*math.sin(q),120+30*math.sin(q*.6+.5)

def bar_position(o,t,start=None):
    v=((t-(o['prepare_ms'] if start is None else start)+o['phase'])%o['period'])/o['period']
    return 2*v if v<=.5 else 2-2*v

def _coords(a,x='x',y='y'):return number(a.get(x),lo=0,hi=360),number(a.get(y),lo=0,hi=260)
def _tier_count(n,total):return 0 if n>=total else 1 if n>=max(2,total-1) else 2 if n else 3

def machete_metrics(c,o):
    actions=events(c,'actions',o,2);used=set();perfect=good=0
    for e in o['returns']:
        choices=[(abs(a['ms']-e['ms']),i) for i,a in enumerate(actions) if i not in used and integer(a.get('hand'),hi=1)==e['hand']]
        err,i=min(choices,default=(1e9,-1))
        if i>=0:used.add(i)
        perfect+=err<=100*o['factor'];good+=err<=210*o['factor']
    return (0 if perfect==2 else 1 if good==2 else 2 if good==1 else 3),2-good


class ModernGame(Replay,MiniGameSkill):
    game='arena58';reactor='user';reaction='minigame';copyable=False
    TIERS=('Идеально','Хорошо','Частично','Промах')
    AI_WEIGHTS=(25,45,25,5)
    PREP=800
    @property
    def deals_damage(self):return max(self.SPEC['mults'])>0
    def describe_for(self,user):
        peak=max(self.SPEC['mults']);prefix=f'Урон до ~{round(user.get_damage()*peak*user.damage_multiplier())} до брони и крита. ' if peak else ''
        return prefix+self.SPEC['reward']+' '+self.SPEC['hint']
    def pick_reactor(self,user,target,is_human):return user
    def is_available(self,user):
        if not Skill.is_available(self,user):return False
        if self.SPEC.get('ammo') and not getattr(user,'loaded',True):return False
        if self.SPEC.get('mounted') and not getattr(user,'kodo_alive',True):return False
        if self.SPEC['mode']=='summon' and user.summon and user.summon.is_alive():return False
        return True
    def _perform(self,user,target):
        tier=self.ai_tier(user,target)
        return self.apply(user,target,tier,{'bad_catches':(0,0,1,2)[tier]})
    def game_params(self,user,target):
        s=self.SPEC;o=self.params(user);f=o['factor'];mode=s['mode']
        o.update(mode=mode,label=self.name,instruction=s['hint'],reward=s['reward'],verb=s.get('verb','Остановить'),
                 period=round(s.get('period',1700)*f),phase=0,zone=.62,width=s.get('width',.085),shots=s.get('shots',1),
                 rounds=s.get('rounds',1),radius=s.get('radius',36),center=s.get('center',22),charge_ms=round(2000*f))
        if mode in ('aim','sniper'):o['phase']=random.uniform(0,5);o['period']=round(5200*f)
        if mode=='sniper':o['pulse_ms']=round(1800*f)
        if mode=='focus':
            o['track_ms']=round(2800*f);o['path']=[[round(t*f),180+75*math.sin(t/1100),120+25*math.sin(t/900)] for t in range(0,6001,100)]
        if mode in ('path','circuit'):
            o['nodes']=([[55,220],[100,105],[235,75],[305,185]] if mode=='path' else [[90,75],[270,75],[270,195],[90,195],[90,75]])
            o['radius']=38 if mode=='path' else 30
        if mode=='flick':o['targets']=[[65,65],[145,100],[225,65],[300,120]]
        if mode in ('lanes','runes','zones'):
            n=3;step=550 if mode=='zones' else 1050;window=480 if mode=='zones' else 900
            o['waves']=[dict(lane=random.randrange(3),start=round((self.PREP+150+i*step)*f),end=round((self.PREP+150+i*step+window)*f)) for i in range(n)]
            if mode=='lanes':
                for e in o['waves']:e['ms']=round(e['start']+650*f)
        if mode=='rhythm':o['beats']=[round((self.PREP+1000+i*1000)*f) for i in range(3)]
        if mode=='steer':o['gates']=[dict(x=x,ms=round((self.PREP+1100+i*1200)*f)) for i,x in enumerate(random.sample([80,180,280],3))]
        if mode=='catch':o['drops']=[dict(x=x,ms=round((self.PREP+1000+i*950)*f)) for i,x in enumerate(random.sample([60,140,220,300],4))]
        if mode=='echo':
            first=random.randrange(3);second=(first+random.choice((1,2)))%3;third=(second+random.choice((1,2)))%3
            o['sequence']=[first,second,third];o['show_until']=round((self.PREP+2100)*f)
        if mode=='machete':o['returns']=[dict(hand=0,ms=round(2700*f)),dict(hand=1,ms=round(4400*f))]
        return o
    def tier_from(self,c,o):
        if not isinstance(c,dict):return 3
        s=self.SPEC;mode=o['mode'];f=o['factor'];elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms'])
        if elapsed<o['prepare_ms']:return 3
        if mode in ('stop','summon'):
            clicks=events(c,'clicks',o,o['rounds']);good=0;grades=[];start=o['prepare_ms']
            for e in clicks:
                if e['ms']<start:return 3
                d=abs(bar_position(o,e['ms'],start)-o['zone']);start=e['ms']+round(200*f) if mode=='summon' else start;grades.append(0 if d<=o['width'] else 1 if d<=.18 else 2 if d<=.30 else 3);good+=d<=.18
            if mode=='summon':return _tier_count(good,3)
            return grades[0] if grades else 3
        if mode=='hold':
            down=integer(c.get('down_ms'),hi=elapsed);up=integer(c.get('up_ms'),hi=elapsed)
            if down<o['prepare_ms'] or up<=down:return 3
            value=(up-down)/o['charge_ms']
            return 0 if .58<=value<=.78 else 1 if .43<=value<=.92 else 2 if .2<=value<=1.08 else 3
        if mode in ('aim','sniper'):
            shots=events(c,'shots',o,o['shots']);n=0;qualities=[]
            if any(b['ms']-a['ms']<250*f for a,b in zip(shots,shots[1:])):return 3
            for i,a in enumerate(shots):
                d=math.dist(_coords(a),aim_position(o,a['ms'],i));q=0 if d<=o['center'] else 1 if d<=o['radius'] else 3
                if mode=='sniper' and not .25<=((a['ms']-o['prepare_ms'])%o['pulse_ms'])/o['pulse_ms']<=.70:q=max(2,q)
                qualities.append(q);n+=q<=1
            return _tier_count(n,o['shots']) if o['shots']>1 else (qualities[0] if qualities else 3)
        if mode in ('focus','steer','catch'):
            engaged=integer(c.get('engaged_ms'),hi=elapsed);p=trace(c,o)
            if engaged<0 or not p:return 3
            if mode=='focus':
                ts=list(range(o['prepare_ms'],o['prepare_ms']+o['track_ms'],40));n=sum(t<=elapsed and near(at(p,t),at(o['path'],t),o['radius']) for t in ts);ratio=n/max(1,len(ts))
                return 0 if ratio>=.82 else 1 if ratio>=.6 else 2 if ratio>=.35 else 3
            es=o['gates'] if mode=='steer' else o['drops'];n=sum(e['ms']<=elapsed and abs(at(p,e['ms'])[0]-e['x'])<=(45 if mode=='steer' else 35) for e in es)
            return _tier_count(n,len(es))
        if mode in ('path','circuit'):
            p=trace(c,o);down=integer(c.get('down_ms'),hi=elapsed);up=integer(c.get('up_ms'),hi=elapsed)
            if down<o['prepare_ms'] or up<=down or up-down<150*f:return 3
            n=0
            for t,x,y in p:
                if down<=t<=up and n<len(o['nodes']) and near((x,y),o['nodes'][n],o['radius']):n+=1
            if mode=='path' and not (p and near(p[-1][1:],o['nodes'][-1],o['radius'])):n=min(n,2)
            return _tier_count(n,len(o['nodes']))
        if mode=='flick':
            cuts=records(c,'cuts',4);n=0;last=-1
            for i,a in enumerate(cuts):
                if not isinstance(a,dict):return 3
                down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if down<o['prepare_ms'] or down<=last or not 100*f<=up-down<=1500*f:return 3
                last=up;n+=near(_coords(a,'x0','y0'),(180,232),42) and near(_coords(a,'x1','y1'),o['targets'][i],35)
            return _tier_count(n,4)
        if mode in ('lanes','runes','zones'):
            acts=events(c,'actions',o,3);used=set();n=0
            for a in acts:
                i=next((i for i,e in enumerate(o['waves']) if e['start']<=a['ms']<=e['end']),None)
                if i is None or i in used:continue
                used.add(i);e=o['waves'][i];valid=integer(a.get('lane'),hi=2)==e['lane']
                if mode=='lanes':valid&=abs(a['ms']-e['ms'])<=250*f
                n+=valid
            return _tier_count(n,3)
        if mode=='rhythm':
            taps=events(c,'clicks',o,3);used=set();perfect=good=0
            for a in taps:
                err,i=min(((abs(a['ms']-t),i) for i,t in enumerate(o['beats']) if i not in used),default=(1e9,-1))
                if i>=0:used.add(i)
                perfect+=err<=110*f;good+=err<=220*f
            return 0 if perfect==3 else 1 if good>=2 else 2 if good else 3
        if mode=='echo':
            answers=events(c,'actions',o,3)
            if any(a['ms']<o['show_until'] for a in answers):return 3
            n=sum(integer(a.get('lane'),hi=2)==o['sequence'][i] for i,a in enumerate(answers));return _tier_count(n,3)
        if mode=='machete':return machete_metrics(c,o)[0]
        return 3
    def result_data(self,c,o):return {'bad_catches':machete_metrics(c,o)[1]} if o['mode']=='machete' else None
    def apply(self,user,target,tier,data):
        s=self.SPEC;logs=[Announcement(f'{self.icon} {user.name} — «{self.name}»: {self.TIERS[tier]}.')]
        if s.get('ammo'):user.loaded=False
        if s['mode']=='summon':
            if tier<3:
                from .rework_58 import PlagueCompanion
                user.summon=PlagueCompanion(user,2-tier).scale_to(user);logs.append(f'{user.summon.icon} {user.name} призывает {user.summon.describe()} на {user.summon.lifetime} хода.')
            return logs
        mult=s['mults'][tier]*(1.2 if s.get('onfoot') and not user.kodo_alive else 1)
        hits=(3-tier if self.key=='star_arrow' else s.get('hits',(1,1,1,1))[tier])
        damage=0;saved_crit=self.crit_bonus;saved_pierce=getattr(user,'shield_pierce',0)
        self.crit_bonus=s.get('crit',(0,0,0,0))[tier] if not(s.get('crit_best') and tier==0) else 1
        if s.get('shield_pierce'):user.shield_pierce=max(saved_pierce,s['shield_pierce'])
        try:
            for i in range(hits if mult else 0):
                if not target.is_alive():break
                if self.key=='star_arrow' and tier==0 and i==hits-1:self.crit_bonus=.6
                part,dealt=self.strike(user,target,mult/max(1,hits),ignore_armor=s.get('ignore',False) or (s.get('ignore_best',False) and tier==0),pierce=s.get('pierce',0))
                damage+=dealt;logs+=part
        finally:self.crit_bonus=saved_crit;user.shield_pierce=saved_pierce
        if tier<3:
            ratio=(1,.7,.35,0)[tier]
            if (damage or not self.deals_damage) and target.is_alive():
                for name,cls in [('bleed',Bleed),('burn',Burn),('poison',Poison)]:
                    if name in s and not(s.get(name+'_best') and tier!=0):
                        duration,power=s[name];target.add_effect(scale_effect(cls(duration,max(1,round(power*ratio))),user))
                if s.get('slow') and tier<2:target.add_effect(Slow(*s['slow']))
                if s.get('blind') and tier<2:target.add_effect(Blinded(s['blind'][0],round(s['blind'][1]*ratio)))
                if s.get('anti_best') and tier==0:target.add_effect(Antiheal(s['anti_best']))
                if s.get('stun_best') and tier==0:target.add_effect(Stun(1))
            if s.get('heal'):logs.append(f'💚 {user.name} +{user.heal(round(user.max_hp*s["heal"][tier]))} HP.')
            if s.get('shield') and s['shield'][tier]:user.add_effect(Shield(2,round(user.max_hp*s['shield'][tier])))
            if s.get('steal'):
                amount=min(target.energy,s['steal'][tier]);target.spend_energy(amount);user.restore_energy(amount);logs.append(f'😈 Украдено ресурса: {amount}.')
        if user.type_key=='orc' and self.key in ('axe_throw','rage_axe') and damage:
            from .heroes_42 import WarCry
            rate=.167 if user.has_effect(WarCry) else .07
            healed=user.heal(int(damage*rate));user._axe_healed_this_action=True
            if healed:logs.append(f'🩸 Кровожадность: {user.name} +{healed} HP.')
        if s['mode']=='machete':
            bad=data.get('bad_catches',(0,0,1,2)[tier]) if isinstance(data,dict) else (0,0,1,2)[tier]
            if bad:loss=max(1,round(user.max_hp*.03*bad));user.hp-=loss;logs.append(f'🩸 Пропущено мачете: {bad}; собственные клинки отнимают {loss} HP.')
        return logs
    def ai_score(self,user,target):
        from .ai import strike_value,healing,effect_value,threat,tier_average
        s=self.SPEC
        if s['mode']=='summon':
            if user.summon and user.summon.is_alive():return 0
            from .ai import horizon
            from .rework_58 import PlagueCompanion
            incoming=threat(target,user);vals=[]
            for stage in (2,1,0):
                turns=horizon(user,target,PlagueCompanion.LIFE_BY_STAGE[stage])
                attack=max(1,PlagueCompanion.DAMAGE[stage]-target.armor_total())*max(.1,.85-target.get_dodge())*turns
                protection=min(PlagueCompanion.HP[stage],incoming*.25*turns)
                sustain=min(user.max_hp-user.hp,PlagueCompanion.GHOUL_HEAL*turns) if stage==1 else incoming*.5 if stage==2 and turns>=2 else 0
                vals.append(attack+protection+sustain)
            return tier_average(self,user,vals+[0])
        values=[]
        for i,m in enumerate(s['mults']):
            hits=(3-i if self.key=='star_arrow' else s.get('hits',(1,1,1,1))[i])
            value=strike_value(user,target,m/max(1,hits),max(1,hits),force=True,skill=self,ignore_armor=s.get('ignore',False) or s.get('ignore_best') and i==0,pierce=s.get('pierce',0),crit_bonus=s.get('crit',(0,0,0,0))[i] if not(s.get('crit_best') and i==0) else 1) if m else 0
            ratio=(1,.7,.35,0)[i]
            if i<3:
                for name,cls in [('bleed',Bleed),('burn',Burn),('poison',Poison)]:
                    if name in s and not(s.get(name+'_best') and i!=0):value+=effect_value(user,target,scale_effect(cls(s[name][0],max(1,round(s[name][1]*ratio))),user))
                if s.get('heal'):value+=healing(user,user.max_hp*s['heal'][i])
                if s.get('shield') and not user.has_effect(Shield):value+=min(user.max_hp*s['shield'][i],threat(target,user)*2)*.65
                if s.get('stun_best') and i==0:value+=effect_value(user,target,Stun(1))
                if s.get('slow') and i<2:value+=effect_value(user,target,Slow(*s['slow']))
                if s.get('blind') and i<2:value+=effect_value(user,target,Blinded(s['blind'][0],round(s['blind'][1]*ratio)))
                if s.get('steal'):value+=min(target.energy,s['steal'][i])*.12
            if s['mode']=='machete':value-=user.max_hp*.03*(0,0,1,2)[i]
            values.append(value)
        return max(0,tier_average(self,user,values))


_ADAPTERS={}
def adapt(skill,s):
    weights=tuple(getattr(skill,'AI_WEIGHTS',ModernGame.AI_WEIGHTS))
    key=(type(skill),id(s))
    if key not in _ADAPTERS:
        _ADAPTERS[key]=type('Readable'+type(skill).__name__,(ModernGame,type(skill)),dict(SPEC=s,TIME_LIMIT_MS=s.get('limit',5800),PREP=s.get('prep',800),game='arena58',TIERS=ModernGame.TIERS,AI_WEIGHTS=ModernGame.AI_WEIGHTS))
    skill=copy.copy(skill);skill.__class__=_ADAPTERS[key]
    skill.AI_WEIGHTS=weights if len(weights)==4 else ModernGame.AI_WEIGHTS
    skill.game='arena58';skill.prompt=s['hint'];skill.description=s['reward'];skill.reaction='minigame';skill.reactor='user';skill.copyable=False
    skill.effect=None;skill.lifesteal=0;skill.crit_bonus=0;skill.ignore_armor=False;skill.multiplier=1;skill.hits=1;skill.low_hp_bonus=0
    return skill
