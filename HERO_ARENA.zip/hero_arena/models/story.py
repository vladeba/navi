"""5.0: сюжет — 4 локации (Трущобы → Тёмный лес → Проклятая роща → Болото), кат-сцены, элиты, сумка."""
import copy


class Stage:
    """Этап на карте: кружок с противником."""

    def __init__(self, key, title, mob_key, icon, x, y, xp, gold, line, boss=False, elite=False,
                 name=None, before=None, after=None, reward_item=None, chain=None, chain_size=1,
                 figure=None, background=None, after_background=None, desc=None, level=1, skin=None, secret=False, choice=None,
                 make_mob=None, balance_hp=1.0, balance_dmg=1.0):
        self.key, self.title, self.mob_key, self.icon = key, title, mob_key, icon
        self.name = name or title
        self.before = before or []
        self.after = after or []
        self.x, self.y = x, y
        self.xp, self.gold = xp, gold
        self.line = line
        self.boss = boss
        self.elite = elite
        self.reward_item = reward_item          # ключ расходника из CONSUMABLES
        self.chain = chain                      # ключ цепочки (волки/гидра) — HP не восстанавливается
        self.chain_size = chain_size
        self.figure = figure                    # cut-out PNG для кат-сцены
        self.background = background            # фон кат-сцены до боя (если отличный от локации)
        self.after_background = after_background  # фон после боя (иначе background/локация)
        self.desc = desc                    # краткое описание врага на карточке этапа
        self.level = level
        self.skin = skin
        self.secret = secret                    # пасхалка (не на карте, пока не открыта)
        self.choice = choice                    # {"id": "swamp_path", "options": [...]} — развилка
        self.make_mob_fn = make_mob
        self.balance_hp = balance_hp
        self.balance_dmg = balance_dmg

    def make_mob(self):
        if self.make_mob_fn:
            return self.make_mob_fn(self)
        from .heroes_new import MOBS, HERO_CLASSES
        if self.mob_key in MOBS:
            mob = MOBS[self.mob_key](level=self.level)
        elif self.mob_key in HERO_CLASSES:
            mob = HERO_CLASSES[self.mob_key](self.name, level=self.level)
            mob.creatable = False
            mob.mob = True
        else:
            raise ValueError(f"Неизвестный моб «{self.mob_key}»")
        mob.elite = self.elite
        mob.boss = self.boss
        if self.skin:
            mob.skin = self.skin
        if self.name:
            mob.name = self.name
        # элита: чуть сильнее обычного моба
        if self.elite and not self.boss:
            mob._raw_hp = int(mob._raw_hp * 1.15)
            mob._base_damage = mob._base_damage * 1.1
            mob.set_level(self.level)
        # 5.0: ручная подстройка боссов/элит под цель ~55–65% WR героя
        if self.balance_hp != 1.0 or self.balance_dmg != 1.0:
            mob._raw_hp = max(20, int(mob._raw_hp * self.balance_hp))
            mob._base_damage = round(mob._base_damage * self.balance_dmg, 2)
            mob.set_level(self.level)
        return mob

    @property
    def display_level(self):
        """UI-уровень (боссы/элиты — ожидаемый уровень героя). Бой/XP — self.level."""
        # заполняется после DISPLAY_LEVELS; до этого = level
        try:
            return stage_display_level(self)
        except NameError:
            return self.level

    @property
    def card_title(self):
        if self.elite and not self.boss:
            return f"⭐ Элита · {self.name}"
        if self.boss:
            return f"{self.name} — босс"
        return self.name

    def reward_parts(self):
        """Русские имя+иконка предметов награды (не сырой id)."""
        if not self.reward_item:
            return []
        from .item import CONSUMABLES
        out = []
        for k in str(self.reward_item).split("+"):
            k = k.strip()
            cls = CONSUMABLES.get(k)
            if cls:
                out.append({"key": k, "name": cls.title, "icon": cls.icon})
            else:
                out.append({"key": k, "name": k, "icon": "📦"})
        return out

    def to_dict(self):
        parts = self.reward_parts()
        reward_label = " + ".join(f"{p['icon']} {p['name']}" for p in parts) if parts else None
        return {"key": self.key, "title": self.title, "name": self.name, "mob": self.mob_key,
                "icon": self.icon, "x": self.x, "y": self.y, "xp": self.xp, "gold": self.gold,
                "line": self.line, "boss": self.boss, "elite": self.elite,
                "card_title": self.card_title,
                "before": [dialogue_line(*d) for d in self.before],
                "after": [dialogue_line(*d) for d in self.after],
                "reward_item": self.reward_item,
                "reward_parts": parts,
                "reward_label": reward_label,
                "chain": self.chain, "chain_size": self.chain_size,
                "figure": self.figure, "background": self.background,
                "after_background": self.after_background, "desc": self.desc, "level": self.level,
                "display_level": self.display_level,
                "skin": self.skin, "secret": self.secret, "choice": self.choice}


SPEAKERS = {
    "dayla": {"name": "Фея Дейла", "image": "/static/images/story/dayla.jpg",
              "figure": "/static/images/story/cutouts/fig_dayla.png"},
    "karrgall": {"name": "Демон Карр-Галл", "image": "/static/images/story/karrgall.jpg",
                 "figure": "/static/images/story/cutouts/fig_karrgall.png"},
    "gnuss": {"name": "Гнусс", "image": "/static/images/story/gnuss.jpg",
              "figure": "/static/images/story/cutouts/gnuss.png"},
    "radogast": {"name": "Радогаст", "image": "/images/druid",
                 "figure": "/static/images/story/cutouts/fig_radogast.png"},
    "gazlow": {"name": "Газ-Лоу", "image": "/images/goblin",
               "figure": "/static/images/story/cutouts/fig_goblin.png"},
    "altair": {"name": "Альтаир", "image": "/images/assassin",
               "figure": "/static/images/story/cutouts/fig_assassin.png"},
    "shibek": {"name": "Шибэк", "image": "/images/satyr",
               "figure": "/static/images/story/cutouts/fig_satyr.png"},
    "grozokryl": {"name": "Грозокрыл", "image": "/static/images/skins/owlbeast_bark.jpg",
                  "figure": "/static/images/story/cutouts/fig_owlbeast.png"},
    "croc": {"name": "Крок", "image": "/static/images/skins/croc_swamp_croc.jpg",
             "figure": "/static/images/story/cutouts/fig_croc.png"},
    "shrek": {"name": "Шрек", "image": "/static/images/skins/ogre_fisher.jpg",
              "figure": "/static/images/story/cutouts/fig_ogre_fisher.png"},
    "bandit": {"name": "Бандит", "image": "/static/images/story/bandit.jpg",
               "figure": "/static/images/story/cutouts/fig_bandit.png"},
    "magician": {"name": "Фокусник", "image": "/static/images/story/magician.jpg",
                 "figure": "/static/images/story/cutouts/fig_magician.png"},
    "killer": {"name": "Убийца", "image": "/static/images/story/hooded_killer.jpg",
               "figure": "/static/images/story/cutouts/fig_killer.png"},
    "tavern": {"name": "Посетители таверны", "image": None},
    "hero": {"name": None, "image": None},
    "narrator": {"name": "Рассказчик", "image": None},
    "fisherman": {"name": "Рыбак", "image": "/static/images/story/fisherman.jpg",
                  "figure": "/static/images/story/cutouts/fig_fisherman.png"},
    "frog_king": {"name": "Король-лягушка", "image": "/static/images/story/frog_king.jpg",
                  "figure": "/static/images/story/cutouts/fig_frog.png"},
    "murloc": {"name": "Мурлок", "image": "/static/images/story/murloc.jpg",
               "figure": "/static/images/story/cutouts/fig_murloc.png"},
    "giant_croc": {"name": "Гигантский крокодил", "image": "/static/images/story/giant_croc.jpg",
                   "figure": "/static/images/story/cutouts/fig_giant_croc.png"},
    "swamp_monster": {"name": "Болотное чудище", "image": "/static/images/story/swamp_monster.jpg",
                      "figure": "/static/images/story/cutouts/fig_swamp_monster.png"},
    "hydra": {"name": "Гидра", "image": "/static/images/story/hydra.jpg",
              "figure": "/static/images/story/cutouts/fig_hydra.png"},
    "wolf": {"name": "Волк", "image": "/static/images/story/wolf.jpg",
             "figure": "/static/images/story/cutouts/fig_wolf.png"},
    "ghostcat": {"name": "Призрачный кот", "image": "/static/images/ghostcat.jpg",
                 "figure": "/static/images/story/cutouts/fig_ghostcat.png"},
    "bloodbear": {"name": "Кровавый медведь", "image": "/static/images/bloodbear.jpg",
                  "figure": "/static/images/story/cutouts/fig_bloodbear.png"},
    "greatdeer": {"name": "Великий Олень", "image": "/static/images/greatdeer.jpg",
                  "figure": "/static/images/story/cutouts/fig_greatdeer.png"},
    "pack_wolf": {"name": "Стая волков", "image": "/static/images/story/pack_wolf.jpg",
                  "figure": "/static/images/story/cutouts/fig_wolf.png"},
    "snake": {"name": "Гигантская змея", "image": "/static/images/story/giant_snake.jpg",
              "figure": "/static/images/story/cutouts/fig_snake.png"},
    "giant_snake": {"name": "Гигантская змея", "image": "/static/images/story/giant_snake.jpg",
                    "figure": "/static/images/story/cutouts/fig_snake.png"},
}



def dialogue_line(speaker, text, figure=None):
    sp = SPEAKERS.get(speaker)
    if sp is None:
        # неизвестный id — не светим английский ключ игроку
        sp = {"name": None, "image": None, "figure": None}
    return {"speaker": speaker, "name": sp["name"], "image": sp.get("image"),
            "figure": figure or sp.get("figure"), "text": text}


INTRO_SCENES = [
    {"key": "gnuss", "background": "/static/images/story/throne_hall.jpg", "portrait": "gnuss",
     "title": "Врата Демонов",
     "figure": "/static/images/story/cutouts/gnuss.png",
     "lines": [
         dialogue_line("narrator", "Далеко на юге, среди красных пламенных гор, вулканы извергают огонь, "
                                   "а над пропастью высятся Врата Демонов."),
         dialogue_line("narrator", "В тронном зале из чёрного обсидиана прислужник склоняется перед господином."),
         dialogue_line("gnuss", "Господин… этот мир достаточно ослаб. Последний Хранитель обессилел окончательно. "
                                "Теперь этот мир некому защитить."),
         dialogue_line("gnuss", "Печать дрожит. Врата готовы принять ваш приказ.")]},
    {"key": "demon", "background": "/static/images/story/demon_mountains.jpg", "portrait": "karrgall",
     "title": "Карр-Галл",
     "figure": "/static/images/story/cutouts/fig_karrgall.png",
     "lines": [
         dialogue_line("narrator", "На троне из чёрного обсидиана восседает король демонов — Карр-Галл."),
         dialogue_line("karrgall", "Этот мир слаб… Его реки высохнут, леса сгорят, а города обратятся в пепел."),
         dialogue_line("karrgall", "Я уничтожу всё живое на этом свете. И никто — НИКТО — меня не остановит!")]},
    {"key": "tavern", "background": "/static/images/story/tavern.jpg", "portrait": "hero",
     "title": "Таверна «Старый дуб»",
     "figure": "/static/images/story/cutouts/fig_dayla.png",
     "lines": [
         dialogue_line("narrator", "В старой таверне, среди эльфов, дворфов, зверолюдов и людей, "
                                   "сидит одинокий странник."),
         dialogue_line("tavern", "Слыхали? Король сообщил, что Король демонов проснулся! Говорят, последний "
                                 "хранитель ослаб, и не только королевство — весь мир в опасности…"),
         dialogue_line("tavern", "Деревни на юге уже горят. Король мобилизует армии, нужна команда авантюристов, "
                                 "да только где ж таких храбрецов взять?"),
         dialogue_line("narrator", "Вдруг над столом {hero} вспыхивает крошечный огонёк."),
         dialogue_line("dayla", "Вот ты где! Меня зовут Дейла. Владыка Света выбрал тебя, {hero}, — "
                                "я еле нашла тебя. Именно ты один из тех, кому суждено одолеть Короля демонов."),
         dialogue_line("hero", "С чего я должен этому верить?"),
         dialogue_line("dayla", "А ты видел когда-нибудь, чтобы к кому-нибудь прилетала фея со словами, "
                                "что он избранный?"),
         dialogue_line("hero", "Тоже верно. Ну что ж… Веди, Дейла.")]},
]


class Location:
    def __init__(self, key, title, intro, image, stages, battle_bg=None, cutscene_bg=None, order=0):
        self.key, self.title, self.intro, self.image = key, title, intro, image
        self.stages = stages
        self.battle_bg = battle_bg or image
        self.cutscene_bg = cutscene_bg or image
        self.order = order

    def stage_index(self, key):
        for i, s in enumerate(self.stages):
            if s.key == key:
                return i
        raise ValueError(f"Этап «{key}» не найден")

    def visible_stages(self, hero=None):
        """Этапы на карте (без секретных, пока не открыты)."""
        flags = getattr(hero, "story_flags", {}) if hero else {}
        out = []
        for s in self.stages:
            if s.secret and not flags.get(f"secret_{s.key}"):
                continue
            # развилка: показываем только выбранную ветку + общие
            if s.choice and s.choice.get("requires"):
                req = s.choice["requires"]
                if flags.get(req[0]) != req[1]:
                    continue
            out.append(s)
        return out

    def path_status(self, stage, flags):
        """ok — на пути; skip — чужая ветка; wait — развилка ещё не выбрана."""
        if not stage.choice or not stage.choice.get("requires"):
            return "ok"
        req = stage.choice["requires"]
        val = flags.get(req[0])
        if val in (None, ""):
            return "wait"
        return "ok" if val == req[1] else "skip"

    def path_matches(self, stage, flags):
        return self.path_status(stage, flags) == "ok"

    def main_stages(self):
        return [s for s in self.stages if not s.secret]

    def next_open_index(self, hero=None):
        """Индекс следующего открытого этапа. -1 если ждём выбора развилки."""
        flags = getattr(hero, "story_flags", {}) if hero else {}
        done = hero.story_progress.get(self.key, 0) if hero is not None else 0
        main = self.main_stages()
        i = max(0, int(done))
        while i < len(main):
            st = self.path_status(main[i], flags)
            if st == "skip":
                i += 1
                continue
            if st == "wait":
                return -1
            return i
        return i

    def snap_progress(self, hero):
        """После выбора ветки/победы: перепрыгнуть индексы чужой ветки в story_progress."""
        flags = getattr(hero, "story_flags", {}) or {}
        main = self.main_stages()
        done = int(hero.story_progress.get(self.key, 0))
        while done < len(main) and self.path_status(main[done], flags) == "skip":
            done += 1
        hero.story_progress[self.key] = done
        return done

    def _stage_image(self, s):
        if s.mob_key in ("druid_boss",):
            return "/images/druid"
        if s.skin:
            return f"/static/images/skins/{s.mob_key}_{s.skin}.jpg"
        if s.mob_key in ("goblin", "assassin", "satyr", "owlbeast", "croc", "ogre"):
            return f"/images/{s.mob_key}"
        if s.mob_key == "pack_wolf":
            return "/static/images/story/pack_wolf.jpg"
        if Path_exists_story(s.mob_key):
            return f"/static/images/story/{s.mob_key}.jpg"
        return f"/images/{s.mob_key}"

    def to_dict(self, hero=None):
        flags = getattr(hero, "story_flags", {}) if hero else {}
        done = hero.story_progress.get(self.key, 0) if hero is not None else 0
        stages = []
        main = self.main_stages()
        open_i = self.next_open_index(hero)
        cleared = open_i >= len(main)
        choice_pending = open_i < 0
        for i, s in enumerate(main):
            d = s.to_dict()
            st = self.path_status(s, flags)
            if st == "skip":
                d["status"], d["hidden"] = "skipped", True
            elif st == "wait":
                d["status"], d["hidden"] = "locked", True
            elif choice_pending:
                d["status"], d["hidden"] = ("done" if i < done else "locked"), False
            elif i < open_i:
                d["status"], d["hidden"] = "done", False
            elif i == open_i:
                d["status"], d["hidden"] = "open", False
            else:
                d["status"], d["hidden"] = "locked", False
            d["image"] = self._stage_image(s)
            try:
                from .heroes_new import MOBS, HERO_CLASSES
                cls = MOBS.get(s.mob_key) or HERO_CLASSES.get(s.mob_key)
                d["role_name"] = cls.ROLE_NAMES[cls.role] if cls and hasattr(cls, "ROLE_NAMES") else ""
            except Exception:
                d["role_name"] = ""
            if s.chain:
                ch = (hero.story_flags or {}).get(f"chain_{s.chain}", 0) if hero else 0
                d["chain_progress"] = ch
                d["card_title"] = f"{s.name} · {ch}/{s.chain_size}" if ch else d["card_title"]
            d["fight_locked"] = bool(cleared)  # реванш в текущей локации ок; после прохождения локации — нет
            d["replay_before"] = d["status"] in ("open", "done")
            d["replay_after"] = d["status"] == "done"
            stages.append(d)
        for s in self.stages:
            if not s.secret or not flags.get(f"secret_{s.key}"):
                continue
            if s.choice and s.choice.get("requires"):
                req = s.choice["requires"]
                if flags.get(req[0]) != req[1]:
                    continue
            d = s.to_dict()
            d["status"] = "done" if flags.get(f"secret_done_{s.key}") else "open"
            d["hidden"] = False
            d["fight_locked"] = bool(cleared) or d["status"] == "done"  # секрет — один раз
            d["replay_before"] = d["status"] in ("open", "done")
            d["replay_after"] = d["status"] == "done"
            d["image"] = self._stage_image(s)
            d["role_name"] = ""
            stages.append(d)
        visible_main = [s for s in main if self.path_status(s, flags) == "ok"]
        # до выбора ветки в «видимые» входят только общие этапы
        if not flags.get("swamp_path") and self.key == "swamp":
            visible_main = [s for s in main if not (s.choice and s.choice.get("requires"))]
        prog_vis = 0
        if open_i < 0:
            prog_vis = sum(1 for i, s in enumerate(main) if i < done and self.path_status(s, flags) != "skip")
        else:
            prog_vis = sum(1 for i, s in enumerate(main) if self.path_status(s, flags) == "ok" and i < open_i)
        return {"key": self.key, "title": self.title, "intro": self.intro, "image": self.image,
                "battle_bg": self.battle_bg, "cutscene_bg": self.cutscene_bg,
                "cleared": cleared, "progress": prog_vis, "progress_raw": done,
                "choice_pending": choice_pending,
                "stages_total": len(visible_main) if visible_main else len(main),
                "stages": stages, "order": self.order}


def Path_exists_story(key):
    import os
    base = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static", "images", "story")
    return os.path.exists(os.path.join(base, f"{key}.jpg"))


# ---------- Локации ----------
BG_SLUMS = "/static/images/story/slums_street.jpg"
BG_GATE = "/static/images/story/slums_gate.jpg"
BG_BRIDGE = "/static/images/story/city_bridge.jpg"
BG_FOREST = "/static/images/story/forest_scene.jpg"
BG_GROVE = "/static/images/story/grove_scene.jpg"
BG_SWAMP = "/static/images/story/swamp_scene.jpg"
BG_FORK = "/static/images/story/swamp_fork.jpg"
BG_LAIR = "/static/images/story/swamp_lair.jpg"

SLUMS = Location(
    "slums", "🏚 Трущобы королевства",
    "Старые переулки королевства: грязь, тусклые фонари и тени, которым нельзя доверять. "
    "Дейла ведёт тебя к южным воротам — но трущобы не отпустят так просто.",
    "/static/images/story/slums_map.jpg",
    battle_bg=BG_SLUMS, cutscene_bg=BG_SLUMS, order=1,
    stages=[
        Stage("bandit", "Бандит", "bandit", "🪓", 50, 88, 40, 12,
              "Кошелёк или жизнь, путник!", level=1,
              figure="/static/images/story/cutouts/fig_bandit.png", background=BG_SLUMS,
              before=[("narrator", "{hero} идёт за Дейлой по тёмным улицам. Фея рассказывает о Короле демонов, "
                                   "о том, как долго искала избранного, и о трудностях, что ждут на пути."),
                      ("dayla", "Карр-Галл проснулся не просто так. Хранитель слабеет — и мир вместе с ним. "
                                "Нам нельзя медлить."),
                      ("bandit", "Кошелёк или жизнь, путник!"),
                      ("dayla", "Как раз проверим твою силу.")],
              after=[("dayla", "Ух ты! Вот это сноровка! А я уж боялась, что Владыка Света ошибся. "
                               "Ты и вправду хорош, {hero}."),
                     ("hero", "Обычный разбойник. Если все слуги Короля демонов такие — справимся быстро."),
                     ("dayla", "Не обольщайся. В трущобах водятся типы и похитрее. Держись ближе и смотри в оба."),
                     ("hero", "Ладно, фея. Куда дальше?"),
                     ("dayla", "Через старые переулки к воротам. Тихо и без лишних драк… надеюсь.")]),
        Stage("magician", "Фокусник", "magician", "🎩", 38, 68, 45, 14,
              "Хотите фокус?", level=1,
              figure="/static/images/story/cutouts/fig_magician.png", background=BG_SLUMS,
              before=[("magician", "Хотите фокус?")],
              after=[("dayla", "Если в городе так опасно… что же будет дальше?"),
                     ("hero", "Не зря же я всю жизнь был авантюристом. Спокойно, Дейла."),
                     ("narrator", "Что-то со свистом рассекает воздух. {hero} успевает увернуться!"),
                     ("dayla", "Какие рефлексы! Ты… ты едва не…")]),
        Stage("gazlow", "Газ-Лоу", "goblin", "⭐", 60, 50, 70, 28,
              "У тебя хорошие рефлексы. Посмотрим, как они тебе помогут.", level=1, elite=True,
              name="Газ-Лоу", reward_item="bomb",
              figure="/static/images/story/cutouts/fig_goblin.png", background=BG_SLUMS,
              before=[("narrator", "Из-за переулка раздаётся смех."),
                      ("gazlow", "У тебя хорошие рефлексы. Посмотрим, как они тебе помогут.")],
              after=[("gazlow", "Мы ещё встретимся, засранец! Хотя вряд ли Альтаир даст тебе выйти "
                                "из города живым!"),
                     ("hero", "Почему каждый встречный норовит мне всадить нож? Я же только вышел из таверны…"),
                     ("dayla", "Прости. Я… закинула тебе Амулет героя. Он передаёт особую ауру — её чуют "
                               "все, кто жаждет силы."),
                     ("hero", "То есть я теперь ходячий маяк для всех психов округи?"),
                     ("dayla", "Зато сила амулета поможет одолеть Карр-Галла. Без него нам не справиться. Идём.")]),
        Stage("killer", "Убийца", "hooded_killer", "☠", 42, 32, 55, 18,
              "Альтаир похвалит меня, когда я принесу твою голову!", level=2,
              figure="/static/images/story/cutouts/fig_killer.png", background=BG_SLUMS,
              before=[("narrator", "С крыши падает фигура в капюшоне — серп сверкает в лунном свете."),
                      ("killer", "Альтаир похвалит меня, когда я принесу твою голову!")],
              after=[("dayla", "Вон! Ворота! Мы почти выбрались!"),
                     ("narrator", "Но с края крыши поднимается новая тень…")]),
        Stage("altair", "Альтаир", "assassin", "👑", 50, 12, 90, 45,
              "Отдай амулет — и я убью тебя быстро.", level=2, boss=True, name="Альтаир",
              reward_item="smoke_bomb",
              figure="/static/images/story/cutouts/fig_assassin.png", background=BG_GATE,
              after_background=BG_BRIDGE,
              before=[("narrator", "Из тени на краю крыши выходит Альтаир — мастер клинка и тишины."),
                      ("altair", "Отдай амулет — и я убью тебя быстро. Сопротивляйся — будешь умирать дольше."),
                      ("hero", "Амулет останется со мной. Попробуй отнять."),
                      ("altair", "Как пожелаешь.")],
              after=[("altair", "Тебе же хуже — амулет загонит тебя в могилу."),
                     ("narrator", "Альтаир растворяется в тени крыш."),
                     ("dayla", "Он ушёл… но не отступил. {hero}, нам нужно поговорить."),
                     ("dayla", "Тысячу лет назад Хранитель вместе с избранными героями запечатал Карр-Галла "
                               "за Вратами Демонов. Он отдал почти всю свою силу — и с тех пор печать держится "
                               "только на нём."),
                     ("dayla", "Теперь Хранитель угасает. Именно поэтому мир ослаб, звери беснуются, "
                               "а слуги демона просыпаются. Амулет — частица той древней силы."),
                     ("hero", "Значит, пока Хранитель жив — у нас есть шанс."),
                     ("dayla", "Да. Но шанс тает с каждым днём. За воротами — Тёмный лес. Через него лежит "
                               "дорога на юг. Держись рядом.")]),
    ])

FOREST = Location(
    "forest", "🌲 Тёмный лес",
    "Тёмный лес не любит чужаков. Говорят, в его чаще водятся опасные твари: волки с горящими глазами, "
    "призрачный кот размером со льва, медведь, чья шерсть красна от крови, и Великий Олень с рогами до неба. "
    "А в самом сердце леса, у каменного круга, ждёт тот, кто ими повелевает…",
    "/static/images/story/forest_map.jpg",
    battle_bg=BG_FOREST, cutscene_bg=BG_FOREST, order=2,
    stages=[
        Stage("wolf", "Волк", "wolf", "🐺", 50, 90, 55, 15,
              "Волчий вой… Надо разобраться с этой тварью.", level=3,
              figure="/static/images/story/cutouts/fig_wolf.png", background=BG_FOREST,
              before=[("dayla", "Это Тёмный лес. Чужаков он не любит. Держи клинок наготове."),
                      ("narrator", "Между стволами вспыхивают горящие глаза.")],
              after=[("dayla", "Первый зверь пал. Но лес будто… злится. Слышишь?"),
                     ("hero", "Слышу. Идём дальше.")]),
        Stage("ghostcat", "Призрачный кот", "ghostcat", "🐈‍⬛", 40, 69, 60, 20,
              "Что-то чёрное мелькнуло между деревьев. Огромный… Похож на льва. Осторожно.", level=3,
              figure="/static/images/story/cutouts/fig_ghostcat.png", background=BG_FOREST,
              before=[("narrator", "Из тумана беззвучно выходит полупрозрачный кот — глаза горят холодным светом."),
                      ("dayla", "Осторожно! Призрачные коты не нападают на путников… что с ним?"),
                      ("narrator", "Кот шипит и прыгает.")],
              after=[("dayla", "Даже дух леса бросается на нас. Что-то очень не так…"),
                     ("hero", "Амулет?"),
                     ("dayla", "Возможно. Или безумие, что предшествует приходу Карр-Галла.")]),
        Stage("bloodbear", "Кровавый медведь", "bloodbear", "🐻", 58, 50, 70, 30,
              "Следы когтей на деревьях и кровь на траве. Хозяин чащи где-то рядом.", level=3,
              figure="/static/images/story/cutouts/fig_bloodbear.png", background=BG_FOREST,
              before=[("narrator", "Земля дрожит. Из-за деревьев выходит огромный медведь, шерсть слиплась от крови."),
                      ("hero", "Похоже, это и есть хозяин чащи."),
                      ("narrator", "Медведь ревёт и бросается вперёд.")],
              after=[("dayla", "Звери будто обезумели… Они не охотятся — они рвутся к тебе, к амулету."),
                     ("hero", "Тогда не будем давать им второй шанс. Вперёд.")]),
        Stage("greatdeer", "Великий Олень", "greatdeer", "🦌", 43, 31, 80, 35,
              "Между деревьями сияют огромные рога… Это не простой олень — сам лес смотрит его глазами.",
              level=4, figure="/static/images/story/cutouts/fig_greatdeer.png", background=BG_FOREST,
              before=[("narrator", "Дорогу преграждает величественный олень с ветвистыми рогами, по ним струится зелёный свет."),
                      ("dayla", "Это Великий Олень — гордость леса… Он никогда не тронул бы путника."),
                      ("hero", "Но его глаза налиты яростью. Готовься!")],
              after=[("dayla", "Великий Олень… Хранитель малых духов леса. Прости нас, если сможешь."),
                     ("hero", "Дорога к кругу открыта. Я чувствую, кто ждёт впереди.")]),
        Stage("druid", "Радогаст", "druid_boss", "🌿", 50, 11, 100, 60,
              "Вот он, хранитель леса… Это он натравил на меня зверей. Пора с этим покончить.",
              level=4, boss=True, name="Радогаст", reward_item="cleanse",
              figure="/static/images/story/cutouts/fig_radogast.png", background=BG_FOREST,
              before=[("dayla", "Стой, {hero}! Это Радогаст — хранитель здешних лесов."),
                      ("dayla", "Он не пропустит тебя… особенно после того, что ты сделал с его обитателями."),
                      ("radogast", "Ты пролил кровь моих зверей, чужак. Лес не прощает. Защищайся!")],
              after=[("radogast", "Довольно… Твоя сила велика. Зачем ты пришёл в мой лес?"),
                     ("dayla", "Радогаст, мы не враги лесу! Король демонов Карр-Галл проснулся и хочет уничтожить "
                               "всё живое. Владыка Света избрал {hero}, чтобы остановить его. Нам нужно пройти на юг."),
                     ("radogast", "Карр-Галл… Вот почему звери обезумели. Прости меня, {hero}, я принял тебя за "
                                  "очередного разорителя."),
                     ("radogast", "Ступайте. Пусть корни древних деревьев хранят вашу дорогу. Удачи вам!"),
                     ("dayla", "Дальше — Проклятая роща. Там чаща поёт чужим голосом. Будь осторожен.")]),
    ])

GROVE = Location(
    "grove", "🕸 Проклятая роща",
    "Проклятая роща — место, где деревья помнят кровь, а тропы вьются сами. "
    "Дейла чуть сжимается от холода: даже фее здесь не по себе.",
    "/static/images/story/grove_map.jpg",
    battle_bg=BG_GROVE, cutscene_bg=BG_GROVE, order=3,
    stages=[
        Stage("snake", "Гигантская змея", "giant_snake", "🐍", 50, 88, 70, 22,
              "Из кустов выскальзывает чешуя…", level=5,
              figure="/static/images/story/cutouts/fig_snake.png", background=BG_GROVE,
              before=[("dayla", "Эта чаща… она будто дышит. Тысячи лет назад здесь танцевали дриады. "
                                "Теперь — только шипы и шёпот."),
                      ("dayla", "Мне немного страшно, {hero}. Держи меня… ну, мысленно."),
                      ("narrator", "Земля дрожит — из-под корней поднимается гигантская змея!")],
              after=[("dayla", "Фу. Какие здесь водятся… гады."),
                     ("hero", "И это только начало рощи.")]),
        Stage("wolves", "Стая волков ×3", "pack_wolf", "🐺", 40, 62, 90, 30,
              "Вой. Много воя.", level=5, chain="wolves", chain_size=3,
              figure="/static/images/story/cutouts/fig_wolf.png", background=BG_GROVE,
              before=[("narrator", "Герои слышат вой — и на тропу выпрыгивает стая волков!"),
                      ("dayla", "Их трое… и отдыхать между ними не дадут. Держись!")],
              after=[("dayla", "Стая рассеяна. Но слышишь эти шаги? Тяжёлые. Очень тяжёлые.")]),
        Stage("grozokryl", "Грозокрыл", "owlbeast", "⭐", 58, 38, 110, 40,
              "Медведь-сова? Впервые вижу такое.", level=5, elite=True, name="Грозокрыл",
              skin="bark", reward_item="ward",
              figure="/static/images/story/cutouts/fig_owlbeast.png", background=BG_GROVE,
              before=[("narrator", "Громкие шаги. Из чащи выходит существо с крыльями и когтями медведя — "
                                   "Грозокрыл."),
                      ("dayla", "Осторожно!")],
              after=[("dayla", "Я впервые вижу такого зверя…"),
                     ("hero", "Я тоже нечасто вижу медведя-сову."),
                     ("narrator", "Вдали звучит странная музыка — свирель и шорох копыт.")]),
        Stage("shibek", "Шибэк", "satyr", "👑", 50, 12, 130, 55,
              "Договором будет твоя смерть.", level=6, boss=True, name="Шибэк",
              reward_item="poison_vial",
              figure="/static/images/story/cutouts/fig_satyr.png", background=BG_GROVE,
              before=[("narrator", "Силуэт с копытами и шерстью выходит на поляну — это Шибэк."),
                      ("shibek", "Сама чаща напела мне: артефакт невероятной силы идёт прямо ко мне в руки."),
                      ("hero", "Может, договоримся?"),
                      ("shibek", "Договором будет твоя смерть."),
                      ("hero", "*вздыхает* Ну конечно.")],
              after=[("shibek", "Эта сила тебя и погубит…"),
                     ("dayla", "Роща позади. Дальше — болото. Говорят, оно тянется на многие мили…")]),
    ])

SWAMP = Location(
    "swamp", "🐸 Болото",
    "Болото тянется на многие мили. Тысячи лет назад здесь правил Король рек — пока воды не стали чёрными, "
    "а его трон не ушёл под тину. Дейла говорит, что амулет здесь гудит особенно громко.",
    "/static/images/story/swamp_map.jpg",
    battle_bg=BG_SWAMP, cutscene_bg=BG_SWAMP, order=4,
    stages=[
        Stage("murloc", "Мурлок", "murloc", "🐟", 50, 90, 75, 24,
              "Мргл-мргл-ррааа!", level=7,
              figure="/static/images/story/cutouts/fig_murloc.png", background=BG_SWAMP,
              before=[("dayla", "Смотри: болото стелется до горизонта. Тысячи лет назад здесь обитал Король рек — "
                                "владыка пресных вод. Говорят, он дружил с Хранителем… пока тьма не пришла впервые."),
                      ("dayla", "Теперь его статуи лежат под тиной, а из воды лезут твари, что и имён-то не имеют."),
                      ("narrator", "Из трясины с бульканьем выпрыгивает мурлок!"),
                      ("narrator", "Мргл-мргл-ррааа!")],
              after=[("dayla", "Какая… прелесть. Надеюсь, дальше будет тише."),
                     ("hero", "Сомневаюсь.")]),
        Stage("giant_croc", "Гигантский крокодил", "giant_croc", "🐊", 38, 72, 85, 28,
              "Челюсти сомкнулись на ноге!", level=7,
              figure="/static/images/story/cutouts/fig_giant_croc.png", background=BG_SWAMP,
              reward_item="heal_potion",
              before=[("narrator", "Вода взрывается — гигантский крокодил хватает {hero} за ногу!"),
                      ("dayla", "Вытащи ногу! Быстрее!")],
              after=[("dayla", "Держи — зелье лечения. Пей, пока нога цела."),
                     ("hero", "Спасибо. Больше не сунусь в тёмную воду без палки.")]),
        Stage("swamp_monster", "Болотное чудище", "swamp_monster", "🪝", 62, 55, 90, 30,
              "Бедный крокодил…", level=7,
              figure="/static/images/story/cutouts/fig_swamp_monster.png", background=BG_SWAMP,
              after_background=BG_FORK,  # 5.3: развилка — фон с двумя дорогами
              reward_item="energy_potion",
              before=[("narrator", "Из тумана выходит зелёное чудище с гигантским крюком — на плечах шкура крокодила."),
                      ("hero", "Бедный крокодил…")],
              after=[("dayla", "Перед нами две дороги."),
                     ("dayla", "Светлая — долгая: мимо старого причала и лягушачьего трона. "
                               "Тёмная — короткая, но через логово гидры."),
                     ("dayla", "Выбирай, {hero}. Я пойду за тобой.")],
              choice={"id": "swamp_path", "prompt": "Какую дорогу выбрать?",
                      "background": BG_FORK,
                      "options": [{"key": "light", "label": "☀️ Светлая дорога (дольше, безопаснее)"},
                                  {"key": "dark", "label": "🌑 Тёмная дорога (быстрее, опаснее)"}]}),
        # --- светлый путь ---
        Stage("fisherman", "Рыбак", "fisherman", "🎣", 30, 40, 80, 26,
              "Всю рыбу распугал!", level=7,
              figure="/static/images/story/cutouts/fig_fisherman.png", background=BG_SWAMP,
              reward_item="net",
              choice={"requires": ("swamp_path", "light")},
              before=[("fisherman", "Ты! Всю мою рыбу распугал! Я этого так не оставлю!")],
              after=[("dayla", "Какой сердитый дед… Пойдём, пока не достал сачок побольше.")]),
        Stage("shrek_secret", "Шрек", "ogre", "🤫", 14, 48, 0, 450,
              "Всю рыбу распугали!", level=7, secret=True, name="Шрек", skin="fisher",
              figure="/static/images/story/cutouts/fig_ogre_fisher.png", background=BG_SWAMP,
              choice={"requires": ("swamp_path", "light")},
              before=[("shrek", "ВЫ ВСЮ МОЮ РЫБУ РАСПУГАЛИ!!!")],
              after=[("shrek", "Ладно… хотя бы монеты оставлю. Уходите с моего болота."),
                     ("dayla", "Кажется, мы открыли чужой секретный обед.")]),
        Stage("frog_king", "Король-лягушка", "frog_king", "🐸", 30, 22, 95, 32,
              "Ква. Ква-а-а.", level=8,
              figure="/static/images/story/cutouts/fig_frog.png", background=BG_SWAMP,
              reward_item="regen_elixir",
              choice={"requires": ("swamp_path", "light")},
              before=[("narrator", "На огромной кувшинке восседает Король-лягушка в потрёпанной короне."),
                      ("dayla", "Даже у лягушек здесь короли… Болото помнит власть Короля рек.")],
              after=[("dayla", "Трон лягушек позади. Дальше — логово Крока.")]),
        # --- тёмный путь ---
        Stage("hydra", "Гидра ×3", "hydra_head", "🐉", 70, 40, 255, 50,
              "Три головы — три боя без передышки.", level=8, chain="hydra", chain_size=3,
              figure="/static/images/story/cutouts/fig_hydra.png", background=BG_LAIR,
              reward_item="regen_elixir+whetstone",
              choice={"requires": ("swamp_path", "dark")},
              before=[("narrator", "Из чёрной воды поднимается гидра — три шеи, три пасти."),
                      ("dayla", "Головы будут идти одна за другой. Не дай себе передышки — её не будет.")],
              after=[("dayla", "Гидра пала… Но болото ещё не отпустило нас.")]),
        # --- босс ---
        Stage("croc_boss", "Крок", "croc", "👑", 50, 8, 140, 70,
              "Даже на собственном болоте мне не дают покоя!", level=8, boss=True, name="Крок",
              skin="swamp_croc",
              figure="/static/images/story/cutouts/fig_croc.png", background=BG_LAIR,
              before=[("narrator", "Вода расступается. Из глубины поднимается Крок — хозяин болот."),
                      ("croc", "Даже здесь… даже на СОБСТВЕННОМ болоте мне не дают покоя!"),
                      ("croc", "Сначала топчутся по тине, потом будят гидру, потом ещё и амулетом своим "
                               "светите, как маяком! Я столетиями спал в тишине —"),
                      ("dayla", "Мы не хотели тревожить —"),
                      ("croc", "Молчать! Король рек давно мёртв, а я — то, что осталось от его ярости. "
                               "Отдайте силу… или я верну вас болоту по частям!"),
                      ("hero", "Сила останется со мной. А тебе — урок вежливости.")],
              after=[("croc", "РААААА! Я ещё вернусь! Запомните моё имя — КРОК!!!"),
                     ("narrator", "Крок ныряет в трясину. Круги на воде стихают."),
                     ("dayla", "Он ушёл… но болото запомнило нас."),
                     ("hero", "Четыре локации позади. Сколько ещё до Врат Демонов?"),
                     ("dayla", "Много. Но ты растёшь быстрее, чем я думала. Отдохни — продолжение следует.")]),
    ])

STORY = {SLUMS.key: SLUMS, FOREST.key: FOREST, GROVE.key: GROVE, SWAMP.key: SWAMP}

# ----- 5.1h: описания врагов на карточках -----
STAGE_DESCS = {
    # Трущобы
    'bandit': 'Обычный разбойник трущоб — грязный клинок и голодный взгляд. Первый, кто проверит, достоин ли ты пути Дейлы.',
    'magician': 'Уличный фокусник с колодой карт и ножом за поясом. Улыбка добрая, а руки — быстрее глаз.',
    'gazlow': 'Газ-Лоу — хитрый гоблин-элита, чующий силу амулета. Смеётся из переулков и грозит, что Альтаир тебя не отпустит.',
    'killer': 'Убийца в капюшоне с серпом — слуга Альтаира. Падает с крыш беззвучно, как тень на лунном свете.',
    'altair': 'Альтаир — мастер клинка и тишины, страж южных ворот. Он хочет амулет и не простит отказа.',
    # Тёмный лес
    'wolf': 'Волк с горящими глазами — лес уже не охотится, а рвётся к амулету. Первый зверь на тропе в чащу.',
    'ghostcat': 'Призрачный кот размером со льва — чёрный силуэт между стволов. Дух леса, обезумевший от чужой силы.',
    'bloodbear': 'Кровавый медведь: когти в коре, кровь на траве. Звери не охотятся — они идут на тебя.',
    'greatdeer': 'Великий Олень — гордость леса и хранитель малых духов. В его рогах сияет сам Тёмный лес.',
    'druid': 'Радогаст — древний хранитель лесов у каменного круга. Он натравил зверей, приняв тебя за разорителя.',
    # Проклятая роща
    'snake': 'Гигантская змея из-под корней проклятой рощи. Здесь когда-то танцевали дриады — теперь шипы и шёпот.',
    'wolves': 'Стая волков рощи: трое без передышки. Вой множится — тропа не даёт отойти.',
    'grozokryl': 'Грозокрыл — элита рощи, медведь с крыльями совы. Тяжёлые шаги и гром перед музыкой свирели.',
    'shibek': 'Шибэк — козлоногий хозяин рощи. Сама чаща напела ему про артефакт, и договором будет твоя смерть.',
    # Болото
    'murloc': 'Мурлок из чёрной тины — безымянная тварь болот, где когда-то правил Король рек.',
    'giant_croc': 'Гигантский крокодил болот: челюсти из тёмной воды. Хватает за ногу прежде, чем успеешь крикнуть.',
    'swamp_monster': 'Болотное чудище с огромным крюком и крокодильей шкурой на плечах. На развилке двух дорог оно смотрит молча.',
    'fisherman': 'Сердитый рыбак со светлой дороги. Кричит, что ты распугал всю рыбу — и не шутит.',
    'shrek_secret': 'Шрек — огромный зелёный секрет болота. Живёт тихо, пока чужаки не вспугнут его улов.',
    'frog_king': 'Король-лягушка на кувшинке в потрёпанной короне. Болото помнит власть Короля рек — даже в кваканье.',
    'hydra': 'Гидра о трёх головах в тёмном логове. Три шеи — три боя без передышки на короткой дороге.',
    'croc_boss': 'Крок — хозяин болот, ярость мёртвого Короля рек. Столетиями спал в тишине, пока амулет не стал маяком.',
}
for _loc in STORY.values():
    for _s in _loc.stages:
        if _s.key in STAGE_DESCS:
            _s.desc = STAGE_DESCS[_s.key]

# ----- 5.1j: отображаемый (честный) уровень боссов/элит — только UI -----
DISPLAY_LEVELS = {
    "gazlow": 2,
    "altair": 3,
    "druid": 6,
    "grozokryl": 8,
    "shibek": 8,
    "croc_boss": 11
}

def stage_display_level(stage):
    """Уровень на карточке/в бою/на карте. Бой и XP используют stage.level."""
    if getattr(stage, "boss", False) or getattr(stage, "elite", False):
        return DISPLAY_LEVELS.get(stage.key, stage.level)
    return stage.level



# 5.0: баланс боссов/элит (цель — средний WR героя ~60%)
_BOSS_BALANCE = {
    "gazlow": (0.92, 0.88),
    "altair": (1.00, 0.90),
    "druid": (1.00, 1.00),
    "grozokryl": (0.85, 0.92),
    "shibek": (1.02, 0.92),
    "croc_boss": (1.08, 0.94),
    # 5.3: Король-лягушка / Гидра были ~90%+ WR — подтянули к ~60–65%
    "frog_king": (1.15, 1.12),
    "hydra": (1.10, 1.10),
}
for _loc in STORY.values():
    for _st in _loc.stages:
        if _st.key in _BOSS_BALANCE:
            _st.balance_hp, _st.balance_dmg = _BOSS_BALANCE[_st.key]

STORY_ORDER = [SLUMS, FOREST, GROVE, SWAMP]


from .battle import Battle  # noqa: E402


class StoryBattle(Battle):
    """Сюжетный бой с мобом: опыт от награды этапа; проигрыш даёт 30%. 5.0: элиты ×1.5 золота/опыта."""

    def __init__(self, hero, mob, location, stage, mode="manual", items=None):
        # 5.0: сюжетная подстройка моба под класс героя (таблицы STORY_VS) — только сюжет, арена не трогаем
        from .tuning import STORY_VS
        table = STORY_VS.get(stage.key)
        if table is not None:
            f = table.get(getattr(hero, "type_key", ""), 1.0)
            if f != 1.0:
                mob._raw_hp = max(20, int(mob._raw_hp * f))
                mob._base_damage = round(mob._base_damage * f, 3)
                mob.set_level(mob.level)
        elif hasattr(mob, "adapt_to"):
            mob.adapt_to(hero)
        # UI-only: честный уровень на карточке боя (не влияет на статы/XP)
        mob.display_level = stage.display_level
        super().__init__(hero, mob, mode=mode, ai_ids=[mob.id], items=items)
        self.location, self.stage = location, stage
        self.story = {"location": location.key, "stage": stage.key, "title": stage.title, "boss": stage.boss,
                      "elite": getattr(stage, "elite", False), "name": stage.name,
                      "battle_bg": stage.background or location.battle_bg,
                      "cutscene_bg": stage.background or location.cutscene_bg,
                      "map_image": location.image,
                      "reward_item": stage.reward_item,
                      "figure": stage.figure,
                      "display_level": stage.display_level,
                      "level": stage.level,
                      "card_title": (f"⭐ Элита · {stage.name}" if stage.elite and not stage.boss
                                     else f"{stage.name} — босс" if stage.boss else stage.name)}
        if stage.chain:
            self.story.update(chain=stage.chain,chain_size=stage.chain_size,
                              chain_index=int(hero.story_flags.get('chain_'+stage.chain,0))+1)
        self.free_items = {mob.id} if items and mob.id in items else set()
        # сюжетные расходники — «бесплатные» из сумки сюжета
        if items and hero.id in items:
            self.free_items.add(hero.id)
            hero._free_item = True

    def farm_factor(self, hero):
        return max(0.1, min(1.2, 1 - 0.3 * (hero.level - self.hero2.level)))

    def experience_for(self, winner, loser):
        hero = self.hero1
        xp = int(self.stage.xp * self.farm_factor(hero))
        if getattr(self.stage, "elite", False):
            xp = int(xp * 1.5)
        if self.stage.secret:
            xp = 0
        if winner is hero:
            return xp, 0
        return 0, int(xp * 0.3)

    def gold_reward(self):
        if self.winner is not self.hero1:
            return 0
        # 5.1: секретные награды (Шрек 450) — фиксированные, без антифарма
        if self.stage.secret:
            return int(self.stage.gold)
        g = int(self.stage.gold * self.farm_factor(self.hero1))
        if getattr(self.stage, "elite", False):
            g = int(g * 1.5)
        return g
