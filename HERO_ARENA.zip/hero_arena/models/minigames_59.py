"""Personal physical tasks. Grades come from timed input, never a client score."""
import copy,math,random
from .skills import MiniGameSkill
from .minigames_56 import Replay,integer,number,records,events,trace,at,near

SPECS={}
def spec(hero,key,mode,limit,hint,reward=None,**kw):SPECS[hero,key]=dict(mode=mode,limit=limit,hint=hint,reward=reward,**kw)
spec('spartan','shield_wall','phalanx',3400,'Направляйте щит к летящей стреле: ведите указатель вокруг воина. Три стрелы, нажимать не нужно.','Три блока: −45% урона на 2 хода и защита от оглушения; два: −35%; меньше — слабее.')
spec('samurai','iai_flash','drawblade',2900,'Две тусклые вспышки — обманки. На яркой зелёной вспышке проведите клинок слева направо по белой стрелке.','Зелёная вспышка и точный разрез: ×2.2 сквозь броню; хороший разрез: ×1.35.')
spec('minotaur','bulwark_charge','labyrinth',5200,'Пройдите к золотым воротам кнопками-стрелками. Каменные клетки закрыты. Удар и щит зависят от пройденного пути.')
spec('ghoul','hunt_leap','slingshot',3900,'Зажмите гуля, потяните НАЗАД и отпустите. Светлая дуга показывает место прыжка: совместите её конец с добычей.')
spec('orc','rage_axe','chop',3900,'Разрубите три зарубки поперёк бревна: проведите по стрелке, зажав кнопку. Направление каждого взмаха показано.',weights=(12,38,35,15))
spec('dwarf','fusion','forge',4600,'Трижды ударьте в зелёной температуре. Удары греют металл; «Остудить» снижает жар. После трёх ударов — «Закалить».','Три удара: секира-молот на 4 хода; два: на 3; один: на 2. Перегрев снижает качество.')
spec('aarakocra','talon','updraft',4400,'Нажимайте «Взмах», чтобы поднять птицу. Между взмахами она снижается. Пролетите сквозь три зелёных кольца.')
spec('centaur','harp_curse','chords',4000,'Нажимайте нужную СТРУНУ, когда её нота пересекает золотую линию. Ноты видны заранее; всего четыре.')
spec('catfolk','pounce','stalk',4400,'Зажимайте «Красться», пока добыча отвернулась. Отпускайте, когда глаз открывается. Зелёная полоса показывает путь.')
spec('ranger','spear_throw','ricochet',4600,'Зажмите копьё и направьте отражённую линию в цель за щитом. Один отскок от камня; отпустите для броска.')
spec('feliss','scale_breach','scales',4500,'Найдите треснувшую чешуйку и потяните по её стрелке. Три слоя брони; гладкие чешуйки не трогайте.')
spec('paladin','dawn_circle','justice',5000,'Разложите все четыре гири на две чаши так, чтобы вес стал одинаковым: 5 и 5. Затем нажмите «Рассудить».')
spec('mersey','sentence_end','gallows',4400,'Поднимите три затвора к светлым клеймам. Когда все три совпадут — приведите приговор в исполнение.')
spec('darkknight','plague','assembly',8500,'Соберите костяк, затем плоть, затем дракона. Перетащите детали по номерам в силуэт; крылья сначала поверните кнопкой ↻. Можно призвать уже собранный уровень.','Костяк: скелет; второй уровень: лечащий вурдалак; все три: костяной дракон. Незаконченный уровень награды не даёт.',weights=(8,28,44,20))

spec('rhino','stone_armor','stone_fit',6500,'Уложите три каменные фигуры в пустую сетку. Зажмите кружок под фигурой и перенесите к клетке для её верхнего левого угла. Все 12 клеток должны быть заняты без наложений. Можно перекладывать фигуры.','Три фигуры: щит 22% HP и отражение 20% на 3 хода; две: щит 15%; одна: 8%; без фигур: 3%.')

spec('darkelf','ritual','rune_pairs',5100,'Запомните руны, затем откройте три одинаковые пары. Неверная пара закрывается; HP за ошибки не теряется.','Три пары: ×1.7 сквозь броню; две: ×1.2; одна: ×0.65; бездействие не наносит урон.')
spec('monk','breaking_palm','mirror_pose',4600,'Повторите стойку учителя зеркально: перетащите четыре светлых сустава своего монаха справа на подсказки.','Зеркальная стойка: ×1.65, пробитие 30% брони и 20% щитов; частичная стойка слабее.')
spec('beastlord','axe_storm','axe_whirl',4800,'Зажмите рукоять на светлом кольце и сделайте два полных оборота вокруг наездника. Топоры раскручиваются вашим движением.','Два оборота: ×1.8 суммарно; после гибели кодоя на 20% сильнее. Меньше оборотов — слабее удар.')
spec('spiderqueen','web_trap','web_net',5100,'Растяните четыре угла паутины вокруг трёх мушек. Не перетягивайте нить: держите шкалу натяжения зелёной.','Три мушки в целой сети: ×1.2, яд, замедление и оглушение на ход. Порванная или неполная сеть слабее.')

# Rewards describe the new action, not the old copied control.
for _hero,_key,_reward in [
 ('minotaur','bulwark_charge','Ворота без ошибок: ×1.65 и щит 8% HP; неполный путь даёт меньше.'),
 ('ghoul','hunt_leap','Точный прыжок ×2.2 и кровотечение; хорошее попадание ×1.6, касательное ×0.8.'),
 ('orc','rage_axe','Три верных разруба: ×1.65 и кровотечение 2 HP на 2 хода; два: ×1.2; один: ×0.7.'),
 ('aarakocra','talon','Три пройденных кольца: ×1.55 и кровотечение 2 HP на 3 хода; два: ×1.35; одно: ×0.9.'),
 ('centaur','harp_curse','Четыре точные струны: ×1.2, ослепление и замедление; запрет лечения на ход. Частичный аккорд слабее.'),
 ('catfolk','pounce','Полностью подкрались: ×1.85 с пробитием 30% брони; меньший путь: ×1.2 или ×0.7.'),
 ('ranger','spear_throw','Точный отскок: ×1.9, пробитие 35% брони и кровотечение; касательное попадание слабее.'),
 ('feliss','scale_breach','Три снятых слоя: ×2.0 и пробитие 40% брони; два: ×1.5; один: ×0.9. Метки заранее не нужны.'),
 ('paladin','dawn_circle','Равновесие 5/5: ×1.45 и щит 6% HP; небольшой перевес даёт меньшую награду.'),
 ('mersey','sentence_end','Три точных затвора усиливают Свершение; готовый Приговор даёт дополнительную награду.')]:SPECS[_hero,_key]['reward']=_reward


def count_tier(n,total):return 0 if n>=total else 1 if n>=total-1 else 2 if n else 3

def jump_target(o,t):return 265+20*math.sin((t-o['prepare_ms'])/800+o['phase']),105+20*math.cos((t-o['prepare_ms'])/1000+o['phase'])
def jump_end(p):return 125+(125-p[0])*2,200+(200-p[1])*2

def flight(o,taps,end):
    """Shared 20ms integration grid, deterministic across Python and browser."""
    y=150.;v=0.;i=0;out=[];last=-10000;hits=[];es=o['rings'];q=0
    for t in range(o['prepare_ms'],end+1,20):
        while i<len(taps) and taps[i]<=t:
            if taps[i]-last>=200*o['factor']:v=-160/o['factor'];last=taps[i]
            i+=1
        v+=210/o['factor']**2*.02;y+=v*.02
        if y<30:y=30;v=max(0,v)
        if y>230:y=230;v=min(0,v)
        while q<len(es) and es[q]['ms']<=t:hits.append(abs(y-es[q]['y'])<=35);q+=1
        out.append([t,y])
    return y,v,hits,out

def forge_state(actions,o):
    heat=.55;last=o['prepare_ms'];hits=errors=0;quenched=False
    for a in actions:
        if a['ms']-last<90*o['factor']:return heat,0,9,False
        heat=max(.05,heat-(a['ms']-last)*.00002/o['factor']);last=a['ms'];kind=a.get('kind')
        if quenched:return heat,0,9,False
        if kind=='hit':
            if .42<=heat<=.82:hits+=1
            else:errors+=1
            heat=min(1.15,heat+.20)
        elif kind=='cool':heat=max(.05,heat-.28)
        elif kind=='quench':quenched=True
        else:return heat,0,9,False
    return heat,hits,errors,quenched

def assembly_progress(c,o):
    placements=records(c,'placements',12);rotations=events(c,'rotations',o,12);state={i:r for i,r in enumerate(o['angles'])};used=set();stage=0;last=o['prepare_ms']-1
    for p in placements:
        if not isinstance(p,dict):return 0
        part=integer(p.get('part'),hi=6);down=integer(p.get('down_ms'),hi=o['time_limit_ms']);up=integer(p.get('up_ms'),hi=o['time_limit_ms'])
        if part<0 or part in used or o['stages'][part]!=stage or down<=last or not 100*o['factor']<=up-down<=1800*o['factor']:return stage
        last=up
        rot=sum(a['ms']<=down and integer(a.get('part'),hi=6)==part for a in rotations)
        if (state[part]+rot)%4!=0:return stage
        if not near((number(p.get('x0')),number(p.get('y0'))),o['sources'][part],28) or not near((number(p.get('x1')),number(p.get('y1'))),o['slots'][part],27):return stage
        used.add(part)
        if all(i in used for i in range(7) if o['stages'][i]==stage):stage+=1
        if stage==3:break
    return stage


def polygon_inside(p,nodes):
    x,y=p;inside=False;j=len(nodes)-1
    for i,(xi,yi) in enumerate(nodes):
        xj,yj=nodes[j]
        cross=(x-xi)*(yj-yi)-(y-yi)*(xj-xi)
        if abs(cross)<=1e-7 and min(xi,xj)-1e-7<=x<=max(xi,xj)+1e-7 and min(yi,yj)-1e-7<=y<=max(yi,yj)+1e-7:return True
        if ((yi>y)!=(yj>y)) and x<(xj-xi)*(y-yi)/(yj-yi)+xi:inside=not inside
        j=i
    return inside

def net_metrics(nodes,o):
    cross=[]
    for i in range(4):
        a,b,c=nodes[i],nodes[(i+1)%4],nodes[(i+2)%4];cross.append((b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]))
    if not(all(x>0 for x in cross) or all(x<0 for x in cross)):return 0,float('inf')
    return sum(polygon_inside(p,nodes) for p in o['flies']),sum(math.dist(nodes[i],nodes[(i+1)%4]) for i in range(4))


class PersonalGame(Replay,MiniGameSkill):
    game='arena59';PREP=600;TIERS=('Идеально','Хорошо','Частично','Промах');AI_WEIGHTS=(22,43,25,10)
    def pick_reactor(self,user,target,is_human):return user
    def is_available(self,user):return self._original59.is_available(user)
    def describe_for(self,user):
        old=self._original59;s=self.PERSONAL
        reward=s.get('reward') or (old.SPEC['reward'] if hasattr(old,'SPEC') else old.description)
        prefix='Урон напрямую не наносится. ' if s['mode'] in ('phalanx','forge','assembly','stone_fit') else 'Урон зависит от качества выполнения. '
        return prefix+reward+' '+s['hint']
    def game_params(self,user,target):
        o=self.params(user);f=o['factor'];prep=o['prepare_ms'];mode=self.PERSONAL['mode']
        o.update(mode=mode,label=self.name,instruction=self.PERSONAL['hint'],reward=self.PERSONAL.get('reward') or (self._original59.SPEC['reward'] if hasattr(self._original59,'SPEC') else self._original59.description))
        if mode=='phalanx':o['arrows']=[dict(angle=a,ms=round((1400+i*700)*f)) for i,a in enumerate(random.sample([-.9,0,.9,2.2,3.1,4.2],3))]
        if mode=='drawblade':o.update(flash=round(random.randint(1550,1750)*f),origin=[70,140],exit=[290,100])
        if mode=='labyrinth':
            o.update(cols=4,rows=4,start=0,goal=15,walls=[2,3,6,7,11,12],route=[0,4,5,9,10,14,15])
        if mode=='slingshot':o['phase']=random.uniform(0,5)
        if mode=='chop':o['notches']=[dict(y=70+i*60,direction=1 if i%2==0 else -1) for i in range(3)]
        if mode=='updraft':o['rings']=[dict(ms=round((1550+i*1050)*f),y=y) for i,y in enumerate(random.sample([95,150,195],3))]
        if mode=='chords':o['notes']=[dict(lane=random.randrange(4),ms=round((1300+i*700)*f)) for i in range(4)]
        if mode=='stalk':
            count=4 if self.TIME_LIMIT_MS>=5400 else 3
            f*=self.TIME_LIMIT_MS/5400 if self.TIME_LIMIT_MS>=5400 else 1
            o['factor']=f
            o['safe']=[[round((700+i*1100)*f),round((1400+i*1100)*f)] for i in range(count)]
            o['goal_ms']=round(2100*f)
        if mode=='ricochet':o.update(origin=[65,210],wall=180,target=[75,random.choice([70,95,120])])
        if mode=='scales':o['layers']=[dict(cracked=random.randrange(3),direction=random.randrange(4)) for _ in range(3)]
        if mode=='justice':o.update(weights=random.sample([1,2,3,4],4),sources=[[55+i*82,215] for i in range(4)],pans=[[90,120],[270,120]])
        if mode=='gallows':o['locks']=[random.choice([65,105,145,180]) for _ in range(3)]
        if mode=='rune_pairs':o.update(cards=random.sample([0,0,1,1,2,2],6),show_until=prep+round(850*f))
        if mode=='mirror_pose':
            enemy=[[55,random.choice([75,110,155])],[125,random.choice([75,110,155])],[65,random.choice([200,220])],[115,random.choice([200,220])]]
            o.update(enemy=enemy,sources=[[235,145],[305,145],[245,235],[295,235]],targets=[[360-enemy[i][0],enemy[i][1]] for i in [1,0,3,2]])
        if mode=='web_net':
            flies=[[random.randint(65,120),random.randint(60,105)],[random.randint(230,295),random.randint(70,120)],[random.randint(130,225),random.randint(170,205)]]
            o.update(flies=flies,corners=[[140,95],[220,95],[220,165],[140,165]],budget=2*(max(x for x,y in flies)-min(x for x,y in flies)+max(y for x,y in flies)-min(y for x,y in flies))+140)
        if mode=='stone_fit':o.update(shapes=[[[0,0],[1,0],[0,1],[0,2]],[[1,0],[0,1],[1,1],[1,2]],[[1,0],[0,1],[1,1],[2,1]]],sources=[[60,220],[180,220],[300,220]],grid=[100,40,32],cols=3,rows=4)
        if mode=='assembly':o.update(stages=[0,0,1,1,2,2,2],sources=[[65+i*110,220] for i in [0,1,0,1,0,1,2]],slots=[[130,100],[230,100],[130,100],[230,100],[85,125],[275,125],[180,65]],angles=[0,0,0,0,3,1,2])
        return o
    def tier_from(self,c,o):
        if not isinstance(c,dict):return 3
        mode=o['mode'];elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);f=o['factor'];prep=o['prepare_ms']
        if elapsed<prep:return 3
        if mode=='phalanx':
            p=trace(c,o)
            if integer(c.get('engaged_ms'),hi=elapsed)<0 or not p:return 3
            n=0
            for e in o['arrows']:
                x,y=at(p,e['ms']);angle=math.atan2(y-135,x-180);d=abs((angle-e['angle']+math.pi)%(2*math.pi)-math.pi)
                n+=e['ms']<=elapsed and d<=.55
            return count_tier(n,3)
        if mode in ('slingshot','drawblade','ricochet'):
            cuts=records(c,'cuts',1)
            if len(cuts)!=1 or not isinstance(cuts[0],dict):return 3
            a=cuts[0];down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed);p0=(number(a.get('x0')),number(a.get('y0')));p1=(number(a.get('x1')),number(a.get('y1')))
            if down<prep or up-down<100*f:return 3
            if mode=='slingshot':
                if not near(p0,(125,200),35):return 3
                d=math.dist(jump_end(p1),jump_target(o,up));return 0 if d<=23 else 1 if d<=42 else 2 if d<=65 else 3
            if mode=='drawblade':
                if not near(p0,o['origin'],45) or p1[0]-p0[0]<130:return 3
                err=abs(down-o['flash']);slope=abs((p1[1]-p0[1])/(p1[0]-p0[0])+.18)
                return 0 if err<=140*f and slope<.25 else 1 if err<=270*f and slope<.5 else 2 if err<=450*f else 3
            if not near(p0,o['origin'],35) or p1[0]<105:return 3
            slope=(p1[1]-210)/(p1[0]-65);bounce=210+115*slope;end=210+220*slope
            if not 35<=bounce<=220:return 3
            d=abs(end-o['target'][1]);return 0 if d<=14 else 1 if d<=28 else 2 if d<=45 else 3
        if mode=='labyrinth':
            actions=events(c,'actions',o,24);cell=0;best=99;errors=0;last=prep-100
            for a in actions:
                if a['ms']-last<90*f:return 3
                last=a['ms'];dx,dy={'left':(-1,0),'right':(1,0),'up':(0,-1),'down':(0,1)}.get(a.get('dir'),(99,99));x,y=cell%4+dx,cell//4+dy
                if not 0<=x<4 or not 0<=y<4 or y*4+x in o['walls']:errors+=1;continue
                cell=y*4+x;best=min(best,abs(x-3)+abs(y-3))
            return 0 if cell==15 and errors==0 and len(actions)<=8 else 1 if cell==15 else 2 if best<=3 else 3
        if mode=='chop':
            cuts=records(c,'cuts',3);n=0;last=prep-1
            for i,a in enumerate(cuts):
                if not isinstance(a,dict):return 3
                down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed);x0,y0=number(a.get('x0')),number(a.get('y0'));x1,y1=number(a.get('x1')),number(a.get('y1'));e=o['notches'][i]
                if down<=last or down<prep or up-down<100*f:return 3
                last=up
                n+=e['direction']*(x1-x0)>120 and min(x0,x1)<145 and max(x0,x1)>215 and abs((y0+y1)/2-e['y'])<24 and abs(y1-y0)<55
            return count_tier(n,3)
        if mode=='forge':
            heat,n,errors,done=forge_state(events(c,'actions',o,12),o)
            return 0 if done and n>=3 and errors==0 else 1 if done and n>=2 else 2 if done and n>=1 else 3
        if mode=='updraft':
            taps=[a['ms'] for a in events(c,'clicks',o,16)];n=sum(flight(o,taps,elapsed)[2]);return count_tier(n,3) if taps else 3
        if mode=='chords':
            acts=events(c,'actions',o,4);used=set();perfect=good=0
            for a in acts:
                candidates=[(abs(a['ms']-e['ms']),i,e) for i,e in enumerate(o['notes']) if i not in used];err,i,e=min(candidates,default=(1e9,-1,{}),key=lambda q:q[0])
                if i>=0:used.add(i)
                if integer(a.get('lane'),hi=3)==e.get('lane'):
                    perfect+=err<=120*f;good+=err<=240*f
            return 0 if perfect==4 else 1 if good>=3 else 2 if good else 3
        if mode=='stalk':
            holds=records(c,'holds',6);safe=bad=0;last=prep-1
            for a in holds:
                if not isinstance(a,dict):return 3
                down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if down<prep or down<=last or up<=down:return 3
                last=up;green=sum(max(0,min(up,b)-max(down,a)) for a,b in o['safe']);safe+=green;bad+=up-down-green
            total=o.get('goal_ms',sum(b-a for a,b in o['safe']));ratio=(safe-max(0,bad-90*f)*1.8)/total
            return 0 if ratio>=.85 else 1 if ratio>=.6 else 2 if ratio>=.3 else 3
        if mode=='scales':
            cuts=records(c,'cuts',64);n=0;last=prep-1
            for a in cuts:
                if not isinstance(a,dict):return 3
                down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if down<prep or down<=last or up<down:return 3
                last=up
                if up-down<100*f:continue
                e=o['layers'][n];p0=(number(a.get('x0')),number(a.get('y0')));dx,dy=number(a.get('x1'))-p0[0],number(a.get('y1'))-p0[1]
                vx,vy=[(0,-1),(1,0),(0,1),(-1,0)][e['direction']];along=dx*vx+dy*vy;across=abs(dx*vy-dy*vx)
                if near(p0,(80+100*e['cracked'],125),32) and along>=60 and across<=along*.55:n+=1
                if n==3:break
            return count_tier(n,3)
        if mode=='justice':
            drops=records(c,'placements',8);placed={};last=prep-1
            for a in drops:
                if not isinstance(a,dict):return 3
                i=integer(a.get('part'),hi=3);down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if i<0 or down<=last or down<prep or up-down<100*f:return 3
                last=up;p0=(number(a.get('x0')),number(a.get('y0')));p1=(number(a.get('x1')),number(a.get('y1')))
                source=o['sources'][i]
                if not near(p0,source,30):return 3
                pan=next((j for j,p in enumerate(o['pans']) if near(p1,p,55)),None)
                if pan is not None:placed[i]=pan
            if len(placed)<4:return 2 if len(placed)>=2 else 3
            left=sum(o['weights'][i] for i,pan in placed.items() if pan==0);d=abs(10-2*left)
            return 0 if d==0 else 1 if d<=2 else 2 if d<=4 else 3
        if mode=='gallows':
            drops=records(c,'placements',6);placed={};last=prep-1
            for a in drops:
                if not isinstance(a,dict):return 3
                i=integer(a.get('part'),hi=2);down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if i<0 or down<=last or down<prep or up-down<100*f:return 3
                last=up;x0,y0,x1,y1=[number(a.get(k)) for k in ('x0','y0','x1','y1')]
                if abs(x0-(80+i*100))>30 or abs(y0-placed.get(i,220))>30 or abs(x1-x0)>45:return 3
                placed[i]=y1
            distances=[abs(placed.get(i,999)-y) for i,y in enumerate(o['locks'])]
            return 0 if max(distances)<=13 else 1 if max(distances)<=28 else 2 if sum(d<=35 for d in distances)>=1 else 3
        if mode=='rune_pairs':
            acts=events(c,'actions',o,16);found=set();opened=[];last=o['show_until']-120;closed_until=0
            for a in acts:
                i=integer(a.get('card'),hi=5)
                if i<0 or a['ms']<o['show_until'] or a['ms']-last<110*f or a['ms']<closed_until:return 3
                last=a['ms']
                if i in found or i in opened:continue
                opened.append(i)
                if len(opened)==2:
                    if o['cards'][opened[0]]==o['cards'][opened[1]]:found.update(opened)
                    else:closed_until=a['ms']+260*f
                    opened=[]
            return count_tier(len(found)//2,3)
        if mode=='mirror_pose':
            drops=records(c,'placements',8);positions=[p[:] for p in o['sources']];moved=set();last=prep-1
            for a in drops:
                if not isinstance(a,dict):return 3
                i=integer(a.get('part'),hi=3);down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if i<0 or down<=last or down<prep or up-down<100*f:return 3
                last=up
                if not near((number(a.get('x0')),number(a.get('y0'))),positions[i],26):return 3
                positions[i]=[number(a.get('x1')),number(a.get('y1'))];moved.add(i)
            n=sum(i in moved and near(positions[i],target,22) for i,target in enumerate(o['targets']));return count_tier(n,4)
        if mode=='axe_whirl':
            down=integer(c.get('down_ms'),hi=elapsed);up=integer(c.get('up_ms'),hi=elapsed);p=trace(c,o)
            if down<prep or up-down<700*f:return 3
            turns=0;previous=None;valid=0
            for t,x,y in p:
                if not down<=t<=up:continue
                radius=math.hypot(x-180,y-130)
                if not 40<=radius<=110:previous=None;continue
                angle=math.atan2(y-130,x-180);valid+=1
                if previous is not None:
                    delta=(angle-previous+math.pi)%(2*math.pi)-math.pi
                    if abs(delta)<=.8:turns+=delta
                previous=angle
            if valid<12:return 3
            value=abs(turns)/(2*math.pi)
            return 0 if value>=1.85 else 1 if value>=1.4 else 2 if value>=.8 else 3
        if mode=='web_net':
            drops=records(c,'placements',64);nodes=[p[:] for p in o['corners']];last=prep-1
            if not drops:return 3
            for a in drops:
                if not isinstance(a,dict):return 3
                i=integer(a.get('part'),hi=3);down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if i<0 or down<=last or down<prep or up-down<100*f:return 3
                last=up
                if not near((number(a.get('x0')),number(a.get('y0'))),nodes[i],26):return 3
                x,y=number(a.get('x1')),number(a.get('y1'))
                if not 20<=x<=340 or not 35<=y<=225:return 3
                nodes[i]=[x,y]
            n,length=net_metrics(nodes,o)
            return 0 if n==3 and length<=o['budget'] else 1 if n>=2 and length<=o['budget']*1.2 else 2 if n else 3
        if mode=='stone_fit':
            placements=records(c,'placements',16);placed={};last=prep-1
            for a in placements:
                if not isinstance(a,dict):return 3
                i=integer(a.get('part'),hi=2);down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if i<0 or down<=last or up-down<100*f:return 3
                last=up
                if not near((number(a.get('x0')),number(a.get('y0'))),o['sources'][i],28):return 3
                x=round((number(a.get('x1'))-100)/32);y=round((number(a.get('y1'))-40)/32)
                if abs(number(a.get('x1'))-(100+32*x))>15 or abs(number(a.get('y1'))-(40+32*y))>15:return 3
                cells={(x+dx,y+dy) for dx,dy in o['shapes'][i]}
                others=set().union(*(v for j,v in placed.items() if j!=i)) if placed else set()
                if all(0<=cx<3 and 0<=cy<4 for cx,cy in cells) and not cells&others:placed[i]=cells
            return count_tier(len(placed),3)
        if mode=='assembly':return 3-assembly_progress(c,o)
        return 3
    def apply(self,user,target,tier,data):
        old=self._original59;old_tier=(0,1,2,2)[tier] if len(old.TIERS)==3 else tier
        return old.apply(user,target,old_tier,data)
    def ai_score(self,user,target):return self._original59.ai_score(user,target)
    def _perform(self,user,target):return self.apply(user,target,self.ai_tier(user,target),None)

_ADAPTERS={}
def adapt(skill,s):
    k=(type(skill),id(s))
    if k not in _ADAPTERS:_ADAPTERS[k]=type('Personal'+type(skill).__name__,(PersonalGame,type(skill)),dict(PERSONAL=s,TIME_LIMIT_MS=s['limit'],PREP=600,game='arena59',TIERS=PersonalGame.TIERS,AI_WEIGHTS=s.get('weights',getattr(skill,'AI_WEIGHTS',PersonalGame.AI_WEIGHTS) if len(getattr(skill,'AI_WEIGHTS',()))==4 else PersonalGame.AI_WEIGHTS)))
    new=copy.copy(skill);new.__class__=_ADAPTERS[k];new._original59=copy.copy(skill)
    weights=new.AI_WEIGHTS
    new._original59.AI_WEIGHTS=(weights[0],weights[1],weights[2]+weights[3]) if len(skill.TIERS)==3 else weights
    new.TIME_LIMIT_MS=s['limit'];new.game='arena59';new.prompt=s['hint'];new.description=new.describe_for(None) if hasattr(skill,'SPEC') else s.get('reward') or s['hint'];new.reaction='minigame';new.reactor='user';new.copyable=False
    if not hasattr(new,'armor_pierce'):new.armor_pierce=0
    return new

def install(classes):
    for hero in {h for h,k in SPECS}:
        old=classes[hero]._create_skills
        def factory(self,_old=old,_key=hero):return [adapt(s,SPECS[_key,s.key]) if (_key,s.key) in SPECS else s for s in _old(self)]
        classes[hero]._create_skills=factory

# Shorten generous tasks; multiply their existing clock so targets/lock windows
# scale as they already do for ShortGame. Combat rewards and AI tiers stay intact.
PACING={('owlbeast','nephews'):.85,('owlbeast','night_hunt'):.85,
 ('lightelf','light_pillar'):.80,('lightelf','constellation'):.75,
 ('lightelf','last_dawn'):.80,('leon','composure'):.65,
 ('getou','raise_bones'):.83,('getou','raise_zombie'):.75,
 ('getou','flesh_stitch'):.80,('cyclops','fang_grip'):.76,
 ('cyclops','stone_flesh'):.80,('mage','water_spirit'):.83,
 ('mage','rune_seal'):.84,('mage','ice_shield'):.80}

class PacedGame:
    def public_options(self,user=None,target=None):
        old=getattr(self,'_time_multiplier',1)
        self._time_multiplier=old*self.PACE59
        try:return super().public_options(user,target)
        finally:self._time_multiplier=old

_paced={}
def pace(skill,factor):
    k=(type(skill),factor)
    if k not in _paced:_paced[k]=type('Paced'+type(skill).__name__,(PacedGame,type(skill)),dict(PACE59=factor))
    skill.__class__=_paced[k];return skill

_install_personal=install
def install(classes):
    _install_personal(classes)
    for hero in {h for h,k in PACING}:
        old=classes[hero]._create_skills
        def factory(self,_old=old,_key=hero):return [pace(s,PACING[_key,s.key]) if (_key,s.key) in PACING else s for s in _old(self)]
        classes[hero]._create_skills=factory
