"""4.2: девять новых героев.

🃏 Ловкачи: Газ-Лоу (гоблин-хитрец), Шибэк (сатир с серпами), Гуль (вурдалак-выпад).
🛡 Танки:   Риноу (человек-носорог), Дуррила (богатырь, копит «Мощь»).
⚔ Воины:   Моргал (орк, раскол брони и вампиризм), Эриксон (дворф: молот + топор).
🪶 Лёгкие:  Каэль-туас (светлый эльф, брат Нер-зула), Нефруит (тень).
"""
import random
import time

from .character import Character, HERO_CLASSES
from .effects import Announcement, Shield, Stun, Bleed, Burn, Poison, Slow, DodgeBuff, Blinded, DamageOverTime
from .effects_42 import (Feint, Devastation, Disarmed, Winded, ArmorBreak, LockBreak, Fear, Exposed, Vulnerable,
                         AxeHammerForm, Guard, BroadChest, Reflect, CupsTrick, Blessing, LungeReady)
from .skills import DamageSkill, SelfBuffSkill, DebuffSkill, Skill, MiniGameSkill, scale_effect
from .minigames_42 import CountGame, TargetGame
from .summons import Decoy, ForestSpirit


def _shield_total(user):
    return sum(e.power for e in user.get_effects() if isinstance(e, Shield))


def _add_shield(user, pct, turns=3, cap=None):
    """Щит pct·HP; cap — общий потолок всех щитов (доля HP)."""
    amount = max(1, int(user.max_hp * pct))
    if cap is not None:
        amount = max(0, min(amount, int(user.max_hp * cap) - _shield_total(user)))
    if amount <= 0:
        return 0
    old = next((e for e in user.get_effects() if type(e) is Shield), None)
    if old:
        old.power += amount
        old.duration = max(old.duration, turns)
    else:
        user.add_effect(Shield(turns, amount))
    return amount


def _fatigue_k(user, start=8, step=0.025, floor=0.4):
    """Лечение слабеет от усталости — бой не затягивается."""
    return max(floor, 1 - step * max(0, user.turn_number - start))


class _Buff(DodgeBuff):
    """Технический бафф без уклонения (наследники задают свой бонус)."""

    def dodge_bonus(self):
        return 0.0


class _ArmorUp(_Buff):
    name, icon = "Броня+", "🛡"

    def armor_bonus(self):
        return self.power


class _CritOnce(_Buff):
    name, icon = "Меткий шаг", "🎯"

    def crit_bonus(self):
        return self.power / 100


class FeintReady(_Buff):
    name, icon = "Финт готов", "🎭"

    def damage_bonus(self):
        return 0.4


class WarCry(_Buff):
    name, icon = "Боевой рёв", "📣"

    def damage_bonus(self):
        return 0.20


class _Blind(Blinded):
    name, icon = "Ослепление", "☀"


class _StompDebuff(Slow):
    name, icon = "Топот", "🦶"

    def accuracy_bonus(self):
        return -0.10


class ShadowTwins(_Buff):
    """Теневые двойники: каждый принимает на себя один удар героя (промах)."""
    name, icon = "Теневые двойники", "👥"

    def modify_incoming(self, owner, damage, attacker):
        if attacker is None or not hasattr(attacker, "skills") or self.power <= 0:
            return damage, []
        self.power -= 1
        if self.power <= 0:
            self.duration = 0
        return 0, [f"👥 Удар приходится в теневого двойника {owner.name} — он рассеивается."]


# ============================================================================
# 🃏 Газ-Лоу
# ============================================================================
class FeintSkill(Skill):
    copyable = False

    """«Финт»: на 2 хода точность врага −30%, следующий удар Газ-Лоу ×1.4."""

    def _perform(self, user, target):
        target.add_effect(Feint(2, 30))
        user.add_effect(FeintReady(3, 40))
        return [f"🎭 {user.name} делает финт: {target.name} бьёт по пустому месту (−30% точности), следующий удар ×1.4."]

    def ai_score(self, user, target):
        return 0 if target.has_effect(Feint) else 15


class DecoySkill(Skill):
    copyable = False

    """«Подмена»: двойник 30 HP (35% перехват, 3 хода, взрыв 8 при гибели)."""

    def is_available(self, user):
        return super().is_available(user) and (user.summon is None or not user.summon.is_alive())

    def _perform(self, user, target):
        user.summon = Decoy(user).scale_to(user)
        return [Announcement(f"👥 {user.name} подменяет себя двойником! (HP {user.summon.hp}, перехват {round(user.summon.intercept_chance*100)}%, 3 хода)")]

    def ai_score(self, user, target):
        return 14


class GoblinMine(DamageOverTime):
    """Мина Газ-Лоу: срабатывает в начале хода врага, урон сквозь броню."""

    name, icon, verb = "Гоблинская мина", "💣", "подрывается на мине"

    def on_turn_start(self, owner):
        owner.hp = owner.hp - self.power
        self.duration = 0
        return [f"💣 {owner.name} наступает на гоблинскую мину: −{self.power} HP (сквозь броню)!"]


class MineSkill(Skill):
    def _perform(self, user, target):
        mine = scale_effect(GoblinMine(1, 14), user)
        target.add_effect(mine)
        return [f"💣 {user.name} закладывает мину под {target.name} ({mine.power} урона в начале его хода)."]

    def ai_score(self, user, target):
        return 0 if target.has_effect(GoblinMine) else 12 + target.armor_total() * 2


class StealSkill(DamageSkill):
    """«Кража»: ×0.8, крадёт один бафф врага (щит — ослабленный вдвое), иначе 15 ресурса."""

    def _after_hit(self, user, target, damage):
        logs = super()._after_hit(user, target, damage)
        # 4.4: «форму» героя (Каменный щит огра, Контракт ассасина…) украсть нельзя — только обычные баффы
        buffs = [e for e in target.get_effects() if e.positive and getattr(e, "stealable", True)]
        if buffs:
            eff = buffs[0]
            target._effects = [e for e in target.get_effects() if e is not eff]
            if isinstance(eff, Shield):
                eff.power = max(1, eff.power // 2)
            user.add_effect(eff)
            logs.append(Announcement(f"🫳 {user.name} крадёт у {target.name}: {eff.name}"
                                     + (" (щит ослаблен вдвое)" if isinstance(eff, Shield) else "") + "!"))
        else:
            take = min(15, target.energy)
            target.restore_energy(-take)
            user.restore_energy(take)
            logs.append(f"🫳 {user.name} крадёт {take} ресурса у {target.name}.")
        return logs

    def ai_score(self, user, target):
        return super().ai_score(user, target) + (10 if any(e.positive and getattr(e, "stealable", True)
                                                           for e in target.get_effects()) else 3)


class CupsSkill(MiniGameSkill):
    """«Напёрстки»: шарик под одним из 3 стаканов, 4 перемешивания за 3 с — укажите стакан.
    Верно — следующая ОБЫЧНАЯ атака врага гарантированно мимо и враг теряет 20 ресурса. Неверно — ход потрачен."""

    game, prompt = "cups", "Следите за шариком — где он?"
    TIME_LIMIT_MS = 6500  # same four swaps, less idle time
    TIERS = ("угадал", "мимо")
    AI_WEIGHTS = (40, 60)
    TIER_VALUE = (0.0, 0.0)

    def game_params(self, user, target):
        swaps = [random.sample(range(3), 2) for _ in range(4)]
        return {"cups": 3, "start": random.randrange(3), "swaps": swaps, "swap_ms": 450, "show_ms": 700}

    @staticmethod
    def final_cup(options):
        pos = options.get("start", 0)
        for a, b in options.get("swaps", []):
            pos = b if pos == a else a if pos == b else pos
        return pos

    def tier_from(self, choice, options):
        cup = choice.get("cup") if isinstance(choice, dict) else choice
        try:
            return 0 if int(cup) == self.final_cup(options) else 1
        except (TypeError, ValueError):
            return 1

    def apply(self, user, target, tier, data):
        if tier == 1:
            return [f"🥤 {user.name} — «Напёрстки»: шарик не там. Ход потрачен."]
        user.add_effect(CupsTrick(3, 1))
        take = min(20, target.energy)
        target.restore_energy(-take)
        return [Announcement(f"🥤 {user.name} обвёл {target.name} вокруг пальца: следующая обычная атака уйдёт "
                             f"в пустой стакан, −{take} ресурса!")]

    def ai_score(self, user, target):
        return 0 if user.has_effect(CupsTrick) else 9


class LockpickSkill(MiniGameSkill):
    """«Взлом замка»: найдите «сладкую точку» отмычки за 5 с.
    Идеально (≤3 с) — снять щит врага, броня −4 на 3 хода, лучшее умение врага +2 к перезарядке;
    хорошо — броня −2 на 3 хода; провал — отмычка сломалась. Против врагов без брони бесполезна."""

    game, prompt = "timing_multi", "Поймайте сладкую точку отмычки!"
    TIME_LIMIT_MS = 5000
    TIERS = ("Идеально", "Хорошо", "Провал")
    AI_WEIGHTS = (25, 40, 35)

    def game_params(self, user, target):
        return {"presses": 1, "zone": round(random.uniform(0.25, 0.75), 2), "perfect_w": 0.05, "good_w": 0.13,
                "period_ms": 950, "icon": "🔓", "fast_ms": 2200}  # 5.4

    def tier_from(self, choice, options):
        if not isinstance(choice, dict):
            return 2
        perfect, good, ms = int(choice.get("perfect", 0)), int(choice.get("hits", 0)), float(choice.get("ms", 9999))
        if perfect >= 1 and ms <= options.get("fast_ms", 3000):
            return 0
        return 1 if good >= 1 else 2

    def apply(self, user, target, tier, data):
        if tier == 2:
            return [f"🔓 Отмычка {user.name} сломалась — ход потрачен."]
        if tier == 1:
            target.add_effect(LockBreak(3, 2))
            return [f"🔓 {user.name} вскрывает защиту {target.name}: броня −2 на 3 хода."]
        target._effects = [e for e in target.get_effects() if not isinstance(e, Shield)]
        target.add_effect(LockBreak(3, 4))
        best = max((s for s in target.skills.values() if s.key != "attack"), key=lambda s: s.cooldown, default=None)
        extra = ""
        if best is not None:
            target._cooldowns[best.key] = target.cooldown_left(best.key) + 2
            extra = f", «{best.name}» +2 к перезарядке"
        return [Announcement(f"🔓 Идеальный взлом! {user.name} снимает щиты {target.name}, броня −4{extra}.")]

    def ai_score(self, user, target):
        return 0 if target.armor_total() <= 0 else 6 + target.armor_total() * 3


class GazLow(Character):
    """Газ-Лоу — зелёный гоблин со шрамом на глазу и двумя кинжалами. Выигрывает хитростью, а не силой:
    бьёт мелко, зато обходит броню (мина), подменяет себя, крадёт эффекты и срывает планы врага.
    Мини-игры «Напёрстки» и «Взлом замка» (против врагов без брони взлом бесполезен)."""

    hero_class, type_key, resource_name = "Гоблин", "goblin", "хитрость"
    signature_skill = "daggers"
    role = "trickster"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=184, base_damage=17.5, armor=0, level=level, speed=8, dodge=0.14,  # 4.4: было HP 172, урон 19.1, уклонение 20%
                         crit_chance=0.12, max_energy=100, energy_regen=10, start_energy=50)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Тычок кинжалом", "Обычная атака", accuracy=0.9, icon="🗡"),
            DamageSkill("daggers", "Два кинжала", "Два удара по ×0.7, точность 90%, каждый игнорирует 50% брони",
                        multiplier=0.7, hits=2, accuracy=0.9, armor_pierce=0.5, cost=10, icon="🔪"),
            FeintSkill("feint", "Финт", "2 хода: точность врага −30%, ваш следующий удар ×1.4", cost=15, cooldown=4,
                       icon="🎭"),
            DecoySkill("decoy", "Подмена", "Двойник: 30 HP, 40% перехватить удар, 3 хода, при гибели взрыв 8",
                       cost=20, cooldown=5, icon="👥"),
            MineSkill("mine", "Гоблинская мина", "В начале хода врага — 14 урона сквозь броню. Против танков",
                      cost=20, cooldown=4, icon="💣"),
            StealSkill("steal", "Кража", "×0.8, крадёт бафф врага (щит — вдвое слабее) или 15 ресурса",
                       multiplier=0.8, cost=15, cooldown=3, icon="🫳"),
            CupsSkill("cups", "Напёрстки", "Мини-игра: угадайте стакан. Верно — следующая обычная атака врага мимо "
                      "(от мини-игр и призывов не спасает), −20 ресурса врагу", cost=25, cooldown=5, icon="🥤"),
            LockpickSkill("lockpick", "Взлом замка", "Мини-игра: идеально — снять щит, броня врага −4, лучшее умение "
                          "+2 к перезарядке; хорошо — броня −2. Бесполезна против врагов без брони",
                          cost=30, cooldown=6, icon="🔓"),
        ]

    def on_hit_landed(self, target, skill):
        self._effects = [e for e in self._effects if not isinstance(e, FeintReady)]
        return []


# ============================================================================
# 🃏 Шибэк
# ============================================================================
class SickleSkill(DamageSkill):
    """Удар серпом: +10% урона за уровень Мелодии и игнор 1 брони."""

    def _single_hit(self, user, target, force_hit=False):
        saved = (self.multiplier, self.armor_pierce)
        arm = target.armor_total() if hasattr(target, "armor_total") else getattr(target, "armor", 0)
        self.multiplier *= 1 + getattr(user, "MELODY_STEP", 0.1) * getattr(user, "melody", 0)
        if arm > 0 and not self.ignore_armor:
            self.armor_pierce = min(1.0, saved[1] + 1 / arm)
        try:
            return DamageSkill._single_hit(self, user, target, force_hit)
        finally:
            self.multiplier, self.armor_pierce = saved


class PanFluteSkill(Skill):
    copyable = False

    def _perform(self, user, target):
        healed = user.heal(int(user.max_hp * 0.06 * _fatigue_k(user)))
        user.add_melody(1)
        return [f"🪈 {user.name} играет на флейте Пана: +{healed} HP, Мелодия {user.melody}/5."]

    def ai_score(self, user, target):
        return 12 if user.melody < 5 or user.hp < user.max_hp * 0.7 else 2


class SickleWhirlSkill(CountGame):
    """«Серповой вихрь»: 4 с режьте листья и плоды (8), шипы не трогайте (каждый шип −2).
    7–8 — 5 ударов ×0.9; 5–6 — 4; 3–4 — 3; 0–2 — 1. Удары серпами: Мелодия и игнор 1 брони."""

    game, prompt = "click_good_bad", "Режьте листья и плоды — шипы не трогайте!"
    TIME_LIMIT_MS = 4000
    MAX, BANDS = 8, (7, 5, 3, 0)
    COUNT_FIELD = "good"
    TIERS = ("7–8", "5–6", "3–4", "0–2")
    AI_WEIGHTS = (30, 40, 22, 8)   # 4.4: было (15, 35, 35, 15)
    STRIKES = (5, 4, 3, 1)

    def game_params(self, user, target):
        items = [{"icon": random.choice(["🍃", "🍂", "🍎", "🍐"]), "good": True} for _ in range(8)] + \
                [{"icon": "🌵", "good": False} for _ in range(3)]
        random.shuffle(items)
        return {"items": items, "life_ms": 900, "spawn_ms": 330, "show_kind": True}

    def tier_from(self, choice, options):
        if isinstance(choice, dict) and int(choice.get("bad", 0) or 0) > 0:
            choice = dict(choice, good=max(0, int(choice.get("good", 0)) - 2 * int(choice.get("bad", 0))))
        return CountGame.tier_from(self, choice, options)

    def expected_value(self):
        w = self.AI_WEIGHTS
        return sum(a * self.STRIKES[i] * 0.9 for i, a in enumerate(w)) / sum(w)

    def _single_hit(self, user, target, force_hit=False):
        return SickleSkill._single_hit(self, user, target, force_hit)

    def apply(self, user, target, tier, data):
        n = self.STRIKES[tier]
        logs = [f"🌀 {user.name} — «Серповой вихрь»: {n} ударов!"]
        for _ in range(n):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, 0.9)
            logs += part
        return logs

    def ai_score(self, user, target):
        return super().ai_score(user, target) * 1.3 + 4



class SatyrDanceSkill(CountGame):
    """«Пляска сатира»: 8 нот по двум дорожкам. 7–8 — +3 Мелодии; 5–6 — +2; 3–4 — +1; 0–2 — 0."""

    game, prompt = "arrows_seq", "Ноты падают — жмите свою дорожку!"
    TIME_LIMIT_MS = 6500  # same four swaps, less idle time
    MAX, BANDS = 8, (7, 5, 3, 0)
    TIERS = ("7–8", "5–6", "3–4", "0–2")
    AI_WEIGHTS = (32, 38, 22, 8)   # 4.4: было (20, 35, 30, 15)
    GAIN = (3, 2, 1, 0)

    def game_params(self, user, target):
        return {"sequence": [random.choice(["left", "right"]) for _ in range(8)], "dirs": ["left", "right"],
                "window_ms": 650, "icon": "🎵"}

    def apply(self, user, target, tier, data):
        user.add_melody(self.GAIN[tier])
        text = (f"💃 {user.name} — «Пляска сатира» ({self.TIERS[tier]}): Мелодия {user.melody}/5 "
                f"(+{int(user.melody * user.MELODY_STEP * 100)}% урона серпов).")
        return [Announcement(text) if tier == 0 else text]

    def ai_score(self, user, target):
        if user.melody >= 4:
            return 1
        return 28 if user.turn_number <= 3 else 14


class ForestSpiritSkill(CountGame):
    """«Лесной дух» (призыв): соберите духа из 4 осколков за 6 с.
    4/4 — 60 HP, урон 6; 3 — 45 HP, 4; 2 — 30 HP, 3; 0–1 — 15 HP, только отвлекает. С 4-го хода."""

    game, prompt = "order_click", "Соберите духа: осколки 1 → 2 → 3 → 4!"
    TIME_LIMIT_MS = 4000  # 5.4 was 6000
    MAX, BANDS = 4, (4, 3, 2, 0)
    COUNT_FIELD = "done"
    TIERS = ("4/4", "3/4", "2/4", "0–1/4")
    AI_WEIGHTS = (32, 38, 22, 8)   # 4.4: было (20, 35, 30, 15)
    SPIRIT = ((60, 6), (45, 4), (30, 3), (15, 0))

    def game_params(self, user, target):
        return {"points": random.sample([[x,y] for x in (18,50,82) for y in (20,50,80)],4), "icon": "💠"}

    def is_available(self, user):
        return super().is_available(user) and (user.summon is None or not user.summon.is_alive())

    def apply(self, user, target, tier, data):
        hp, dmg = self.SPIRIT[tier]
        user.summon = ForestSpirit(user, hp, dmg).scale_to(user)
        return [Announcement(f"🌳 {user.name} собирает лесного духа ({self.TIERS[tier]}): HP {user.summon.hp}, урон {user.summon.damage}.")]

    def ai_score(self, user, target):
        return 18 if user.turn_number >= 4 else 0


class Satyr(Character):
    """Шибэк — долговязый сатир с фиолетовыми глазами, длинными рожками и двумя серпами.
    Пассивка «Мелодия» 0–5: +10% урона серпов за уровень, каждые 3 его хода −1. Серпы игнорируют 1 брони.
    ⚠ Сила Шибэка сильно зависит от точности в трёх мини-играх: новичку им играть труднее, мастеру — сильнее."""

    hero_class, type_key, resource_name = "Сатир", "satyr", "дух"
    signature_skill = "whirl"
    role = "trickster"
    MELODY_STEP = 0.10

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=186, base_damage=13.9, armor=1, level=level, speed=7, dodge=0.15,
                         crit_chance=0.08, max_energy=100, energy_regen=10, start_energy=50)
        self.melody = 0

    def _create_skills(self):
        return [
            SickleSkill("attack", "Взмах серпом", "Обычная атака серпом", accuracy=0.85, icon="🌙"),
            SickleSkill("sickles", "Два серпа", "Два удара по ×0.6, точность 85%", multiplier=0.6, hits=2,
                        accuracy=0.85, cost=10, icon="⚔"),
            SickleSkill("trip", "Подсечка", "×1.0, скорость врага −2 на 2 хода", effect=lambda: Slow(2, 2),
                        cost=15, cooldown=3, icon="🦶"),
            SelfBuffSkill("light_step", "Лёгкий шаг", "+35% уклонения на 2 хода и +20% крита следующему удару",
                          effects=[lambda: DodgeBuff(2, 35), lambda: _CritOnce(2, 20)], cost=15, cooldown=4, icon="🍃"),
            PanFluteSkill("flute", "Флейта Пана", "+6% HP и +1 Мелодия", cost=20, cooldown=5, icon="🪈"),
            SickleWhirlSkill("whirl", "Серповой вихрь", "Мини-игра: режьте листья (не шипы). 7–8 — 5 ударов ×0.9, "
                             "5–6 — 4, 3–4 — 3, 0–2 — 1", cost=25, cooldown=4, icon="🌀"),
            SatyrDanceSkill("dance", "Пляска сатира", "Мини-игра-ритм: 8 нот, 7–8 — +3 Мелодии, 5–6 — +2, 3–4 — +1",
                            cost=20, cooldown=5, icon="💃"),
            ForestSpiritSkill("forest_spirit", "Лесной дух", "Мини-игра: соберите духа из 4 осколков. "
                              "4/4 — дух 60 HP, урон 6 … 0–1 — 15 HP, только отвлекает. С 4-го хода",
                              cost=40, cooldown=8, min_turn=4, icon="🌳"),
        ]

    def add_melody(self, n):
        self.melody = max(0, min(5, self.melody + n))

    def start_turn(self):
        logs, can_act = super().start_turn()
        if self.is_alive() and self.turn_number % 3 == 0 and self.melody:
            self.melody -= 1
            logs.append(f"🎵 Мелодия {self.name} затихает: {self.melody}/5.")
        return logs, can_act

    def on_hit_landed(self, target, skill):
        self._effects = [e for e in self._effects if not isinstance(e, _CritOnce)]
        return []

    def _on_reset(self):
        self.melody = 0

    def describe(self):
        return super().describe() + f", Мелодия {self.melody}/5"

    def to_dict(self):
        data = super().to_dict()
        data["melody"] = self.melody
        return data


# ============================================================================
# 🃏 Гуль
# ============================================================================
class GhoulClaws(DamageSkill):
    def _after_hit(self, user, target, damage):
        user.restore_energy(5)
        return super()._after_hit(user, target, damage)


class DeadlyLunge(DamageSkill):
    """Смертельный выпад: ×2.6, +20% крит, игнор 30% брони, потом «Опустошение» 2 хода."""

    def _perform(self, user, target):
        ready = next((e for e in user.get_effects() if isinstance(e, LungeReady)), None)
        saved = self.multiplier
        if ready:
            self.multiplier += 0.4
            user._effects = [e for e in user.get_effects() if e is not ready]
        try:
            logs = super()._perform(user, target)
        finally:
            self.multiplier = saved
        user.add_effect(Devastation(2))
        logs.append(f"🥀 {user.name} опустошён после выпада: −30% урона, −15% уклонения на 2 хода.")
        return logs

    def ai_score(self, user, target):
        if user.has_effect(Devastation):
            return 2
        return super().ai_score(user, target) * (1.3 if user.has_effect(LungeReady) else 1.0)


class DevourSkill(DamageSkill):
    def _perform(self, user, target):
        had = user.has_effect(Devastation)
        user._effects = [e for e in user.get_effects() if not isinstance(e, Devastation)]
        logs = super()._perform(user, target)
        if had:
            logs.append(f"🍖 {user.name} насыщается — «Опустошение» снято.")
        return logs

    def ai_score(self, user, target):
        return super().ai_score(user, target) * (1.8 if user.has_effect(Devastation) else 0.9)


class LurkSkill(Skill):
    def _perform(self, user, target):
        user.add_effect(DodgeBuff(1, 40))
        user.add_effect(LungeReady(4, 0))
        user.restore_energy(20)
        return [f"🫥 {user.name} затаился: +40% уклонения на 1 ход, следующий выпад сильнее (+×0.4), +20 голода."]

    def ai_score(self, user, target):
        return 0 if user.has_effect(LungeReady) else (16 if user.energy < 40 else 8)


class HuntLeapSkill(MiniGameSkill):
    """«Охотничий прыжок»: кольцо сжимается — кликните, когда совпадёт с целью.
    Идеально — ×3.2 и кровотечение, «Опустошение» 3 хода; хорошо — ×2.2, «Опустошение» 2 хода;
    промах — урона нет, «Опустошение» 2 хода и −5% HP. С 3-го хода."""

    game, prompt = "timing_ring", "Кликните, когда кольцо совпадёт с целью!"
    TIME_LIMIT_MS = 3000
    TIERS = ("идеально", "хорошо", "промах")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (3.2, 2.2, 0.0)

    def game_params(self, user, target):
        return {"period_ms": random.randint(1000, 1400), "icon": "🎯"}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 90 else 1 if err <= 220 else 2

    def apply(self, user, target, tier, data):
        if tier == 2:
            loss = int(user.max_hp * 0.05)
            user.hp = user.hp - loss
            user.add_effect(Devastation(2))
            return [f"🐾 {user.name} пролетает мимо {target.name}! −{loss} HP и «Опустошение» на 2 хода."]
        head = f"🐾 {user.name} — «Охотничий прыжок» ({self.TIERS[tier]})!"
        logs = [Announcement(head) if tier == 0 else head]
        part, dmg = self.strike(user, target, self.TIER_VALUE[tier])
        logs += part
        if tier == 0 and dmg and target.is_alive():
            target.add_effect(scale_effect(Bleed(3, 5), user))
            logs.append(f"🩸 {target.name} истекает кровью.")
        user.add_effect(Devastation(3 if tier == 0 else 2))
        return logs

    def ai_score(self, user, target):
        return 0 if user.has_effect(Devastation) else super().ai_score(user, target) + 4


class Ghoul(Character):
    """Гуль — вурдалак с серой кожей, длинными когтями и голодными светящимися глазами.
    Вкладывается в один смертельный выпад, а потом расплачивается «Опустошением» (−30% урона, −15% уклонения).
    Выход из слабости — «Пожирание»."""

    hero_class, type_key, resource_name = "Гуль", "ghoul", "голод"
    signature_skill = "lunge"
    role = "trickster"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=190, base_damage=13.6, armor=1, level=level, speed=8, dodge=0.12,
                         crit_chance=0.15, max_energy=100, energy_regen=10, start_energy=40)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар когтем", "Обычная атака", accuracy=0.85, icon="🖐"),
            GhoulClaws("claws", "Когти", "×1.0, точность 90%, +5 голода", accuracy=0.9, cost=10, icon="💅"),
            DeadlyLunge("lunge", "Смертельный выпад", "×2.6, +20% крита, игнор 30% брони. Потом «Опустошение» 2 хода",
                        multiplier=2.6, crit_bonus=0.2, armor_pierce=0.3, accuracy=0.85, cost=40, cooldown=5, icon="🩸"),
            DamageSkill("corpse_poison", "Трупный яд", "×0.8 + яд 4/ход на 3 хода", multiplier=0.8,
                        effect=lambda: Poison(3, 4), cost=15, cooldown=3, icon="☠"),
            DevourSkill("devour", "Пожирание", "×1.2, вампиризм 40%, снимает «Опустошение»", multiplier=1.2,
                        lifesteal=0.4, cost=25, cooldown=5, icon="🍖"),
            LurkSkill("lurk", "Затаиться", "+40% уклонения на 1 ход, следующий выпад +×0.4, +20 голода",
                      cooldown=4, icon="🫥"),
            HuntLeapSkill("hunt_leap", "Охотничий прыжок", "Мини-игра: кольцо. Идеально — ×3.2 и кровотечение, "
                          "хорошо — ×2.2, промах — ничего и −5% HP. Всегда «Опустошение»", cost=50, cooldown=7,
                          min_turn=3, icon="🐾"),
        ]


# ============================================================================
# 🛡 Риноу
# ============================================================================
class RhinoStrike(DamageSkill):
    """Удар Риноу с шансом оглушить: одну цель нельзя оглушать 2 хода подряд."""

    def __init__(self, *a, stun_chance=0.0, **kw):
        super().__init__(*a, **kw)
        self.stun_chance = stun_chance

    def _after_hit(self, user, target, damage):
        logs = super()._after_hit(user, target, damage)
        if self.stun_chance and target.is_alive() and random.random() < self.stun_chance:
            if user.turn_number - getattr(user, "_last_stun_turn", -9) <= 2:
                logs.append(f"🦏 {target.name} ещё не отошёл от прошлого оглушения — не оглушается.")
            elif target.add_effect(Stun(1)):
                user._last_stun_turn = user.turn_number
                user.restore_energy(10)
                logs.append(f"💫 {target.name} оглушён! {user.name}: +10 напора.")
        return logs


class RhinoShieldSkill(Skill):
    def _perform(self, user, target):
        got = _add_shield(user, 0.12, 3, cap=(0.33 if user.type_key=="rhino" else 0.30))
        return [f"🪨 {user.name} — «{self.name}»: щит +{got} (потолок щитов 30% HP)."]

    def ai_score(self, user, target):
        return 0 if _shield_total(user) > user.max_hp * 0.15 else (16 if user.hp < user.max_hp * 0.8 else 8)


class StubbornSkill(Skill):
    def _perform(self, user, target):
        user._effects = [e for e in user.get_effects() if not isinstance(e, (Stun, Slow))]
        user.add_effect(_ArmorUp(2, 2))
        return [f"🦏 {user.name} упирается: замедление снято, броня +2 на 2 хода."]

    def ai_score(self, user, target):
        return 14 if user.has_effect(Slow) else 4


class MudBathSkill(MiniGameSkill):
    """«Грязевая ванна»: 4 с держите метку в плавающей зоне. ≥80% — +14% HP и снятие дебаффов;
    50–79% — +9%; 20–49% — +5%; <20% — +2%. Слабеет от усталости."""

    game, prompt = "hold_zone", "Держите метку в грязевой зоне!"
    TIME_LIMIT_MS = 4000
    TIERS = ("≥80%", "50–79%", "20–49%", "<20%")
    AI_WEIGHTS = (20, 35, 30, 15)
    HEAL = (0.14, 0.09, 0.05, 0.02)

    def tier_from(self, choice, options):
        share = float(choice.get("in_zone", 0)) if isinstance(choice, dict) else 0
        return 0 if share >= 0.8 else 1 if share >= 0.5 else 2 if share >= 0.2 else 3

    def apply(self, user, target, tier, data):
        healed = user.heal(int(user.max_hp * self.HEAL[tier] * _fatigue_k(user)))
        logs = [f"🟤 {user.name} — «Грязевая ванна» ({self.TIERS[tier]}): +{healed} HP."]
        if tier == 0:
            user._effects = [e for e in user.get_effects() if e.positive]
            logs.append(f"🟤 Грязь смывает все дебаффы с {user.name}.")
        return logs

    def ai_score(self, user, target):
        return 22 if user.hp < user.max_hp * 0.55 else 3


class StoneArmorSkill(CountGame):
    """«Каменная броня»: поймайте 6 падающих камней. 5–6 — щит 22% и отражение 20% урона на 3 хода;
    3–4 — щит 15%; 1–2 — 8%; 0 — 3%."""

    game, prompt = "click_targets", "Ловите падающие камни!"
    TIME_LIMIT_MS = 5000
    MAX, BANDS = 6, (5, 3, 1, 0)
    TIERS = ("5–6", "3–4", "1–2", "0")
    AI_WEIGHTS = (20, 40, 30, 10)
    PCT = (0.22, 0.15, 0.08, 0.03)

    def game_params(self, user, target):
        return {"count": 6, "icon": "🪨", "spawn_ms": 700}

    def apply(self, user, target, tier, data):
        got = _add_shield(user, self.PCT[tier], 3, cap=(0.33 if user.type_key=="rhino" else 0.30))
        text = f"🧱 {user.name} — «Каменная броня» ({self.TIERS[tier]}): щит +{got}."
        if tier == 0:
            user.add_effect(Reflect(3, 20))
            return [Announcement(text + " Отражение 20% урона на 3 хода!")]
        return [text]

    def ai_score(self, user, target):
        return 0 if _shield_total(user) > user.max_hp * 0.12 else (20 if user.hp < user.max_hp * 0.85 else 9)


class Rhino(Character):
    """Риноу — человек-носорог со сломанным рогом и толстой серой шкурой в шрамах. Медленный танк:
    оглушает, закрывается щитами и берёт измором. «Толстая шкура»: пока есть щит — +1 броня;
    за каждое оглушение врага +10 напора; одну цель нельзя оглушить 2 хода подряд; щиты — не больше 30% HP."""

    hero_class, type_key, resource_name = "Носорог", "rhino", "напор"
    signature_skill = "ram"
    role = "tank"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=214, base_damage=17.4, armor=5, level=level, speed=3, dodge=0.0,
                         crit_chance=0.05, max_energy=100, energy_regen=10, start_energy=40)
        self._last_stun_turn = -9

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар кулаком", "Обычная атака", accuracy=0.8, icon="👊"),
            RhinoStrike("horn", "Удар рогом", "×1.0, точность 85%, 10% оглушить", accuracy=0.85, stun_chance=0.10,
                        cost=10, icon="🦏"),
            RhinoStrike("ram", "Таран", "×1.5, точность 75%, 35% оглушить", multiplier=1.5, accuracy=0.75,
                        stun_chance=0.35, cost=25, cooldown=4, icon="💥"),
            RhinoShieldSkill("stone_hide", "Каменная шкура", "Щит 12% HP на 3 хода", cost=20, cooldown=4, icon="🪨"),
            DamageSkill("stomp", "Топот", "×0.8, враг −3 скорости и −10% точности на 2 хода", multiplier=0.8,
                        effect=lambda: _StompDebuff(2, 3), cost=15, cooldown=3, icon="🦶"),
            StubbornSkill("stubborn", "Упрямство", "Снимает оглушение и замедление, +2 брони на 2 хода",
                          cost=15, cooldown=5, icon="😤"),
            MudBathSkill("mud_bath", "Грязевая ванна", "Мини-игра (лечение): держите метку в зоне. "
                         "≥80% — +14% HP и снятие дебаффов … <20% — +2%", cost=35, cooldown=6, icon="🟤"),
            StoneArmorSkill("stone_armor", "Каменная броня", "Мини-игра (щит): ловите 6 камней. "
                            "5–6 — щит 22% и отражение 20%; 3–4 — 15%; 1–2 — 8%; 0 — 3%", cost=35, cooldown=6,
                            icon="🧱"),
        ]

    def armor_total(self):
        return super().armor_total() + (1 if self.has_effect(Shield) else 0)

    def _on_reset(self):
        self._last_stun_turn = -9


# ============================================================================
# 🛡 Дуррила
# ============================================================================
class BogatyrStrike(MiniGameSkill):
    """5.0: «Богатырский удар» — двухфазная мини-игра.
    1) Богатырь выбирает 2 из 4 направлений удара (влево/вправо/вверх/вниз).
    2) Соперник выбирает, куда увернуться. Если увернулся В выбранное направление — полный удар;
       иначе — вскользь (половина). ИИ-богатырь выбирает 2 направления наугад; ИИ-соперник — наугад."""

    game, prompt = "dir_pick", "Выберите 2 направления удара!"
    TIME_LIMIT_MS = 5000
    TIERS = ("увернулся", "под удар")
    AI_WEIGHTS = (50, 50)   # для ИИ: шанс, что цель «угадает» (увернётся в выбранное) — 50%
    MULT = 4.0              # 5.0: было 4.2 — чуть ослабили, т.к. игрок сам целится (цель 58–60% perfect)
    DIRS = ["up", "down", "left", "right"]
    LABELS = {"up": "⬆️ Вверх", "down": "⬇️ Вниз", "left": "⬅️ Влево", "right": "➡️ Вправо"}
    reactor = "user"        # первую фазу играет богатырь
    copyable = False

    def pick_reactor(self, actor, target, is_human):
        """5.0: если богатырь — ИИ, а цель — человек, человек сразу играет уворот (целится ИИ)."""
        if not is_human(actor) and is_human(target):
            return target
        return actor

    def is_available(self, user):
        warned = getattr(user, "_might_warned", None)
        return (super(MiniGameSkill, self).is_available(user) and user.energy >= 100 and user.turn_number >= 4
                and warned is not None and user.turn_number > warned)

    def game_params(self, user, target):
        return {"dirs": self.DIRS, "labels": dict(self.LABELS), "pick_count": 2, "phase": "aim"}

    def public_options(self, user=None, target=None):
        data = {"game": self.game, "time_limit_ms": self.TIME_LIMIT_MS, "tiers": list(self.TIERS)}
        data.update(self.game_params(user, target))
        return data

    def secret_pick(self, options=None):
        secret = super().secret_pick(options)
        secret["phase"] = (options or {}).get("phase", "aim")
        return secret

    def _normalize_dirs(self, choice):
        if isinstance(choice, dict):
            dirs = choice.get("dirs") or choice.get("picked") or []
            if choice.get("dir") and not dirs:
                dirs = [choice["dir"]]
        elif isinstance(choice, (list, tuple)):
            dirs = list(choice)
        else:
            dirs = []
        return [d for d in dirs if d in self.DIRS]

    def resolve(self, user, target, choice, secret):
        """Фаза aim: сохраняем направления и просим бой поставить уворот цели.
        Фаза dodge: считаем попадание."""
        phase = secret.get("phase", "aim")
        late = secret.get("deadline") and time.time() > secret["deadline"]
        if phase == "aim":
            dirs = self._normalize_dirs(choice)
            if late or len(dirs) < 2:
                need = [d for d in self.DIRS if d not in dirs]
                random.shuffle(need)
                dirs = (dirs + need)[:2]
            else:
                dirs = dirs[:2]
            user._bogatyr_aim = dirs
            # бой (Battle.react) увидит этот флаг и откроет вторую фазу «Куда увернуться?»
            self._followup = {
                "phase": "dodge",
                "aimed": dirs,
                "options": {"game": "dodge_pick", "dirs": self.DIRS, "labels": dict(self.LABELS),
                            "safe_count": 2, "time_limit_ms": 3000, "phase": "dodge", "aimed": dirs},
                "prompt": "Богатырь замахивается! Куда увернуться?",
                "reactor": "target",
            }
            dirs_txt = ", ".join(self.LABELS.get(d, d) for d in dirs)
            return [Announcement(f"💪 {user.name} выбирает направления удара: {dirs_txt}!")]
        # phase == dodge
        aimed = secret.get("aimed") or getattr(user, "_bogatyr_aim", [])
        d = choice.get("dir") if isinstance(choice, dict) else choice
        if late or d not in self.DIRS:
            tier = 1
        else:
            tier = 1 if d in aimed else 0
        return self.apply(user, target, tier, d)

    def _perform(self, user, target):
        """ИИ-богатырь: целится в 2 случайных направления; ИИ-цель уворачивается наугад (50%)."""
        aimed = random.sample(self.DIRS, 2)
        user._bogatyr_aim = aimed
        # 50% шанс, что цель увернётся «в» удар (полный); иначе вскользь
        if getattr(target, "perfect", False):
            dodge = random.choice([d for d in self.DIRS if d not in aimed])  # идеальная цель всегда вскользь
            tier = 0
        elif getattr(user, "perfect", False):
            # идеальный богатырь: цель всё равно угадывает 50% (как раньше TARGET_WEIGHTS)
            tier = 0 if random.random() < 0.5 else 1
            dodge = random.choice(aimed) if tier == 1 else random.choice([d for d in self.DIRS if d not in aimed])
        else:
            dodge = random.choice(self.DIRS)
            tier = 1 if dodge in aimed else 0
        return self.apply(user, target, tier, dodge)

    def apply(self, user, target, tier, data):
        user._might_warned = None
        user.restore_energy(-user.energy)
        aimed = getattr(user, "_bogatyr_aim", [])
        user._bogatyr_aim = None
        mult = self.MULT * (0.5 if tier == 0 else 1.0)
        dirs_txt = ", ".join(self.LABELS.get(d, d) for d in aimed) if aimed else "?"
        head = (f"🛡 {target.name} уворачивается — богатырский удар задевает вскользь (половина урона)!"
                if tier == 0 else f"👊 {target.name} попадает прямо под БОГАТЫРСКИЙ УДАР!")
        logs = [Announcement(f"💪 {user.name} бьёт в: {dirs_txt}."), Announcement(head)]
        part, _ = self.strike(user, target, mult, pierce=0.3)
        logs += part
        user.add_effect(Winded(1, 1.5))
        logs.append(f"😮‍💨 {user.name} переводит дух: −2 брони на 1 ход.")
        return logs

    def ai_score(self, user, target):
        return 500


class _FistSkill(DamageSkill):
    copyable = False

    def _after_hit(self, user, target, damage):
        user.add_might(5)
        return super()._after_hit(user, target, damage)


class _OakSkin(Skill):
    def _perform(self, user, target):
        got = _add_shield(user, 0.108, 3, cap=(0.33 if user.type_key=="rhino" else 0.30))
        return [f"🌳 {user.name} — «Дубовая кожа»: щит +{got}."]

    def ai_score(self, user, target):
        return 0 if user.has_effect(Shield) else (14 if user.hp < user.max_hp * 0.85 else 7)


# ----- 4.3: свои умения Дуррилы -----
class ShieldWallGuard(Guard):
    """«Щит-стена» Дуррилы: −35% получаемого урона и иммунитет к оглушению на 2 хода."""
    name, icon = "Щит-стена", "🛡"

    def blocks_stun(self):
        return True


class BogatyrSwingSkill(MiniGameSkill):
    """«Богатырский замах» (4.3) — своя мини-игра Дуррилы: зажмите кнопку, шкала силы растёт;
    отпустите в золотой зоне. Точно — ×2.4 и оглушение на 1 ход; почти — ×1.6; мимо (или перегруз) — ×0.8."""

    game, prompt = "hold_release", "Зажмите и отпустите в золотой зоне — богатырский замах!"
    TIME_LIMIT_MS = 5000
    TIERS = ("точно", "почти", "мимо", "перегруз")
    AI_WEIGHTS = (55, 33, 10, 2)    # 4.4: ИИ замахивается точнее (было 34/41/20/5) — меньше разрыв с «идеальным игроком»
    TIER_VALUE = (2.2, 1.6, 0.8, 0.8)   # 4.4: точно ×2.4 → ×2.2
    copyable = False

    def game_params(self, user, target):
        c = random.randint(58, 82) / 100
        return {"perfect": [round(c - 0.045, 2), round(c + 0.045, 2)],
                "good": [round(c - 0.14, 2), round(c + 0.14, 2)], "fill_ms": 1700, "theme": "gold"}

    def tier_from(self, choice, options):
        x = float(choice.get("charge", 0)) if isinstance(choice, dict) else float(choice)
        p, g = options.get("perfect", [0.66, 0.74]), options.get("good", [0.56, 0.84])
        if x >= 1.0:
            return 3
        return 0 if p[0] <= x <= p[1] else 1 if g[0] <= x <= g[1] else 2

    def apply(self, user, target, tier, data):
        head = f"💪 {user.name} — «Богатырский замах»: {self.TIERS[tier]}!"
        part, dmg = self.strike(user, target, self.TIER_VALUE[tier], force=tier < 2)
        logs = [Announcement(head) if tier == 0 else head] + part
        if tier == 0 and dmg > 0 and target.is_alive() and target.add_effect(Stun(1)):
            logs.append(f"💫 {target.name} оглушён богатырским замахом!")
        return logs

    def ai_score(self, user, target):
        per_hit = max(1, user.get_damage() - target.armor_total())
        # 4.4: мощь от 70 копится на «Богатырский удар» (раньше ИИ тратил её на замахи и удар почти не бил)
        if _saving_might(user):
            return 1
        return per_hit * self.expected_value() + 2


def _saving_might(user):
    """4.4: ИИ Дуррилы копит мощь от 70 на «Богатырский удар» (если HP не низкое)."""
    return user.energy >= 70 and user.hp > user.max_hp * 0.35


class LivingWaterSkill(DamageSkill):
    """«Живая вода» (4.3): удар ×1.1, лечит 50% нанесённого урона и ещё 5% max HP."""
    copyable = True   # 5.0: обычный урон — монах может скопировать

    def _perform(self, user, target):
        before = target.hp
        logs = super()._perform(user, target)
        dealt = max(0, before - target.hp)
        healed = user.heal(int(dealt * 0.5 + user.max_hp * 0.05))
        if healed:
            logs.append(f"💧 Живая вода: {user.name} +{healed} HP.")
        return logs

    def ai_score(self, user, target):
        base = super().ai_score(user, target)
        return base * (1.6 if user.hp < user.max_hp * 0.6 else 0.9)


class Durrila(Character):
    """Дуррила — могучий улыбчивый богатырь, руки скрещены на груди, огромные кулаки. Впитывает урон в «Мощь»
    (+1 за единицу урона после брони, +{c.MIGHT_PER_TURN} за ход, не больше +{c.MIGHT_CAP_PER_TURN} за ход) и выдаёт её «Богатырским ударом» ×{strike}.
    Против удара СОПЕРНИК играет «Куда увернуться?» (2 стрелки из 4 безопасны — половина урона).
    За ход до удара появляется предупреждение. Свои умения: мини-игра «Богатырский замах», «Щит-стена»
    и «Живая вода». «Обороны» не складываются — действует самая сильная. «Богатырское здоровье»: яд,
    горение и кровотечение слабее на {dot}."""

    hero_class, type_key, resource_name = "Богатырь", "bogatyr", "мощь"
    signature_skill = "bogatyr_strike"
    role = "tank"
    MIGHT_CAP_PER_TURN = 18   # 4.3: было 25 — мощь меньше зависит от того, как сильно бьёт враг
    MIGHT_PER_TURN = 9        # 4.3: было +5 за ход
    DOT_RESIST = 0.4          # 4.4: «Богатырское здоровье» — яд, горение и кровотечение −40%

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=179, base_damage=13.0, armor=4, level=level, speed=4, dodge=0.0,  # 4.4: урон 12.6→13.0
                         crit_chance=0.05, max_energy=100, energy_regen=0, start_energy=0)
        self._might_turn = 0
        self._might_warned = None

    def _create_skills(self):
        return [
            _FistSkill("attack", "Кулак", "×1.0, точность 90%, +5 мощи", accuracy=0.9, icon="👊"),
            SelfBuffSkill("bogatyr_stance", "Стойка богатыря", "−40% получаемого урона на 2 хода "
                          "(заблокированное тоже идёт в мощь)",
                          effects=[lambda: Guard(2, 40, title="Стойка богатыря")], cooldown=5, score=13, icon="🧍"),  # 4.4: перезарядка 4→5
            _OakSkin("oak_skin", "Дубовая кожа", "Щит 12% HP на 3 хода", cooldown=6, icon="🌳"),  # 4.4: перезарядка 5→6
            SelfBuffSkill("broad_chest", "Широкая грудь", "Следующий удар врага вдвое слабее, мощь с него ×2",
                          effects=[lambda: BroadChest(2, 1)], cooldown=5, score=11, icon="💪"),
            BogatyrStrike("bogatyr_strike", "Богатырский удар", "Нужно 100 мощи (тратит всю), не раньше 4-го хода, "
                          "через ход после предупреждения: ×4.2, игнор 30% брони. Соперник играет «Куда увернуться?»: "
                          "угадал — половина урона. После — «Отдышка» −2 брони", icon="💥"),
            # ----- 4.3: своя мини-игра, защита и полуатака-полухил (тратят мощь) -----
            BogatyrSwingSkill("bogatyr_swing", "Богатырский замах", "Мини-игра: зажмите — шкала силы растёт, "
                              "отпустите в золотой зоне. Точно — ×2.2 и оглушение на 1 ход, почти — ×1.6, мимо — ×0.8",
                              cost=35, cooldown=5, icon="🏋"),
            SelfBuffSkill("shield_wall", "Щит-стена", "2 хода: получаемый урон −35% и иммунитет к оглушению",
                          effects=[lambda: ShieldWallGuard(2, 35, title="Щит-стена")], cost=25, cooldown=5, score=12,
                          icon="🛡"),
            LivingWaterSkill("living_water", "Живая вода", "×1.1 и лечит 50% нанесённого урона + 5% max HP",
                             multiplier=1.1, cost=30, cooldown=4, icon="💧"),
            DamageSkill("shoulder_bash", "Удар плечом", "×1.25, точность 90%", multiplier=1.25,
                        accuracy=0.9, cost=15, cooldown=3, icon="🛡"),
        ]

    def add_might(self, n, cap=True):
        if n <= 0:
            return
        if cap:
            n = max(0, min(n, self.MIGHT_CAP_PER_TURN - self._might_turn))
        self._might_turn += n
        before = self.energy
        self.restore_energy(n)
        if before < 100 <= self.energy and self._might_warned is None:
            self._might_warned = self.turn_number
            self._events.append(Announcement(f"⚠ {self.name} набрал Мощь! Следующим ходом — БОГАТЫРСКИЙ УДАР, "
                                             f"приготовьтесь увернуться!"))

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        pre = max(1, int(amount if ignore_armor else amount - self.armor_total()))
        real = super().take_damage(amount, ignore_armor, attacker)
        self.add_might(pre if self.has_effect(Guard) else real)
        return real

    def start_turn(self):
        self._might_turn = 0
        logs, can_act = super().start_turn()
        if self.is_alive():
            self.add_might(self.MIGHT_PER_TURN)
            logs += self.pop_events()
        return logs, can_act

    def _on_reset(self):
        self._might_turn, self._might_warned = 0, None

    def describe(self):
        return super().describe() + f", мощь {self.energy}/100"

    def to_dict(self):
        data = super().to_dict()
        data["might_warned"] = self._might_warned is not None
        return data


# ============================================================================
# ⚔ Моргал
# ============================================================================
class OrcAxe(DamageSkill):
    """Удар топором: вешает «Раскол» (−1 брони за метку, до −4, 3 хода)."""

    def __init__(self, *a, splits=1, **kw):
        super().__init__(*a, **kw)
        self.splits = splits

    def ai_score(self, user, target):
        from .ai import effect_value
        return super().ai_score(user,target)+effect_value(user,target,ArmorBreak(3,self.splits))

    def _after_hit(self, user, target, damage):
        logs = super()._after_hit(user, target, damage)
        if self.splits and target.is_alive():
            target.add_effect(ArmorBreak(3, self.splits))
            n = min(4, next((e.power for e in target.get_effects() if isinstance(e, ArmorBreak)), 0))
            logs.append(f"💔 Раскол брони {target.name}: −{n}.")
        return logs


class BloodFeast(Skill):
    def _perform(self, user, target):
        stacks = min(4, next((e.power for e in target.get_effects() if isinstance(e, ArmorBreak)), 0))
        healed = user.heal(int(user.max_hp * (0.10 + 0.03 * stacks) * _fatigue_k(user)))
        return [f"🍖 {user.name} — «Кровавый пир»: +{healed} HP (расколов на враге: {stacks})."]

    def ai_score(self, user, target):
        return 24 if user.hp < user.max_hp * 0.5 else (8 if user.hp < user.max_hp * 0.75 else 0)


class FerocitySkill(OrcAxe):
    def is_available(self, user):
        return super().is_available(user) and user.hp < user.max_hp * 0.4


class AxeThrowSkill(MiniGameSkill):
    """«Бросок топора»: прицел (маятник) + сила (бегущая шкала) — 2 нажатия.
    Оба идеальные — ×2.05 сквозь броню и кровотечение 4/ход 3 хода; хотя бы одно хорошее — ×1.6, игнор 50% брони;
    оба плохие — мимо, «Безоружен» (−30% урона) на 1 ход."""

    game, prompt = "timing_multi", "Два клика: прицел и сила броска!"
    TIME_LIMIT_MS = 4000  # 5.4 was 6000
    TIERS = ("в цель!", "попал", "мимо")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (2.05, 1.35, 0.0)  # 5.4 nerf

    def game_params(self, user, target):
        return {"presses": 2, "zone": round(random.uniform(0.3, 0.7), 2), "perfect_w": 0.06, "good_w": 0.15,
                "period_ms": 900, "icon": "🪓", "labels": ["Прицел", "Сила"]}  # 5.4

    def tier_from(self, choice, options):
        if not isinstance(choice, dict):
            return 2
        perfect, good = int(choice.get("perfect", 0)), int(choice.get("hits", 0))
        return 0 if perfect >= 2 else 1 if good >= 1 else 2

    def apply(self, user, target, tier, data):
        if tier == 2:
            user.add_effect(Disarmed(1))
            return [f"🪓 Топор {user.name} пролетает мимо! «Безоружен»: −30% урона на 1 ход."]
        head = f"🪓 {user.name} — «Бросок топора»: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, dmg = self.strike(user, target, self.TIER_VALUE[tier], ignore_armor=tier == 0,
                                pierce=0.5 if tier == 1 else None)
        logs += part
        if tier == 0 and dmg and target.is_alive():
            target.add_effect(scale_effect(Bleed(3, 4), user))
            logs.append(f"🩸 {target.name} истекает кровью.")
        return logs


class Orc(Character):
    """Моргал — орк в небольшом рогатом шлеме, с топором и двумя торчащими клыками. Раскалывает броню врага
    («Раскол»: −1 брони за метку, до −4, 3 хода) и лечится его кровью («Кровожадность»: удары топором
    возвращают 8% урона). В отличие от Конана (защита и контроль) — пробивание брони и вампиризм."""

    hero_class, type_key, resource_name = "Орк", "orc", "ярость орды"
    signature_skill = "splitter"
    role = "warrior"
    AXE = ("attack", "chop", "splitter", "ferocity", "axe_throw", "rage_axe")

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=214, base_damage=14.2, armor=3, level=level, speed=5, dodge=0.05,
                         crit_chance=0.10, max_energy=100, energy_regen=10, start_energy=30)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар топором", "Обычная атака", accuracy=0.88, icon="🤜"),
            OrcAxe("chop", "Рубящий удар", "×1.0, вешает 1 «Раскол»", accuracy=0.9, cost=10, icon="🪓"),
            OrcAxe("splitter", "Раскалыватель", "×1.55, игнор 50% брони, 2 «Раскола»", multiplier=1.55,
                   armor_pierce=0.5, splits=2, cost=20, cooldown=3, icon="⛏"),
            BloodFeast("blood_feast", "Кровавый пир", "Лечит 10% HP +3% за каждый «Раскол» на враге "
                       "(слабеет от усталости)", cost=25, cooldown=5, icon="🍖"),
            SelfBuffSkill("war_cry", "Боевой рёв", "+20% урона и +10% вампиризма на 3 хода",
                          effects=[lambda: WarCry(3, 20)], cost=20, cooldown=5, score=13, icon="📣"),
            FerocitySkill("ferocity", "Свирепость", "Только при HP < 40%: ×1.6, вампиризм 40%", multiplier=1.6,
                          lifesteal=0.4, splits=1, cost=25, cooldown=4, icon="👹"),
            AxeThrowSkill("axe_throw", "Бросок топора", "Мини-игра: прицел + сила. Идеально — ×2.05 сквозь броню и "
                          "кровотечение; хорошо — ×1.35; мимо — «Безоружен»", cost=28, cooldown=6, icon="🎯"),
        ]

    def perform(self, key, target):
        before = target.hp
        self._axe_healed_this_action=False
        logs = super().perform(key, target)
        dealt = max(0, before - target.hp)
        if dealt and key in self.AXE and not self._axe_healed_this_action:
            steal = 0.07 + (0.097 if self.has_effect(WarCry) else 0)
            healed = self.heal(int(dealt * steal))
            if healed:
                logs.append(f"🩸 Кровожадность: {self.name} +{healed} HP.")
        return logs


# ============================================================================
# ⚔ Эриксон
# ============================================================================
class DwarfSkill(DamageSkill):
    copyable = True   # 5.0: обычный урон — монах может скопировать

    """Умение дворфа: weapon = hammer / axe. Топор копит «Запал» (со 2-го подряд −4% HP за единицу),
    молот сбрасывает. В форме секиры-молота удары ×1.3, 25% оглушить, −1 брони врагу, запал не ранит."""

    def __init__(self, *a, weapon="hammer", stun=0.0, fuse=1, **kw):
        super().__init__(*a, **kw)
        self.weapon, self.stun, self.fuse = weapon, stun, fuse

    def _perform(self, user, target):
        form = user.has_effect(AxeHammerForm)
        saved = self.multiplier
        if form:
            self.multiplier *= 1.3
        try:
            logs = super()._perform(user, target)
        finally:
            self.multiplier = saved
        # 4.3: враг уже пал — запал не ранит дворфа (победа больше не превращается в ничью)
        # 5.0: копия у монаха — без запала дворфа
        if hasattr(user, "weapon_used"):
            logs = logs + user.weapon_used(self.weapon, self.fuse, target_alive=target.is_alive())
        return logs

    def _after_hit(self, user, target, damage):
        logs = super()._after_hit(user, target, damage)
        if not target.is_alive():
            return logs
        form = user.has_effect(AxeHammerForm)
        chance = max(self.stun, 0.25 if form else 0)
        if chance and random.random() < chance and target.add_effect(Stun(1)):
            logs.append(f"💫 {target.name} оглушён!")
        if form:
            target.add_effect(ArmorBreak(3, 1))
        return logs

    def ai_score(self, user, target):
        base = super().ai_score(user, target)
        if self.stun:
            base += 10 * self.stun
        if not hasattr(user, "fuse"):   # 5.0: копия у монаха — без механики запала
            return base
        if self.weapon == "axe" and not user.has_effect(AxeHammerForm):
            if user.fuse + self.fuse > 2:
                return 0
            if user.hp <= user.fuse_loss(user.fuse + self.fuse):   # 4.3: не убивать себя запалом
                return 0
            if user.fuse >= 1:
                base *= 0.45
        if self.weapon == "hammer" and user.fuse >= 1:
            base *= 1.6
        return base


class RuneStanceSkill(SelfBuffSkill):
    copyable = False

    def _perform(self, user, target):
        logs = super()._perform(user, target)
        if hasattr(user, "weapon_used"):
            logs = logs + user.weapon_used("stance", 0)
        return logs


class FusionSkill(CountGame):
    """«Соединение»: половинки молота и топора сближаются — жмите, когда совпадёт каждая из 3 рун.
    Получается секира-молот: удары ×1.3, 25% оглушить, −1 брони врагу (до −4), запал не ранит; но враг бьёт сильнее.
    3/3 — 4 хода, +25% получаемого урона; 2 — 3 хода, +30%; 1 — 2 хода, +30%; 0 — сорвалось, +15% на 1 ход."""

    game, prompt = "timing_multi", "Жмите, когда руна совпадёт — 3 раза!"
    TIME_LIMIT_MS = 6500  # same four swaps, less idle time
    MAX, BANDS = 3, (3, 2, 1, 0)
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (25, 35, 25, 15)
    FORM = ((4, 23), (3, 23), (2, 23))

    def game_params(self, user, target):
        return {"presses": 3, "zone": round(random.uniform(0.35, 0.65), 2), "perfect_w": 0.05, "good_w": 0.09,
                "period_ms": 850, "icon": "ᛟ"}  # 5.4

    def is_available(self, user):
        return super().is_available(user) and not user.has_effect(AxeHammerForm)

    def apply(self, user, target, tier, data):
        user.fuse = 0
        if tier == 3:
            user.add_effect(Vulnerable(1, 15))
            return [f"⚒ Соединение сорвалось! {user.name} открыт: +15% получаемого урона на 1 ход."]
        turns, vuln = self.FORM[tier]
        user.add_effect(AxeHammerForm(turns, vuln))
        return [Announcement(f"⚒ {user.name} соединяет молот и топор в СЕКИРУ-МОЛОТ ({self.TIERS[tier]}) на {turns} х.: "
                             f"удары ×1.3, оглушают и режут броню, но получаемый урон +{vuln}%!")]

    def ai_score(self, user, target):
        return 26 if user.hp > user.max_hp * 0.45 else 8


class Dwarf(Character):
    """Эриксон — дворф с длинной рыжей бородой в кольцах, большим носом и рогатым шлемом с рунами;
    в руках молот и топор. Молот оглушает, но бьёт слабо; топор бьёт сильно, но «Запал» ранит самого
    дворфа (со 2-го удара топором подряд −4% HP за единицу запала). Оружие нужно чередовать.
    «Соединение» превращает их в секиру-молот (сильнее, но враг бьёт по нему больнее)."""

    hero_class, type_key, resource_name = "Дворф", "dwarf", "руническая сила"
    signature_skill = "chop"
    role = "warrior"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=218, base_damage=17.4, armor=4, level=level, speed=4, dodge=0.05,
                         crit_chance=0.08, max_energy=100, energy_regen=10, start_energy=40)
        self.fuse = 0

    def _create_skills(self):
        return [
            DwarfSkill("attack", "Тычок молотом", "Обычная атака молотом (сбрасывает запал)", accuracy=0.88,
                       weapon="hammer", icon="🔨"),
            DwarfSkill("hammer", "Удар молота", "×0.7, 30% оглушить, сбрасывает запал", multiplier=0.7,
                       stun=0.30, weapon="hammer", cost=10, icon="🔨"),
            DwarfSkill("concussion", "Сотрясение", "×0.5, точность врага −15% на 2 хода, 50% оглушить",
                       multiplier=0.5, stun=0.5, effect=lambda: Blinded(2, 15), weapon="hammer", cost=20,
                       cooldown=4, icon="💫"),
            DwarfSkill("chop", "Рубка", "Топор ×1.3, +1 запал", multiplier=1.3, weapon="axe", cost=10, icon="🪓"),
            DwarfSkill("double_swing", "Двойной замах", "Топор: два удара по ×0.9, +2 запала", multiplier=0.9, hits=2,
                       weapon="axe", fuse=2, cost=20, cooldown=3, icon="⚔"),
            RuneStanceSkill("rune_stance", "Руническая стойка", "+3 брони на 2 хода, сбрасывает запал",
                            effects=[lambda: _ArmorUp(2, 3)], cost=15, cooldown=4, score=10, icon="ᛉ"),
            FusionSkill("fusion", "Соединение", "Мини-игра: совместите 3 руны. Секира-молот на 2–4 хода "
                        "(×1.3, оглушение 25%, −1 брони врагу), но получаемый урон +25–30%", cost=60, cooldown=9,
                        min_turn=4, icon="⚒"),
        ]

    def choose_action(self, target):
        """ИИ Эриксона не доводит запал топора выше 2 (вне формы секиры-молота) — даже при случайном ходе."""
        key = super().choose_action(target)
        sk = self.skills.get(key)
        if (isinstance(sk, DwarfSkill) and sk.weapon == "axe" and not self.has_effect(AxeHammerForm)
                and (self.fuse + sk.fuse > 2 or self.hp <= self.fuse_loss(self.fuse + sk.fuse))):
            safe = [s for s in self.skills.values() if self.can_use(s)
                    and not (isinstance(s, DwarfSkill) and s.weapon == "axe")]
            if safe:
                return max(safe, key=lambda s: s.ai_score(self, target)).key
        return key

    def fuse_loss(self, fuse):
        """Сколько HP отнимет запал при данном его уровне (0 — в форме секиры-молота или запал < 2)."""
        if self.has_effect(AxeHammerForm) or fuse < 2:
            return 0
        return int(self.max_hp * 0.04 * (fuse - 1))

    def weapon_used(self, weapon, fuse, target_alive=True):
        if weapon != "axe":
            if self.fuse:
                self.fuse = 0
                return [f"🔨 {self.name} меняет оружие — запал сброшен."]
            return []
        self.fuse += fuse
        if self.has_effect(AxeHammerForm) or self.fuse < 2:
            return [f"🪓 Запал {self.fuse}."]
        if not target_alive:
            return [f"🪓 Запал {self.fuse} — но враг уже повержен."]
        loss = self.fuse_loss(self.fuse)
        self.hp = self.hp - loss
        return [f"🔥 Запал топора {self.fuse}: {self.name} ранит сам себя −{loss} HP. Смените оружие!"]

    def _on_reset(self):
        self.fuse = 0

    def describe(self):
        return super().describe() + f", запал {self.fuse}"

    def to_dict(self):
        data = super().to_dict()
        data["fuse"] = self.fuse
        return data


# ============================================================================
# 🪶 Каэль-туас
# ============================================================================
class AimDodgeSkill(TargetGame):
    """Удар «прицел + уклонение». Если цель — человек, она уворачивается (выбирает сторону), а прицел эльфа
    берётся по весам ИИ (или «идеально»). Иначе прицеливается сам эльф (игрок или ИИ), а ИИ-цель уворачивается
    наугад. Не в центр — урон −30%."""

    TIME_LIMIT_MS = 3500
    TIERS = ("в центр", "задел", "мимо")
    AIM_WEIGHTS = (45, 38, 17)   # 4.3: было (35, 40, 25) — меньше разрыв «идеальный игрок ↔ ИИ»
    MULT = 2.4                   # 4.3: было 2.6
    SIDES = ["left", "right"]
    LABELS = {"left": "⬅️ Влево", "right": "➡️ Вправо", "down": "⬇️ Вниз", "up": "⬆️ Вверх"}
    DODGE_PROMPT = "Светлый эльф целится — куда увернуться?"
    AIM_PROMPT = "Наведите свет на движущуюся цель!"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._mode = "aim"
        self.prompt = self.AIM_PROMPT

    def pick_reactor(self, user, target, is_human):
        self._mode = "dodge" if is_human(target) else "aim"
        self.prompt = self.DODGE_PROMPT if self._mode == "dodge" else self.AIM_PROMPT
        return target if self._mode == "dodge" else user

    def public_options(self, user=None, target=None):
        data = super().public_options(user, target)
        if self._mode == "dodge":
            data.update(game="dodge_pick", dirs=self.SIDES, labels={k: self.LABELS[k] for k in self.SIDES},
                        time_limit_ms=3000, mode="dodge")
        else:
            data.update(game="moving_target", speed=random.randint(150, 230), center_r=12, ring_r=30, mode="aim")
        return data

    def secret_pick(self, options=None):
        secret = super().secret_pick(options)
        secret["side"] = random.choice(self.SIDES)
        secret["mode"] = self._mode
        return secret

    def _aim_tier(self, user):
        if getattr(user, "perfect", False):
            return 0
        from .skills import ai_weights
        return random.choices(range(3), weights=ai_weights(user, self.AIM_WEIGHTS))[0]

    def _ai_dodged(self, target):
        if getattr(target, "perfect", False):
            return True
        return random.random() < 1 - 1 / len(self.SIDES)

    def resolve(self, user, target, choice, secret):
        late = secret.get("deadline") and time.time() > secret["deadline"]
        if secret.get("mode") == "dodge":
            guess = choice.get("dir") if isinstance(choice, dict) else choice
            dodged = (not late) and guess in self.SIDES and guess != secret.get("side")
            return self._land(user, target, self._aim_tier(user), dodged)
        zone = choice.get("zone") if isinstance(choice, dict) else choice
        aim = 2 if late else {"center": 0, "ring": 1}.get(zone, 2)
        return self._land(user, target, aim, self._ai_dodged(target))

    def _perform(self, user, target):
        return self._land(user, target, self._aim_tier(user), self._ai_dodged(target))

    def _land(self, user, target, aim, dodged):
        if aim == 2:
            return [f"{self.icon} {user.name} — «{self.name}»: свет уходит мимо цели."]
        if dodged:
            return [f"{self.icon} {user.name} — «{self.name}»: {target.name} уворачивается! Промах."]
        mult = self.MULT * (0.9 if aim == 0 else 0.7)   # 4.2b: «в центр» ×1.0 → ×0.9
        logs = [Announcement(f"{self.icon} {user.name} — «{self.name}» попадает"
                             f"{' точно в центр' if aim == 0 else ''}!")]
        part, dmg = self.strike(user, target, mult, ignore_armor=True)
        logs += part
        if dmg and target.is_alive():
            logs += self.on_land(user, target, dmg)
        return logs

    def on_land(self, user, target, dmg):
        return []

    def ai_score(self, user, target):
        w = self.AIM_WEIGHTS
        aim = (w[0] * 0.9 + w[1] * 0.7) / sum(w)
        return max(1, user.get_damage()) * self.MULT * aim / len(self.SIDES) + 6


class LightPillar(AimDodgeSkill):
    def on_land(self, user, target, dmg):
        target.add_effect(_Blind(2, 15))
        return [f"☀ {target.name} ослеплён: −15% точности на 2 хода."]


class LastDawn(AimDodgeSkill):
    MULT = 2.8   # 4.3: было 3.0
    SIDES = ["left", "right", "down"]
    DODGE_PROMPT = "Солнечное копьё летит! Влево, вправо или вниз?"
    AIM_PROMPT = "Наведите солнечное копьё!"

    def on_land(self, user, target, dmg):
        healed = user.heal(int(dmg * 0.2))
        return [f"🌅 Последний рассвет лечит {user.name}: +{healed} HP."]

    def ai_score(self, user, target):
        return super().ai_score(user, target) * 1.8


class JudgementSkill(DamageSkill):
    def _perform(self, user, target):
        buffs = [e for e in target.get_effects() if e.positive]
        saved = self.multiplier
        if buffs:
            self.multiplier *= 1.4
        try:
            logs = super()._perform(user, target)
        finally:
            self.multiplier = saved
        if buffs and target.is_alive():
            gone = buffs[0]
            target._effects = [e for e in target.get_effects() if e is not gone]
            logs.append(f"⚖ Суд света срывает с {target.name}: {gone.name}.")
        return logs


class FlashSkill(Skill):
    def _perform(self, user, target):
        target.add_effect(_Blind(1, 25))
        logs = [f"💡 {user.name} — «Ослепляющая вспышка»: {target.name} −25% точности."]
        if random.random() < 0.3 and target.add_effect(Stun(1)):
            logs.append(f"💫 {target.name} ослеплён и оглушён!")
        return logs

    def ai_score(self, user, target):
        return 0 if target.has_effect(_Blind) else 13


class LightShieldSkill(Skill):
    def _perform(self, user, target):
        got = _add_shield(user, 0.18, 3)
        return [f"🔆 {user.name} — «Светлый щит»: щит на {got} урона (без платы HP)."]

    def ai_score(self, user, target):
        return 0 if user.has_effect(Shield) else (15 if user.hp < user.max_hp * 0.8 else 6)


class StarArrowSkill(CountGame):
    """«Звёздная стрела»: по небу летит звезда — 3 выстрела. Каждое попадание ×0.8, 3/3 — последний крит."""

    game, prompt = "click_targets", "Стреляйте по летящей звезде!"
    TIME_LIMIT_MS = 4000
    MAX, BANDS = 3, (3, 2, 1, 0)
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (50, 32, 13, 5)   # 4.4: было (40, 35, 18, 7)

    def game_params(self, user, target):
        return {"count": 3, "icon": "⭐", "spawn_ms": 1100}

    def expected_value(self):
        return sum(w * (3 - i) * 0.8 for i, w in enumerate(self.AI_WEIGHTS)) / sum(self.AI_WEIGHTS)

    def apply(self, user, target, tier, data):
        hits = 3 - tier
        logs = [f"⭐ {user.name} — «Звёздная стрела»: {hits}/3."]
        for i in range(hits):
            if not target.is_alive():
                break
            saved = self.crit_bonus
            if tier == 0 and i == hits - 1:
                self.crit_bonus = 0.6          # 4.2b: было 5.0 (гарантированный крит) — идеальный игрок был слишком силён
            try:
                part, _ = self.strike(user, target, 0.8)
            finally:
                self.crit_bonus = saved
            logs += part
        return logs


class ConstellationSkill(CountGame):
    """«Созвездие»: соедините 5 звёзд по порядку за 5 с. 5/5 — +15% HP и щит 10%; 3–4 — +10%; 1–2 — +5%; 0 — ничего."""

    game, prompt = "order_click", "Соедините звёзды 1 → 5!"
    TIME_LIMIT_MS = 5000
    MAX, BANDS = 5, (5, 3, 1, 0)
    COUNT_FIELD = "done"
    TIERS = ("5/5", "3–4", "1–2", "0")
    AI_WEIGHTS = (45, 37, 13, 5)   # 4.4: было (35, 40, 18, 7)
    HEAL = (0.12, 0.10, 0.05, 0.0)       # 4.2b: лучший исход 15% → 12%

    def game_params(self, user, target):
        return {"points": random.sample([[x,y] for x in (18,50,82) for y in (20,50,80)],5), "icon": "✦"}

    def apply(self, user, target, tier, data):
        healed = user.heal(int(user.max_hp * self.HEAL[tier] * _fatigue_k(user)))
        text = f"✨ {user.name} — «Созвездие» ({self.TIERS[tier]}): +{healed} HP."
        if tier == 0:
            got = _add_shield(user, 0.10, 3)
            return [Announcement(text + f" Щит +{got}!")]
        return [text]

    def ai_score(self, user, target):
        return 22 if user.hp < user.max_hp * 0.55 else 3


class LightElf(Character):
    """Каэль-туас — светлый эльф, будущий брат Нер-зула: светлые волосы, чистые синие глаза, лёгкая улыбка,
    в поднятой руке закручивается золотисто-белый свет. Зеркален брату: тот сильнее раненым, Каэль — пока полон сил
    («Сияние»: +10% урона при HP > 70%). Самый сложный герой: 8 умений, 4 из них мини-игры;
    в «Столпе света» и «Последнем рассвете» СОПЕРНИК уворачивается."""

    hero_class, type_key, resource_name = "Светлый эльф", "lightelf", "свет"
    signature_skill = "light_pillar"
    role = "light"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=161, base_damage=13.3, armor=2, level=level, speed=6, dodge=0.10,
                         crit_chance=0.12, max_energy=100, energy_regen=14, start_energy=50)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Луч света", "Обычная атака лучом света", accuracy=0.95, icon="✨"),
            JudgementSkill("judgement", "Суд света", "×1.8, по врагу с баффом +40%, срывает бафф", multiplier=1.8,
                           cost=30, cooldown=4, icon="⚖"),
            DamageSkill("solar_bolt", "Солнечный заряд", "×1.35 чистого света", multiplier=1.35,
                        accuracy=0.92, cost=20, cooldown=3, icon="☀"),
            FlashSkill("flash", "Ослепляющая вспышка", "Точность врага −25% на 1 ход, 30% оглушить", cost=20,
                       cooldown=5, icon="💡"),
            SelfBuffSkill("blessing", "Благословение", "+15% точности и +10% уклонения на 3 хода",
                          effects=[lambda: Blessing(3)], cost=15, cooldown=5, score=10, icon="🙏"),
            LightShieldSkill("light_shield", "Светлый щит", "Щит 18% HP на 3 хода (без платы HP)", cost=25,
                             cooldown=6, icon="🔆"),
            LightPillar("light_pillar", "Столп света", "Мини-игра: наведите столп, СОПЕРНИК уворачивается. "
                        "Попадание — ×2.6 сквозь броню и «Ослепление»; не в центр — −30%", cost=35, cooldown=3,
                        icon="☀"),
            StarArrowSkill("star_arrow", "Звёздная стрела", "Мини-игра: 3 выстрела по звезде, каждый ×0.8, "
                           "3/3 — последний крит", cost=25, cooldown=3, icon="⭐"),
            ConstellationSkill("constellation", "Созвездие", "Мини-игра: соедините 5 звёзд. 5/5 — +15% HP и щит 10%",
                               cost=30, cooldown=6, icon="🌌"),
            LastDawn("last_dawn", "Последний рассвет", "При HP < 30%, раз за бой: наведите копьё, СОПЕРНИК "
                     "уворачивается (влево/вправо/вниз). ×3.0 сквозь броню, лечит 20% урона", cost=40,
                     once_per_battle=True, icon="🌅"),
        ]

    def skill_unlocked(self, skill):
        if skill.key == "last_dawn":
            return self.hp < self.max_hp * 0.3
        return True

    def damage_multiplier(self):
        return super().damage_multiplier() + (0.10 if self.hp > self.max_hp * 0.7 else 0)


# ============================================================================
# 🪶 Нефруит
# ============================================================================
class ShadowStrike(DamageSkill):
    DODGED_MULT = 1.9   # 4.4: было ×2.2 — многоударные герои (гоблин, дворф) чаще «кормили» тень уклонениями

    def _perform(self, user, target):
        saved = self.multiplier
        if getattr(user, "_dodged_last", False):
            self.multiplier = self.DODGED_MULT
        try:
            return super()._perform(user, target)
        finally:
            self.multiplier = saved
            user._dodged_last = False

    def ai_score(self, user, target):
        return super().ai_score(user, target) * (1.35 if getattr(user, "_dodged_last", False) else 1.0)


class TwinsSkill(MiniGameSkill):
    """«Теневые двойники»: 4 с ведите тень сквозь тьму, не задевая светлых пятен.
    Чисто (≥80%) — 2 двойника на 3 хода (каждый — один промах врага); с ошибками (≥40%) — 1; провал — нет."""

    game, prompt = "hold_zone", "Ведите тень во тьме — мимо света!"
    TIME_LIMIT_MS = 4000
    TIERS = ("чисто", "с ошибками", "провал")
    AI_WEIGHTS = (25, 45, 30)

    def tier_from(self, choice, options):
        share = float(choice.get("in_zone", 0)) if isinstance(choice, dict) else 0
        return 0 if share >= 0.8 else 1 if share >= 0.4 else 2

    def apply(self, user, target, tier, data):
        n = (2, 1, 0)[tier]
        if not n:
            return [f"👥 {user.name} задевает свет — двойники не появились."]
        user.add_effect(ShadowTwins(3, n))
        return [Announcement(f"👥 {user.name} рассыпается на теневых двойников ({n}) — столько ударов врага уйдёт в пустоту!")]

    def ai_score(self, user, target):
        return 0 if user.has_effect(ShadowTwins) else 14


class SkullDarkSkill(CountGame):
    """«Череп во тьме»: череп 4 раза вспыхивает — кликайте. Каждое попадание ×0.7 сквозь броню;
    3+ — «Страх» (−10% урона на 2 хода); 4/4 — ещё и оглушение."""

    game, prompt = "click_targets", "Кликайте по вспыхивающему черепу!"
    TIME_LIMIT_MS = 4400
    MAX, BANDS = 4, (4, 3, 2, 1, 0)
    TIERS = ("4/4", "3/4", "2/4", "1/4", "0/4")
    AI_WEIGHTS = (18, 30, 27, 17, 8)

    def game_params(self, user, target):
        return {"count": 4, "icon": "💀", "spawn_ms": 900, "dark": True}

    def expected_value(self):
        return sum(w * (4 - i) * 0.7 for i, w in enumerate(self.AI_WEIGHTS)) / sum(self.AI_WEIGHTS)

    def apply(self, user, target, tier, data):
        hits = 4 - tier
        logs = [f"💀 {user.name} — «Череп во тьме»: {hits}/4."]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, 0.7, ignore_armor=True)
            logs += part
        if hits >= 3 and target.is_alive():
            target.add_effect(Fear(2))
            logs.append(f"😱 {target.name} охвачен страхом: −10% урона на 2 хода.")
        if hits == 4 and target.is_alive() and target.add_effect(Stun(1)):
            logs.append(f"💫 {target.name} оцепенел от ужаса!")
        return logs


class CatchShadowSkill(MiniGameSkill):
    """4.2: мини-игра ПРОТИВНИКА Нефруита «Поймать тень». Каждые 4 хода тени мелькают несколько силуэтов,
    среди них чёрный череп — кликните его за 0.9 с. Поймал — удар ×1.8 с гарантированным попаданием
    и уклонение тени 0 на 1 ход. ИИ ловит в 35% случаев. Умение появляется у соперника само, стоит 0."""

    copyable = False
    game, prompt = "click_good_bad", "Какая тень настоящая? Ищите чёрный череп среди силуэтов!"
    TIME_LIMIT_MS = 800
    TIERS = ("поймал", "мимо")
    AI_WEIGHTS = (35, 65)

    def game_params(self, user, target):
        n = 10
        good = random.randrange(n)
        items = [{"icon": "💀" if i == good else "👤", "good": i == good} for i in range(n)]
        return {"items": items, "together": True, "life_ms": 800, "spawn_ms": 0, "pick_one": True}

    def is_available(self, user):
        foe = user.opponent
        return super().is_available(user) and foe is not None and getattr(foe, "shadow_window", False)

    def tier_from(self, choice, options):
        if not isinstance(choice, dict):
            return 1
        return 0 if int(choice.get("good", 0)) >= 1 and int(choice.get("bad", 0)) == 0 else 1

    def apply(self, user, target, tier, data):
        target.shadow_window = False
        if tier == 1:
            return [f"👤 {user.name} хватает пустую тень — Нефруит ускользает."]
        target.add_effect(Exposed(1))
        logs = [Announcement(f"🔦 {user.name} ловит Нефруита! Тень проявилась.")]
        part, _ = self.strike(user, target, 1.8, force=True)
        return logs + part

    def ai_score(self, user, target):
        return 60


class Nefruit(Character):
    """Нефруит — тёмный силуэт, сквозь мрак которого светится череп. По тени трудно попасть (уклонение {dodge}),
    но «Бесплотность»: горение, яд и кровотечение бьют по ней на {incorporeal} сильнее.
    Каждые 4 хода тени у соперника появляется мини-игра «Поймать тень»: поймал — удар ×1.8 и уклонение тени 0. «Удар из тени» после уклонения — ×{shadow}. «Ускользание»: даже точный удар мини-игры проходит мимо с шансом {evade}."""

    hero_class, type_key, resource_name = "Тень", "shade", "мрак"
    signature_skill = "shadow_strike"
    role = "light"
    WINDOW_EVERY = 4
    FORCED_EVADE = 0.75  # 4.4: «Ускользание» — точный приём мини-игры проходит мимо с шансом 75% её уклонения
    INCORPOREAL = 0.15   # 4.4: «Бесплотность» — горение/яд/кровотечение сильнее на 15% (было 30%)

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=190, base_damage=12.9, armor=1, level=level, speed=8, dodge=0.17,  # 4.3: уклонение 35%→26%, броня 0→1; 4.4: уклонение 26%→20%, HP 172→190 (меньше «всё или ничего» против неточных/точных)
                         crit_chance=0.12, max_energy=100, energy_regen=12, start_energy=50)
        self.shadow_window = False
        self._dodged_last = False

    def _create_skills(self):
        return [
            DamageSkill("attack", "Касание мрака", "Обычная атака", accuracy=0.9, icon="🖤"),
            DamageSkill("dark_touch", "Касание пустоты", "×1.0, точность 90%", accuracy=0.9, cost=10, icon="🌑"),
            SelfBuffSkill("dissolve", "Растворение", "+25% уклонения на 1 ход (не выше 75%)",
                          effects=[lambda: DodgeBuff(1, 25)], cost=15, cooldown=4, score=9, icon="🌫"),
            ShadowStrike("shadow_strike", "Удар из тени", "×1.6, если в прошлый ход увернулся — ×1.9",
                         multiplier=1.6, cost=20, cooldown=3, icon="🗡"),
            DebuffSkill("void_whisper", "Шёпот пустоты", "Точность врага −10% на 3 хода",
                        effect=lambda: Blinded(3, 10), cost=15, cooldown=5, icon="🕳"),
            TwinsSkill("twins", "Теневые двойники", "Мини-игра: ведите тень мимо света. Чисто — 2 двойника "
                       "(2 промаха врага), с ошибками — 1", cost=30, cooldown=6, icon="👥"),
            SkullDarkSkill("skull", "Череп во тьме", "Мини-игра: 4 вспышки черепа, каждое попадание ×0.7 сквозь броню. "
                           "3+ — «Страх», 4/4 — оглушение", cost=30, cooldown=5, icon="💀"),
        ]

    def note_dodged(self):
        """Хук: по Нефруиту промахнулись (для «Удара из тени»)."""
        self._dodged_last = True

    def start_turn(self):
        extra = sum(int(e.power * self.INCORPOREAL) for e in self._effects if isinstance(e, (Burn, Poison, Bleed)))
        logs, can_act = super().start_turn()
        if extra and self.is_alive():
            self.hp = self.hp - extra
            logs.append(f"🖤 Бесплотность: {self.name} получает ещё −{extra} HP от горения/яда/кровотечения.")
        self.shadow_window = False
        if self.is_alive() and self.turn_number % self.WINDOW_EVERY == 0:
            self.shadow_window = True
            foe = self.opponent
            if foe is not None and "foe_catch_shadow" not in foe.skills:
                foe.skills["foe_catch_shadow"] = CatchShadowSkill(
                    "foe_catch_shadow", "Поймать тень", "Мини-игра против тени: найдите чёрный череп среди "
                    "силуэтов за 0.9 с. Поймал — ×1.8 с гарантированным попаданием", icon="🔦")
            logs.append(Announcement(f"🔦 Тень {self.name} проявляется! Следующим ходом её можно поймать."))
        return logs, can_act

    def _on_reset(self):
        self.shadow_window = False
        self._dodged_last = False

    def to_dict(self):
        data = super().to_dict()
        data["shadow_window"] = self.shadow_window
        return data


NEW_HEROES_42 = {"goblin": GazLow, "satyr": Satyr, "ghoul": Ghoul, "rhino": Rhino, "bogatyr": Durrila,
                 "orc": Orc, "dwarf": Dwarf, "lightelf": LightElf, "shade": Nefruit}
HERO_CLASSES.update(NEW_HEROES_42)
