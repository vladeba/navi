"""Internal save-compatible build identifier; the product title is HERO ARENA."""
APP_VERSION = "6.0.8"
