/* Simple visible goals; every score below is replayed independently by the server. */
(function(){
'use strict';
const {setup,circle,line,text,interpolate}=window.arenaMiniUI;
const near=(a,b,r)=>Math.hypot(a[0]-b[0],a[1]-b[1])<=r;
const path=r=>r.state.points.map(p=>[p.t,p.x,p.y]);
function exact(r,t,p){r.setCursor(p);const a={t,x:p.x,y:p.y};if(r.state.points.at(-1)?.t===t)r.state.points[r.state.points.length-1]=a;else r.state.points.push(a)}
function target(o,t,i=0){const q=(t-o.prepare_ms)/o.period*2*Math.PI+o.phase+i*1.4;return[180+75*Math.sin(q),120+30*Math.sin(q*.6+.5)]}
function bar(o,t,start=o.prepare_ms){const v=((t-start+o.phase)%o.period)/o.period;return v<=.5?2*v:2-2*v}
function button(id,label){return `<button class="btn" id="${id}">${esc(label)}</button>`}
function ready(r,t){if(t>=r.o.prepare_ms)return true;r.status(`Приготовьтесь: ${Math.max(1,Math.ceil((r.o.prepare_ms-t)/1000))}…`);return false}
function engage(r){const move=r.svg.onpointermove;r.svg.onpointermove=e=>{move(e);r.state.engaged_ms??=r.elapsed()};r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);r.setCursor(r.pos(e));r.state.engaged_ms??=r.elapsed()}}
function countTier(n,total){return n>=total?'Идеально':n>=Math.max(2,total-1)?'Хорошо':n?'Частично':'Пока без попаданий'}
function body(){return '<path d="M180 40 C153 40 150 78 165 92 L143 123 L125 215 L235 215 L217 123 L195 92 C210 78 207 40 180 40Z" fill="#51475e88" stroke="#aa92ae" stroke-width="2"/>'}
const modes={};
MINIGAMES.arena58=function(o,head){modes[o.mode](o,head)};
modes.stop=modes.summon=function(o,h){
 const summon=o.mode==='summon',r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>',button('a58Stop',summon?'Закрепить уровень':o.verb));r.state.clicks=[];let grade=null,stageStart=o.prepare_ms;
 const btn=document.getElementById('a58Stop');
 function result(){let good=0,start=o.prepare_ms;for(const a of r.state.clicks){good+=Math.abs(bar(o,a.ms,start)-o.zone)<=.18;start=a.ms+Math.round(200*o.factor)}return good}
 btn.onclick=()=>{const ms=r.elapsed();if(ms<o.prepare_ms||ms<stageStart||r.state.clicks.length>=o.rounds)return;const d=Math.abs(bar(o,ms,stageStart)-o.zone);grade=d<=o.width?'Идеально':d<=.18?'Хорошо':d<=.3?'Частично':'Промах';r.state.clicks.push({ms});if(!summon||r.state.clicks.length===o.rounds)r.finish();else stageStart=ms+Math.round(200*o.factor)};
 if(summon)document.getElementById('rFinish').textContent='Призвать сейчас';
 r.animate(t=>{const x=bar(o,t,stageStart),active=t>=Math.max(stageStart,o.prepare_ms),d=Math.abs(x-o.zone),gold=d<=o.width,green=d<=.18;
 let out=summon?text(180,50,['НЕТ ПРИЗЫВА','СКЕЛЕТ','ВУРДАЛАК','КОСТЯНОЙ ДРАКОН'][result()],18)+text(180,85,`Попытка ${Math.min(3,r.state.clicks.length+1)} из 3`,16):body()+circle(180,130,25,gold?'#eac16f55':'#55466055',gold?'#ffdd8b':'#aa91ac');
 out+=`<rect x="25" y="185" width="310" height="32" rx="8" fill="#181723" stroke="#7a6e89"/><rect x="${25+310*(o.zone-.18)}" y="186" width="${310*.36}" height="30" fill="#4d9561"/><rect x="${25+310*(o.zone-o.width)}" y="186" width="${620*o.width}" height="30" fill="#e8bc55"/>`+line(25+310*x,176,25+310*x,226,'#fff4d9',4)+text(180,250,'ЗОЛОТО — ИДЕАЛ · ЗЕЛЁНОЕ — ХОРОШО',11);
 r.svg.innerHTML=out;btn.disabled=!active;if(ready(r,t))r.status(!active?'Следующий уровень…':gold?'СЕЙЧАС — ИДЕАЛ':green?'СЕЙЧАС — ХОРОШО':grade?`Прошлая попытка: ${grade}. Ждите зелёную зону`:'Ждите зелёную зону');
 });
};
modes.hold=function(o,h){
 const r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>',button('a58Hold',o.verb==='Остановить'?'Натянуть':o.verb));let down=null;
 const b=document.getElementById('a58Hold');b.onpointerdown=e=>{e.preventDefault();if(down!==null||r.elapsed()<o.prepare_ms)return;b.setPointerCapture(e.pointerId);down=r.elapsed();r.state.down_ms=down};
 const release=()=>{if(down===null)return;r.state.up_ms=r.elapsed();r.finish()};b.onpointerup=release;b.onpointercancel=release;
 r.animate(t=>{const value=down===null?0:(t-down)/o.charge_ms,gold=value>=.58&&value<=.78,green=value>=.43&&value<=.92;const y=225-Math.min(1.2,value)*145;
 r.svg.innerHTML=body()+line(70,225,70,y,gold?'#f4cb79':'#a8bece',10)+text(70,55,'СИЛА',13)+`<rect x="105" y="212" width="225" height="24" rx="6" fill="#161523"/><rect x="${105+225*.43/1.2}" y="213" width="${225*.49/1.2}" height="22" fill="#4b945f"/><rect x="${105+225*.58/1.2}" y="213" width="${225*.20/1.2}" height="22" fill="#ddb75b"/>`+line(105+225*Math.min(1.2,value)/1.2,205,105+225*Math.min(1.2,value)/1.2,243,'#fff2d4',3)+text(180,25,down===null?'ЗАЖМИТЕ КНОПКУ':value>1.08?'ПЕРЕДЕРЖАЛИ':gold?'ОТПУСКАЙТЕ — ИДЕАЛ':'СИЛА НАРАСТАЕТ',16);
 b.disabled=t<o.prepare_ms;if(ready(r,t))r.status(down===null?'Зажмите кнопку → дождитесь зелёного → отпустите':gold?'ОТПУСТИТЕ СЕЙЧАС':green?'Можно отпускать':value>1.08?'Передержали: сила сорвалась':'Держите…');
 });
};
modes.aim=modes.sniper=function(o,h){
 const sniper=o.mode==='sniper',r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>');r.state.shots=[];let feedback=null;
 r.svg.onpointerdown=e=>{e.preventDefault();const t=r.elapsed();if(t<o.prepare_ms||r.state.shots.length>=o.shots||t-(r.state.shots.at(-1)?.ms??-9999)<250*o.factor)return;const p=r.pos(e),i=r.state.shots.length,q=target(o,t,i),d=Math.hypot(p.x-q[0],p.y-q[1]),lit=!sniper||((t-o.prepare_ms)%o.pulse_ms)/o.pulse_ms>=.25&&((t-o.prepare_ms)%o.pulse_ms)/o.pulse_ms<=.70;
 r.state.shots.push({ms:t,x:p.x,y:p.y});feedback={t,hit:d<=o.radius,lit};if(r.state.shots.length===o.shots)r.session.timers.push(setTimeout(r.finish,180));
 };
 r.animate(t=>{const i=Math.min(o.shots-1,r.state.shots.length),p=target(o,t,i),phase=sniper?((t-o.prepare_ms)%o.pulse_ms)/o.pulse_ms:0,lit=!sniper||phase>=.25&&phase<=.70;
 let out=text(180,25,sniper?(lit?'ЗЕЛЁНЫЙ — СТРЕЛЯЙТЕ':'ЖДИТЕ ЗЕЛЁНУЮ ПОДСВЕТКУ'):`ВЫСТРЕЛ ${Math.min(o.shots,r.state.shots.length+1)} / ${o.shots}`,15);
 out+=circle(...p,o.radius,lit?'#71bb7d44':'#675b7733',lit?'#acd79c':'#93869f')+circle(...p,o.center,'#c96c6b77','#f0b7a1')+circle(...p,5,lit?'#fff0b5':'#cab2cf','#f6deb7')+line(p[0]-o.radius-7,p[1],p[0]+o.radius+7,p[1],'#cab9a355',1)+line(p[0],p[1]-o.radius-7,p[0],p[1]+o.radius+7,'#cab9a355',1);
 out+=line(36,232,r.cursor.x,r.cursor.y,'#b2a1c144',1)+text(180,246,'ПОПАДАНИЕ СЧИТАЕТСЯ В ВИДИМЫЙ КРУГ',11);
 r.svg.innerHTML=out;if(ready(r,t))r.status(feedback&&t-feedback.t<550?(feedback.hit?(feedback.lit?'Попадание!':'Ранний выстрел — слабее'):'Промах'):sniper?(lit?'Цель зелёная — нажмите по ней':'Наведитесь и дождитесь зелёного'):`Нажмите по кругу · осталось ${o.shots-r.state.shots.length}`);
 });
};
modes.focus=function(o,h){
 const r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>');engage(r);
 r.animate(t=>{const p=interpolate(o.path,t),nearby=near([r.cursor.x,r.cursor.y],p,o.radius),ts=[];for(let ms=o.prepare_ms;ms<o.prepare_ms+o.track_ms;ms+=40)ts.push(ms);const a=path(r),n=ts.filter(ms=>ms<=t&&near(interpolate(a,ms),interpolate(o.path,ms),o.radius)).length,share=n/Math.max(1,ts.length);
 r.svg.innerHTML=body()+circle(...p,o.radius,nearby?'#64a87155':'#614b6755',nearby?'#a5e39e':'#a288ae')+circle(...p,8,'#f0c78c')+line(r.cursor.x-12,r.cursor.y,r.cursor.x+12,r.cursor.y,'#eff1cf',2)+line(r.cursor.x,r.cursor.y-12,r.cursor.x,r.cursor.y+12,'#eff1cf',2)+`<rect x="30" y="230" width="300" height="14" rx="5" fill="#171625"/><rect x="30" y="230" width="${300*share}" height="14" rx="5" fill="${share>=.82?'#dfbc65':'#70aa7b'}"/>`+text(180,27,'ВЕДИТЕ ПРИЦЕЛ ЗА ЦЕЛЬЮ',15);
 if(ready(r,t))r.status(`Накоплено ${Math.round(share*100)}% · 82% — идеал`);if(t>=o.prepare_ms+o.track_ms+60)r.finish();
 });
};
modes.path=modes.circuit=function(o,h){
 const circuit=o.mode==='circuit',r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>');let down=null;
 r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e),t=r.elapsed();if(t<o.prepare_ms||down!==null||!near([p.x,p.y],o.nodes[0],o.radius+8))return;r.svg.setPointerCapture(e.pointerId);down=t;r.state.down_ms=t;exact(r,t,p)};
 r.svg.onpointerup=e=>{if(down===null)return;r.state.up_ms=r.elapsed();exact(r,r.state.up_ms,r.pos(e));r.finish()};r.svg.onpointercancel=r.svg.onpointerup;
 r.animate(t=>{let n=0;for(const p of r.state.points)if(down!==null&&p.t>=down&&n<o.nodes.length&&near([p.x,p.y],o.nodes[n],o.radius))n++;let out='';for(let i=1;i<o.nodes.length;i++)out+=line(...o.nodes[i-1],...o.nodes[i],'#7e729455',circuit?20:38)+line(...o.nodes[i-1],...o.nodes[i],i<n?'#a2d599':'#b1a0c1',3);
 o.nodes.forEach(([x,y],i)=>{if(circuit&&i===o.nodes.length-1)return;out+=circle(x,y,circuit?22:25,i<n?'#5a825b':'#342d46',i===n?'#f1d689':'#c9b9d3')+text(x,y+6,i+1,18)});
 const pts=r.state.points.filter(p=>down!==null&&p.t>=down);for(let i=1;i<pts.length;i++)out+=line(pts[i-1].x,pts[i-1].y,pts[i].x,pts[i].y,'#f0d79b',3);
 out+=text(180,26,circuit?'СОЕДИНИТЕ ПО НОМЕРАМ И ЗАМКНИТЕ':'ПРОВЕДИТЕ ПО СВЕТЛОЙ ДУГЕ',14);r.svg.innerHTML=out;if(ready(r,t))r.status(down===null?'Начните с точки 1: зажмите и ведите':n>=o.nodes.length?'Готово — отпустите':`Пройдено ${n}/${o.nodes.length} · следующая точка ${Math.min(o.nodes.length,n+1)}`);
 });
};
modes.flick=function(o,h){
 const r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>');r.state.cuts=[];let down=null,hits=0;
 r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e),t=r.elapsed();if(t<o.prepare_ms||r.state.cuts.length>=4||!near([p.x,p.y],[180,232],42))return;r.svg.setPointerCapture(e.pointerId);r.setCursor(p);down={t,p}};
 r.svg.onpointerup=e=>{if(!down)return;const p=r.pos(e),t=r.elapsed(),i=r.state.cuts.length;const a={down_ms:down.t,up_ms:t,x0:down.p.x,y0:down.p.y,x1:p.x,y1:p.y};r.state.cuts.push(a);hits+=t-down.t>=100*o.factor&&t-down.t<=1500*o.factor&&near([p.x,p.y],o.targets[i],35);down=null;if(r.state.cuts.length===4)r.finish()};r.svg.onpointercancel=()=>{down=null};
 r.animate(t=>{const i=Math.min(3,r.state.cuts.length);let out=text(180,25,'РУКА → МЕТКА → ОТПУСТИТЬ',16);o.targets.forEach(([x,y],j)=>out+=circle(x,y,30,j<i?'#414453':j===i?'#81724a':'#312c41',j===i?'#f0d58a':'#766a87')+text(x,y+7,j+1,20));out+=circle(180,232,25,'#6a5540','#e3c394')+text(180,240,'🪓',26);if(down)out+=line(180,232,r.cursor.x,r.cursor.y,'#e1c894',3);r.svg.innerHTML=out;if(ready(r,t))r.status(`Броски ${r.state.cuts.length}/4 · попадания ${hits}/4`)});
};
function lanes(o,h){
 const zones=o.mode==='zones',runes=o.mode==='runes',labels=zones?['Голова','Корпус','Ноги']:runes?['ᚱ','ᚨ','ᚦ']:['← Левый','↓ Центр','Правый →'];
 const r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>',labels.map((s,i)=>`<button class="btn lane58" data-lane="${i}">${esc(s)}</button>`).join(''));r.state.actions=[];let feedback=null;
 function choose(lane){const t=r.elapsed(),i=o.waves.findIndex(e=>t>=e.start&&t<=e.end);if(t<o.prepare_ms||i<0||r.state.actions.some(a=>a.wave===i))return;const e=o.waves[i],good=lane===e.lane&&(o.mode!=='lanes'||Math.abs(t-e.ms)<=250*o.factor);r.state.actions.push({ms:t,lane,wave:i});feedback={good,t};if(i===o.waves.length-1)r.session.timers.push(setTimeout(r.finish,200))}
 document.querySelectorAll('.lane58').forEach(b=>b.onclick=()=>choose(+b.dataset.lane));
 if(o.mode==='lanes'){r.svg.closest('.ritual55').classList.add('traps605');r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e);choose(Math.max(0,Math.min(2,Math.round((p.x-80)/100))))};const key=e=>{const lane={Digit1:0,Digit2:1,Digit3:2,Numpad1:0,Numpad2:1,Numpad3:2}[e.code];if(lane!==undefined&&!e.repeat){e.preventDefault();choose(lane)}};document.onkeydown=key;r.session.keydown=key;}
 if(zones)r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e),i=[65,135,210].findIndex(y=>near([p.x,p.y],[180,y],40));if(i>=0)choose(i)};
 r.animate(t=>{const i=o.waves.findIndex(e=>t>=e.start&&t<=e.end),e=o.waves[i],used=i<0||r.state.actions.some(a=>a.wave===i);let out=text(180,25,zones?'НАЖИМАЙТЕ ПОДСВЕЧЕННУЮ ЧАСТЬ':runes?'НАЖМИТЕ ЗЕЛЁНУЮ РУНУ':'СЛЕД → ЗЕЛЁНАЯ ПОЛОСА → КАПКАН',13);
 if(zones){out+=body();[65,135,210].forEach((y,j)=>out+=circle(180,y,30,e?.lane===j?'#70a76499':'#302a4055',e?.lane===j?'#e9d389':'#95819f')+text(180,y+5,labels[j],11))}
 else for(let j=0;j<3;j++){const x=80+j*100;if(runes)out+=circle(x,135,35,e?.lane===j?'#64a76a99':'#393144',e?.lane===j?'#d9edac':'#8f7f9f')+text(x,147,labels[j],36);else{out+=line(x,55,x,218,'#675975',4)+`<rect x="${x-32}" y="175" width="64" height="48" fill="#6d9c5b55"/>`+text(x,230,'🪤',26);if(e&&e.lane===j){const y=190+(t-e.ms)/(900*o.factor)*180;out+=circle(x,y,14,Math.abs(t-e.ms)<=250*o.factor?'#d5de8f':'#9e8d9f')+text(x,y+5,'↑',17)}}}
 r.svg.innerHTML=out;document.querySelectorAll('.lane58').forEach(b=>b.disabled=used);if(ready(r,t))r.status(feedback&&t-feedback.t<450?(feedback.good?'Верно!':'Не попали — следующая попытка'):i<0?'Приготовьтесь к следующей подсказке':o.mode==='lanes'?(Math.abs(t-e.ms)<=250*o.factor?'СЕЙЧАС — НУЖНЫЙ КАПКАН':'Ждите след в зелёной полосе'):'Нажмите зелёную область');if(t>o.waves.at(-1).end+100)r.finish();
 });
}
modes.lanes=modes.runes=modes.zones=lanes;
modes.rhythm=function(o,h){
 const r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>',button('a58Beat',o.verb));r.state.clicks=[];
 document.getElementById('a58Beat').onclick=()=>{if(r.elapsed()<o.prepare_ms||r.state.clicks.length>=3)return;r.state.clicks.push({ms:r.elapsed()});if(r.state.clicks.length===3)r.finish()};
 r.animate(t=>{let out=text(180,25,'НАЖИМАЙТЕ НА ЗОЛОТОЙ ЛИНИИ',14)+line(40,205,320,205,'#e6bf68',4)+`<rect x="130" y="185" width="100" height="40" fill="#7caf6444"/>`;for(const b of o.beats){const y=205+(t-b)/(1500*o.factor)*200;if(y>=40&&y<=235)out+=circle(180,y,13,Math.abs(t-b)<=110*o.factor?'#f1d680':'#bca3d6')+text(180,y+5,'♪',21)}r.svg.innerHTML=out;document.getElementById('a58Beat').disabled=t<o.prepare_ms;if(ready(r,t))r.status(`Нажатий ${r.state.clicks.length}/3`);if(t>o.beats.at(-1)+400*o.factor)r.finish()});
};
modes.steer=modes.catch=function(o,h){
 const steer=o.mode==='steer',es=steer?o.gates:o.drops,r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>');engage(r);const good=new Set(),bad=new Set();
 r.animate(t=>{const p=path(r);es.forEach((e,i)=>{if(t>=e.ms&&!good.has(i)&&!bad.has(i))(Math.abs(interpolate(p,e.ms)[0]-e.x)<=(steer?45:35)?good:bad).add(i)});let out=text(180,25,steer?'ПРОЙДИТЕ В ЗЕЛЁНЫЙ ПРОСВЕТ':'ПОДСТАВЬТЕ КОРЗИНУ ПОД КОКОН',14);
 for(const e of es){const dt=(t-e.ms)/(1100*o.factor),y=200+dt*180;if(y<45||y>230)continue;if(steer)out+=`<rect x="20" y="${y-12}" width="${Math.max(0,e.x-65)}" height="24" rx="8" fill="#6c6467"/><rect x="${e.x+45}" y="${y-12}" width="${Math.max(0,295-e.x)}" height="24" rx="8" fill="#6c6467"/><rect x="${e.x-44}" y="${y-15}" width="88" height="30" fill="#76b26955"/>`;else out+=circle(e.x,y,14,'#9a80a6','#e4c7ee')+line(e.x,y-25,e.x,y-14,'#c6bdd777',1)}
 const x=r.cursor.x;out+=steer?circle(x,220,21,'#967c58','#e6c17b')+text(x,229,'↑',28):`<path d="M${x-32} 213 Q${x} 251 ${x+32} 213Z" fill="#7f648f" stroke="#d6bfdf" stroke-width="3"/>`;
 r.svg.innerHTML=out;if(ready(r,t))r.status(`Успехов ${good.size}/${es.length} · ${countTier(good.size,es.length)}`);if(t>=es.at(-1).ms+120)r.finish();
 });
};
modes.echo=function(o,h){
 const arrows=['←','↑','→'],r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>',arrows.map((s,i)=>`<button class="btn echo58" data-lane="${i}">${s}</button>`).join(''));r.state.actions=[];
 document.querySelectorAll('.echo58').forEach(b=>b.onclick=()=>{if(r.elapsed()<o.show_until||r.state.actions.length===o.sequence.length)return;r.state.actions.push({ms:r.elapsed(),lane:+b.dataset.lane});if(r.state.actions.length===o.sequence.length)r.finish()});
 r.animate(t=>{const showing=t<o.show_until,i=Math.floor((t-o.prepare_ms)/((o.show_until-o.prepare_ms)/o.sequence.length)),lane=o.sequence[Math.max(0,Math.min(o.sequence.length-1,i))];let out=text(180,35,showing?'ЗАПОМНИТЕ ЧЕТЫРЕ СТРЕЛКИ':'ПОВТОРИТЕ СТРЕЛКИ КНОПКАМИ',14);for(let j=0;j<3;j++)out+=circle(80+j*100,125,33,showing&&i>=0&&lane===j?'#b2934f':'#393044','#ba9dc5')+text(80+j*100,138,arrows[j],38);out+=text(180,220,showing&&i>=0?`Стрелка ${Math.min(o.sequence.length,i+1)}/${o.sequence.length}`:`Ответы ${r.state.actions.length}/${o.sequence.length}`,18);r.svg.innerHTML=out;document.querySelectorAll('.echo58').forEach(b=>b.disabled=showing);if(ready(r,t))r.status(showing?'Смотрите, пока не нажимайте':'Теперь повторите в том же порядке')});
};
modes.machete=function(o,h){
 const r=setup(o,h,o.instruction+'<br><b>'+esc(o.reward)+'</b>',`<button class="btn catch58" data-hand="0">ЛОВИТЬ ЛЕВОЙ</button><button class="btn catch58" data-hand="1">ЛОВИТЬ ПРАВОЙ</button>`);r.state.actions=[];
 document.querySelectorAll('.catch58').forEach(b=>b.onclick=()=>{const hand=+b.dataset.hand,t=r.elapsed();if(t<o.prepare_ms||r.state.actions.some(a=>a.hand===hand))return;r.state.actions.push({hand,ms:t});if(r.state.actions.length===2)r.session.timers.push(setTimeout(r.finish,150))});
 r.animate(t=>{let out=text(180,25,'ДВА ВОЗВРАТА — ДВА ПЕРЕХВАТА',14);for(const e of o.returns){const x=e.hand?260:100,dt=t-e.ms,y=200+dt/(1000*o.factor)*160,green=Math.abs(dt)<=210*o.factor,gold=Math.abs(dt)<=100*o.factor;out+=line(x,55,x,225,'#695b78',5)+`<rect x="${x-35}" y="166" width="70" height="68" rx="8" fill="#6fa76844"/><rect x="${x-35}" y="184" width="70" height="32" fill="#d7b15a44"/>`+line(x-37,200,x+37,200,'#f0d28b',3)+text(x,253,e.hand?'ПРАВАЯ':'ЛЕВАЯ',13);if(y>40&&y<240)out+=text(x,y,gold?'🪃':'╱',gold?35:42,green?'#e9d589':'#b9becb');}
 r.svg.innerHTML=out;const next=o.returns.find(e=>t<=e.ms+210*o.factor&&!r.state.actions.some(a=>a.hand===e.hand));if(ready(r,t))r.status(next?(Math.abs(t-next.ms)<=210*o.factor?`СЕЙЧАС — ${Math.abs(t-next.ms)<=100*o.factor?"ИДЕАЛ · ":"ХОРОШО · "}${next.hand?'ПРАВАЯ':'ЛЕВАЯ'} РУКА`:`Скоро ${next.hand?'правый':'левый'} мачете — ждите зелёную зону`):'Возвраты закончились');document.querySelectorAll('.catch58').forEach(b=>b.disabled=t<o.prepare_ms||r.state.actions.some(a=>a.hand===+b.dataset.hand));if(t>o.returns.at(-1).ms+350*o.factor)r.finish();
 });
};
})();

/* Context help: pointer, keyboard and a tap on mobile. Text comes from server state. */
(function(){
'use strict';
const style=document.createElement('style');style.textContent=`
.help-strip58{display:flex;justify-content:center;gap:5px;flex-wrap:wrap;margin:8px 0 2px}.help-strip58 button{font:12px inherit;color:#d9cba8;background:#171322;border:1px solid #665474;border-radius:6px;padding:4px 7px;cursor:help}
[data-help58]{cursor:help}[data-help58]:focus-visible{outline:2px solid #e1be6b;outline-offset:2px}.help-pop58{position:fixed;z-index:100;max-width:min(350px,calc(100vw - 24px));padding:12px 14px;border:1px solid #b69a66;border-radius:10px;background:#241c30f7;color:#f1e8dc;font:14px/1.45 system-ui;box-shadow:0 8px 30px #0009;white-space:normal;pointer-events:none}.skill-help58-wrap{display:block}.skill-help58-wrap>.skill{pointer-events:none}
`;document.head.appendChild(style);
const tip=document.createElement('div');tip.id='help58';tip.className='help-pop58';tip.setAttribute('role','tooltip');tip.hidden=true;document.body.appendChild(tip);let active=null,pinned=false;
function hide(){tip.hidden=true;if(active)active.removeAttribute('aria-describedby');active=null;pinned=false}
function show(el,pin=false){if(!el?.dataset.help58)return;if(active&&active!==el)active.removeAttribute('aria-describedby');active=el;pinned=pin;tip.textContent=el.dataset.help58;tip.hidden=false;el.setAttribute('aria-describedby','help58');const r=el.getBoundingClientRect(),width=tip.offsetWidth,height=tip.offsetHeight;tip.style.left=Math.max(12,Math.min(innerWidth-width-12,r.left+r.width/2-width/2))+'px';tip.style.top=Math.max(12,r.bottom+8+height<innerHeight?r.bottom+8:r.top-height-8)+'px'}
function bind(el,message){if(!el||!message)return;el.dataset.help58=message;el.setAttribute('tabindex','0');el.removeAttribute('title')}
function decorate(b){
 if(!b?.heroes)return;
 b.heroes.forEach((h,i)=>{const card=document.getElementById('f'+i);if(!card)return;const help=h.mechanics_help||{};
  bind(card.querySelector('.hpbar'),help.HP);bind(card.querySelector('.enbar'),help['Ресурс']);
  card.querySelectorAll('.effects span').forEach((el,j)=>bind(el,h.effects?.[j]?.help));
  card.querySelectorAll('.states55 span,.status-chip,.badge,.katana').forEach(el=>{const value=el.textContent.toLowerCase();let key=Object.keys(help).find(k=>!['Пассивка','Ресурс','HP'].includes(k)&&value.includes(k.toLowerCase()));if(!key&&value.includes('комбо'))key=h.type==='gambler'?'Комбо карт':'Комбо';if(!key&&value.includes('катан'))key='Катана';if(key)bind(el,help[key]);else if(el.classList.contains('katana')&&h.katana)bind(el,h.katana.description||help['Катана'])});
  const pet=card.querySelector('.summon');if(pet&&h.summon)bind(pet,(h.summon.about||'Призыв атакует после хозяина и может перехватывать удары.')+` HP ${h.summon.hp}/${h.summon.max_hp}.`);
  for(const petState of h.summons||[]){const host=card.querySelector(`[data-minion="${petState.id}"]`);if(host){const label=host.querySelector('b');bind(label,petState.about+` HP ${petState.hp}/${petState.max_hp}; ${petState.lifetime} раундов жизни.`)}}
  let strip=card.querySelector('.help-strip58');if(!strip){strip=document.createElement('div');strip.className='help-strip58';card.appendChild(strip)}
  const keys=['Пассивка','Ресурс',...Object.keys(help).filter(k=>!['Пассивка','Ресурс','HP'].includes(k))];
  for(const key of keys){let el=Array.from(strip.children).find(e=>e.dataset.helpKey===key);if(!el){el=document.createElement('button');el.type='button';el.dataset.helpKey=key;el.textContent='ⓘ '+key;el.setAttribute('aria-label','Подсказка: '+key);strip.appendChild(el)}bind(el,help[key])}
 });
 const actor=b.heroes.find(h=>h.id===b.current_hero_id);if(actor)document.querySelectorAll('#skillBox button.skill:disabled').forEach(button=>{const key=button.getAttribute('onclick')?.match(/turn\('([^']+)'\)/)?.[1],s=actor.skills.find(s=>s.key===key);if(!s?.unavailable_reason)return;let wrapper=button.parentElement;if(!wrapper.classList.contains('skill-help58-wrap')){wrapper=document.createElement('span');wrapper.className='skill-help58-wrap';button.replaceWith(wrapper);wrapper.appendChild(button)}bind(wrapper,s.unavailable_reason)});
}
let queued=false;function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;decorate(typeof battle==='undefined'?null:battle)})}
const old=renderFighters;renderFighters=function(b,...args){const out=old(b,...args);decorate(b);return out};
// Observe child replacement only; tooltip attributes do not trigger another pass.
const panel=document.getElementById('arenaPanel');if(panel)new MutationObserver(schedule).observe(panel,{childList:true,subtree:true});
document.addEventListener('pointerover',e=>{const el=e.target.closest?.('[data-help58]');if(el&&!pinned)show(el)});
document.addEventListener('pointerout',e=>{if(!pinned&&active&&!active.contains(e.relatedTarget))hide()});
document.addEventListener('focusin',e=>{const el=e.target.closest?.('[data-help58]');if(el)show(el)});
document.addEventListener('focusout',()=>{if(!pinned)hide()});
document.addEventListener('click',e=>{const el=e.target.closest?.('[data-help58]');if(el){e.preventDefault();e.stopPropagation();if(active===el&&pinned)hide();else show(el,true)}else hide()},true);
document.addEventListener('keydown',e=>{if(e.key==='Escape')hide();else if((e.key==='Enter'||e.key===' ')&&e.target.matches?.('[data-help58]')){e.preventDefault();if(active===e.target&&pinned)hide();else show(e.target,true)}});
window.addEventListener('scroll',()=>{if(active)hide()},true);window.addEventListener('resize',hide);
})();
