// ===================== Хиро арена 4.0: интерфейс новых функций =====================
// Подключается после основного скрипта и переопределяет часть функций (тот же глобальный scope).

let ITEMS = {};              // ключ расходника → данные из /api/shop (иконка, имя, вес…)
let storyData = null, storyStage = null, opponents = [];
const ROLE_ICON = {light: "🪶", warrior: "🛡", monster: "👹", trickster: "🃏"};

function itemInfo(k) { const c = ITEMS[k]; return c ? [c.icon, c.name] : ["📦", k]; }
function skinName(h, k) {
  const s = shop && (shop.skins[h.type] || []).find(x => x.skin === k);
  return s ? s.name : (SKIN_NAMES[k] || k);
}
async function ensureShop() {
  if (!shop) shop = await api("/api/shop");
  if (shop) shop.consumables.forEach(c => ITEMS[c.key] = c);
}

// ---------- Чит разработчика: 3 клика по «Хиро арена» ----------
let logoClicks = 0, logoTimer = null;
document.getElementById("logo").addEventListener("click", async () => {
  logoClicks++;
  clearTimeout(logoTimer);
  logoTimer = setTimeout(() => logoClicks = 0, 700);
  if (logoClicks < 3) return;
  logoClicks = 0;
  const p = currentPlayer(); if (!p) return toast("Сначала выберите игрока");
  const r = await api(`/api/players/${p.id}/dev_gold`, "POST");
  if (r) { toast(r.message, "event"); await loadPlayers(); renderShop(); }
});

// ---------- Вкладки ----------
document.querySelectorAll("nav button").forEach(b => b.onclick = () => {
  document.querySelectorAll("nav button, .tab").forEach(x => x.classList.remove("active"));
  b.classList.add("active"); document.getElementById(b.dataset.tab).classList.add("active");
  if (b.dataset.tab === "top") loadTop(); else if (b.dataset.tab === "story") loadStory(); else loadHeroes();
});

// ---------- Сумка и роли ----------
function roleBadge(h) { return h.role ? `<span class="badge role-${h.role}" title="Тип героя">${ROLE_ICON[h.role] || ""} ${esc(h.role_name)}</span>` : ""; }
bag = function (h) {
  const items = Object.entries(h.consumables || {}).map(([k, n]) => `<span>${itemInfo(k)[0]} ${esc(itemInfo(k)[1])} ×${n}</span>`);
  const inv = h.inventory || {};
  if (!items.length) return h.custom ? `<div class="bag muted">🎒 Сумка пуста · 0/${inv.max_weight || 5} кг</div>` : "";
  return `<div class="bag">🎒 ${items.join("")} <span class="muted">${(inv.total_weight || 0).toFixed(1)}/${inv.max_weight || 5} кг</span></div>`;
};

// ---------- Окно инвентаря: 10 слотов и вес ----------
let invChosen = null;
async function openInventory(heroId, pickMode = false) {
  await ensureShop();
  const h = await api(`/api/heroes/${heroId}`); if (!h) return;
  const inv = h.inventory, items = inv.items;
  const groups = {};
  items.forEach(i => { const k = i.key || ("w" + i.id); (groups[k] = groups[k] || {...i, count: 0}).count++; });
  const slots = [];
  items.forEach(i => slots.push(i));
  while (slots.length < inv.max_slots) slots.push(null);
  invChosen = document.getElementById("battleItem").value || null;
  const w = inv.total_weight;
  document.getElementById("modal2Box").innerHTML = `<h3 style="color:var(--gold);margin-top:0">🎒 Инвентарь — ${esc(h.name)}</h3>
    <div class="bar wbar" style="height:16px"><div style="width:${Math.min(100, 100 * w / inv.max_weight)}%"></div><span style="line-height:16px">⚖ ${w.toFixed(1)} / ${inv.max_weight} кг</span></div>
    <div class="muted">Слоты: ${items.length}/${inv.max_slots} · сумка своя у каждого героя · в бой можно взять ОДИН предмет</div>
    <div class="inv-grid">${slots.map(i => i ? `<div class="inv-slot full ${pickMode && i.key === invChosen ? "chosen" : ""}" title="${esc(i.name)} — ${esc(i.description || "")} (${i.weight} кг)"
        ${pickMode && i.key ? `style="cursor:pointer" onclick="chooseItem('${i.key}')"` : ""}>${i.icon || "📦"}<small>${i.weight} кг</small></div>`
      : `<div class="inv-slot"></div>`).join("")}</div>
    ${pickMode ? `<div class="muted">Нажмите на предмет, чтобы взять его в следующий бой.</div>
      <button class="btn small ghost" style="margin-top:8px" onclick="chooseItem('')">Без предмета</button>` : ""}
    <div style="margin-top:12px"><button class="btn" onclick="document.getElementById('modal2').style.display='none'">Закрыть</button></div>`;
  document.getElementById("modal2").style.display = "flex";
}
function chooseItem(k) {
  document.getElementById("battleItem").value = k;
  document.getElementById("modal2").style.display = "none";
  toast(k ? `В бой берём: ${itemInfo(k)[0]} ${itemInfo(k)[1]}` : "Без предмета", "ok");
}

// ---------- Герои: свои (активный) и соперники ----------
loadHeroes = async function () {
  await ensureShop();
  const type = document.getElementById("filter").value;
  const all = await api("/api/heroes"); if (!all) return;
  allHeroes = all;
  const p = currentPlayer();
  const mine = all.filter(h => p && h.owner_id === p.id && !h.story);
  const others = all.filter(h => !(p && h.owner_id === p.id) && !h.story && (!type || h.type === type));
  const card = (h, own) => `
    <div class="hero ${own ? "mine" : ""} ${own && p && p.active_hero_id === h.id ? "active-hero" : ""}" data-id="${h.id}" data-type="${h.type}" ${own ? `onclick="selectHero(event, ${h.id})"` : `onclick="openHeroInfo('${h.type}', ${h.id})"` } style="cursor:pointer">
      <button type="button" class="hero-info-btn" title="О герое" onclick="event.stopPropagation(); openHeroInfo('${h.type}', ${h.id})">i</button>
      <img src="${h.image}" alt="${h.hero_class}">
      <div class="body">
        <div class="name">${esc(h.name)}</div>
        <div>${own && p.active_hero_id === h.id ? `<span class="badge active">⭐ Активный</span>` : ""}${own ? `<span class="badge own">👑 Ваш герой</span>` : `<span class="badge">🤖 Соперник арены</span>`}${roleBadge(h)}${h.protected ? `<span class="badge prot">🦉 бонусный · не удаляется</span>` : ""}${h.skin ? `<span class="badge">🎨 ${esc(skinName(h, h.skin))}</span>` : ""}</div>
        <div class="muted">${h.hero_class} · 🏆 ${h.wins} / 💀 ${h.losses}</div>
        ${katana(h)}${bars(h)}
        <div class="muted">⚔ ${h.damage} · 🛡 ${h.armor} · ⚡ ${h.speed} · уклон ${Math.round(h.dodge*100)}% · крит ${Math.round(h.crit_chance*100)}%</div>
        ${effects(h)}${bag(h)}
        ${own && h.skins.length ? `<div class="row" style="margin:4px 0" onclick="event.stopPropagation()"><span class="muted">Облик:</span>
          <select onchange="equip(${h.id}, this.value)"><option value="">Обычный</option>${h.skins.map(k => `<option value="${k}" ${h.skin === k ? "selected" : ""}>${esc(skinName(h, k))}</option>`).join("")}</select></div>` : ""}
        <div class="row" onclick="event.stopPropagation()">
        
        ${own ? `<button class="btn small ghost" onclick="openInventory(${h.id})">🎒 Инвентарь</button>` : ""}
        ${h.protected || h.npc ? "" : `<button class="btn small red" onclick="delHero(${h.id})">Удалить</button>`}</div>
      </div>
    </div>`;
  document.getElementById("myHeroList").innerHTML = mine.map(h => card(h, true)).join("") || "<p class='muted'>У вас пока нет героев — создайте первого выше (до 5, Совух — бонусный шестой).</p>";
  document.getElementById("heroList").innerHTML = others.map(h => card(h, false)).join("");
  if (p && p.slots) document.getElementById("slotsInfo").textContent = `Ваши герои: ${p.slots.used}/${p.slots.max} (Совух не занимает слот) · сюжетные: ${p.slots.story_used}/${p.slots.story_max}`;
  renderShop();
  const s1 = document.getElementById("h1"), v1 = s1.value;
  s1.innerHTML = mine.map(h => `<option value="${h.id}">${esc(h.name)} (${h.hero_class})</option>`).join("");
  if (v1 && mine.some(h => h.id == v1)) s1.value = v1;
  else if (p && p.active_hero_id && mine.some(h => h.id === p.active_hero_id)) s1.value = p.active_hero_id;
  await loadOpponents();
};
async function selectHero(ev, id) {
  if (ev.target.closest("button, select")) return;
  const p = currentPlayer(); if (!p) return;
  const r = await api(`/api/players/${p.id}/select_hero`, "POST", {hero_id: id});
  if (!r) return;
  toast(r.message, "ok");
  localStorage.setItem("myHeroId", id);
  document.getElementById("h1").value = "";
  await loadPlayers(); await loadHeroes();
}
async function loadOpponents() {
  const id = +document.getElementById("h1").value, s2 = document.getElementById("h2"), v2 = s2.value;
  const itemSel = document.getElementById("battleItem"), iv = itemSel.value;
  if (!id) { s2.innerHTML = ""; itemSel.innerHTML = `<option value="">—</option>`; return; }
  opponents = await api(`/api/heroes/${id}/opponents`) || [];
  const me = allHeroes.find(h => h.id === id);
  s2.innerHTML = opponents.map(h => `<option value="${h.id}">${h.npc ? "🤖" : "🧑"} ${esc(h.name)} (${h.hero_class})</option>`).join("");
  if (v2 && opponents.some(h => h.id == v2)) s2.value = v2;
  const cnt = (me && me.consumables) || {};
  itemSel.innerHTML = `<option value="">— без предмета —</option>` + Object.entries(cnt).map(([k, n]) => `<option value="${k}">${itemInfo(k)[0]} ${esc(itemInfo(k)[1])} ×${n}</option>`).join("");
  if (iv && cnt[iv]) itemSel.value = iv;
  if (me) {
    document.getElementById("groupInfo").textContent = "На арене все герои сражаются с базовыми характеристиками.";
  }
}

// ---------- Создание героя: лимит и занятые имена приходят с сервера ----------

// ---------- Магазин: расходники с весом, облики по редкости ----------
renderShop = async function () {
  await ensureShop(); if (!shop) return;
  const sel = document.getElementById("shopHero"), p = currentPlayer();
  const mine = allHeroes.filter(h => p && h.owner_id === p.id && h.custom && !h.story);
  const old = sel.value || (p && p.active_hero_id);
  sel.innerHTML = mine.map(h => `<option value="${h.id}">${esc(h.name)} (${h.hero_class})</option>`).join("");
  if (old && mine.some(h => h.id == old)) sel.value = old;
  document.getElementById("shopGold").textContent = p ? `💰 ${p.gold} зол.` : "";
  const h = mine.find(x => x.id == sel.value), body = document.getElementById("shopBody");
  if (!h) { body.innerHTML = `<p class="muted">Покупать могут только ВАШИ герои. Создайте своего героя выше.</p>`; return; }
  const cnt = h.consumables || {}, inv = h.inventory;
  const skins = shop.skins[h.type] || [];
  const order = ["common", "rare", "epic", "legendary"];
  body.innerHTML = `<h3 style="margin:6px 0">🎒 Расходники <span class="muted">(сумка ${esc(h.name)}: ${inv.items.length}/${inv.max_slots} слотов, ${inv.total_weight.toFixed(1)}/${inv.max_weight} кг · в бой — один предмет)</span></h3>
    <div class="shop-grid">${shop.consumables.map(c => {
      const heavy = inv.total_weight + c.weight > inv.max_weight + 1e-9 || inv.items.length >= inv.max_slots;
      return `<div class="shop-card"><div class="ic">${c.icon}</div><b>${esc(c.name)}</b>
      <div class="muted">${esc(c.description)}</div><div>💰 ${c.price} · ⚖ ${c.weight} кг · в сумке ${cnt[c.key] || 0}/${c.stack_max}</div>
      <button class="btn small" ${(cnt[c.key] || 0) >= c.stack_max || p.gold < c.price || heavy ? "disabled" : ""} onclick="buy(${h.id}, '${c.key}')">${heavy ? "Слишком тяжело" : "Купить"}</button></div>`; }).join("")}</div>
    <h3 style="margin:6px 0">🎨 Облики класса «${h.hero_class}»</h3>
    ${order.map(r => { const list = skins.filter(s => s.rarity === r); if (!list.length) return "";
      return `<div class="muted" style="margin-top:8px">${list[0].rarity_name} · ${list[0].price} зол.</div><div class="shop-grid">${list.map(s => {
        const own = h.skins.includes(s.skin), on = h.skin === s.skin;
        return `<div class="shop-card rar-${s.rarity} ${on ? "equipped" : ""}">${s.available ? `<img src="${s.image}" alt="${esc(s.name)}">` : `<div class="soon">🖌 Скоро<br>${esc(s.description)}${s.difficulty_label ? `<div class="muted">${esc(s.difficulty_label)}</div>` : ""}</div>`}
          <b>${esc(s.name)}</b><div class="muted">${s.rarity_name}</div>
          <div>${own ? (on ? "✅ надет" : "куплен") : s.available ? `💰 ${s.price}` : "⏳ скоро в продаже"}</div>
          ${own ? `<button class="btn small ghost" onclick="equip(${h.id}, ${on ? "null" : `'${s.skin}'`})">${on ? "Снять" : "Надеть"}</button>`
                : s.available ? `<button class="btn small" ${p.gold < s.price ? "disabled" : ""} onclick="buy(${h.id}, 'skin:${s.skin}')">Купить</button>` : ""}</div>`; }).join("")}</div>`; }).join("")}`;
};

// ---------- Бой ----------
startBattle = async function () {
  if (busy) return;
  const item = document.getElementById("battleItem").value || null;
  const b = await api("/api/battles", "POST", {
    hero1_id: +document.getElementById("h1").value, hero2_id: +document.getElementById("h2").value,
    mode: battleMode, vs_ai: document.getElementById("vsAi").checked, item});
  if (!b) return;
  if (b.closed_battles && b.closed_battles.length) toast(`Старые незаконченные бои закрыты: №${b.closed_battles.join(", №")}`, "ok");
  document.getElementById("resume").style.display = "none";
  battle = null; resetArena();
  await update(b, true);
};
const _renderFighters = renderFighters;
renderFighters = function (b, snap = null, hideFx = false) {
  _renderFighters(b, snap, hideFx);
  b.heroes.forEach((h, i) => {
    const el = document.getElementById("f" + i), extra = document.createElement("div");
    extra.className = "muted";
    extra.innerHTML = `${roleBadge(h)}${b.items && b.items[h.id] ? `<span class="badge">🎒 ${itemInfo(b.items[h.id])[0]} ${h.item_used ? "использован" : esc(itemInfo(b.items[h.id])[1])}</span>` : ""}${h.loaded !== undefined ? `<span class="badge">${h.loaded ? "🔫 заряжено" : "🔫 разряжено"}</span>` : ""}${h.legacy !== undefined ? `<span class="badge">🐂 наследие ${h.legacy}</span>` : ""}${h.satiety !== undefined ? `<span class="badge">🍖 сытость ${h.satiety}</span>` : ""}${h.hate !== undefined ? `<span class="badge">🩸 ненависть ${h.hate}</span>` : ""}`;
    el.insertBefore(extra, el.children[3] || null);
  });
  if (b.fatigue) document.getElementById("roundInfo").textContent += ` · 😓 усталость +${Math.round(b.fatigue * 100)}%`;
  if (b.story) document.getElementById("roundInfo").textContent += ` · 📖 ${b.story.title}`;
};
renderSkills = function (b) {
  const box = document.getElementById("skillBox"), ctl = document.getElementById("battleCtl");
  ctl.innerHTML = b.status === "active"
    ? `<button class="btn small ghost" onclick="surrender()">🏳 Сдаться</button><button class="btn small red" onclick="cancelBattle()">⛔ Отменить</button>` : "";
  if (b.status !== "active" || b.pending || !b.current_hero_id || b.ai_ids.includes(b.current_hero_id)) { box.innerHTML = ""; return; }
  const hero = b.heroes.find(h => h.id === b.current_hero_id);
  box.innerHTML = `<div class="muted" style="text-align:center">Ход: <b style="color:var(--gold)">${esc(hero.name)}</b></div>` +
    hero.skills.filter(s => s.visible).map(s => `<button class="skill" ${s.available ? "" : "disabled"} onclick="turn('${s.key}')">
      <b>${s.icon} ${esc(s.name)}</b> ${s.cost ? `<span class="muted">(${s.cost} ${hero.resource_name})</span>` : ""}${(s.is_minigame || s.reaction === "minigame" || s.reaction === "sequence") ? ` <span class="badge">🎮 мини-игра</span>` : ""}
      <small>${esc(s.description)}${s.difficulty_label ? `<div class="muted">${esc(s.difficulty_label)}</div>` : ""}${s.cooldown_left ? ` · ⏳ ещё ${s.cooldown_left} х.` : ""}${s.blocked_left ? ` · ⚡ заблокировано ${s.blocked_left} х.` : ""}${s.once_per_battle ? " · раз за бой" : ""}</small></button>`).join("") +
    (b.available_items || []).map(it => `<button class="skill item-btn" onclick="turn('${it.key}')">
      <b>${it.icon} ${esc(it.name)}</b><small>предмет этого боя (один на бой) · тратит ход</small></button>`).join("") +
    `<button class="skill" onclick="turn('auto')"><b>🤖 Пусть решит ИИ</b></button>`;
};
const _showResult = showResult;
showResult = function (b) {
  _showResult(b);
  if (b.story) {
    const s = b.story;
    document.getElementById("skillBox").innerHTML = `<button class="btn" onclick="document.querySelector('nav button[data-tab=story]').click()">🗺 К карте</button>`;
    if (b.winner_id === b.hero1_id) toast(`📖 Этап «${s.title}» пройден! +${b.xp ? b.xp[0] : 0} опыта, +${s.gold || 0} золота`, "event");
  }
  (b.notices || []).forEach(n => {
    if (n.type === "class_unlocked") showUnlock(n);
    else toast(n.text, "event");
  });
};
function showUnlock(n) {
  document.getElementById("modal2Box").innerHTML = `<h3 style="color:var(--gold);margin-top:0;font-size:24px">🔓 Вы открыли новый класс: ${esc(n.hero_class)}</h3>
    <img src="${n.image}" style="width:220px;border-radius:12px;box-shadow:0 0 30px #f5b94288">
    <p>Теперь можно создать своего героя этого класса.</p>
    <input id="unlockName" placeholder="Имя героя" maxlength="30" style="font-size:16px">
    <div style="margin-top:10px"><button class="btn" onclick="createUnlocked('${n.class}')">✨ Создать</button>
    <button class="btn ghost" onclick="document.getElementById('modal2').style.display='none'">Позже</button></div>`;
  document.getElementById("modal2").style.display = "flex";
}
async function createUnlocked(type) {
  const p = currentPlayer();
  const h = await api("/api/heroes", "POST", {name: document.getElementById("unlockName").value, type, player_id: p ? p.id : null});
  if (h) { document.getElementById("modal2").style.display = "none"; toast(`👑 ${h.name} создан!`, "ok"); refreshAll(); }
}

// ---------- Реакции и мини-игры ----------
let mg = null;
function mgStart(o, onEnd) {   // общий таймер мини-игры
  if(mg){if(document.onkeydown===mg.keydown)document.onkeydown=null;if(document.onkeyup===mg.keyup)document.onkeyup=null;mg.done=true;mg.timers.forEach(t=>{clearTimeout(t);clearInterval(t)});if(mg.raf)cancelAnimationFrame(mg.raf)}
  mg = {done: false, timers: [], onEnd, o, keydown:document.onkeydown,keyup:document.onkeyup,t0: performance.now()-Math.max(0,Number(o._elapsed_offset605)||0)};
  const session=mg;
  const bar = document.getElementById("mgTimer");
  if (bar && o.time_limit_ms) { const left=Math.max(0,o.time_limit_ms-(Number(o._elapsed_offset605)||0));bar.style.transition='none';bar.style.width=(100*left/o.time_limit_ms)+'%';void bar.offsetWidth;bar.style.transition='width '+left+'ms linear';bar.style.width='0%'; }
  if (o.time_limit_ms) mg.timers.push(setTimeout(() => {if(mg===session&&!session.done)mgFinish(onEnd())}, Math.max(0,o.time_limit_ms-(Number(o._elapsed_offset605)||0))));
}
function mgLater(callback, delay) {
  const session=mg;
  const timer=setTimeout(()=>{if(mg===session&&!session.done)callback()},delay);
  session.timers.push(timer);
  return timer;
}
function mgFinish(choice) {
  if (!mg || mg.done) return;
  if(document.onkeydown===mg.keydown)document.onkeydown=null;if(document.onkeyup===mg.keyup)document.onkeyup=null;
  mg.done = true; mg.timers.forEach(t => { clearTimeout(t); clearInterval(t); });
  if (mg.raf) cancelAnimationFrame(mg.raf);
  const session=mg,answer=choice===undefined?null:JSON.parse(JSON.stringify(choice));setTimeout(() => {if(mg===session)(window.__mgHook || react)(answer)}, 300);   // __mgHook — для автотеста интерфейса

}
const timerBar = `<div class="timer"><div id="mgTimer" style="width:100%"></div></div>`;
function openBox(html) { document.getElementById("modalBox").innerHTML = html; document.getElementById("modal").style.display = "flex"; }
const rnd = (a, b) => a + Math.random() * (b - a);

const _showPending = showPending;
showPending = function (b) {
  const p = b.pending;
  if (!p || b.ai_ids.includes(p.hero_id)) { hideModal(); return; }
  if (p.type === "dodge" && Array.isArray(p.options) && p.options.includes("down")) {
    const att = b.heroes.find(h => h.id === p.attacker_id);
    return openBox(`<h3>${esc(att.name)} применяет «${esc(p.skill)}»!</h3><p class="muted">Угадайте, куда уйти от удара:</p>
      <button class="btn dodge-btn" onclick="react('left')">⬅️ Влево</button>
      <button class="btn dodge-btn" onclick="react('down')">⬇️ Пригнуться</button>
      <button class="btn dodge-btn" onclick="react('right')">Вправо ➡️</button>`);
  }
  if (p.type !== "minigame") return _showPending(b);
  const o = p.options, me = b.heroes.find(h => h.id === p.hero_id), foe = b.heroes.find(h => h.id !== p.hero_id);
  const head = `<h3>🎮 ${esc(p.skill)}</h3><p>${esc(p.prompt)}</p>`;
  const G = MINIGAMES[o.game];
  if (!G) return openBox(head + `<button class="btn" onclick="react({})">OK</button>`);
  G(o, head, me, foe);
};

const MINIGAMES = {
  // Воин: стащить крестики с брони
  drag_crosses(o, head, me) {
    openBox(head + timerBar + `<div class="mg-area" id="mgA"><img class="bgimg" src="${me.image}">${o.crosses.map((c, i) =>
      `<div class="mg-tok cross" id="c${i}" style="left:${c[0]}%;top:${c[1]}%">✖</div>`).join("")}</div><div class="muted">Убрано: <b id="mgCnt">0</b>/${o.crosses.length}</div>`);
    let removed = 0, drag = null;
    const area = document.getElementById("mgA");
    area.querySelectorAll(".cross").forEach(el => el.onpointerdown = e => { drag = el; el.setPointerCapture(e.pointerId); });
    area.onpointermove = e => { if (!drag) return; const r = area.getBoundingClientRect();
      drag.style.left = (e.clientX - r.left) + "px"; drag.style.top = (e.clientY - r.top) + "px"; };
    area.onpointerup = e => { if (!drag) return; const r = area.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      if (x < 25 || y < 25 || x > r.width - 25 || y > r.height - 25) { drag.remove(); removed++; document.getElementById("mgCnt").textContent = removed;
        if (removed >= o.crosses.length) mgFinish({removed}); }
      drag = null; };
    mgStart(o, () => ({removed}));
  },
  // Лучник/ассасин: клик по целям
  click_targets(o, head) {
    openBox(head + timerBar + `<div class="mg-area" id="mgA"></div><div class="muted">Попаданий: <b id="mgCnt">0</b>/${o.count}</div>`);
    let hits = 0, shown = 0;
    const area = document.getElementById("mgA");
    mgStart(o, () => ({hits}));
    const spawn = () => {
      if (mg.done || shown >= o.count) return;
      shown++;
      const t = document.createElement("div");
      t.className = "mg-tok"; t.textContent = o.icon; t.style.left = rnd(10, 90) + "%"; t.style.top = rnd(12, 88) + "%";
      t.onpointerdown = () => { hits++; t.remove(); document.getElementById("mgCnt").textContent = hits; if (hits >= o.count) mgFinish({hits}); };
      area.appendChild(t);
      mg.timers.push(setTimeout(() => t.remove(), o.spawn_ms * 1.15));
      mg.timers.push(setTimeout(spawn, o.spawn_ms));
    };
    spawn();
  },
  // Огр: запомнить ингредиенты
  memory(o, head) {
    openBox(head + `<div style="font-size:44px;margin:16px" id="mgSeq">${o.sequence.join(" ")}</div><div class="muted" id="mgHint">Запоминайте!</div><div id="mgPool"></div>` + timerBar);
    const picked = [];
    mgStart(o, () => ({picked}));
    mgLater(() => {
      if (!mg || mg.done) return;
      document.getElementById("mgSeq").textContent = "❔ ❔ ❔ ❔";
      document.getElementById("mgHint").textContent = "Повторите по порядку (🌶 — ловушка!)";
      document.getElementById("mgPool").innerHTML = o.pool.map(f => `<button class="mg-btn" onclick="memPick(this,'${f}')">${f}</button>`).join("");
      window.memPick = (btn, f) => { picked.push(f); btn.disabled = true;
        document.getElementById("mgSeq").textContent = picked.join(" ") + " ❔".repeat(Math.max(0, 4 - picked.length));
        if (picked.length >= 4 || f === "🌶") mgFinish({picked}); };
    }, o.show_ms);
  },
  // Спартанец: кольцо сжимается к щиту
  timing_ring(o, head) {
    openBox(head + `<div class="mg-area" id="mgA" style="width:300px;height:300px;cursor:pointer"><div style="position:absolute;left:50%;top:50%;width:90px;height:90px;margin:-45px;border-radius:50%;border:6px solid var(--gold);display:flex;align-items:center;justify-content:center;font-size:40px">🛡</div>
      <div id="ring" style="position:absolute;left:50%;top:50%;border-radius:50%;border:4px solid #4cd07d"></div></div>` + timerBar + `<div class="muted">Нажмите в любом месте поля, когда кольцо совпадёт со щитом</div>`);
    const ring = document.getElementById("ring"), P = o.period_ms, M = P * 0.75;   // совпадение — на 75% цикла
    const sz = ph => 300 - (300 - 96) * (ph / M);
    const loop = () => { if (mg.done) return; const ph = (performance.now() - mg.t0) % P, s = Math.max(20, sz(ph));
      ring.style.width = ring.style.height = s + "px"; ring.style.margin = (-s / 2) + "px"; mg.raf = requestAnimationFrame(loop); };
    mgStart(o, () => ({error_ms: 9999}));
    loop();
    document.getElementById("mgA").onpointerdown = () => { const ph = (performance.now() - mg.t0) % P; mgFinish({error_ms: Math.round(Math.min(Math.abs(ph - M), P - Math.abs(ph - M)))}); };
  },
  // Спартанец: угадать действие врага
  read_enemy(o, head, me, foe) {
    openBox(head + `<p class="muted">Что сделает ${esc(foe.name)} следующим ходом?</p>` +
      Object.entries(o.choices).map(([k, v]) => `<button class="btn dodge-btn" onclick="mgFinish('${k}')">${esc(v)}</button>`).join(""));
    mg = {done: false, timers: []};
  },
  // Самурай: зоны манекена
  zones(o, head) {
    const names = {head: "Голова", body: "Корпус", legs: "Ноги"}, tops = {head: 6, body: 37, legs: 70};
    openBox(head + timerBar + `<div class="mg-area" id="mgA" style="width:260px;height:320px">${o.zones.map(z =>
      `<div class="zone" id="z_${z}" style="top:${tops[z]}%;height:26%">${names[z]}</div>`).join("")}</div><div class="muted">Попаданий: <b id="mgCnt">0</b>/3</div>`);
    let hits = 0, idx = -1, live = null;
    mgStart(o, () => ({hits}));
    o.zones.forEach(z => document.getElementById("z_" + z).onpointerdown = () => {
      if (live === z) { hits++; live = null; document.getElementById("z_" + z).classList.remove("flash"); document.getElementById("mgCnt").textContent = hits; }
    });
    const next = () => {
      if (mg.done) return;
      o.zones.forEach(z => document.getElementById("z_" + z).classList.remove("flash"));
      idx++;
      if (idx >= o.sequence.length) return mgFinish({hits});
      live = o.sequence[idx];
      document.getElementById("z_" + live).classList.add("flash");
      mg.timers.push(setTimeout(next, o.flash_ms + 250));
    };
    mg.timers.push(setTimeout(next, 400));
  },
  // Тёмный эльф: руны с риском
  runes_risk(o, head) {
    const flipped = [];
    openBox(head + timerBar + `<div>${Array.from({length: o.runes}, (_, i) => `<button class="rune" id="r${i}" onclick="runeFlip(${i})">ᚱ</button>`).join("")}</div>
      <p class="muted">Каждая открытая чистая руна усиливает удар. Одна из ${o.runes} проклята — откроете её, и ритуал сорвётся.</p>
      <button class="btn" onclick="mgFinish({flipped: window._flipped})">✋ Остановиться и ударить</button>`);
    window._flipped = flipped;
    window.runeFlip = i => { if (flipped.includes(i)) return; flipped.push(i); const r = document.getElementById("r" + i); r.classList.add("open"); r.textContent = "✦"; r.disabled = true; };
    mgStart(o, () => ({flipped}));
  },
  // Мушкетёр: движущаяся цель с упреждением
  moving_target(o, head) {
    openBox(head + timerBar + `<div class="mg-area" id="mgA" style="cursor:crosshair"><div id="tgt" style="position:absolute;width:${o.ring_r * 2}px;height:${o.ring_r * 2}px;margin:-${o.ring_r}px;border-radius:50%;border:3px solid #e05555;background:radial-gradient(#ff5a5a 0 ${o.center_r}px,transparent ${o.center_r + 1}px)"></div></div>
      <div class="muted">Пуля летит 0.25 с — стреляйте туда, где цель БУДЕТ.</div>`);
    const area = document.getElementById("mgA"), tgt = document.getElementById("tgt"), W = 420, H = 300;
    const pos = t => { const s = o.speed / 1000, x = (t * s) % (2 * (W - 60)), y = H / 2 + Math.sin(t / 420) * 80;
      return [30 + (x < W - 60 ? x : 2 * (W - 60) - x), y]; };
    const loop = () => { if (mg.done) return; const [x, y] = pos(performance.now() - mg.t0); tgt.style.left = x + "px"; tgt.style.top = y + "px"; mg.raf = requestAnimationFrame(loop); };
    mgStart(o, () => ({zone: "miss"}));
    loop();
    area.onpointerdown = e => { const r = area.getBoundingClientRect(), [x, y] = pos(performance.now() - mg.t0 + 250);
      const d = Math.hypot(e.clientX - r.left - x, e.clientY - r.top - y);
      mgFinish({zone: d <= o.center_r + 4 ? "center" : d <= o.ring_r + 4 ? "ring" : "miss"}); };
  },
  // Язычник: выбор бога
  prayer(o, head) {
    openBox(head + Object.entries(o.gods).map(([k, v]) => `<div><button class="btn dodge-btn" style="width:90%" onclick="mgFinish('${k}')">${esc(v)}</button></div>`).join(""));
    mg = {done: false, timers: []};
  },
  // Язычник: оборотень — выбрать зверя и провести по точкам руны
  rune_draw(o, head) {
    openBox(head + `<div id="mgForms">${Object.entries(o.forms).map(([k, v]) => `<button class="mg-btn" onclick="pickForm('${k}')">${v}</button>`).join("")}</div>
      <div id="mgDraw" style="display:none">${timerBar}<div class="mg-area" id="mgA">${o.points.map((p, i) => `<div class="mg-tok" id="pt${i}" style="left:${p[0]}%;top:${p[1]}%;font-size:22px;width:44px;height:44px;border-radius:50%;background:#2b2738;border:2px solid #b98cff;display:flex;align-items:center;justify-content:center">${i + 1}</div>`).join("")}<svg id="mgSvg" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none"></svg></div>
      <div class="muted">Зажмите мышь и проведите 1 → 2 → 3 → 4 → 5. Точек: <b id="mgCnt">0</b>/5</div></div>`);
    mg = {done: false, timers: []};
    let form = "wolf", points = 0, down = false, last = null;
    window.pickForm = f => {
      form = f; document.getElementById("mgForms").style.display = "none"; document.getElementById("mgDraw").style.display = "block";
      mgStart({...o}, () => ({form, points}));
      const area = document.getElementById("mgA"), svg = document.getElementById("mgSvg");
      area.onpointerdown = e => {e.preventDefault();down=true;area.setPointerCapture(e.pointerId);visitNext(e)};
      function visitNext(e){if(!down||points>=o.points.length)return;const b=area.getBoundingClientRect(),p=o.points[points],x=b.left+p[0]/100*b.width,y=b.top+p[1]/100*b.height;if(Math.hypot(e.clientX-x,e.clientY-y)<=25)document.getElementById('pt'+points).onpointerenter()}
      area.onpointermove=visitNext;area.onpointerup = () => { down = false; if (points > 0 && points < 5) mgFinish({form, points}); };
      o.points.forEach((p, i) => document.getElementById("pt" + i).onpointerenter = () => {
        if (!down || i !== points) return;
        const el = document.getElementById("pt" + i); el.style.background = "#7a4cff";
        if (last) svg.innerHTML += `<line x1="${last[0]}%" y1="${last[1]}%" x2="${p[0]}%" y2="${p[1]}%" stroke="#b98cff" stroke-width="5"/>`;
        last = p; points++; document.getElementById("mgCnt").textContent = points;
        if (points >= 5) mgFinish({form, points});
      });
      document.getElementById("pt0").onpointerdown = () => { down = true; document.getElementById("pt0").onpointerenter(); };
    };
  },
  // Минотавр: барабаны предков (Web Audio)
  rhythm(o, head) {
    openBox(head + `<div class="drum" id="drum">🥁</div><div class="muted" id="mgHint">Слушайте ритм…</div>` + timerBar);
    mg = {done: false, timers: []};
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const boom = () => { const t = ctx.currentTime, os = ctx.createOscillator(), g = ctx.createGain();
      os.frequency.setValueAtTime(140, t); os.frequency.exponentialRampToValueAtTime(45, t + .25);
      g.gain.setValueAtTime(1, t); g.gain.exponentialRampToValueAtTime(.001, t + .35);
      os.connect(g).connect(ctx.destination); os.start(t); os.stop(t + .4);
      const d = document.getElementById("drum"); d.classList.add("hit"); mgLater(() => d.classList.remove("hit"), 120); };
    o.beats_ms.forEach(ms => mg.timers.push(setTimeout(boom, 300 + ms)));
    const listenAt = 300 + o.beats_ms[o.beats_ms.length - 1] + (o.listen_pause_ms ?? 900);
    const taps = [];
    mg.timers.push(setTimeout(() => {
      document.getElementById("mgHint").innerHTML = "<b>Теперь вы!</b> Повторите ритм по барабану (первый удар — когда готовы)";
      document.getElementById("drum").onpointerdown = () => { boom(); taps.push(performance.now());
        if (taps.length >= o.beats_ms.length) mgFinish({hits: score()}); };
      mgStart({time_limit_ms: o.time_limit_ms - listenAt}, () => ({hits: score()}));
    }, listenAt));
    const score = () => { if (!taps.length) return 0; let hits = 1;
      for (let i = 1; i < o.beats_ms.length && i < taps.length; i++) if (Math.abs((taps[i] - taps[0]) - o.beats_ms[i]) <= o.tolerance_ms) hits++;
      return hits; };
  },
  // Крок: удерживать маркер в зелёной зоне
  hold_zone(o, head) {
    openBox(head + `<div class="vbar" id="vb"><div class="gz" id="gz" style="height:26%"></div><div class="mk" id="mk"></div></div>
      <div class="muted">Зажмите кнопку мыши / пробел — маркер поднимается, отпустите — падает. В зоне: <b id="mgCnt">0</b>%</div>` + timerBar);
    let y = .45, v = 0, hold = false, inZ = 0, total = 0, lastT = performance.now();
    const box = document.getElementById("modalBox");
    box.onpointerdown = () => hold = true; box.onpointerup = () => hold = false;
    document.onkeydown = e => { if (e.code === "Space") hold = true; }; document.onkeyup = e => { if (e.code === "Space") hold = false; };
    mgStart(o, () => ({in_zone: total ? +(inZ / total).toFixed(2) : 0}));
    const loop = now => { if (mg.done) return; const dt = Math.min(50, now - lastT) / 1000; lastT = now;
      v += (hold ? 2.4 : -2.2) * dt; v = Math.max(-1, Math.min(1, v)); y = Math.max(0, Math.min(.96, y + v * dt));
      const t = (now - mg.t0) / 1000, zc = .5 + .32 * Math.sin(t * 1.7) * Math.cos(t * .6), zh = .26;
      document.getElementById("gz").style.bottom = ((zc - zh / 2) * 100) + "%"; document.getElementById("mk").style.bottom = (y * 100) + "%";
      total += dt; if (Math.abs(y + .015 - zc) <= zh / 2) inZ += dt;
      document.getElementById("mgCnt").textContent = Math.round(100 * inZ / total);
      mg.raf = requestAnimationFrame(loop); };
    mg.raf = requestAnimationFrame(loop);
  },
  // Крок: кольца панциря
  rings(o, head) {
    const pos = o.rings.slice();
    openBox(head + timerBar + `<div style="margin:14px 0">${pos.map((p, i) => `<div class="ringw" onclick="ringTurn(${i})"><span class="mark">▼</span><div class="r" id="rg${i}" style="transform:rotate(${p * 360 / o.steps}deg);width:${110 - i * 0}px"></div></div>`).join("")}</div>
      <div class="muted">Кликайте по кольцу, чтобы повернуть его. Совпало: <b id="mgCnt">0</b>/3</div><button class="btn small" onclick="mgFinish({aligned: window._aligned()})">Готово</button>`);
    window._aligned = () => pos.filter(p => p % o.steps === 0).length;
    window.ringTurn = i => { pos[i] = (pos[i] + 1) % o.steps; document.getElementById("rg" + i).style.transform = `rotate(${pos[i] * 360 / o.steps}deg)`;
      document.getElementById("mgCnt").textContent = window._aligned(); if (window._aligned() === 3) mgFinish({aligned: 3}); };
    mgStart(o, () => ({aligned: window._aligned()}));
  },
  // Тёмный рыцарь: зажать и отпустить в зоне
  hold_release(o, head) {
    openBox(head + `<div class="vbar"><div class="gz" style="bottom:${o.good[0] * 100}%;height:${(o.good[1] - o.good[0]) * 100}%"></div><div class="pz" style="bottom:${o.perfect[0] * 100}%;height:${(o.perfect[1] - o.perfect[0]) * 100}%"></div><div class="fill" id="fill" style="height:0"></div></div>
      <button class="btn" id="holdBtn" style="font-size:18px;padding:12px 24px">🔥 Зажмите</button><div class="muted">Жёлтая зона — идеально, зелёная — хорошо, до верха — перегрев</div>` + timerBar);
    let start = null, charge = 0;
    const btn = document.getElementById("holdBtn");
    mgStart(o, () => ({charge}));
    const loop = () => { if (mg.done || start === null) return; charge = Math.min(1, (performance.now() - start) / o.fill_ms);
      document.getElementById("fill").style.height = (charge * 100) + "%"; if (charge >= 1) return mgFinish({charge: 1}); mg.raf = requestAnimationFrame(loop); };
    btn.onpointerdown = e => { e.preventDefault();btn.setPointerCapture(e.pointerId);if (start === null) { start = performance.now(); loop(); } };
    btn.onpointerup = btn.onpointerleave = () => { if (start !== null && !mg.done) mgFinish({charge: +Math.min(1,(performance.now()-start)/o.fill_ms).toFixed(3)}); };
  },
};

// ---------- 4.0: Сюжет ----------
async function loadStory() {
  await loadPlayers();
  const p = currentPlayer(); if (!p) return;
  const heroes = (await api("/api/heroes") || []).filter(h => h.story && h.owner_id === p.id);
  const sel = document.getElementById("storyHero"), old = sel.value;
  sel.innerHTML = heroes.map(h => `<option value="${h.id}">${esc(h.name)} (${h.hero_class}, ур. ${h.level})</option>`).join("") || `<option value="">— нет сюжетных героев —</option>`;
  if (old && heroes.some(h => h.id == old)) sel.value = old;
  document.getElementById("storySlots").textContent = `${heroes.length}/1`;
  const ts = document.getElementById("storyType");
  if (!ts.options.length) ts.innerHTML = classes.filter(c => c.creatable !== false && !c.required_wins).map(c => `<option value="${c.type}">${c.hero_class}</option>`).join("");
  const hid = sel.value;
  storyData = await api("/api/story" + (hid ? `?hero_id=${hid}` : ""));
  if (!storyData) return;
  const loc = storyData.locations[0];
  document.getElementById("storyTitle").textContent = loc.title + (loc.cleared ? " ✅ пройден" : "");
  document.getElementById("storyMap").innerHTML = loc.stages.map(s => `
    <div class="node ${hid ? s.status : "locked"} ${s.boss ? "boss" : ""}" style="left:${s.x}%;top:${s.y}%" onclick="pickStage('${s.key}')">
      ${s.icon}<label>${esc(s.title)}${s.boss ? " 👑" : ""}</label></div>`).join("");
  const info = document.getElementById("storyInfo");
  if (!hid) { info.innerHTML = `<p>${esc(loc.intro)}</p><p class="muted">Создайте сюжетного героя (1 уровень), чтобы отправиться в лес.</p>`; return; }
  const h = storyData.hero;
  info.innerHTML = `<p>${esc(loc.intro)}</p><div class="muted">${esc(h.name)}: ур. ${h.level}, опыт ${h.experience}/100 · пройдено этапов ${loc.progress}/${loc.stages.length}</div>`;
  const open = loc.stages.find(s => s.status === "open");
  if (open) pickStage(open.key);
}
function pickStage(key) {
  const hid = document.getElementById("storyHero").value;
  if (!storyData || !hid) return toast("Сначала создайте сюжетного героя");
  const loc = storyData.locations[0], s = loc.stages.find(x => x.key === key);
  if (s.status === "locked") return toast("🔒 Этап закрыт — победите предыдущего противника");
  storyStage = s;
  const h = storyData.hero;
  document.getElementById("storyInfo").innerHTML = `<div class="row" style="align-items:flex-start"><img src="${s.image}" style="width:120px;border-radius:10px">
    <div><h3 style="margin:0;color:var(--gold)">${s.icon} ${esc(s.title)}${s.boss ? " — босс" : ""} ${s.status === "done" ? "✅" : ""}</h3>
    <p style="font-style:italic">💬 ${esc(h.name)}: «${esc(s.line)}»</p>
    <div class="muted">Награда: до ${s.xp} опыта и ${s.gold} золота (меньше, если герой сильнее моба)</div>
    <div class="row" style="margin-top:8px">🎒 <select id="storyItem"><option value="">— без предмета —</option>${Object.entries(h.consumables || {}).map(([k, n]) => `<option value="${k}">${itemInfo(k)[0]} ${esc(itemInfo(k)[1])} ×${n}</option>`).join("")}</select>
    <button class="btn" onclick="storyFight('${s.key}')">⚔ В бой</button></div></div></div>`;
}
async function storyFight(stage) {
  const hid = document.getElementById("storyHero").value;
  const item = document.getElementById("storyItem").value || null;
  const b = await api(`/api/heroes/${hid}/story_battle`, "POST", {location: "forest", stage, mode: "manual", item});
  if (!b) return;
  document.querySelectorAll("nav button, .tab").forEach(x => x.classList.remove("active"));
  document.querySelector('nav button[data-tab=battle]').classList.add("active"); document.getElementById("battle").classList.add("active");
  battle = null; resetArena();
  await update(b, true);
}
async function createStoryHero() {
  const p = currentPlayer(); if (!p) return;
  const h = await api(`/api/players/${p.id}/story_heroes`, "POST", {name: document.getElementById("storyName").value, type: document.getElementById("storyType").value});
  if (h) { toast(`📖 ${h.name} отправляется в Тёмный лес!`, "ok"); document.getElementById("storyName").value = ""; document.getElementById("storyHero").innerHTML = `<option value="${h.id}"></option>`; await loadStory(); }
}

// ---------- Первый визит: создать своего героя, если своих нет ----------
checkFirstVisit = async function () {
  const p = currentPlayer();
  const hasMine = !!(p && (allHeroes || []).some(h => h.owner_id === p.id && !h.story));
  if (hasMine) return;
  // «Позже» в этой вкладке — не достаём; после перезагрузки страницы снова предложим
  if (window._welcomeDismissed) return;
  try { localStorage.removeItem("welcomeSkipped"); } catch (e) {}
  showWelcome();
};

const _showWelcome40 = typeof showWelcome === "function" ? showWelcome : null;
showWelcome = function () {
  if (!classes || !classes.length) {
    // классы ещё не подгрузились — подтянем и покажем
    return loadClasses().then(() => showWelcome());
  }
  const list = creatable().filter(c => !isLocked(c));
  if (!list.length) {
    console.warn("showWelcome: нет доступных классов");
    return;
  }
  if (_showWelcome40) return _showWelcome40();
  // fallback
  if (!list.some(c => c.type === welcomePick)) welcomePick = list[0].type;
  document.getElementById("welcomeClasses").innerHTML = list.map(c => `
    <div class="class-card ${c.type === welcomePick ? "selected" : ""}" data-type="${c.type}" onclick="pickWelcome('${c.type}')">
      <img src="${c.image}" alt="${c.hero_class}"><b>${c.hero_class}</b>
      <div class="stats">❤ ${c.max_hp} ⚔ ${c.damage}${c.damage_basis ? ` (${esc(c.damage_basis)})` : ""} 🛡 ${c.armor}</div></div>`).join("");
  document.getElementById("welcome").style.display = "flex";
};

if (!window.ONLINE_MODE) loadClasses().then(refreshAll).then(checkFirstVisit);
