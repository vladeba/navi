"""Solo storage, validated interaction sessions, and isolated practice."""
import os,time,json,math,uuid,threading,hashlib
from collections import OrderedDict
from datetime import datetime,timezone
from flask import request,jsonify,g
from werkzeug.exceptions import HTTPException

def install(app,get_service):
 from services import GameService,BusyError
 from models import HERO_CLASSES,Character
 from models.skills import MiniGameSkill
 from models.minigames_56 import Replay
 app.config['MAX_CONTENT_LENGTH']=2*1024*1024
 lock=threading.RLock();cache=OrderedDict();practice=OrderedDict()
 state={'last_saved':None,'error':None}
 s=get_service()
 if os.path.exists(s.save_path):
  try:s.load();state['last_saved']=datetime.fromtimestamp(os.path.getmtime(s.save_path),timezone.utc).isoformat()
  except Exception as e:state['error']='Не удалось загрузить сохранение. Файл сохранён без изменений: '+str(e)

 def meta():return dict(last_saved=state['last_saved'],error=state['error'],backup_available=os.path.exists(get_service().save_path+'.bak'),unfinished_battles_saved=False)
 def pending_meta(b):
  p=b.pending
  if not p:return None
  if '_token605' not in p:
   p['_token605']=uuid.uuid4().hex;p['_ready605']=False;p['_client605']=True
  limit=p['options'].get('time_limit_ms',0) if isinstance(p['options'],dict) else 0
  started=p.get('_started605')
  return dict(token=p['_token605'],ready=p['_ready605'],elapsed_ms=round((time.time()-started)*1000) if started else 0,remaining_ms=max(0,round(limit-(time.time()-started)*1000)) if started and limit else limit)
 def begin(p,token):
  if token!=p.get('_token605'):raise ValueError('Эта попытка уже неактуальна. Обновите бой.')
  if p.get('_ready605'):return
  p['_ready605']=True;p['_started605']=time.time()
  options=p['options'];limit=options.get('time_limit_ms',0) if isinstance(options,dict) else 0
  secret=p['secret']
  if isinstance(secret,dict):
   secret['started']=time.time();secret['deadline']=time.time()+limit/1000+1.5 if limit else None
  elif isinstance(secret,float):p['secret']=time.time()+limit/1000+1.5

 def validate_input(p,choice):
  if choice=='timeout':return
  if not p.get('_ready605'):raise ValueError('Сначала нажмите «Начать».')
  skill=p['skill'];skill.check_choice(choice)
  if isinstance(skill,MiniGameSkill) and not isinstance(choice,dict) and skill.game!='prayer':raise ValueError('Ожидается запись действий мини-игры, а не готовая оценка.')
  if isinstance(choice,dict):
   skill.check_choice(choice)
   # Older games used summary counters. Accept them only with a bounded input
   # replay from the current interaction, never an instant naked counter.
   if isinstance(skill,MiniGameSkill) and not isinstance(skill,Replay):
    inputs=choice.get('_input605')
    if not inputs and isinstance(p['options'],dict) and p['options'].get('time_limit_ms') and (time.time()-p['_started605'])*1000>=p['options']['time_limit_ms']-150:return
    if not isinstance(inputs,list) or not inputs or len(inputs)>600:raise ValueError('Нет записи действий этой попытки.')
    wall=(time.time()-p['_started605'])*1000;last=-1
    for e in inputs:
     if not isinstance(e,dict) or isinstance(e.get('ms'),bool) or not isinstance(e.get('ms'),(int,float)) or not math.isfinite(e['ms']) or not last<=e['ms']<=wall+350:raise ValueError('Некорректное время действий.')
     if e.get('type') not in ('down','up','key','change','move'):raise ValueError('Некорректное действие.')
     last=e['ms']
    downs=[e for e in inputs if e['type'] in ('down','key','change')]
    if not downs:raise ValueError('Попытка не содержит действий.')
    if skill.game=='hold_zone' and wall<p['options'].get('time_limit_ms',0)-350:raise ValueError('Удержание ещё не завершено.')
    if skill.game=='memory' and choice.get('picked') and wall<p['options'].get('show_ms',0):raise ValueError('Сначала дождитесь конца показа.')
    if skill.game=='splash_aim':
     hits=choice.get('hits',0);o=p['options']
     taps=[e for e in downs if e.get('type')=='down'];spawn=o.get('spawn_ms',330)
     if not isinstance(hits,int) or not 0<=hits<=o['count'] or len(taps)<hits:raise ValueError('Счётчик не соответствует действиям.')
     if hits>1 and taps[-1]['ms']-taps[0]['ms']<(hits-1)*spawn*.7:raise ValueError('Цели ещё не успели появиться.')
    for key in ('hits','removed'):
     value=choice.get(key)
     if isinstance(value,(int,float)) and value>len(downs) and skill.game in ('click_targets','splash_aim','shunpo','order_click','arrows_seq','rhythm'):
      raise ValueError('Счётчик не соответствует действиям.')

 @app.before_request
 def before605():
  if not request.path.startswith('/api/'):return
  lock.acquire();g.lock605=True
  key=request.headers.get('Idempotency-Key');g.key605=None
  for field in ('hero_id','player_id'):
   if field in request.args and not request.args[field].isdigit():return jsonify(error='Неверный идентификатор: '+field),400
  if request.method not in ('GET','HEAD','OPTIONS'):
   if state['error'] and request.path not in ('/api/load','/api/storage/restore_backup'):return jsonify(error=state['error'],storage=meta()),409
   d=request.get_json(silent=True)
   if d is None and request.get_data():return jsonify(error='Не удалось прочитать JSON действия'),400
   if d is not None and not isinstance(d,dict):return jsonify(error='Тело запроса должно быть объектом'),400
   d=d or {}
   for field in ('hero_id','hero1_id','hero2_id','player_id','target_id'):
    if field in d and d[field] not in (None,'hero'):
     if field=='target_id' and isinstance(d[field],str) and __import__('re').fullmatch(r's[0-9]+(?:_[0-9]+)?',d[field]):continue
     if isinstance(d[field],bool) or not isinstance(d[field],(int,str)) or not str(d[field]).isdigit():return jsonify(error='Неверный идентификатор: '+field),400
   if request.path=='/api/battles' and (d.get('hero1_id') is None or d.get('hero2_id') is None):return jsonify(error='Выберите двух бойцов'),400
   if 'ai_ids' in d and (not isinstance(d['ai_ids'],list) or any(type(x) is not int for x in d['ai_ids'])):return jsonify(error='ai_ids должен быть списком номеров героев'),400
   if key:
    sig=hashlib.sha256(request.get_data()).hexdigest();g.key605=(request.method,request.path,key);g.sig605=sig
    old=cache.get(g.key605)
    if old:
     if old[0]!=sig:return jsonify(error='Повторный запрос содержит другое действие'),409
     g.replayed605=True
     return app.response_class(old[1],status=old[2],mimetype='application/json')
   match=__import__('re').fullmatch(r'/api/heroes/([0-9]+)/(heal|attack|items|use/[0-9]+)',request.path)
   if match:
    h=get_service().get_hero(int(match.group(1)))
    if get_service()._active_battle_of(h):raise BusyError('Внешние действия с героем недоступны, пока он сражается. Используйте умения и предметы в бою.')
    if match.group(2)=='attack' and d.get('target_id') is not None:
     target=get_service().get_hero(int(d['target_id']))
     if get_service()._active_battle_of(target):raise BusyError('Цель уже участвует в бою.')
   if '/battles/' in request.path and request.path.endswith('/react'):
    b=get_service().get_battle(int(request.path.split('/')[-2]));p=b.pending
    if p and p.get('_client605'):
     if d.get('token')!=p['_token605']:raise ValueError('Ответ относится к другой попытке. Обновите бой.')
     validate_input(p,d.get('choice'))

 @app.after_request
 def after605(response):
  if not request.path.startswith('/api/'):return response
  response.headers['Cache-Control']='no-store'
  data=response.get_json(silent=True)
  if isinstance(data,list) and request.path=='/api/heroes':
   for h in data:
    h['in_battle']=bool(get_service()._active_battle_of(get_service().get_hero(h['id'])))
   response.set_data(app.json.dumps(data))
  def decorate605(value):
   if isinstance(value,list):
    for child in value:decorate605(child)
   elif isinstance(value,dict):
    if value.get('pending') and 'id' in value and not request.path.startswith('/api/practice'):
     b=get_service()._battles.get(value['id'])
     if b:value['pending'].update(pending_meta(b) or {})
    if isinstance(value.get('heroes'),list) and 'status' in value:
     for h in value['heroes']:
      if isinstance(h,dict):h['in_battle']=value.get('status')=='active'
    for child in value.values():
     if isinstance(child,(dict,list)):decorate605(child)
  if response.status_code<300:decorate605(data)
  if isinstance(data,list):response.set_data(app.json.dumps(data))
  if response.status_code<300 and request.path=='/api/save':state['last_saved']=datetime.now(timezone.utc).isoformat()
  if response.status_code<300 and request.path=='/api/load':
   state['error']=None;state['last_saved']=datetime.now(timezone.utc).isoformat()
  if response.status_code<300 and not getattr(g,'replayed605',False) and request.method in ('POST','PUT','PATCH','DELETE') and not request.path.startswith('/api/practice') and not request.path.endswith('/begin') and request.path not in ('/api/load','/api/save','/api/storage/restore_backup'):
   try:
    get_service().save();state['last_saved']=datetime.now(timezone.utc).isoformat()
   except OSError:
    response=jsonify(error='Не удалось сохранить прогресс на диск. Освободите место и нажмите «Сохранить».',storage=meta());response.status_code=503;data=None
  if isinstance(data,dict):
   data['storage']=meta();response.set_data(app.json.dumps(data))
  if getattr(g,'key605',None) and response.status_code<300:
   cache[g.key605]=(g.sig605,response.get_data(),response.status_code)
   while len(cache)>256:cache.popitem(last=False)
  return response

 @app.teardown_request
 def unlock605(error):
  if getattr(g,'lock605',False):g.lock605=False;lock.release()

 @app.errorhandler(413)
 def large605(e):return jsonify(error='Слишком большой объём данных действия'),413

 @app.errorhandler(500)
 def server_error605(e):return jsonify(error='Не удалось обработать действие. Обновите страницу и повторите.'),500

 @app.get('/api/storage')
 def storage605():return jsonify(meta())
 @app.post('/api/storage/restore_backup')
 def restore605():
  from services import GameService
  s=get_service();candidate=GameService(save_path=s.save_path+'.bak');candidate.load()
  if os.path.exists(s.save_path):os.replace(s.save_path,s.save_path+'.damaged-'+str(int(time.time())))
  candidate.save_path=s.save_path;s.__dict__.update(candidate.__dict__);s.save();state['error']=None;state['last_saved']=datetime.now(timezone.utc).isoformat()
  return jsonify(message='Резервная копия восстановлена. Обновите страницу.',storage=meta())

 @app.post('/api/battles/<int:bid>/begin')
 def begin605(bid):
  b=get_service().get_battle(bid)
  if not b.pending:raise ValueError('Сейчас нет мини-игры')
  pending_meta(b);begin(b.pending,(request.get_json() or {}).get('token'))
  return jsonify(**b.to_dict(),pending605=pending_meta(b))

 @app.get('/api/story/classes')
 def story_classes605():return jsonify([C.class_info(arena=False) for C in HERO_CLASSES.values() if C.creatable and (not C.secret or get_service().is_unlocked(get_service().get_player(int(request.args.get('player_id',1)))))])

 @app.get('/api/practice/catalog/<hero>')
 def practice_catalog605(hero):
  if hero not in HERO_CLASSES:raise ValueError('Неизвестный герой')
  h=HERO_CLASSES[hero]('Тренировка');h.configure_arena();h.reset()
  return jsonify([dict(key=s.key,name=s.name,description=s.describe_for(h),reaction=s.reaction) for s in h.skills.values() if s.reaction])

 @app.post('/api/practice')
 def create_practice605():
  d=request.get_json() or {};hero=d.get('hero');key=d.get('skill')
  if hero not in HERO_CLASSES:raise ValueError('Неизвестный герой')
  h=HERO_CLASSES[hero]('Тренировка');h.configure_arena();h.reset();h.hp=round(h.max_hp*.65);h.turn_number=10;h.restore_energy(999)
  t=HERO_CLASSES['warrior']('Манекен');t.configure_arena();t.reset();h.opponent=t;t.opponent=h;s=h.skills.get(key)
  if not s or not s.reaction:raise ValueError('Выберите мини-игру')
  if hasattr(s,'game'):o=s.public_options(h,t);secret=s.secret_pick(o)
  else:o=s.public_options();secret=s.secret_pick()
  token=uuid.uuid4().hex;p=dict(skill=s,actor=h,target=t,options=o,secret=secret,_token605=token,_ready605=False,_client605=True)
  practice[token]=p
  while len(practice)>128:practice.popitem(last=False)
  return jsonify(id=token,heroes=[h.to_dict(),t.to_dict()],ai_ids=[],pending=dict(type=s.reaction,hero_id=h.id,attacker_id=h.id,target_id=t.id,skill=s.name,prompt=s.prompt,options=o,token=token,ready=False),practice=True)

 @app.post('/api/practice/<token>/begin')
 def start_practice605(token):
  if token not in practice:raise ValueError('Тренировка завершена')
  begin(practice[token],token);return jsonify(ok=True)
 @app.post('/api/practice/<token>/result')
 def end_practice605(token):
  p=practice.get(token)
  if not p:raise ValueError('Тренировка завершена')
  d=request.get_json() or {};c=d.get('choice');validate_input(p,c);s=p['skill'];h=p['actor'];t=p['target'];before=t.hp;hp=h.hp
  logs=s.resolve(h,t,s.check_choice(c),p['secret']);practice.pop(token,None)
  return jsonify(logs=list(map(str,logs)),damage=before-t.hp,healing=max(0,h.hp-hp),effects=[e.to_dict() for e in h.get_effects()],practice=True)
