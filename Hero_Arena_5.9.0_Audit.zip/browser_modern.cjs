const {chromium}=require('playwright'),fs=require('fs');
const ROOT='/workspace/hero-arena-review/variety590',BASE='http://127.0.0.1:5590';
const assert=(x,m)=>{if(!x)throw Error(m)};
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox'],headless:true});const results=[],errors=[];
try{for(const mobile of [false,true]){
 const ctx=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1440,height:1000},isMobile:mobile,hasTouch:mobile});const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(BASE+'/',{waitUntil:'networkidle'});await page.evaluate(()=>skipWelcome());await page.waitForFunction(()=>window.arenaMiniUI&&MINIGAMES.arena58);await page.clock.install();await page.clock.pauseAt(new Date());
 const games=await (await page.request.get(BASE+'/audit/games?kind=arena58')).json();const cdp=await ctx.newCDPSession(page);
 for(const g of games){
  await page.evaluate(o=>{window.__result58=null;window.__mgHook=c=>{window.__endedMs=Math.max(0,Math.floor(performance.now()-mg.t0)-300);window.__result58=c};MINIGAMES.arena58(o,'<h3>Проверка</h3>')},g.options);
  const o=g.options,w=g.win,mode=o.mode;let down=false;
  async function advance(t){const now=await page.evaluate(()=>Math.floor(performance.now()-mg.t0));if(t>now)await page.clock.runFor(t-now)}
  async function point(x,y,kind='move'){
   const r=await page.locator('#rStage').boundingBox();const X=r.x+x*r.width/360,Y=r.y+y*r.height/260;
   if(mobile){if(kind==='down'){down=true;await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:X,y:Y,id:1}]})}else if(kind==='up'){await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});down=false}else if(down)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:X,y:Y,id:1}]});else{down=true;await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:X,y:Y,id:1}]})}}
   else{await page.mouse.move(X,Y);if(kind==='down'){await page.mouse.down();down=true}else if(kind==='up'){await page.mouse.up();down=false}}
   if(mobile)await new Promise(resolve=>setTimeout(resolve,25)); // flush Chromium touch delivery while virtual time is paused
  }
  async function click(id){const b=await page.locator(id).boundingBox(),x=b.x+b.width/2,y=b.y+b.height/2;if(mobile){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});await new Promise(r=>setTimeout(r,25));await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await new Promise(r=>setTimeout(r,25))}else await page.mouse.click(x,y)}
  if(['stop','summon'].includes(mode)){for(const e of w.clicks){await advance(e.ms);await click('#a58Stop')}if(mode==='summon')await click('#rFinish')}
  else if(mode==='hold'){await advance(w.down_ms);const b=await page.locator('#a58Hold').boundingBox();if(mobile){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:b.x+b.width/2,y:b.y+b.height/2,id:1}]});await advance(w.up_ms);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]})}else{await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await page.mouse.down();await advance(w.up_ms);await page.mouse.up()}}
  else if(['aim','sniper'].includes(mode)){for(const e of w.shots){await advance(e.ms);await point(e.x,e.y,'down');await point(e.x,e.y,'up')}}
  else if(['focus','steer','catch'].includes(mode)){for(const p of w.points){await advance(p.t);await point(p.x,p.y)}await advance((mode==='focus'?o.prepare_ms+o.track_ms:o[mode==='steer'?'gates':'drops'].at(-1).ms)+200);if(down)await point(180,220,'up')}
  else if(['path','circuit'].includes(mode)){await advance(w.down_ms);const first=w.points[0];await point(first.x,first.y,'down');for(const p of w.points.slice(1)){await advance(p.t);await point(p.x,p.y)}await point(w.points.at(-1).x,w.points.at(-1).y,'up')}
  else if(mode==='flick'){for(const e of w.cuts){await advance(e.down_ms);await point(e.x0,e.y0,'down');await advance(e.up_ms);await point(e.x1,e.y1);await point(e.x1,e.y1,'up')}}
  else if(['lanes','runes','zones','echo','machete'].includes(mode)){for(const a of w.actions){await advance(a.ms);await page.clock.runFor(17);await click(mode==='machete'?`.catch58[data-hand="${a.hand}"]`:mode==='echo'?`.echo58[data-lane="${a.lane}"]`:`.lane58[data-lane="${a.lane}"]`)}}
  else if(mode==='rhythm'){for(const a of w.clicks){await advance(a.ms);await click('#a58Beat')}}
  await page.clock.runFor(700);if(!await page.evaluate(()=>__result58))await click('#rFinish');await page.clock.runFor(400);
  const choice=await page.evaluate(()=>__result58);assert(choice,'No result '+g.hero+'/'+g.skill);const grade=await (await page.request.post(BASE+'/audit/grade',{data:{...g,choice}})).json();
  if(grade.tier!==0){fs.writeFileSync(ROOT+'/browser_modern_failure.json',JSON.stringify({mobile,g,choice,grade},null,2));await page.screenshot({path:ROOT+'/browser_modern_failure.png'});throw Error(`${mobile?'mobile':'desktop'} ${g.hero}/${g.skill}: ${grade.tier}`)}
  results.push({mobile,hero:g.hero,skill:g.skill,mode,elapsed_ms:choice.elapsed_ms??await page.evaluate(()=>window.__endedMs),limit_ms:o.time_limit_ms,tier:grade.tier});console.log('PASS',mobile?'touch':'desktop',g.hero,g.skill);
 }
 await ctx.close();
}
assert(!errors.length,errors.join('\n'));fs.writeFileSync(ROOT+'/browser_modern.json',JSON.stringify({results,errors,tooltips:'desktop hover, touch tap, disabled reasons'},null,2));console.log('PASS ALL',results.length)}finally{await browser.close()}})().catch(e=>{console.error(e);process.exit(1)});
