const {chromium}=require('playwright'),fs=require('fs');
const ROOT='/workspace/hero-arena-review/variety590',BASE='http://127.0.0.1:5590';
const assert=(x,m)=>{if(!x)throw Error(m)};
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox'],headless:true});const results=[],errors=[];
try{for(const mobile of [false,true]){
 const ctx=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1440,height:1000},isMobile:mobile,hasTouch:mobile});const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(BASE+'/',{waitUntil:'networkidle'});await page.evaluate(()=>skipWelcome());await page.waitForFunction(()=>window.arenaMiniUI&&MINIGAMES.arena58);await page.clock.install();await page.clock.pauseAt(new Date());
 const games=await (await page.request.get(BASE+'/audit/games?kind=arena59')).json();const cdp=await ctx.newCDPSession(page);
 for(const g of games){
  if(process.env.GAME_KEYS&&!process.env.GAME_KEYS.split(',').includes(g.skill))continue;
  await page.evaluate(o=>{window.__result58=null;window.__mgHook=c=>{window.__endedMs=Math.max(0,Math.floor(performance.now()-mg.t0)-300);window.__result58=c};MINIGAMES.arena59(o,'<h3>Проверка</h3>')},g.options);
  const o=g.options,w=g.win,mode=o.mode;let down=false;
  async function advance(t){const now=await page.evaluate(()=>Math.floor(performance.now()-mg.t0));if(t>now)await page.clock.runFor(t-now)}
  async function point(x,y,kind='move'){
   const r=await page.locator('#rStage').boundingBox();const X=r.x+x*r.width/360,Y=r.y+y*r.height/260;
   if(mobile){if(kind==='down'){down=true;await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:X,y:Y,id:1}]})}else if(kind==='up'){await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});down=false}else if(down)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:X,y:Y,id:1}]});else{down=true;await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:X,y:Y,id:1}]})}}
   else{await page.mouse.move(X,Y);if(kind==='down'){await page.mouse.down();down=true}else if(kind==='up'){await page.mouse.up();down=false}}
   if(mobile)await new Promise(resolve=>setTimeout(resolve,25)); // flush Chromium touch delivery while virtual time is paused
  }
  async function click(id){const b=await page.locator(id).boundingBox(),x=b.x+b.width/2,y=b.y+b.height/2;if(mobile){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});await new Promise(r=>setTimeout(r,25));await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await new Promise(r=>setTimeout(r,25))}else await page.mouse.click(x,y)}
  async function drag(a){await advance(a.down_ms);await point(a.x0,a.y0,'down');await advance(a.up_ms-70);await point(a.x1,a.y1);await advance(a.up_ms);await point(a.x1,a.y1,'up')}
  async function holdButton(id,downMs,upMs){await advance(downMs);const button=page.locator(id);await button.scrollIntoViewIfNeeded();const b=await button.boundingBox();if(mobile){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:b.x+b.width/2,y:b.y+b.height/2,id:1}]});await new Promise(resolve=>setTimeout(resolve,25));await advance(upMs);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await new Promise(resolve=>setTimeout(resolve,25))}else{await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await page.mouse.down();await advance(upMs);await page.mouse.up()}}
  if(['slingshot','drawblade','ricochet','chop','scales'].includes(mode)){for(const a of w.cuts)await drag(a)}
  else if(mode==='phalanx'){for(const p of w.points){await advance(p.t);await point(p.x,p.y)}await advance(o.arrows.at(-1).ms+250);if(down)await point(180,220,'up')}
  else if(mode==='labyrinth'){for(const a of w.actions){await advance(a.ms);await click(`.maze59[data-dir="${a.dir}"]`)}}
  else if(mode==='forge'){for(const a of w.actions){await advance(a.ms);await click(a.kind==='hit'?'#forgeHit59':a.kind==='cool'?'#forgeCool59':'#forgeQuench59')}}
  else if(mode==='updraft'){for(const a of w.clicks){await advance(a.ms);await click('#flap59')}await advance(o.rings.at(-1).ms+180)}
  else if(mode==='chords'){for(const a of w.actions){await advance(a.ms);await click(`.chord59[data-lane="${a.lane}"]`)}}
  else if(mode==='stalk'){for(const a of w.holds)await holdButton('#stalk59',a.down_ms,a.up_ms);await advance(o.safe.at(-1)[1]+180)}
  else if(mode==='justice'||mode==='gallows'||mode==='stone_fit'){for(const a of w.placements)await drag(a);await click('#rFinish')}
  else if(mode==='rune_pairs'){for(const a of w.actions){await advance(a.ms);const x=75+(a.card%3)*105,y=90+Math.floor(a.card/3)*100;await point(x,y,'down');await point(x,y,'up')}}
  else if(mode==='mirror_pose'||mode==='web_net'){for(const a of w.placements)await drag(a);if(mode==='web_net')await click('#rFinish')}
  else if(mode==='axe_whirl'){await advance(w.down_ms);await point(w.points[0].x,w.points[0].y,'down');for(const a of w.points.slice(1)){await advance(a.t);await point(a.x,a.y)}await point(w.points.at(-1).x,w.points.at(-1).y,'up')}
  else if(mode==='assembly'){const jobs=[...w.rotations.map(a=>({...a,t:a.ms,kind:'rotation'})),...w.placements.map(a=>({...a,t:a.down_ms,kind:'drop'}))].sort((a,b)=>a.t-b.t);for(const a of jobs){if(a.kind==='rotation'){await advance(a.t);await click(`.rotate59[data-part="${a.part}"]`)}else await drag(a)}}
  await page.clock.runFor(700);if(!await page.evaluate(()=>__result58))await click('#rFinish');await page.clock.runFor(400);
  const choice=await page.evaluate(()=>__result58);assert(choice,'No result '+g.hero+'/'+g.skill);const grade=await (await page.request.post(BASE+'/audit/grade',{data:{...g,choice}})).json();
  if(grade.tier!==0){fs.writeFileSync(ROOT+'/browser_personal_failure.json',JSON.stringify({mobile,g,choice,grade},null,2));await page.screenshot({path:ROOT+'/browser_personal_failure.png'});throw Error(`${mobile?'mobile':'desktop'} ${g.hero}/${g.skill}: ${grade.tier}`)}
  results.push({mobile,hero:g.hero,skill:g.skill,mode,elapsed_ms:choice.elapsed_ms??await page.evaluate(()=>window.__endedMs),limit_ms:o.time_limit_ms,tier:grade.tier});console.log('PASS',mobile?'touch':'desktop',g.hero,g.skill);
 }
 await ctx.close();
}
assert(!errors.length,errors.join('\n'));fs.writeFileSync(ROOT+'/browser_personal.json',JSON.stringify({results,errors,tooltips:'desktop hover, touch tap, disabled reasons'},null,2));console.log('PASS ALL',results.length)}finally{await browser.close()}})().catch(e=>{console.error(e);process.exit(1)});
