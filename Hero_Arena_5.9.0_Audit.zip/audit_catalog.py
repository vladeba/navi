from pathlib import Path
import sys,json,csv,collections
ROOT=Path(__file__).resolve().parent;G=Path('/workspace/hero-arena-game/hero_arena');sys.path[:0]=[str(G),str(G/'tests')]
from models import HERO_CLASSES
from models.lore import NAMES
from models.minigames_59 import SPECS,PACING
ANCHORS={
'warrior':('armor_fix','Стаскивать крестики за край доспеха'),
'mage':('lightning','Поворачивать проводники: ток через два конденсатора без заземления'),
'archer':('hunt','Стрелять с упреждением: учесть полёт стрелы и ветер'),
'ogre':('feast','Запомнить четыре ингредиента, повторить рецепт, избежать перца'),
'spartan':('shield_wall','Направлять угловой щит против трёх стрел'),
'assassin':('knives','Четыре направленных броска ножей из исходной точки'),
'samurai':('iai_flash','Пропустить две обманки и провести разрез по зелёной вспышке'),
'druid':('forest_call','Переносить отдельных лесных духов в центр призыва'),
'monk':('breaking_palm','Зеркально повторить позу учителя четырьмя суставами'),
'darkelf':('ritual','Найти три пары перевёрнутых рун'),
'owlbeast':('night_hunt','Выдержать фокус на появляющихся глазах перед каждым броском'),
'musketeer':('sniper_shot','Навести и выстрелить при зелёном сигнале цели'),
'pagan':('werewolf','Выбрать зверя и непрерывно начертить его руну'),
'minotaur':('bulwark_charge','Пройти каменный лабиринт кнопками направлений'),
'croc':('shell_puzzle','Совместить поворотные кольца панциря'),
'darkknight':('plague','Три уровня костяного призыва, повороты крыльев перед сборкой дракона'),
'goblin':('cups','Проследить настоящий стакан через четыре перестановки'),
'satyr':('whirl','Выбирать листья среди опасных шипов'),
'ghoul':('hunt_leap','Оттянуть гуля назад и выпустить по предсказанной дуге в добычу'),
'rhino':('stone_armor','Уложить три разные каменные фигуры в сетку без наложений'),
'bogatyr':('bogatyr_strike','Защитник выбирает два направления ухода от богатырского удара'),
'orc':('rage_axe','Три чередующихся разруба поперёк зарубок бревна'),
'dwarf':('fusion','Нагреть, трижды проковать, охладить и закалить металл'),
'lightelf':('light_pillar','Настроить путь луча зеркалами и открыть фазовые ворота'),
'shade':('skull','Стереть все стороны четырёх печатей, удерживая кнопку'),
'aarakocra':('talon','Взмахами удержать высоту птицы и пролететь три кольца'),
'hunter':('traps','Перехватить след на нужной дорожке точно у капкана'),
'gnoll':('bone_dice','Остановить вращающуюся кость на вспышке: число случайное, есть бонус мастерства'),
'centaur':('harp_curse','Играть четыре ноты на четырёх разных струнах'),
'bluetroll':('catch_return','Поймать два возвращающихся клинка на разных дугах'),
'paladin':('dawn_circle','Разложить четыре гири между чашами до равновесия 5/5'),
'catfolk':('pounce','Красться только пока добыча смотрит в другую сторону'),
'beastlord':('axe_storm','Физически раскрутить топоры двумя оборотами указателя'),
'spiderqueen':('web_trap','Растянуть четыре угла сети вокруг трёх целей, не порвав нить'),
'ranger':('spear_throw','Направить один отскок копья в цель за щитом'),
'pandaren':('ignite','Накопить дыхание и отпустить до перегрева; результат по реальному времени'),
'gambler':('card_draw','Слепой выбор одной карты после тасования, разные ситуационные действия'),
'keltazar':('blood_game','Самостоятельно распределить кровь между атакой и лечением с риском отката'),
'feliss':('scale_breach','Отличить треснувшую чешуйку и снять три слоя по стрелкам'),
'cyclops':('stone_flesh','Гасить случайные толчки каменного ядра противоположным движением'),
'mersey':('sentence_end','Совместить три затвора перед исполнением приговора'),
'leon':('composure','После отсчёта читать четыре меняющиеся стойки и бить открытую зону'),
'getou':('puppet_threads','Распутать граф управления существами, убрав пересечения нитей')}
assert set(ANCHORS)==set(HERO_CLASSES)
normal={(r['hero'],r['skill']):r for r in json.loads((ROOT/'ablation_normal10.json').read_text())['rows']}
perfect={(r['hero'],r['skill']):r for r in json.loads((ROOT/'ablation_perfect8.json').read_text())['rows']}
rows=[];games=[];signatures=[]
for k,cls in HERO_CLASSES.items():
 h=cls(k);h.configure_arena();h.reset();t=HERO_CLASSES['warrior']('target');t.configure_arena();t.reset();h.opponent=t;t.opponent=h;h.turn_number=6;h.hp=round(h.max_hp*.6);h.restore_energy(999)
 anchor,objective=ANCHORS[k];signatures.append(dict(hero=k,name=NAMES.get(k,h.name),skill=anchor,objective=objective))
 assert h.skills[anchor].reaction
 for sk,s in h.skills.items():
  key=k,sk
  try:description=s.describe_for(h)
  except Exception:description=s.description
  row=dict(hero=k,hero_name=NAMES.get(k,h.name),skill=sk,name=s.name,cost=s.cost,cooldown=s.cooldown,reaction=s.reaction or '',game=getattr(s,'game',''),description=description,ablation_before_pp=round(normal.get(key,{}).get('delta_pp',0),3),ablation_perfect_before_pp=round(perfect.get(key,{}).get('delta_pp',0),3))
  rows.append(row)
  if not s.reaction:continue
  o=s.public_options(h,t) if hasattr(s,'game') else s.public_options()
  if not isinstance(o,dict):o={}
  mode=o.get('mode') or getattr(s,'game',s.reaction)
  g=dict(row,mode=mode,limit_ms=o.get('time_limit_ms',0),prepare_ms=o.get('prepare_ms',0),signature=sk==anchor,objective=objective if sk==anchor else o.get('instruction',getattr(s,'prompt',description)),reward=o.get('reward',description),paced_factor=PACING.get(key,1))
  g['review']='Сохранена отдельная задача' if sk==anchor and key not in SPECS else 'Заменена личной задачей' if key in SPECS else 'Дополнительная игра, общий приём допустим при наличии личной задачи'
  if mode in ('dice_roll','veil_blind_draw','prayer','read_enemy','blood_split','dir_pick','dodge','squares'):g['review']+='; выбор/случайность, максимум не гарантирован реакцией'
  games.append(g)
for name,data in [('abilities',rows),('minigames',games),('signatures',signatures)]:
 (ROOT/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
 with (ROOT/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print('catalog:',len(rows),'abilities including basic actions;',len(games),'reactions;',len(signatures),'distinct signature objectives;',len(SPECS),'reworked tasks')
