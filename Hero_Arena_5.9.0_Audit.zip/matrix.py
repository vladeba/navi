import argparse,json,time,sys,csv
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import ablation
sys.path.insert(0,'/workspace/hero-arena-review/heroes550');from run_matrix import report

def init(project,quality):
 ablation.init(project,'perfect' if quality=='perfect' else 'normal')
 if quality=='common':
  from models import tuning
  tuning.AI_SKILL.update({k:1.0 for k in ablation.HC})

def job(args):
 a,types,n,base=args;rr=[]
 for b in types:
  results=[];rounds=0
  for i in range(n):
   score,r=ablation.fight(a,b,0,ablation.seed(a,b,0,i,base));results.append(score);rounds+=r
  rr.append(dict(a=a,b=b,n=n,wr=100*sum(results)/n,score=sum(results),outcomes=results,rounds=rounds))
 return rr

def main():
 p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--out',required=True);p.add_argument('--quality',choices=['normal','perfect','common'],default='normal');p.add_argument('--n',type=int,default=40);p.add_argument('--seed',type=int,default=59000);p.add_argument('--workers',type=int,default=4);a=p.parse_args();init(a.project,a.quality);types=list(ablation.HC);out=Path(a.out);rows=[];start=time.monotonic()
 with ProcessPoolExecutor(a.workers,initializer=init,initargs=(a.project,a.quality)) as pool:
  fs={pool.submit(job,(k,types,a.n,a.seed)):k for k in types}
  for i,f in enumerate(as_completed(fs),1):
   rows+=f.result();data=dict(config=vars(a),types=types,rows=rows,seconds=time.monotonic()-start);out.write_text(json.dumps(data));print('%d/%d %s seconds=%.1f'%(i,len(types),fs[f],time.monotonic()-start),flush=True)
 data['summary']=report(rows,types);out.write_text(json.dumps(data));print(json.dumps(data['summary'],indent=2),flush=True)
if __name__=='__main__':main()
