"""Paired non-basic skill ablations, both seats, real Battle engine."""
import argparse,hashlib,json,random,sys,time,math
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed

def init(project,profile):
 sys.path.insert(0,project)
 global HC,Battle,Character,PROFILE
 from models import HERO_CLASSES as HC,Battle,Character,hp_journal
 PROFILE=profile;hp_journal.record=lambda *a:None
 Battle._add_log=lambda *a,**kw:None;Battle._log_many=lambda *a,**kw:None;Battle._capture_arena_result=lambda *a,**kw:None

def seed(a,b,side,i,base):return int.from_bytes(hashlib.sha256(('%s:%s:%s:%s:%s'%(base,a,b,side,i)).encode()).digest()[:8],'big')

def fight(a,b,side,rngseed,disabled=None):
 random.seed(rngseed);Character._next_id=Battle._next_id=1;u,t=HC[a]('A'),HC[b]('B')
 if PROFILE=='perfect':u.perfect=t.perfect=True
 if disabled:
  old=u.can_use;unlocked=u.skill_unlocked
  u.can_use=lambda s:s.key!=disabled and old(s)
  u.skill_unlocked=lambda s:s.key!=disabled and unlocked(s)
 battle=Battle(u,t) if side==0 else Battle(t,u);winner=battle.fight()
 return (1. if winner is u else 0. if winner is t else .5),battle.round

def job(args):
 a,n,base,keys=args;enemies=[b for b in HC if b!=a];baseline={};total=0;rows=[]
 for b in enemies:
  for side in (0,1):
   for i in range(n):
    key=(b,side,i);baseline[key]=fight(a,b,side,seed(a,b,side,i,base));total+=1
 before=sum(x[0] for x in baseline.values())/len(baseline)
 for sk in keys:
  deltas=[];rounds=0;per_pair=[]
  for b in enemies:
   local=[]
   for side in (0,1):
    for i in range(n):
     result,r=fight(a,b,side,seed(a,b,side,i,base),sk);rounds+=r;diff=baseline[b,side,i][0]-result;deltas.append(diff);local.append(diff);total+=1
   per_pair.append(dict(opponent=b,delta_pp=100*sum(local)/len(local)))
  mean=sum(deltas)/len(deltas);var=sum((d-mean)**2 for d in deltas)/max(1,len(deltas)-1);se=(var/len(deltas))**.5
  rows.append(dict(hero=a,skill=sk,profile=PROFILE,n=len(deltas),baseline_wr=100*before,disabled_wr=100*(before-mean),delta_pp=100*mean,paired_ci95_pp=[100*(mean-1.96*se),100*(mean+1.96*se)],mean_rounds_disabled=rounds/len(deltas),pairs=per_pair))
 return rows,total

def main():
 p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--out',required=True);p.add_argument('--n',type=int,default=10);p.add_argument('--seed',type=int,default=59100);p.add_argument('--profile',choices=['normal','perfect'],default='normal');p.add_argument('--workers',type=int,default=6);p.add_argument('--select',help='JSON list of [hero,skill] for targeted rechecks');a=p.parse_args();init(a.project,a.profile)
 selected=json.loads(Path(a.select).read_text()) if a.select else None;tasks=[]
 for hero,cls in HC.items():
  keys=[s.key for s in cls('audit').skills.values() if s.key!='attack' and (selected is None or [hero,s.key] in selected)]
  if keys:tasks.append((hero,a.n,a.seed,keys))
 out=Path(a.out);rows=[];total=0;t=time.monotonic()
 with ProcessPoolExecutor(a.workers,initializer=init,initargs=(a.project,a.profile)) as pool:
  futures={pool.submit(job,x):x[0] for x in tasks}
  for index,f in enumerate(as_completed(futures),1):
   rr,nn=f.result();rows+=rr;total+=nn;data=dict(config=vars(a),fights=total,seconds=time.monotonic()-t,rows=rows);out.write_text(json.dumps(data,ensure_ascii=False));print('%d/%d %s skills=%d fights=%d seconds=%.1f'%(index,len(tasks),futures[f],len(rows),total,time.monotonic()-t),flush=True)
 print('DONE',len(rows),'abilities',total,'fights',flush=True)
 print(json.dumps(sorted([{k:v for k,v in r.items() if k!='pairs'} for r in rows],key=lambda x:-x['delta_pp'])[:25],indent=2))
if __name__=='__main__':main()
