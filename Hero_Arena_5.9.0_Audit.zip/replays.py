"""Browser test-player plans, not game code. Never packaged or trusted as a score."""
import math
from test_variety_59 import winning59
from test_rework_58 import winning58
from test_mechanics_56 import winning
from models.mage_skills import FireballCraftSkill,GolemStackSkill

GAMES56={'hunt_lead_56','knife_flick_56','spirit_guide_56','nest_catch_56','night_focus_56','soul_tether_56','stone_stack_56','shadow_erase_56','light_prism_56','star_pattern_56','dawn_focus_56'}

def plan(s,o):
 g=getattr(s,'game',None);limit=o.get('time_limit_ms',0) if isinstance(o,dict) else 0;c={'elapsed_ms':max(0,limit-5)}
 if g=='arena59':return winning59(s,o)
 if g=='arena58':return winning58(s,o)
 if g in GAMES56:return winning(s,o)
 if s.reaction=='sequence':return list(range(1,7))
 if s.reaction=='dodge':return o[0]
 if s.reaction=='squares':return 0
 if g=='prayer':return next(iter(o['gods']))
 if g=='read_enemy':return next(iter(o['choices']))
 if g=='mage_rune_weave':c['rotations']=o['targets'];return c
 if g=='mage_water_sculpt':c['placements']=[dict(part=i,slot=slot) for i,slot in enumerate(o['target_slots'])];return c
 if g=='mage_ice_weave':c['path']=[0,1,2,3,4,5,0];return c
 if g=='mage_lightning_circuit':c['rotations']=[0]*12;return c
 if g=='mage_fire_core':
  for end in range(2400,4850):
   down=round(.75*end-1500 if end<3333 else end-84/36*1000)
   choice=dict(events=[dict(ms=down,down=True),dict(ms=end,down=False)],elapsed_ms=end)
   if down>=100 and s.tier_from(choice,o)==0:return choice
  raise ValueError('no fire solution')
 if g=='mage_golem_stack':
  c['drops']=[];left,right=100,260;previous=100
  for i,(period,phase) in enumerate(zip(o['periods'],o['phases'])):
   center=(left+right)/2;t=next(t for t in range(previous+120,limit-50) if abs(180+o['amplitude']*math.sin(2*math.pi*(t+phase)/period)-center)<1)
   x=180+o['amplitude']*math.sin(2*math.pi*(t+phase)/period);width=right-left;left=max(left,x-width/2);right=min(right,x+width/2);previous=t;c['drops'].append(t)
  return c
 if g in ('dread_flinch','watchful_nogo'):c['taps']=[f['ms']+90 for f in o['flashes'] if f['true']];return c
 if g=='blood_split':c['attack_percent']=50;return c
 if g in ('blood_tide','slit_gaze','execution_charge'):
  start=450 if g=='execution_charge' else 100;t=next(t for t in range(start,limit-100) if abs(abs(math.sin(2*math.pi*(t+o['phase'])/o['period']))-.8)<o['width']*.25);c['stop_ms']=t
  if g=='execution_charge':c.update(down_ms=100,up_ms=t+100,held_ms=t)
  return c
 if g in ('fang_drift','sentence_hold'):
  from models.rituals_55 import interpolate
  c['points']=[dict(t=t,x=interpolate(o['path'],t)[0],y=interpolate(o['path'],t)[1]) for t in range(0,limit,25)];return c
 if g=='horn_streak':c['taps']=o['beats'];return c
 if g=='stone_balance':
  position=velocity=0;c['points']=[]
  for t in range(0,limit,25):
   for at,kick in o['kicks']:
    if t<=at<t+25:velocity+=kick
   control=max(-1,min(1,-position*6-velocity*3));c['points'].append(dict(t=t,x=180+control*160,y=130));velocity=(velocity+control*.045)*.96;position=max(-1.4,min(1.4,position+velocity*.12))
  return c
 if g=='blade_orbits':
  c['stop_ms']=next(t for t in range(100,limit-20) if abs(((2*math.pi*(t+o['phases'][0])/o['periods'][0]-2*math.pi*(t+o['phases'][1])/o['periods'][1])+math.pi)%(2*math.pi)-math.pi)<.04);return c
 if g=='king_risk':c.update(down_ms=100,up_ms=3900,held_ms=3800);return c
 if g=='predator_afterimage':c.update(x=o['target'][0],y=o['target'][1],elapsed_ms=o['show_ms']+250);return c
 if g=='royal_read':c['attacks']=[dict(ms=p['start']+150,lane=p['open']) for p in o['stances']];return c
 if g=='flesh_suture':
  period=o['suture_period'];c['stitches']=[dict(down_ms=round(100+i*period),up_ms=round(100+i*period+period*.625)) for i in range(4)];return c
 if g in ('raise_bones','raise_zombie','build_homunculus'):
  c['placements']=[];last=100
  for part,slot in enumerate(o['slots']):
   end=last+400
   if o.get('locks'):
    period,phase=o['locks'][part]
    end=next(t for t in range(end,limit-25) if abs(math.sin(2*math.pi*(t+phase)/period))<o['lock_width']*.25)
   c['placements'].append(dict(part=part,slot=slot,ms=end));last=end+100
  return c
 if g=='puppet_threads':c['nodes']=[[180+110*math.cos(i*math.pi/4),130+100*math.sin(i*math.pi/4)] for i in range(8)];return c
 # Legacy controls report these values only after their real UI actions.
 if g=='drag_crosses':c['removed']=len(o['crosses']);return c
 if g=='memory':c['picked']=o['sequence'];return c
 if g=='arrows_seq':c['hits']=len(o['sequence']);return c
 if g=='rune_draw':c.update(form='wolf',points=5);return c
 if g=='rhythm':c['hits']=len(o['beats_ms']);return c
 if g=='hold_zone':c['in_zone']=.95;return c
 if g=='rings':c['aligned']=3;return c
 if g=='hold_release':c['charge']=sum(o['perfect'])/2;return c
 if g=='cups':
  cup=o['start']
  for a,b in o['swaps']:
   if cup==a:cup=b
   elif cup==b:cup=a
  c['cup']=cup;return c
 if g=='timing_multi':c.update(hits=o['presses'],perfect=o['presses'],ms=round(o['period_ms']*o['zone']));return c
 if g=='click_good_bad':c.update(good=sum(bool(i['good']) for i in o['items']),bad=0);return c
 if g=='order_click':c['done']=len(o['points']);return c
 if g=='dir_pick':c['picked']=o['dirs'][:o.get('pick_count',2)];return c
 if g=='dice_roll':c.update(roll=3,base_roll=3,mastery=True,error_ms=0);return c
 if g=='dual_stop':c.update(hits=2,stops=[dict(ok=True,perfect=True,err=0)]*2);return c
 if g=='boomerang_dual':c['catches']=[dict(i=i,error_ms=0) for i in range(2)];return c
 if g=='veil_blind_draw':return dict(pick=0)
 if g=='splash_aim':c['hits']=o['count'];return c
 if g in ('breath_hold','judgment_scale'):c.update(error_ms=0,ratio=.72);return c
 raise NotImplementedError(g or s.reaction)
