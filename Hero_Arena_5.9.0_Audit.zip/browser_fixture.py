"""Only a local browser fixture, excluded from release packages."""
import sys,time,json
from pathlib import Path
sys.path.insert(0,'/workspace/hero-arena-game/hero_arena');sys.path.insert(0,'/workspace/hero-arena-game/hero_arena/tests')
from app import app
from flask import jsonify,request
from models import HERO_CLASSES
from models.minigames_59 import SPECS
from replays import plan
from test_variety_59 import winning59
from test_rework_58 import winning58
from test_mechanics_56 import winning

@app.get('/audit/games')
def games():
 result=[];kind=request.args.get('kind')
 for k,cls in HERO_CLASSES.items():
  h=cls(k);h.configure_arena();h.reset();h.turn_number=6;h.restore_energy(999);h.hp=round(h.max_hp*.6);t=HERO_CLASSES['warrior']('target');t.configure_arena();t.reset();h.opponent=t;t.opponent=h
  for s in h.skills.values():
   if not s.reaction:continue
   if kind and getattr(s,'game',None)!=kind:continue
   o=s.public_options(h,t) if hasattr(s,'game') else s.public_options()
   try:choice=plan(s,o)
   except Exception as e:choice=dict(error=str(e))
   result.append(dict(hero=k,skill=s.key,name=s.name,game=getattr(s,'game',None),reaction=s.reaction,options=o,win=choice,me=h.to_dict(),foe=t.to_dict()))
 return jsonify(result)
@app.post('/audit/grade')
def grade():
 d=request.json;h=HERO_CLASSES[d['hero']]('h');s=h.skills[d['skill']]
 if not hasattr(s,'tier_from'):return jsonify(accepted=s.check_choice(d['choice']) is not None,tier=None)
 try:q=s.tier_from(d['choice'],d['options']);return jsonify(tier=q)
 except Exception as e:return jsonify(error=str(e),tier=None)
app.run(host='127.0.0.1',port=5590,debug=False,use_reloader=False)
