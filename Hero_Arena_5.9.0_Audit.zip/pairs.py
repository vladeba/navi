import sys,json,argparse,time
from pathlib import Path
import ablation
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--out',required=True);p.add_argument('--n',type=int,default=400);a=p.parse_args();root=Path(__file__).resolve().parent
source=json.loads((root/'probe40.json').read_text());lookup={(r['a'],r['b']):r['wr'] for r in source['rows']};types=source['types'];pairs=[]
for i,x in enumerate(types):
 for y in types[i+1:]:
  wr=(lookup[x,y]+100-lookup[y,x])/2;pairs.append((abs(wr-50),x,y))
pairs=sorted(pairs,reverse=True)[:20]
ablation.init(a.project,'normal');rows=[];start=time.monotonic()
for _,x,y in pairs:
 scores=[];rounds=0
 for side in (0,1):
  for i in range(a.n):
   r,t=ablation.fight(x,y,side,ablation.seed(x,y,side,i,59550));scores.append(r);rounds+=t
 mean=sum(scores)/len(scores);se=(sum((v-mean)**2 for v in scores)/(len(scores)-1)/len(scores))**.5
 rows.append(dict(a=x,b=y,n=len(scores),wr=100*mean,ci95=[100*(mean-1.96*se),100*(mean+1.96*se)],rounds=rounds/len(scores)));Path(a.out).write_text(json.dumps(dict(config=vars(a),fights=sum(r['n'] for r in rows),seconds=time.monotonic()-start,rows=rows)));print(x,y,round(mean*100,1),flush=True)
