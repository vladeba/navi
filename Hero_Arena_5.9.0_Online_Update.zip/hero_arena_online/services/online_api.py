"""Anonymous session cookies authorize seats, never hero IDs from the client."""
import hashlib
from version import APP_VERSION
import secrets
from flask import Blueprint,jsonify,request,render_template,make_response
from .online_rooms import OnlineRooms,RoomError

COOKIE='hero_arena_online'

def online_blueprint(rooms=None):
    rooms=rooms or OnlineRooms()
    bp=Blueprint('online',__name__)

    @bp.errorhandler(RoomError)
    def error(exc):return jsonify(error=str(exc)),exc.status

    @bp.before_request
    def protect():
        if request.path.startswith('/api/online/') and request.method=='POST':
            if request.headers.get('X-Arena-Client')!='online':raise RoomError('Неверный источник запроса',403)
            if not request.is_json:raise RoomError('Ожидается JSON')
            origin=request.headers.get('Origin')
            if origin and origin.rstrip('/')!=request.host_url.rstrip('/'):raise RoomError('Неверный источник запроса',403)
            if request.content_length and request.content_length>131072:raise RoomError('Слишком большой запрос',413)

    @bp.after_request
    def headers(response):
        response.headers['Cache-Control']='no-store'
        response.headers['Referrer-Policy']='same-origin'
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['X-Frame-Options']='DENY'
        return response

    def session():
        raw=request.cookies.get(COOKIE,'')
        if len(raw)<32 or len(raw)>100:raise RoomError('Сначала создайте комнату или войдите по приглашению',403)
        return hashlib.sha256(raw.encode()).hexdigest()

    def data():
        d=request.get_json(silent=True)
        if not isinstance(d,dict):raise RoomError('Ожидается JSON-объект')
        return d

    def enter(fn):
        raw=request.cookies.get(COOKIE,'')
        if len(raw)<32 or len(raw)>100:raw=secrets.token_urlsafe(32)
        out=fn(hashlib.sha256(raw.encode()).hexdigest())
        response=jsonify(out);response.set_cookie(COOKIE,raw,max_age=7*86400,httponly=True,secure=request.is_secure,samesite='Lax',path='/')
        return response

    @bp.get('/online')
    @bp.get('/online/r/<code>')
    def page(code=None):
        response=make_response(render_template('index.html',app_version=APP_VERSION,online_mode=True))
        raw=request.cookies.get(COOKIE,'')
        if len(raw)<32 or len(raw)>100:
            response.set_cookie(COOKIE,secrets.token_urlsafe(32),max_age=7*86400,httponly=True,secure=request.is_secure,samesite='Lax',path='/')
        return response

    @bp.get('/api/online/roster')
    def roster():return jsonify(rooms.roster())

    @bp.post('/api/online/rooms')
    def create():
        d=data();return enter(lambda s:rooms.create(s,d.get('name','Игрок')))

    @bp.post('/api/online/rooms/<code>/join')
    def join(code):
        d=data();return enter(lambda s:rooms.join(code,s,d.get('name','Друг')))

    @bp.get('/api/online/rooms/<code>')
    def state(code):return jsonify(rooms.state(code,session()))

    @bp.post('/api/online/rooms/<code>/<action>')
    def mutate(code,action):return jsonify(rooms.mutate(code,session(),action,data()))

    bp.rooms=rooms
    return bp
