"""Private two-player rooms. Combat stays in the existing Battle engine."""
import copy
import hashlib
import json
import secrets
from random import Random
import threading
import time
from collections import OrderedDict
from models import HERO_CLASSES, Battle
from models.heroes_new import DEV_ARENA_MOB_KEYS

PLAYABLE = {k:c for k,c in HERO_CLASSES.items() if k not in DEV_ARENA_MOB_KEYS}

class RoomError(Exception):
    def __init__(self,message,status=400):
        super().__init__(message);self.status=status

class OnlineRooms:
    TURN_SECONDS=90
    PREPARE_SECONDS=15
    IDLE_SECONDS=7200
    MAX_ROOMS=256

    def __init__(self,clock=time.time):
        self.rooms={};self.lock=threading.RLock();self.clock=clock

    def roster(self):
        result=[]
        for key,cls in PLAYABLE.items():
            info=cls.class_info();info.update(type=key,locked=False,required_wins=0)
            result.append(info)
        return result

    def _member(self,session,name='Игрок'):
        name=name.strip() if isinstance(name,str) else ''
        if not 1<=len(name)<=24:raise RoomError('Имя должно содержать от 1 до 24 символов')
        return dict(session=session,name=name,hero='warrior',ready=False,last_seen=self.clock())

    def _find(self,code,session):
        room=self.rooms.get(code)
        if not room:raise RoomError('Комната не найдена или уже закрыта',404)
        if self.clock()-room['touched']>self.IDLE_SECONDS:
            del self.rooms[code];raise RoomError('Срок жизни комнаты истёк',410)
        seat=next((i for i,m in enumerate(room['members']) if m['session']==session),None)
        return room,seat

    def create(self,session,name):
        with self.lock:
            now=self.clock()
            self.rooms={k:r for k,r in self.rooms.items() if now-r['touched']<=self.IDLE_SECONDS}
            # One current room per anonymous browser, without erasing active duels.
            for room in self.rooms.values():
                if any(m['session']==session for m in room['members']) and room['phase']!='finished':
                    raise RoomError('У вас уже есть комната. Вернитесь в неё или покиньте её',409)
            if len(self.rooms)>=self.MAX_ROOMS:raise RoomError('Сервер занят. Попробуйте позже',503)
            code=secrets.token_urlsafe(18)
            room=dict(code=code,members=[self._member(session,name)],phase='waiting',revision=1,
                      battle=None,match=0,pending_ref=None,pending_id=0,started=False,deadline=None,
                      touched=now,requests=OrderedDict())
            self.rooms[code]=room
            return self._view(room,0)

    def join(self,code,session,name):
        with self.lock:
            room,seat=self._find(code,session)
            if seat is not None:return self._view(room,seat)
            if len(room['members'])>=2:raise RoomError('В комнате уже два игрока',409)
            room['members'].append(self._member(session,name));room['revision']+=1
            room['touched']=self.clock()
            return self._view(room,1)

    def state(self,code,session):
        with self.lock:
            room,seat=self._find(code,session)
            if seat is None:raise RoomError('Войдите в комнату по приглашению',403)
            room['members'][seat]['last_seen']=self.clock();room['touched']=self.clock()
            self._expire(room)
            return self._view(room,seat)

    def _arm(self,room):
        b=room['battle']
        if not b:return
        if b.finished:
            room['phase']='finished';room['deadline']=None
            room['pending_ref']=None
            for m in room['members']:m['ready']=False
        elif b.pending is not room['pending_ref']:
            room['pending_ref']=b.pending;room['started']=False
            if b.pending:
                room['pending_id']+=1;room['deadline']=self.clock()+self.PREPARE_SECONDS
            else:room['deadline']=self.clock()+self.TURN_SECONDS
        elif room['deadline'] is None:room['deadline']=self.clock()+self.TURN_SECONDS

    def _expire(self,room):
        b=room['battle']
        if not b or b.finished or self.clock()<(room['deadline'] or float('inf')):return
        if b.pending:
            skill=b.pending['skill'];reactor=b.pending['reactor']
            if skill.reaction in ('minigame','sequence'):
                try:skill.check_choice('timeout')
                except ValueError:b.surrender(reactor)
                else:b.react('timeout')
            else:b.surrender(reactor)
        else:b.surrender(b.current)
        room['revision']+=1;room['deadline']=None;self._arm(room)

    def mutate(self,code,session,action,data):
        with self.lock:
            room,seat=self._find(code,session)
            if seat is None:raise RoomError('Это не ваша комната',403)
            self._expire(room)
            nonce=data.get('request_id')
            if not isinstance(nonce,str) or not 8<=len(nonce)<=80:raise RoomError('Нужен идентификатор действия')
            digest=hashlib.sha256(json.dumps([seat,action,data],sort_keys=True).encode()).hexdigest()
            if nonce in room['requests']:
                if room['requests'][nonce]!=digest:raise RoomError('Идентификатор действия уже использован',409)
                return self._view(room,seat)
            version=data.get('revision')
            if type(version) is not int or version!=room['revision']:raise RoomError('Состояние боя изменилось. Обновите комнату',409)
            m=room['members'][seat];b=room['battle']
            if action=='choose':
                if room['phase']=='playing':raise RoomError('Героя можно менять между боями',409)
                key=data.get('hero')
                if not isinstance(key,str) or key not in PLAYABLE:raise RoomError('Выберите игрового героя. Мобы недоступны')
                m['hero']=key;m['ready']=False
            elif action=='ready':
                if room['phase']=='playing':raise RoomError('Бой уже начался',409)
                if type(data.get('ready')) is not bool:raise RoomError('ready должен быть true или false')
                m['ready']=data['ready']
                if len(room['members'])==2 and all(x['ready'] for x in room['members']):
                    heroes=[PLAYABLE[x['hero']](x['name']) for x in room['members']]
                    b=Battle(*heroes,mode='manual');b.rng=Random(secrets.randbits(128));b.test_arena=True;b.start()
                    room.update(battle=b,phase='playing',match=room['match']+1,pending_ref=None,deadline=None)
                    self._arm(room)
            elif action in ('turn','begin','react','surrender'):
                if not b or b.finished:raise RoomError('Сейчас нет активного боя',409)
                own=(b.hero1,b.hero2)[seat]
                if action=='surrender':b.surrender(own)
                elif action=='turn':
                    if b.pending or b.current is not own:raise RoomError('Сейчас ход соперника',403)
                    skill=data.get('skill')
                    if not isinstance(skill,str) or len(skill)>80:raise RoomError('Выберите способность')
                    target=data.get('target_id')
                    if target is not None and (not isinstance(target,str) or len(target)>80):raise RoomError('Неверная цель')
                    self._combat(room,lambda:b.play_turn(skill,target_id=target))
                else:
                    if not b.pending or b.pending['reactor'] is not own:raise RoomError('Сейчас отвечает соперник',403)
                    if type(data.get('pending_id')) is not int or data['pending_id']!=room['pending_id']:raise RoomError('Эта мини-игра уже закончилась',409)
                    if action=='begin':
                        if not room['started']:
                            room['started']=True
                            options=b.pending['options']
                            limit=(options.get('time_limit_ms',0) if isinstance(options,dict) else 0) or 20000
                            room['deadline']=self.clock()+limit/1000+1.5
                            secret=b.pending['secret']
                            if isinstance(secret,dict):secret.update(started=self.clock(),deadline=room['deadline'])
                            elif b.pending['skill'].reaction=='sequence':b.pending['secret']=room['deadline']
                    else:
                        if not room['started']:raise RoomError('Сначала начните мини-игру',409)
                        self._combat(room,lambda:b.react(data.get('choice')))
                # Each completed action gets a fresh turn clock, including extra turns.
                if action not in ('begin',):room['deadline']=None
                self._arm(room)
            elif action=='leave':
                if b and not b.finished:b.surrender((b.hero1,b.hero2)[seat])
                del self.rooms[code]
                return dict(closed=True)
            else:raise RoomError('Неизвестное действие',404)
            room['revision']+=1;room['touched']=self.clock();m['last_seen']=self.clock()
            room['requests'][nonce]=digest
            while len(room['requests'])>64:room['requests'].popitem(last=False)
            return self._view(room,seat)

    def _combat(self,room,perform):
        # Legacy minigames must not leave a half-applied action after malformed JSON.
        from models import hp_journal
        snapshot=copy.deepcopy(room['battle']);journal=hp_journal.journal();mark=len(journal)
        try:perform()
        except (ValueError,TypeError,KeyError,IndexError,OverflowError) as exc:
            room['battle']=snapshot;room['pending_ref']=snapshot.pending
            del journal[mark:]
            raise RoomError('Некорректное действие или ответ мини-игры') from exc

    def _view(self,room,seat):
        b=room['battle'];state=copy.deepcopy(b.to_dict()) if b else None
        if state:
            own=(b.hero1,b.hero2)[seat]
            if b.pending and b.pending['reactor'] is not own:state['pending']['options']={}
            state['online_hero_id']=own.id
        return dict(code=room['code'],seat=seat,phase=room['phase'],revision=room['revision'],
                    match=room['match'],battle=state,pending_id=room['pending_id'],
                    reaction_started=room['started'],deadline=room['deadline'],server_time=self.clock(),
                    members=[dict(name=m['name'],hero=m['hero'],ready=m['ready'],connected=self.clock()-m['last_seen']<15) for m in room['members']])
