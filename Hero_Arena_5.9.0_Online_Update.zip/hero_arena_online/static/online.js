/* Session-authorized two-player rooms, polling without restarting reactions. */
(function(){
'use strict';
let room=null,inFlight=false,polling=false,reactionKey=null,localReaction=null,requestKey=null,lastBattle=null;
const lobby=document.getElementById('onlineLobby');
const pathCode=location.pathname.match(/^\/online\/r\/([A-Za-z0-9_-]+)$/)?.[1];
let code=pathCode||localStorage.getItem('arenaOnlineRoom');
const url=action=>`/api/online/rooms/${encodeURIComponent(code)}${action?'/'+action:''}`;
const uuid=()=>crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2)}`;
async function call(path,method='GET',data){
 const response=await fetch(path,{method,credentials:'same-origin',headers:{'Content-Type':'application/json','X-Arena-Client':'online'},body:data===undefined?undefined:JSON.stringify(data)});
 const value=await response.json();if(!response.ok){const e=new Error(value.error||'Не удалось выполнить действие');e.status=response.status;throw e}return value;
}
function stopGame(){if(typeof mg!=='undefined'&&mg){mg.done=true;for(const t of mg.timers||[]){clearTimeout(t);clearInterval(t)}if(mg.raf)cancelAnimationFrame(mg.raf)}if(typeof seq!=='undefined'&&seq?.timer)clearTimeout(seq.timer);hideModal();reactionKey=null;localReaction=null}
function intro(message=''){
 lobby.innerHTML=`<h2>🤝 Дуэль с другом</h2><p>Создайте комнату и отправьте другу ссылку. Все 43 героя доступны сразу, включая монаха и Совуха. Мобов в выборе нет.</p>${message?`<p class="online-error">${esc(message)}</p>`:''}<div class="row"><input id="onlineName" placeholder="Ваше имя" maxlength="24" value="${esc(localStorage.getItem('arenaOnlineName')||'Игрок')}"><button class="btn" id="onlineEnter">${pathCode?'Присоединиться':'Создать приглашение'}</button></div>`;
 document.getElementById('onlineEnter').onclick=async()=>{if(inFlight)return;inFlight=true;const name=document.getElementById('onlineName').value.trim();try{localStorage.setItem('arenaOnlineName',name);const value=await call(pathCode?url('join'):'/api/online/rooms','POST',{name});code=value.code;localStorage.setItem('arenaOnlineRoom',code);history.replaceState(null,'','/online/r/'+code);await accept(value,true)}catch(e){toast(e.message)}finally{inFlight=false}};
}
async function mutate(action,extra={}){
 if(inFlight||!room)return null;
 inFlight=true;const payload={...extra,revision:room.revision,request_id:uuid()};
 try{const value=await call(url(action),'POST',payload);if(value.closed){localStorage.removeItem('arenaOnlineRoom');location.href='/online';return value}await accept(value);return value}
 catch(e){toast(e.message);await poll(true);return null}finally{inFlight=false}
}
function lobbyView(){
 const own=room.members[room.seat],playing=room.phase==='playing';
 const invite=location.origin+'/online/r/'+room.code;
 const members=room.members.map((m,i)=>`<div class="online-member"><b>${esc(m.name)}${i===room.seat?' · вы':''}</b><div>${esc(classes.find(c=>c.type===m.hero)?.hero_class||m.hero)}</div><div class="muted">${m.connected?'● на связи':'○ связь потеряна'} · ${m.ready?'готов':'выбирает героя'}</div></div>`).join('');
 lobby.innerHTML=`<div class="row" style="justify-content:space-between"><h2>🤝 Дуэль с другом</h2><button class="btn ghost small" id="onlineLeave">Закрыть комнату</button></div><div class="row"><input id="onlineLink" readonly aria-label="Ссылка приглашения" value="${esc(invite)}"><button class="btn small" id="onlineCopy">Копировать ссылку</button></div><div class="online-members">${members}${room.members.length===1?'<div class="online-member muted">Ждём друга по ссылке…</div>':''}</div><div id="onlineStatus"></div><div id="onlineClock"></div>${playing?'':`<p class="muted">Все игровые герои открыты. Одинаковые правила арены, без уровней и предметов из сохранения.</p><div class="row"><input id="onlineSearch" placeholder="Найти героя"><button class="btn" id="onlineReady">${own.ready?'Отменить готовность':room.match?'Готов к реваншу':'Готов к бою'}</button></div><div class="online-grid" id="onlineRoster"></div>`}`;
 document.getElementById('onlineCopy').onclick=async()=>{try{await navigator.clipboard.writeText(invite);toast('Ссылка скопирована')}catch{document.getElementById('onlineLink').select();toast('Скопируйте выделенную ссылку')}};
 document.getElementById('onlineLeave').onclick=()=>{if(confirm('Закрыть комнату для обоих игроков? Текущий бой закончится сдачей.'))mutate('leave')};
 if(!playing){const roster=document.getElementById('onlineRoster');function draw(){const search=document.getElementById('onlineSearch').value.toLowerCase();roster.innerHTML=classes.filter(c=>(c.hero_class+' '+(c.name||'')).toLowerCase().includes(search)).map(c=>`<button class="online-hero" data-hero="${c.type}" aria-pressed="${own.hero===c.type}"><img loading="lazy" src="/images/${c.type}" alt=""><span>${esc(c.hero_class)}</span></button>`).join('');roster.querySelectorAll('button').forEach(b=>b.onclick=()=>mutate('choose',{hero:b.dataset.hero}))}draw();document.getElementById('onlineSearch').oninput=draw;document.getElementById('onlineReady').onclick=()=>mutate('ready',{ready:!own.ready})}
 clock();
}
function clock(){if(!room)return;const b=room.battle;const el=document.getElementById('onlineClock');if(el){const left=room.deadline?Math.max(0,Math.ceil((room.deadline-(Date.now()/1000+room._offset)))):null;el.textContent=left===null?'':`${b?.pending?'На ответ':'На ход'}: ${left} с`}}
const originalPending=showPending;
showPending=function(b){
 const p=b.pending;if(!p||p.hero_id!==b.online_hero_id){hideModal();return}
 const key=`${room.match}:${room.pending_id}`;
 if(reactionKey===key)return;
 reactionKey=key;
 if(room.reaction_started){
  // An already-started game is never regenerated after reload or in another tab.
  openBox('<h3>Мини-игра уже началась</h3><p>Завершите её в открытой вкладке или дождитесь окончания времени.</p><button class="btn ghost" id="onlineSkip">Пропустить ответ</button>');
  document.getElementById('onlineSkip').onclick=()=>['minigame','sequence'].includes(p.type)?mutate('react',{pending_id:room.pending_id,choice:'timeout'}):mutate('surrender');return;
 }
 openBox('<h3>Ваш ответ</h3><p>'+esc(p.skill)+'</p><button class="btn" id="onlineBegin">Начать</button>');
 document.getElementById('onlineBegin').onclick=async()=>{const value=await mutate('begin',{pending_id:room.pending_id});if(value&&value.battle?.pending){localReaction=key;originalPending(value.battle)}};
};
const originalSkills=renderSkills;
renderSkills=function(b){
 originalSkills(b);
 const ctl=document.getElementById('battleCtl');ctl.innerHTML=b.status==='active'?'<button class="btn small ghost" onclick="surrender()">🏳 Сдаться</button>':'';
 if(b.status==='active'&&b.current_hero_id!==b.online_hero_id)document.getElementById('skillBox').innerHTML=`<p class="muted">${b.pending?(b.pending.hero_id===b.online_hero_id?'Ваш ответ в окне мини-игры':'Соперник выполняет мини-игру…'):'Ход соперника…'}</p>`;
};
const originalFighters=renderFighters;
renderFighters=function(b,...args){originalFighters(b,...args);if(b.current_hero_id!==b.online_hero_id)document.querySelectorAll('.target55').forEach(e=>e.remove())};
showResult=function(b){document.getElementById('banner').textContent=b.draw?'🤝 Ничья':b.cancelled?'Бой отменён':`🏆 Победил ${b.winner}`;document.getElementById('banner').style.display='block';document.getElementById('skillBox').innerHTML='<p>Выберите героя и подтвердите готовность к реваншу выше.</p>'};
send=async function(path,data){if(busy)return;const action=path.split('/').at(-1);stopGame();const result=await mutate(action,{...data,pending_id:room?.pending_id});if(!result&&room?.battle){reactionKey=null;renderSkills(room.battle);showPending(room.battle)}};
surrender=async()=>{if(confirm('Сдаться?'))await mutate('surrender')};
cancelBattle=surrender;
// Suppress local-account refreshes from shared UI helpers.
loadPlayers=loadHeroes=loadClasses=checkActive=async()=>{};
shop={consumables:[],skins:{}};ensureShop=async()=>{};
async function accept(value,first=false){
 value._offset=value.server_time-Date.now()/1000;const changed=!room||value.revision!==room.revision;room=value;
 if(changed||first)lobbyView();else{
  document.querySelectorAll('.online-member .muted').forEach((el,i)=>{const m=room.members[i];if(m)el.textContent=`${m.connected?'● на связи':'○ связь потеряна'} · ${m.ready?'готов':'выбирает героя'}`});clock();
 }
 if(!room.battle)return;
 const status=document.getElementById('onlineStatus'),current=room.battle;
 if(status)status.textContent=current.status!=='active'?'Бой окончен — можно сыграть реванш':current.pending?(current.pending.hero_id===current.online_hero_id?'Выполните свой ответ':'Ждём ответ соперника'):current.current_hero_id===current.online_hero_id?'Ваш ход':'Ход соперника';
 const b=room.battle,newBattle=lastBattle!==b.id;
 if(newBattle){stopGame();battle=null;resetArena();lastBattle=b.id;shownLog=0;shownHp={}}
 document.getElementById('arenaPanel').style.display='block';
 if(!changed&&!first)return;
 if(!b.pending||`${room.match}:${room.pending_id}`!==reactionKey){stopGame()}
 // Avoid replaying long animations while the other browser is waiting on a short reaction.
 fast=true;await update(b,newBattle);fast=false;
 const s=document.getElementById('onlineStatus');if(s)s.textContent=b.status!=='active'?'Бой окончен — можно сыграть реванш':b.pending?(b.pending.hero_id===b.online_hero_id?'Выполните свой ответ':'Ждём ответ соперника'):b.current_hero_id===b.online_hero_id?'Ваш ход':'Ход соперника';
}
async function poll(force=false){if(!code||polling||(!force&&(!room||inFlight||busy)))return;polling=true;try{const value=await call(url());await accept(value);const s=document.getElementById('onlineStatus');if(s)s.classList.remove('online-error')}catch(e){if([403,404,410].includes(e.status)){stopGame();room=null;if(!pathCode)localStorage.removeItem('arenaOnlineRoom');intro(e.status===403?'Откройте приглашение, чтобы занять место.':e.message);code=pathCode||null}else{const s=document.getElementById('onlineStatus');if(s){s.textContent='Связь потеряна. Пытаемся восстановить…';s.classList.add('online-error')}}}finally{polling=false}}
async function boot(){try{classes=await call('/api/online/roster');if(code)await poll(true);else intro()}catch(e){intro('Сервер недоступен. Обновите страницу после восстановления связи.')}}
setInterval(()=>poll(),700);setInterval(clock,250);window.addEventListener('online',()=>poll(true));document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll(true)});boot();
})();
