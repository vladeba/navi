@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
if not exist "share_online.py" goto missing_files
if not exist ".venv-online\Scripts\python.exe" goto missing_python
".venv-online\Scripts\python.exe" share_online.py
pause
exit /b
:missing_files
echo Extract the game ZIP completely. Keep this BAT next to share_online.py.
pause
exit /b 1
:missing_python
echo Run start_online.bat first. Leave its window open, then run this BAT.
pause
exit /b 1
