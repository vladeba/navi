"""4.0: новые герои — Мушкетёр Рейв, Язычник Даагаш, Минотавр Кэрн, Крок, Тёмный рыцарь Мордред —
и мобы сюжета «Тёмный лес» (волк, призрачный кот, кровавый медведь, босс-друид)."""
import random

from .character import Character, Druid, HERO_CLASSES
from .effects import (Announcement, Shield, Stun, Bleed, Burn, Slow, Blinded, Chill, DamageReduction,
                      GodGift, BeastForm, ShellStance, FearAura, Undying, DodgeBuff, Antiheal, Berserk, Regeneration, Poison)
from .skills import DamageSkill, SelfBuffSkill, DebuffSkill, SummonSkill, HealSkill, Skill, scale_effect, MiniGameSkill
from .minigames import (DuelShotSkill, PrayerSkill, WerewolfSkill, DrumsSkill, DeathRollSkill, ShellPuzzleSkill,
                        TemperSkill)
from .minigames_54 import SoulSiphonSkill
from .summons import SkeletonSquad


# ======================= Мушкетёр Рейв =======================
class ReloadSkill(Skill):
    """Перезарядка: ставит заряд обратно и даёт +10% уклонения до следующего хода. Тратит ход."""

    copyable = False

    def is_available(self, user):
        return super().is_available(user) and not getattr(user, 'loaded', True)

    def _perform(self, user, target):
        user.loaded = True
        user.add_effect(DodgeBuff(1, 10))
        return [f"🔫 {user.name} перезаряжает мушкет (+10% уклонения до следующего хода)."]

    def ai_score(self, user, target):
        return 0 if getattr(user, "loaded", True) else 14


class LoadedShot(DamageSkill):
    """Выстрел, которому нужен заряд ружья; после выстрела ружьё разряжено."""

    copyable = False

    def is_available(self, user):
        return super().is_available(user) and getattr(user, 'loaded', False)

    def _perform(self, user, target):
        user.loaded = False
        return super()._perform(user, target) + [f"🔫 Ружьё {user.name} разряжено."]


class Musketeer(Character):
    """Мушкетёр Рейв: бьёт редко, но сильно — мощный выстрел, потом перезарядка (пока не заряжен — уязвим)."""

    hero_class, type_key, resource_name = "Мушкетёр", "musketeer", "порох"
    signature_skill = "musket_shot"
    role = "light"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=201, base_damage=17.2, armor=1, level=level,
                         speed=5, dodge=0.05, crit_chance=0.1,
                         max_energy=60, energy_regen=8, start_energy=40)
        self.loaded = True

    def _create_skills(self):
        return [
            DamageSkill("attack", "Приклад", "Обычный удар прикладом ×0.8", multiplier=0.8, accuracy=0.9, icon="🪵"),
            LoadedShot("musket_shot", "Мушкетный выстрел", "×2.0, точность 85%, игнорирует 50% брони. Нужен заряд",
                       multiplier=2.0, accuracy=0.85, armor_pierce=0.5, cost=20, icon="🔫"),
            ReloadSkill("reload", "Перезарядка", "Заряжает ружьё, +10% уклонения до следующего хода (тратит ход)",
                        icon="🔄"),
            DamageSkill("pistol", "Пистолет", "×1.0, точность 90%, заряд ружья не нужен", multiplier=1.0,
                        accuracy=0.9, cost=5, icon="🔫"),
            DamageSkill("bayonet", "Штык-удар", "×1.3, 25% замедлить врага на 2 хода", multiplier=1.3,
                        effect=lambda: Slow(2, 2), effect_chance=0.25, cost=10, cooldown=1, icon="🗡"),
            DamageSkill("buckshot", "Картечь", "3 попадания по ×0.7, точность 75% — хороша против уклонения",
                        multiplier=0.7, hits=3, accuracy=0.75, cost=25, cooldown=4, icon="💥"),
            DuelShotSkill("duel_shot", "Дуэльный выстрел", "Мини-игра: упреждение по движущейся цели. Центр — ×2.6 "
                          "сквозь броню, кольцо — ×1.9, промах — осечка. Нужен заряд",
                          cost=20, cooldown=6, icon="🎯"),
        ]

    def _on_reset(self):
        self.loaded = True

    def describe(self):
        return super().describe() + (", 🔫 заряжено" if self.loaded else ", 🔫 разряжено")

    def to_dict(self):
        data = super().to_dict()
        data["loaded"] = self.loaded
        return data


# ======================= Язычник Даагаш =======================
class Pagan(Character):
    """Язычник Даагаш: поклоняется старым богам. «Молитва» — дар одного из двух богов; «Оборотень» — волк, медведь или ворон."""

    hero_class, type_key, resource_name = "Язычник", "pagan", "вера"
    signature_skill = "thunder"
    role = "warrior"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=207, base_damage=15.8, armor=2, level=level,
                         speed=5, dodge=0.08, crit_chance=0.1,
                         max_energy=100, energy_regen=10, start_energy=50)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар посохом", "Обычная атака (меняется в форме зверя)", accuracy=0.88, icon="🦴"),
            PrayerSkill("prayer", "Молитва", "Выберите одного из двух случайных богов — его дар на 3 хода "
                        "(Перун, Велес, Мокошь, Морена)", cost=0, cooldown=4, icon="🙏"),
            DamageSkill("thunder", "Гром Перуна", "×1.8, точность 80%, 20% оглушить", multiplier=1.8, accuracy=0.8,
                        effect=lambda: Stun(1), effect_chance=0.2, cost=25, cooldown=3, icon="⚡"),
            SelfBuffSkill("mokosh_cover", "Покров Мокоши", "Щит 10% HP на 3 хода",
                          effects=[lambda: Shield(3, int(self.max_hp * 0.10 / self.power_scale()))],
                          cost=20, cooldown=4, icon="🌾"),
            DebuffSkill("veles_whisper", "Шёпот Велеса", "Проклятие: точность врага −15% на 3 хода",
                        effect=lambda: Blinded(3, 15), cost=15, cooldown=4, icon="🐍"),
            DamageSkill("morena_frost", "Стужа Морены", "Холод 4 урона в ход на 3 хода (сквозь броню)",
                        multiplier=0.5, ignore_armor=True, effect=lambda: Chill(3, 4), cost=20, cooldown=3, icon="❄"),
            DamageSkill("yarila_flame", "Пламя Ярилы", "×1.4 + горение 3 в ход на 3 хода", multiplier=1.4,
                        effect=lambda: Burn(3, 3), cost=25, cooldown=3, icon="🔥"),
            WerewolfSkill("werewolf", "Оборотень", "Мини-игра: выберите зверя и проведите по 5 точкам руны за 4 с. "
                          "Волк / Медведь / Ворон на 4 хода (качество рисунка = сила)", cost=45, cooldown=8,
                          min_turn=3, icon="🌕"),
        ]

    def _gift(self):
        return next((e for e in self._effects if isinstance(e, GodGift)), None)

    def _form(self):
        return next((e for e in self._effects if isinstance(e, BeastForm)), None)

    def get_damage(self):  # дар Перуна: +4 к каждому удару
        gift = self._gift()
        bonus = gift.power if gift and gift.god == "perun" else 1 if gift and gift.god == "morena" else 0
        return super().get_damage() + bonus

    def attack(self, target):  # форма зверя меняет обычную атаку
        form, base = self._form(), self.skills["attack"]
        if form is None:
            return super().attack(target)
        saved = (base.multiplier, base.hits, base.ignore_armor, base.effect, base.effect_chance)
        q = form.quality
        if form.form == "wolf":
            base.multiplier, base.hits, base.effect, base.effect_chance = 0.7 + 0.1 * q, 2, (lambda: Bleed(3, 4)), q
        elif form.form == "bear":
            base.multiplier, base.effect, base.effect_chance = 1.0 + 0.5 * q, (lambda: Stun(1)), 0.15 * q
        else:
            base.multiplier, base.ignore_armor = 1.0 + 0.2 * q, True
        try:
            return " ".join(base.execute(self, target))
        finally:
            base.multiplier, base.hits, base.ignore_armor, base.effect, base.effect_chance = saved

    def on_hit_landed(self, target, skill):  # дары Велеса и Морены
        gift, logs = self._gift(), []
        if gift and gift.god == "morena" and target.is_alive():
            target.add_effect(Slow(2, 2))
            target.add_effect(scale_effect(Chill(2, 5), self))
            logs.append(f"❄ Морена морозит {target.name}: −2 скорости, холод.")
        return logs

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        return super().take_damage(amount, ignore_armor, attacker)

    def _vampire(self, dealt):
        gift = self._gift()
        if gift and gift.god == "veles" and dealt > 0:
            self.heal(int(dealt * 0.2))

    def perform(self, key, target):  # Велес: 20% нанесённого урона возвращается в HP
        before = target.hp
        logs = super().perform(key, target)
        self._vampire(max(0, before - target.hp))
        return logs

    def ai_score_attack_bonus(self):
        return 1.0


# ======================= Минотавр Кэрн =======================
class AncestorsWrath(DamageSkill):
    """Гнев предков: нужно 5 зарядов наследия, тратит их."""

    copyable = False

    def is_available(self, user):
        return super().is_available(user) and getattr(user, 'legacy', 0) >= 5

    def _perform(self, user, target):
        user.legacy -= 5
        return [f"🐂 {user.name} тратит 5 зарядов наследия!"] + super()._perform(user, target)

    def ai_score(self, user, target):  # копить до 10 или добивать (<25% HP)
        if user.legacy >= user.MAX_LEGACY or target.hp < target.max_hp * 0.25:
            return super().ai_score(user, target) * 1.4
        return 0


class Minotaur(Character):
    """Минотавр Кэрн: танк с огромным HP. «Наследие предков»: раз в 2 хода +1 заряд (до {c.MAX_LEGACY}) —
    каждый даёт +3% урона, −1% получаемого урона и +0.15% HP регенерации (4.1: было 0.25%). Чем дольше бой, тем он сильнее."""

    hero_class, type_key, resource_name = "Минотавр", "minotaur", "дух"
    signature_skill = "horns"
    role = "tank"
    MAX_LEGACY = 7   # 4.4: было 10 — в затяжных боях (Дуррила, Совух) Кэрн становился непобедим

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=230, base_damage=12.38, armor=3, level=level,  # 4.4: урон 10.9→11.9 (наследие до 7, а не до 10)
                         speed=3, dodge=0.0, crit_chance=0.08,
                         max_energy=100, energy_regen=10, start_energy=40)
        self.legacy = 0

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар топором", "Обычная атака", accuracy=0.88, icon="🪓"),
            DamageSkill("horns", "Удар рогами", "×1.5, точность 85%, при попадании +1 заряд наследия",
                        multiplier=1.5, accuracy=0.85, cost=18, cooldown=2, icon="🐂"),
            DamageSkill("stomp", "Топот", "×0.8, скорость врага −3 на 3 хода", multiplier=0.8,
                        effect=lambda: Slow(3, 3), cost=20, cooldown=3, icon="🦶"),
            SelfBuffSkill("bone_wall", "Стена из костей", "Щит 12% HP на 3 хода",
                          effects=[lambda: Shield(3, int(self.max_hp * 0.12 / self.power_scale()))],
                          cost=25, cooldown=4, icon="🦴"),
            SelfBuffSkill("unbreakable", "Несокрушимость", "Получаемый урон −25% на 2 хода, иммунитет к оглушению",
                          effects=[lambda: DamageReduction(2, 25, stun_immune=True, title="Несокрушимость")],
                          cost=20, cooldown=5, icon="🗿"),
            AncestorsWrath("wrath", "Гнев предков", "Нужно 5 зарядов (тратит их): ×2.2, игнорирует 30% брони",
                           multiplier=2.2, armor_pierce=0.3, cost=30, cooldown=5, icon="👹"),
            DrumsSkill("drums", "Барабаны предков", "Мини-игра на слух: повторите ритм из 5 ударов. "
                       "5/5 — +20% HP, снятие дебаффов, +3 заряда; 3–4 — +12%, +2; 1–2 — +5%, +1",
                       cost=30, cooldown=6, icon="🥁"),
        ]

    def add_legacy(self, n):
        self.legacy = min(self.MAX_LEGACY, self.legacy + n)

    def damage_multiplier(self):
        return super().damage_multiplier() + 0.03 * self.legacy

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        amount = max(1, int(amount * (1 - 0.01 * self.legacy)))
        return super().take_damage(amount, ignore_armor, attacker)

    def on_hit_landed(self, target, skill):
        if skill.key == "horns":
            self.add_legacy(1)
            return [f"🐂 Наследие предков: {self.legacy}/{self.MAX_LEGACY}."]
        return []

    def start_turn(self):
        logs, can_act = super().start_turn()
        if self.is_alive():
            if self.turn_number % 2 == 0 and self.legacy < self.MAX_LEGACY:
                self.add_legacy(1)
                if self.legacy == self.MAX_LEGACY:
                    logs.append(Announcement(f"🐂 {self.name}: наследие предков на максимуме — +{3 * self.MAX_LEGACY}% урона!"))
            if self.legacy:
                healed = self.heal(int(self.max_hp * 0.0015 * self.legacy))
                if healed:
                    logs.append(f"🐂 Предки лечат {self.name}: +{healed} HP.")
        return logs, can_act

    def _on_reset(self):
        self.legacy = 0

    def describe(self):
        return super().describe() + f", наследие {self.legacy}/{self.MAX_LEGACY}"

    def to_dict(self):
        data = super().to_dict()
        data["legacy"] = self.legacy
        return data


# ======================= Крок =======================
class BiteSkill(DamageSkill):
    """Удар Крока, который копит Сытость."""

    satiety_gain = 0

    def _after_hit(self, user, target, damage):
        logs = super()._after_hit(user, target, damage)
        if hasattr(user, "feed"):
            user.feed(self.satiety_gain)
        return logs


class ShellSkill(Skill):
    """Грязевой панцирь: стойка до 3 ходов. Снимает горение."""

    copyable = False

    def is_available(self, user):
        return super().is_available(user) and not user.has_effect(ShellStance)

    def _perform(self, user, target):
        user._effects = [e for e in user.get_effects() if not isinstance(e, Burn)]
        user.add_effect(ShellStance(3))
        cut = min(40, 20 + int(user.satiety * 0.2))
        return [Announcement(f"🐊 {user.name} уходит в панцирь: −{cut}% урона, горение снято (сытость {user.satiety}).")]

    def ai_score(self, user, target):
        from .ai import threat, healing, horizon, strike_value, resource_price
        if user.has_effect(ShellStance):
            return 0
        turns=horizon(user,target)
        incoming=threat(target,user)
        own=threat(user,target)
        satiety=getattr(user,'satiety',0)
        reduction=min(0.40,0.20+satiety*0.002)
        average_satiety=max(0,satiety-25*turns/2)
        average_reduction=min(0.40,0.20+average_satiety*0.002)
        enemy_basic=target.skills.get('attack')
        armor_help=0 if enemy_basic and getattr(enemy_basic,'ignore_armor',False) else 2
        protection=(incoming*average_reduction+armor_help)*max(0.5,turns-0.5)
        regen=healing(user,user.max_hp*0.02*min(turns,(satiety+24)//25))
        burn=sum(e.power*min(e.duration,turns)*1.3 for e in user.get_effects() if isinstance(e,Burn))
        # Spending a full turn and weakening two subsequent attacks loses a
        # damage race. Use this stance to cleanse burning or avert a lethal
        # burst, rather than cycling it whenever satiety is available.
        basic=user.skills.get('attack')
        shields=sum(e.power for e in target.get_effects() if isinstance(e,Shield))
        basic_damage=strike_value(user,target,basic.multiplier,accuracy=basic.accuracy,skill=basic) if basic else 0
        if basic and target.hp+shields<=basic_damage:
            return 0
        # Cleansing a weak burn that expires next turn cannot pay for the
        # setup, weakened follow-up attacks and resource. Treat protection
        # as a bonus instead of using it to justify that losing exchange.
        tempo_loss=own*0.30*min(2,turns)
        if burn and burn+regen<basic_damage+tempo_loss+self.cost*resource_price(user):
            return 0
        first_saved=incoming*reduction+2
        if not burn and (user.hp>incoming or incoming-first_saved>=user.hp):
            return 0
        # Shell also weakens our next two attacks and consumes satiety.
        return protection+regen+burn-tempo_loss


class LungeSkill(DamageSkill):
    """Выпад из панциря: только после стойки. ×1.3 + 1% урона за каждые 2 пункта Сытости (тратит её)."""

    copyable = False

    def is_available(self, user):
        return super().is_available(user) and getattr(user, 'lunge_ready', False)

    def _perform(self, user, target):
        bonus = user.satiety // 2
        user.satiety, user.lunge_ready = 0, False
        saved = self.multiplier
        self.multiplier = saved * (1 + bonus / 100)
        try:
            return [f"🐊 {user.name} — выпад из панциря (+{bonus}% от сытости)!"] + super()._perform(user, target)
        finally:
            self.multiplier = saved

    def ai_score(self, user, target):
        from .ai import strike_value
        mult=self.multiplier*(1+(user.satiety//2)/100)
        damage=strike_value(user,target,mult,accuracy=self.accuracy,skill=self)
        return damage+(min(12,target.hp) if damage>=target.hp else 0)


class ScavengerSkill(DamageSkill):
    """Падальщик: ×1.8 по цели с HP < 35% (иначе ×1.0); при добивании лечит 12% HP."""

    def _perform(self, user, target):
        saved = self.multiplier
        self.multiplier = 1.8 if target.hp < target.max_hp * 0.35 else 1.0
        try:
            logs = super()._perform(user, target)
        finally:
            self.multiplier = saved
        if not target.is_alive():
            healed = user.heal(int(user.max_hp * 0.12))
            logs.append(f"🐊 {user.name} пирует над добычей: +{healed} HP.")
        return logs

    def ai_score(self, user, target):
        return super().ai_score(user, target) * (1.8 if target.hp < target.max_hp * 0.35 else 0.6)


class Croc(Character):
    """Крок — зверолюд-крокодил: «Сытость» превращает урон в защиту. Охотится (копит сытость),
    потом уходит в «Панцирь» и держит удар. Слабость «Пересыхание»: горение бьёт на 30% сильнее."""

    hero_class, type_key, resource_name = "Крок", "croc", "выдержка"
    signature_skill = "bite"
    role = "tank"
    MAGIC_GUARD = 0.2   # 4.4: «Толстая чешуя» — удары сквозь броню (магия) слабее на 20%

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=219, base_damage=13.6, armor=5, level=level,
                         speed=4, dodge=0.0, crit_chance=0.05,
                         max_energy=100, energy_regen=10, start_energy=50)
        self.satiety = 0
        self.lunge_ready = False

    def _create_skills(self):
        bite = BiteSkill("bite", "Укус", "×1.6, точность 80%, лечит 10% нанесённого, +12 сытости",
                         multiplier=1.6, accuracy=0.8, lifesteal=0.1, cost=15, icon="🐊")
        bite.satiety_gain = 12
        tail = BiteSkill("tail", "Удар хвостом", "×0.9, точность 90%, 25% оглушить, +8 сытости",
                         multiplier=0.9, accuracy=0.9, effect=lambda: Stun(1), effect_chance=0.25,
                         cost=20, cooldown=4, icon="🦎")
        tail.satiety_gain = 8
        attack = BiteSkill("attack", "Удар булавой", "Обычная атака, +5 сытости", accuracy=0.8, icon="🔨")
        attack.satiety_gain = 5
        return [
            attack, bite, tail,
            ShellSkill("mud_shell", "Грязевой панцирь", "Стойка до 3 ходов: урон −20% и ещё −0.2% за пункт сытости "
                       "(до −40%), лечение 2%/ход, свой урон −30%. Снимает горение", cost=20, cooldown=5, icon="🛡"),
            LungeSkill("lunge", "Выпад из панциря", "После стойки: ×1.3 и +1% за каждые 2 пункта сытости",
                       multiplier=1.3, cost=15, icon="💥"),
            ScavengerSkill("scavenger", "Падальщик", "×1.8 по цели с HP < 35% (иначе ×1.0); добил — +12% HP",
                           cost=25, cooldown=5, icon="🦴"),
            DeathRollSkill("death_roll", "Смертельное вращение", "Мини-игра: держите маркер в зелёной зоне 4 с. "
                           "До ×2.6, оглушение и +30 сытости", cost=28, cooldown=6, icon="🌀"),
            ShellPuzzleSkill("shell_puzzle", "Сборка панциря", "Мини-игра: поверните 3 кольца за 6 с. "
                             "3/3 — −38% урона и иммунитет к оглушению; 2 — −30%; 0–1 — −20%. Сытость не нужна",
                             cost=35, cooldown=7, icon="🧩"),
        ]

    def feed(self, n):
        self.satiety = max(0, min(100, self.satiety + n))

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        return super().take_damage(amount, ignore_armor, attacker)

    def start_turn(self):  # «Пересыхание»: горение на 30% сильнее
        extra = sum(int(e.power * 0.3) for e in self._effects if isinstance(e, Burn))
        logs, can_act = super().start_turn()
        if extra and self.is_alive():
            self.hp = self.hp - extra
            logs.append(f"☀ Пересыхание: {self.name} получает ещё −{extra} HP от горения.")
        return logs, can_act

    def damage_vs(self, victim):  # первый удар после стойки — ×1.3
        return 1.0

    def _on_reset(self):
        self.satiety, self.lunge_ready = 0, False

    def describe(self):
        return super().describe() + f", сытость {self.satiety}/100"

    def to_dict(self):
        data = super().to_dict()
        data.update(satiety=self.satiety, lunge_ready=self.lunge_ready)
        return data


# ======================= Тёмный рыцарь Мордред =======================
class BloodHarvest(DamageSkill):
    """Кровавая жатва: стоит 8% своего HP, ×2.0, возвращает половину нанесённого урона."""

    def is_available(self, user):
        return super().is_available(user) and user.hp > user.max_hp * 0.12

    def pay(self, user):
        super().pay(user)
        user.hp = user.hp - int(user.max_hp * 0.08)

    def ai_score(self, user, target):
        from .ai import strike_value, healing
        damage=strike_value(user,target,self.multiplier,accuracy=self.accuracy,skill=self)
        payment=int(user.max_hp*0.08)
        returned=healing(user,damage*self.lifesteal,missing=user.max_hp-user.hp+payment)
        finish=min(12,target.hp) if damage>=target.hp else 0
        return damage+returned-payment+finish


class Plague(SummonSkill):
    def ai_score(self, user, target):
        from .ai import threat,horizon
        if user.summon and user.summon.is_alive():
            return 0
        summon=SkeletonSquad(user)
        turns=horizon(user,target,summon.lifetime)
        hit=max(0.1,summon.accuracy-target.get_dodge())
        damage=2*max(1,summon.damage*user.power_scale()-target.armor_total())*hit*turns
        protection=min(summon.max_hp,threat(target,user)*summon.intercept_chance*turns)
        return damage+protection


class DarkKnight(Character):
    """Тёмный рыцарь Мордред — павший паладин. Платит своим HP за силу: чем больше его бьют, тем он злее.
    «Ненависть» растёт на 5 в ход и на 15 за каждый полученный удар (25 — под Нечестивым доспехом)."""

    hero_class, type_key, resource_name = "Тёмный рыцарь", "darkknight", "ненависть"
    signature_skill = "blood_harvest"
    role = "warrior"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=224, base_damage=10.5, armor=4, level=level,  # 5.4: HP 218→224
                         speed=5, dodge=0.05, crit_chance=0.1,
                         max_energy=100, energy_regen=5, start_energy=30)
        self._oath_used = False

    def _create_skills(self):
        return [
            DamageSkill("attack", "Проклятый клинок", "Основная атака ×1.4, +10 ненависти", multiplier=1.4,
                        accuracy=0.85, icon="🗡"),
            BloodHarvest("blood_harvest", "Кровавая жатва", "Плата 8% своего HP: ×2.0, возвращает 50% урона",
                         multiplier=2.0, accuracy=0.85, lifesteal=0.5, cost=20, cooldown=3, icon="🩸"),
            DamageSkill("cursed_slash", "Проклятый разрез", "×1.5, точность 88%", multiplier=1.5,
                        accuracy=0.88, cost=18, cooldown=3, icon="⚔"),
            DebuffSkill("fear_aura", "Аура страха", "3 хода: урон врага −15%, точность −10%",
                        effect=lambda: FearAura(3), cost=30, cooldown=5, icon="😱"),
            SelfBuffSkill("unholy_armor", "Нечестивый доспех", "Щит 15% HP; пока держится — +25 ненависти за удар",
                          effects=[lambda: Shield(3, int(self.max_hp * 0.15 / self.power_scale()))],
                          cost=35, cooldown=5, icon="🛡"),
            Plague("plague", "Призыв Плети", "С 4-го хода: два скелета (по 30 HP, урон 4, точность 70%) на 4 хода",
                   summon_factory=SkeletonSquad, cost=70, cooldown=9, min_turn=4, icon="💀"),
            TemperSkill("temper", "Закалка клинка", "Мини-игра: зажмите и отпустите в зелёной зоне. Идеально — ×1.85 "
                        "сквозь броню, хорошо — ×1.7, мимо — ×1.3, перегрев — −5% HP и слабый удар", cost=25, cooldown=5, icon="🔥"),
            SoulSiphonSkill("soul_siphon", "Похищение души", "Мини-игра: ловите души — идеально сильный вампиризм",
                            cost=30, cooldown=5, icon="👻"),
        ]

    def attack(self, target):
        result = super().attack(target)
        self.restore_energy(10)
        return result

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        shielded = self.has_effect(Shield)
        dmg = super().take_damage(amount, ignore_armor, attacker)
        if attacker is not None:
            self.restore_energy(25 if shielded else 15)
        if self.is_alive() and not self._oath_used and self.hp < self.max_hp * 0.25:
            self._oath_used = True
            self.add_effect(Undying(2))
            self._events.append(Announcement(f"☠ ПОСЛЕДНЯЯ КЛЯТВА! 2 хода {self.name} не может пасть."))
        return dmg

    def _on_reset(self):
        self._oath_used = False


# ======================= Мобы сюжета «Тёмный лес» =======================
class Mob(Character):
    """Моб сюжета: не создаётся игроком, бьётся только в сюжете.
    5.3.2: обычные мобы (не босс/элита) можно взять героем арены в режиме разработчика."""

    creatable = False
    mob = True
    dev_playable = True   # 5.3.2: арена в dev_mode
    role = "tank"
    line = "Надо разобраться с этой тварью…"


class Wolf(Mob):
    """Волк — быстрый хищник опушки: кусает и рвёт раны."""

    hero_class, type_key, resource_name = "Волк", "wolf", "ярость"
    role = "warrior"   # 4.3: волк — воин (раньше все мобы были «Танк»)
    signature_skill = "bite"

    def __init__(self, name="Серый волк", level=1):
        super().__init__(name, max_hp=120, base_damage=9, armor=1, level=level,
                         speed=7, dodge=0.12, crit_chance=0.1, max_energy=100, energy_regen=12, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Укус", "Обычная атака", icon="🐺"),
                DamageSkill("bite", "Рваный укус", "×1.4 + кровотечение", multiplier=1.4,
                            effect=lambda: Bleed(3, 3), cost=25, cooldown=3, icon="🩸"),
                DebuffSkill("howl", "Вой", "Враг напуган: −15% точности на 2 хода",
                            effect=lambda: Blinded(2, 15), cost=20, cooldown=5, icon="🌕")]


class GhostCat(Mob):
    """Призрачный кот — огромный чёрный зверь, похожий на льва: исчезает в тумане и бьёт из тени."""

    hero_class, type_key, resource_name = "Призрачный кот", "ghostcat", "тьма"
    role = "warrior"   # 4.3
    signature_skill = "pounce"

    def __init__(self, name="Призрачный кот", level=2):
        super().__init__(name, max_hp=145, base_damage=10, armor=2, level=level,
                         speed=7, dodge=0.22, crit_chance=0.15, max_energy=100, energy_regen=12, start_energy=40)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар лапой", "Обычная атака", icon="🐈‍⬛"),
                DamageSkill("pounce", "Прыжок из тени", "×1.7, +20% крит", multiplier=1.7, crit_bonus=0.2,
                            cost=30, cooldown=3, icon="🌑"),
                SelfBuffSkill("fade", "Раствориться в тумане", "+30% уклонения на 2 хода",
                              effects=[lambda: DodgeBuff(2, 30)], cost=25, cooldown=5, icon="🌫")]


class BloodBear(Mob):
    """Кровавый медведь — свирепый хозяин чащи: дерёт когтями и оглушает."""

    hero_class, type_key, resource_name = "Кровавый медведь", "bloodbear", "ярость"
    role = "tank"      # 4.3: медведь — танк
    signature_skill = "maul"

    def __init__(self, name="Кровавый медведь", level=3):
        super().__init__(name, max_hp=200, base_damage=11, armor=3, level=level,
                         speed=3, dodge=0.0, crit_chance=0.08, max_energy=100, energy_regen=12, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар лапой", "Обычная атака", accuracy=0.85, icon="🐻"),
                DamageSkill("maul", "Растерзать", "×1.6 + кровотечение", multiplier=1.6, accuracy=0.8,
                            effect=lambda: Bleed(3, 4), cost=30, cooldown=3, icon="🩸"),
                DamageSkill("slam", "Медвежий удар", "×1.2, 30% оглушить", multiplier=1.2, effect=lambda: Stun(1),
                            effect_chance=0.3, cost=30, cooldown=4, icon="💫"),
                SelfBuffSkill("rage", "Кровавая ярость", "+30% урона на 3 хода", effects=[lambda: Berserk(3, 30)],
                              cost=35, cooldown=6, icon="😡")]


class GreatDeer(Mob):
    """4.3: Великий Олень — древний дух-хранитель чащи с огромными ветвистыми рогами. Воин леса:
    таранит рогами, топотом замедляет врага и лечится благословением леса."""

    hero_class, type_key, resource_name = "Великий Олень", "greatdeer", "сила леса"
    signature_skill = "antler_charge"
    role = "warrior"

    def __init__(self, name="Великий Олень", level=3):
        super().__init__(name, max_hp=210, base_damage=11, armor=2, level=level,
                         speed=6, dodge=0.1, crit_chance=0.1, max_energy=100, energy_regen=12, start_energy=35)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар копытом", "Обычная атака", accuracy=0.88, icon="🦌"),
                DamageSkill("antler_charge", "Таран рогами", "×1.7, 25% оглушить", multiplier=1.7, accuracy=0.8,
                            effect=lambda: Stun(1), effect_chance=0.25, cost=30, cooldown=3, icon="🦌"),
                DamageSkill("stomp", "Топот", "×1.0 и −2 скорости на 2 хода", effect=lambda: Slow(2, 2),
                            cost=20, cooldown=3, icon="💥"),
                HealSkill("forest_blessing", "Благословение леса", "+10% HP и регенерация 4 HP на 3 хода",
                          percent=0.10, effect=lambda: Regeneration(3, 4), cost=35, cooldown=6, icon="🍃")]


class DruidBoss(Druid):
    """Радогаст, хранитель Тёмного леса — мини-босс. Друид, ставший частью чащи.
    4.3: HP ×1.15 (было ×1.25), звери на 20% слабее (HP и урон), «Дар природы» — перезарядка 7."""

    hero_class, type_key = "Друид-хранитель", "druid"
    creatable = False
    mob = True
    dev_playable = False  # босс — не в пул арены
    role = "light"
    boss_name = "Радогаст"
    line = "Вот он, хранитель леса… Пора с этим покончить."
    HP_BONUS = 1.15
    BEAST_POWER = 0.8

    def __init__(self, name="Радогаст", level=4):
        super().__init__(name, level=level)
        self._raw_hp = int(self._raw_hp * self.HP_BONUS)
        self.set_level(level)
        self.skills["nature_heal"].cooldown = 7
        summon = self.skills["summon_beast"]
        base_factory = summon.summon_factory

        def weaker_beast(owner, _f=base_factory):
            beast = _f(owner)
            beast.max_hp = max(1, int(beast.max_hp * self.BEAST_POWER))
            beast.hp = beast.max_hp
            beast.damage = max(1, int(round(beast.damage * self.BEAST_POWER)))
            return beast
        weaker_beast.boss_wrapped = base_factory
        summon.summon_factory = weaker_beast

    def adapt_to(self, hero):
        """4.4: «Лес знает своих врагов» — сила Радогаста (HP и урон) подстраивается под класс героя,
        чтобы у каждого героя 4 ур. шансы были ~55–65% (таблица RADO_VS в tuning.py)."""
        from .tuning import RADO_VS
        f = RADO_VS.get(getattr(hero, "type_key", ""), 1.0)
        if f != 1.0:
            self._raw_hp = int(self._raw_hp * f)
            self._base_damage = self._base_damage * f
            self.set_level(self.level)
        return f


NEW_HEROES = {"musketeer": Musketeer, "pagan": Pagan, "minotaur": Minotaur, "croc": Croc, "darkknight": DarkKnight}
HERO_CLASSES.update(NEW_HEROES)


# ======================= 5.0: мобы новых локаций =======================
class Bandit(Mob):
    hero_class, type_key, resource_name = "Бандит", "bandit", "ярость"
    role = "warrior"
    signature_skill = "axe_swing"

    def __init__(self, name="Бандит", level=1):
        super().__init__(name, max_hp=110, base_damage=9, armor=1, level=level,
                         speed=5, dodge=0.05, crit_chance=0.08, max_energy=100, energy_regen=12, start_energy=25)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар топором", "Обычная атака", icon="🪓"),
                DamageSkill("axe_swing", "Разбойничий замах", "×1.5", multiplier=1.5, cost=25, cooldown=3, icon="🪓"),
                SelfBuffSkill("tough", "Наглость", "+20% урона на 2 хода",
                              effects=[lambda: Berserk(2, 20)], cost=20, cooldown=5, icon="😈")]


class Magician(Mob):
    hero_class, type_key, resource_name = "Фокусник", "magician", "фокусы"
    role = "trickster"
    signature_skill = "card_throw"

    def __init__(self, name="Фокусник", level=1):
        super().__init__(name, max_hp=100, base_damage=10, armor=0, level=level,
                         speed=6, dodge=0.12, crit_chance=0.15, max_energy=100, energy_regen=14, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Карточный удар", "Обычная атака картой", icon="🃏"),
                DamageSkill("card_throw", "Веер карт", "3 удара по ×0.55", multiplier=0.55, hits=3,
                            cost=30, cooldown=3, icon="🂡"),
                DebuffSkill("trick", "Обман зрения", "Точность врага −20% на 2 хода",
                            effect=lambda: Blinded(2, 20), cost=25, cooldown=5, icon="🎩")]


class HoodedKiller(Mob):
    hero_class, type_key, resource_name = "Убийца", "hooded_killer", "тьма"
    role = "warrior"
    signature_skill = "sickle"

    def __init__(self, name="Убийца", level=2):
        super().__init__(name, max_hp=125, base_damage=11, armor=1, level=level,
                         speed=7, dodge=0.18, crit_chance=0.2, max_energy=100, energy_regen=13, start_energy=35)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар серпом", "Обычная атака", icon="☠"),
                DamageSkill("sickle", "Жатва", "×1.7 + кровотечение", multiplier=1.7,
                            effect=lambda: Bleed(3, 3), cost=30, cooldown=3, icon="🩸"),
                SelfBuffSkill("shadow", "Тень крыши", "+25% уклонения на 2 хода",
                              effects=[lambda: DodgeBuff(2, 25)], cost=25, cooldown=5, icon="🌑")]


class GiantSnake(Mob):
    hero_class, type_key, resource_name = "Гигантская змея", "giant_snake", "яд"
    role = "monster"
    signature_skill = "constrict"

    def __init__(self, name="Гигантская змея", level=5):
        super().__init__(name, max_hp=160, base_damage=12, armor=2, level=level,
                         speed=5, dodge=0.1, crit_chance=0.1, max_energy=100, energy_regen=12, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Укус", "Обычная атака", icon="🐍"),
                DamageSkill("constrict", "Удушающие кольца", "×1.5 + замедление", multiplier=1.5,
                            effect=lambda: Slow(2, 2), cost=25, cooldown=3, icon="🌀"),
                DamageSkill("venom", "Ядовитые клыки", "×1.3 + яд", multiplier=1.3,
                            effect=lambda: Poison(3, 4), cost=30, cooldown=4, icon="🤢")]


class PackWolf(Wolf):
    """Волк из стаи: ~40% слабее обычного."""
    type_key = "pack_wolf"
    POWER = 0.6

    def __init__(self, name="Волк стаи", level=5):
        super().__init__(name, level=level)
        self._raw_hp = int(self._raw_hp * self.POWER)
        self._base_damage = self._base_damage * self.POWER
        self.set_level(level)


class Murloc(Mob):
    hero_class, type_key, resource_name = "Мурлок", "murloc", "слякоть"
    role = "warrior"
    signature_skill = "claws"

    def __init__(self, name="Мурлок", level=7):
        super().__init__(name, max_hp=130, base_damage=11, armor=1, level=level,
                         speed=6, dodge=0.08, crit_chance=0.1, max_energy=100, energy_regen=12, start_energy=25)

    def _create_skills(self):
        return [DamageSkill("attack", "Царапина", "Обычная атака", icon="🐟"),
                DamageSkill("claws", "Острые когти", "×1.55", multiplier=1.55, cost=25, cooldown=3, icon="🐾"),
                DamageSkill("screech", "Мргл-ррааа", "×1.2, 25% оглушить", multiplier=1.2,
                            effect=lambda: Stun(1), effect_chance=0.25, cost=30, cooldown=4, icon="📢")]


class GiantCroc(Mob):
    hero_class, type_key, resource_name = "Гигантский крокодил", "giant_croc", "сытость"
    role = "tank"
    signature_skill = "deathroll"

    def __init__(self, name="Гигантский крокодил", level=7):
        super().__init__(name, max_hp=190, base_damage=12, armor=3, level=level,
                         speed=3, dodge=0.0, crit_chance=0.08, max_energy=100, energy_regen=11, start_energy=25)

    def _create_skills(self):
        return [DamageSkill("attack", "Укус", "Обычная атака", accuracy=0.85, icon="🐊"),
                DamageSkill("deathroll", "Смертельный кувырок", "×1.7", multiplier=1.7, accuracy=0.8,
                            cost=30, cooldown=3, icon="💥"),
                DamageSkill("tail", "Удар хвостом", "×1.2, 30% оглушить", multiplier=1.2,
                            effect=lambda: Stun(1), effect_chance=0.3, cost=25, cooldown=4, icon="🐊")]


class SwampMonster(Mob):
    hero_class, type_key, resource_name = "Болотное чудище", "swamp_monster", "тина"
    role = "tank"
    signature_skill = "hook"

    def __init__(self, name="Болотное чудище", level=7):
        super().__init__(name, max_hp=200, base_damage=13, armor=3, level=level,
                         speed=3, dodge=0.0, crit_chance=0.05, max_energy=100, energy_regen=11, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар крюком", "Обычная атака", accuracy=0.85, icon="🪝"),
                DamageSkill("hook", "Мясницкий крюк", "×1.65", multiplier=1.65, accuracy=0.8,
                            cost=30, cooldown=3, icon="🪝"),
                SelfBuffSkill("hide", "Крокодилья шкура", "Щит 12% HP на 3 хода",
                              effects=[lambda: Shield(3, max(1, int(self.max_hp * 0.12)))], cost=25, cooldown=5, icon="🛡")]


class FishCatchSkill(MiniGameSkill):
    game, prompt = "click_targets", "Ловите рыбок! Нужно 3!"
    TIME_LIMIT_MS = 4000
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (30, 35, 25, 10)
    TIER_VALUE = (0.3, 0.8, 1.3, 2.0)

    def game_params(self, user, target):
        return {"count": 3, "icon": "🐟", "spawn_ms": 900}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 3 - max(0, min(3, k))

    def apply(self, user, target, tier, data):
        mult = self.TIER_VALUE[tier]
        head = f"🎣 {user.name} — «Ловись рыбка»: поймано {3 - tier}/3!"
        part, _ = self.strike(user, target, mult, force=True)
        return [Announcement(head)] + part

    def ai_score(self, user, target):
        return 40


class Fisherman(Mob):
    hero_class, type_key, resource_name = "Рыбак", "fisherman", "удочка"
    role = "warrior"
    signature_skill = "catch_fish"

    def __init__(self, name="Рыбак", level=7):
        super().__init__(name, max_hp=150, base_damage=11, armor=1, level=level,
                         speed=4, dodge=0.05, crit_chance=0.08, max_energy=100, energy_regen=12, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар удилищем", "Обычная атака", icon="🎣"),
                FishCatchSkill("catch_fish", "Ловись рыбка", "Мини-игра: поймайте 3 рыбки или получите урон",
                               cost=0, cooldown=4, icon="🐟"),
                DamageSkill("hook_jab", "Крючок", "×1.4", multiplier=1.4, cost=20, cooldown=3, icon="🪝")]


class FrogKing(Mob):
    hero_class, type_key, resource_name = "Король-лягушка", "frog_king", "ква"
    role = "tank"
    signature_skill = "tongue"

    def __init__(self, name="Король-лягушка", level=8):
        super().__init__(name, max_hp=210, base_damage=12, armor=2, level=level,
                         speed=4, dodge=0.08, crit_chance=0.1, max_energy=100, energy_regen=12, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Удар лапой", "Обычная атака", icon="🐸"),
                DamageSkill("tongue", "Царский язык", "×1.6 + замедление", multiplier=1.6,
                            effect=lambda: Slow(2, 2), cost=30, cooldown=3, icon="👅"),
                HealSkill("royal_slime", "Царская слизь", "+10% HP", percent=0.10, cost=35, cooldown=6, icon="🟢")]


class HydraHead(Mob):
    hero_class, type_key, resource_name = "Голова гидры", "hydra_head", "яд"
    role = "monster"
    signature_skill = "bite"

    def __init__(self, name="Голова гидры", level=8):
        super().__init__(name, max_hp=145, base_damage=13.5, armor=2, level=level,
                         speed=5, dodge=0.05, crit_chance=0.1, max_energy=100, energy_regen=12, start_energy=30)

    def _create_skills(self):
        return [DamageSkill("attack", "Укус", "Обычная атака", icon="🐉"),
                DamageSkill("bite", "Ядовитый укус", "×1.5 + яд", multiplier=1.5,
                            effect=lambda: Poison(3, 5), cost=25, cooldown=3, icon="🤢"),
                DamageSkill("roar", "Рёв головы", "×1.2, 20% оглушить", multiplier=1.2,
                            effect=lambda: Stun(1), effect_chance=0.2, cost=25, cooldown=4, icon="📢")]



MOBS = {"wolf": Wolf, "ghostcat": GhostCat, "bloodbear": BloodBear, "greatdeer": GreatDeer, "druid_boss": DruidBoss,
        "bandit": Bandit, "magician": Magician, "hooded_killer": HoodedKiller, "giant_snake": GiantSnake,
        "pack_wolf": PackWolf, "murloc": Murloc, "giant_croc": GiantCroc, "swamp_monster": SwampMonster,
        "fisherman": Fisherman, "frog_king": FrogKing, "hydra_head": HydraHead}


# 5.3.2: обычные сюжетные мобы (stage.boss=False, elite=False, secret=False) —
# в режиме разработчика это обычные герои арены. Боссы/элиты/секрет не входят.
DEV_ARENA_MOB_KEYS = frozenset({
    "bandit", "magician", "hooded_killer",
    "wolf", "ghostcat", "bloodbear", "greatdeer",
    "giant_snake", "pack_wolf",
    "murloc", "giant_croc", "swamp_monster", "fisherman",
    "frog_king", "hydra_head",
})
# Не добавляем в HERO_CLASSES (их 25) — lookup через MOBS / DEV_ARENA_MOB_KEYS.
