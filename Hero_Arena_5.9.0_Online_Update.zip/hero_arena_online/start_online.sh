#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -x .venv-online/bin/python ]; then python3 -m venv .venv-online; fi
.venv-online/bin/python -m pip install -r requirements-online.txt
exec .venv-online/bin/python run_online.py
