"""Temporary HTTPS link from the player's computer using official cloudflared."""
import argparse
from version import APP_VERSION
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import tarfile
import urllib.request
import webbrowser

VERSION='2026.10.7'
ASSETS={
 ('Windows','amd64'):('cloudflared-windows-amd64.exe','2493dbc168923bb3e59e5e7716f71deced92992eea9acd6e9d74f84ac7751343'),
 ('Linux','amd64'):('cloudflared-linux-amd64','1f99fb518b83dec2ba8d870a7cc991d82a77e6196295a3d2754ba17ab9f91872'),
 ('Linux','arm64'):('cloudflared-linux-arm64','3df43aedc9ff291d1735b5cb576cb97e0b157488796db2e32b28aecabb445775'),
 ('Darwin','amd64'):('cloudflared-darwin-amd64.tgz','02f3edfd87684dd5b705607688e4eb4b323f6e777b81e7b3a85af556aa356848'),
 ('Darwin','arm64'):('cloudflared-darwin-arm64.tgz','3586ccf397e98e5f437e60e7c307ca6ac463e110580503af8bb8e6f9ebf831bd'),
}

def asset_for(system=None,machine=None):
    system=system or platform.system();machine=(machine or platform.machine()).lower()
    arch='amd64' if machine in ('amd64','x86_64') else 'arm64' if machine in ('arm64','aarch64') else machine
    try:return ASSETS[system,arch]
    except KeyError:raise RuntimeError('Автозагрузка поддерживает Windows64 x86, Linux x86/ARM64 и macOS Intel/Apple Silicon')

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def connector(folder):
    name,expected=asset_for();binary=folder/('cloudflared.exe' if platform.system()=='Windows' else 'cloudflared');meta=folder/'cloudflared.json'
    if binary.exists() and meta.exists():
        info=json.loads(meta.read_text())
        if info.get('version')==VERSION and info.get('asset')==name and digest(binary)==info.get('binary_sha256'):return binary
    folder.mkdir(parents=True,exist_ok=True)
    link=f'https://github.com/cloudflare/cloudflared/releases/download/{VERSION}/{name}'
    print('Первый запуск: загружаю официальный Cloudflare Tunnel и проверяю SHA256…',flush=True)
    req=urllib.request.Request(link,headers={'User-Agent':f'HeroArena/{APP_VERSION}'})
    with urllib.request.urlopen(req,timeout=60) as response:
        data=response.read(100*1024*1024+1)
    if len(data)>100*1024*1024 or hashlib.sha256(data).hexdigest()!=expected:raise RuntimeError('Проверка загрузки Cloudflare не пройдена')
    if name.endswith('.tgz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            member=next(m for m in archive.getmembers() if m.isfile() and Path(m.name).name=='cloudflared')
            data=archive.extractfile(member).read()
    temp=binary.with_suffix('.download');temp.write_bytes(data);temp.chmod(0o700);temp.replace(binary)
    meta.write_text(json.dumps(dict(version=VERSION,asset=name,binary_sha256=digest(binary))))
    return binary

def check_server(port):
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/healthz',timeout=5) as r:status=json.load(r)
        if status.get('version')!=APP_VERSION or status.get('status')!='ok':raise ValueError()
    except Exception as e:raise RuntimeError('Сначала запустите start_online.bat или python run_online.py. Нужен отдельный онлайн-сервер на порту '+str(port)) from e

def public_url(line):
    match=re.search(r'https://([a-z0-9-]+)\.trycloudflare\.com',line)
    if not match or match.group(1) in ('api','www') or len(match.group(1))<8:return None
    return match.group()+'/online'

def main():
    parser=argparse.ArgumentParser(description='Временная ссылка для игры с другом')
    parser.add_argument('--port',type=int,default=int(os.environ.get('PORT','5000')))
    parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
    if not 1<=args.port<=65535:parser.error('Неверный порт')
    check_server(args.port)
    folder=Path(__file__).resolve().parent/'.online-tools';binary=connector(folder)
    # An explicit empty config leaves the user's existing named tunnels untouched.
    config=folder/'quick.yml';config.write_text('{}\n')
    command=[str(binary),'--no-autoupdate','tunnel','--config',str(config),'--url',f'http://127.0.0.1:{args.port}','--protocol','http2']
    print('Подключаю временную HTTPS-ссылку…',flush=True)
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
    seen=False;candidate=None
    try:
        for line in process.stdout:
            candidate=public_url(line) or candidate
            if candidate and 'registered tunnel connection' in line.lower() and not seen:
                seen=True;url=candidate
                print('\nОТКРОЙТЕ ЭТУ ССЫЛКУ: '+url,flush=True)
                print('Создайте там комнату и отправьте другу её приглашение. Оба играйте через HTTPS, не через localhost.',flush=True)
                print('Ссылка действует, пока это окно и окно сервера открыты.\n',flush=True)
                if not args.no_browser:webbrowser.open(url)
            elif any(word in line.lower() for word in ('error','err ','failed','registered tunnel')):print(line.rstrip(),flush=True)
        if process.wait():raise RuntimeError('Туннель отключился. Проверьте интернет и перезапустите share_online. Если сеть блокирует Cloudflare, попробуйте другую сеть')
    finally:
        if process.poll() is None:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill()

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('\nПубличная ссылка отключена.')
    except Exception as e:print('\n'+str(e));raise SystemExit(1)
