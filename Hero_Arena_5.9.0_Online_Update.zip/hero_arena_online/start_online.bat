@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
if not exist "run_online.py" goto missing_files
if not exist ".venv-online\Scripts\python.exe" (
  py -3 -m venv .venv-online
  if errorlevel 1 python -m venv .venv-online
)
if not exist ".venv-online\Scripts\python.exe" goto missing_python
".venv-online\Scripts\python.exe" -m pip install -r requirements-online.txt
if errorlevel 1 goto install_failed
".venv-online\Scripts\python.exe" run_online.py
pause
exit /b
:missing_files
echo Extract the game ZIP completely. Keep this BAT next to run_online.py.
pause
exit /b 1
:missing_python
echo Install Python 3.10 or newer from python.org, then try again.
pause
exit /b 1
:install_failed
echo Dependency installation failed. See the error above.
pause
exit /b 1
