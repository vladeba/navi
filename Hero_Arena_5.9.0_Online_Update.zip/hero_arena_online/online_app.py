"""Public online-only entrypoint. No local saves, dev tools or legacy mutation API."""
import os
from version import APP_VERSION
from flask import Flask,jsonify,send_from_directory,redirect
from werkzeug.middleware.proxy_fix import ProxyFix
from services.online_api import online_blueprint
from services.online_rooms import PLAYABLE

app=Flask(__name__)
app.json.ensure_ascii=False
app.config['MAX_CONTENT_LENGTH']=131072
if os.environ.get('ARENA_TRUST_PROXY')=='1':
    # Enable only behind the single trusted HTTPS reverse proxy described in ONLINE_RU.md.
    app.wsgi_app=ProxyFix(app.wsgi_app,x_for=0,x_proto=1,x_host=0,x_port=0,x_prefix=0)
app.register_blueprint(online_blueprint())

@app.get('/')
def index():return redirect('/online')

@app.get('/healthz')
def health():return jsonify(status='ok',version=APP_VERSION)

@app.get('/images/<hero_type>')
def image(hero_type):
    if hero_type not in PLAYABLE:return jsonify(error='Герой не найден'),404
    folder=os.path.join(app.static_folder,'images')
    for ext in ('jpg','png','svg'):
        if os.path.isfile(os.path.join(folder,hero_type+'.'+ext)):return send_from_directory(folder,hero_type+'.'+ext)
    return jsonify(error='Портрет не найден'),404

@app.get('/api/classes/<hero_type>')
def card(hero_type):
    if hero_type not in PLAYABLE:return jsonify(error='Герой не найден'),404
    return jsonify(PLAYABLE[hero_type].class_info())

@app.errorhandler(404)
def not_found(e):return jsonify(error='Маршрут не найден'),404

if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.environ.get('PORT','5000')),threaded=True,debug=False)
