#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -x .venv-online/bin/python ]; then echo 'Сначала запустите sh start_online.sh'; exit 1; fi
exec .venv-online/bin/python share_online.py
