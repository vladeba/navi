"""One process is intentional: both seats share the same in-memory room."""
import argparse
import os
from version import APP_VERSION

def main():
    parser=argparse.ArgumentParser(description='Hero Arena: дуэль по приглашению')
    parser.add_argument('--port',type=int,default=int(os.environ.get('PORT','5000')))
    args=parser.parse_args()
    if not 1<=args.port<=65535:parser.error('port должен быть от 1 до 65535')
    # Origin is loopback-only. The local Cloudflare connector supplies HTTPS headers.
    os.environ.setdefault('ARENA_TRUST_PROXY','1')
    from online_app import app
    from waitress import serve
    print(f'Hero Arena {APP_VERSION}: сервер запущен на http://127.0.0.1:{args.port}',flush=True)
    print('Теперь запустите share_online.bat или python share_online.py.',flush=True)
    print('Оба игрока должны открыть внешнюю HTTPS-ссылку из второго окна.',flush=True)
    print('Оставьте оба окна открытыми на время игры. Ctrl+C — остановить.',flush=True)
    serve(app,host='127.0.0.1',port=args.port,threads=8,max_request_body_size=131072,
          trusted_proxy='127.0.0.1',trusted_proxy_headers={'x-forwarded-proto'})

if __name__=='__main__':main()
