"""All reaction transports: private ownership, begin and timeout must resume play."""
import time,unittest,uuid
from models import HERO_CLASSES
from services.online_rooms import OnlineRooms,RoomError

class EveryOnlineReaction59(unittest.TestCase):
 def test_all_103_reactions_and_followup_dodge_can_finish_without_hanging(self):
  checked=[]
  for kind,cls in HERO_CLASSES.items():
   keys=[s.key for s in cls('catalog').skills.values() if s.reaction]
   for key in keys:
    with self.subTest(hero=kind,skill=key):
     now=[time.time()];rooms=OnlineRooms(clock=lambda:now[0]);a,b='owner','friend';code=rooms.create(a,'Первый')['code'];rooms.join(code,b,'Второй')
     def move(who,action,**data):
      state=rooms.state(code,who);return rooms.mutate(code,who,action,dict(revision=state['revision'],request_id=str(uuid.uuid4()),**data))
     move(a,'choose',hero=kind);move(b,'choose',hero='warrior');move(a,'ready',ready=True);move(b,'ready',ready=True)
     battle=rooms.rooms[code]['battle'];u=battle.hero1;t=battle.hero2;battle.current=u;battle._order=[u,t];battle._index=0;u.turn_number=6;u.restore_energy(999);u.hp=round(u.max_hp*.6)
     # This checks transport for every reaction independently of cooldown/form
     # gates, which remain covered by combat and form tests.
     u.can_use=lambda skill:True;u.skill_unlocked=lambda skill:True
     
     if kind=='getou' and key in ('puppet_threads','flesh_stitch'):
      u.raise_minion('skeleton',0);u.living_minions()[0].hp-=10
     state=move(a,'turn',skill=key);self.assertTrue(state['battle']['pending'],key)
     for phase in range(2):
      pending=battle.pending
      if pending is None:break
      who=a if pending['reactor'] is u else b;other=b if who==a else a
      own=rooms.state(code,who);pid=own['pending_id'];self.assertEqual(rooms.state(code,other)['battle']['pending']['options'],{})
      with self.assertRaises(RoomError):move(other,'begin',pending_id=pid)
      begun=move(who,'begin',pending_id=pid);deadline=begun['deadline'];self.assertEqual(move(who,'begin',pending_id=pid)['deadline'],deadline)
      answer='timeout' if pending['skill'].reaction in ('minigame','sequence') else pending['options'][0]
      move(who,'react',pending_id=pid,choice=answer)
     self.assertIsNone(battle.pending,(kind,key));checked.append((kind,key))
  self.assertEqual(len(checked),103)
