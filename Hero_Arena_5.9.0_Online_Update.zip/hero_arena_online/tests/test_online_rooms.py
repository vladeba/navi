"""Two anonymous browsers own separate seats; legacy APIs are never exposed online."""
import concurrent.futures,time,unittest,uuid
from flask import Flask
from models import HERO_CLASSES
from models.heroes_new import DEV_ARENA_MOB_KEYS
from services.online_rooms import OnlineRooms,RoomError,PLAYABLE
from services.online_api import online_blueprint,COOKIE

class Rooms(unittest.TestCase):
 def setUp(self):
  self.now=time.time();self.s=OnlineRooms(clock=lambda:self.now)
  self.a='host-session';self.b='guest-session';self.r=self.s.create(self.a,'Первый');self.code=self.r['code'];self.s.join(self.code,self.b,'Второй')
 def move(self,who,action,**data):
  r=self.s.state(self.code,who);return self.s.mutate(self.code,who,action,dict(revision=r['revision'],request_id=str(uuid.uuid4()),**data))
 def start(self,a='warrior',b='mage'):
  self.move(self.a,'choose',hero=a);self.move(self.b,'choose',hero=b);self.move(self.a,'ready',ready=True);return self.move(self.b,'ready',ready=True)
 def test_all_playable_characters_free_including_monk_and_owl(self):
  roster=self.s.roster();keys={x['type'] for x in roster};self.assertEqual(keys,set(HERO_CLASSES));self.assertEqual(len(keys),43);self.assertTrue({'monk','owlbeast'}<=keys);self.assertFalse(keys&DEV_ARENA_MOB_KEYS);self.assertTrue(all(not x['locked'] and x['required_wins']==0 for x in roster))
  for mob in DEV_ARENA_MOB_KEYS:
   with self.assertRaises(RoomError):self.move(self.a,'choose',hero=mob)
 def test_two_ready_players_start_fair_manual_battle(self):
  r=self.start('monk','owlbeast');self.assertEqual(r['phase'],'playing');b=self.s.rooms[self.code]['battle'];self.assertFalse(b.ai_ids);self.assertTrue(b.test_arena);self.assertFalse(b.story);self.assertEqual([h.level for h in (b.hero1,b.hero2)],[1,1]);self.assertFalse(b.items)
 def test_third_player_blocked_and_members_can_reconnect(self):
  self.assertEqual(self.s.join(self.code,self.a,'ignored')['seat'],0)
  with self.assertRaises(RoomError) as e:self.s.join(self.code,'third','Третий')
  self.assertEqual(e.exception.status,409)
  with self.assertRaises(RoomError):self.s.state(self.code,'third')
 def test_ready_toggle_choose_unreadies_only_self_and_names_escape_at_ui(self):
  self.move(self.a,'ready',ready=True);self.move(self.a,'choose',hero='monk');r=self.s.state(self.code,self.a);self.assertFalse(r['members'][0]['ready'])
  with self.assertRaises(RoomError):self.s.create('other','x'*25)
 def test_only_current_seat_can_move_and_cannot_choose_enemy_id(self):
  r=self.start();b=self.s.rooms[self.code]['battle'];own=self.a if b.current is b.hero1 else self.b;other=self.b if own==self.a else self.a
  with self.assertRaises(RoomError) as e:self.move(other,'turn',skill='attack',hero_id=b.current.id)
  self.assertEqual(e.exception.status,403);self.move(own,'turn',skill='attack')
 def test_stale_version_cannot_spend_another_turn(self):
  r=self.start();b=self.s.rooms[self.code]['battle'];own=self.a if b.current is b.hero1 else self.b
  with self.assertRaises(RoomError) as e:self.s.mutate(self.code,own,'turn',dict(skill='attack',revision=r['revision']-1,request_id=str(uuid.uuid4())))
  self.assertEqual(e.exception.status,409)
 def test_concurrent_duplicate_delivery_is_exactly_once(self):
  self.start();b=self.s.rooms[self.code]['battle'];own=self.a if b.current is b.hero1 else self.b;r=self.s.state(self.code,own);v=r['revision'];data=dict(skill='attack',revision=v,request_id=str(uuid.uuid4()))
  with concurrent.futures.ThreadPoolExecutor(4) as pool:answers=list(pool.map(lambda _:self.s.mutate(self.code,own,'turn',data),range(4)))
  self.assertEqual({x['revision'] for x in answers},{v+1})
  with self.assertRaises(RoomError):self.s.mutate(self.code,own,'turn',{**data,'skill':'auto'})
 def test_reaction_requires_owner_begin_and_single_shared_clock(self):
  self.start('assassin','mage');room=self.s.rooms[self.code];b=room['battle'];b.current=b.hero1;b._order=[b.hero1,b.hero2];b._index=0;b.hero1.restore_energy(999)
  r=self.move(self.a,'turn',skill='vital_cut');pid=r['pending_id'];self.assertTrue(r['battle']['pending']['options']);self.assertEqual(self.s.state(self.code,self.b)['battle']['pending']['options'],{})
  with self.assertRaises(RoomError):self.move(self.b,'begin',pending_id=pid)
  with self.assertRaises(RoomError):self.move(self.a,'react',pending_id=pid,choice={})
  r=self.move(self.a,'begin',pending_id=pid);deadline=r['deadline'];self.now+=1;r=self.move(self.a,'begin',pending_id=pid);self.assertEqual(r['deadline'],deadline)
  r=self.move(self.a,'react',pending_id=pid,choice='timeout');self.assertFalse(r['battle']['pending'])
 def test_timeout_and_rematch_create_fresh_heroes(self):
  self.start('ghoul','paladin');b=self.s.rooms[self.code]['battle'];self.now+=95;r=self.s.state(self.code,self.a);self.assertEqual(r['phase'],'finished');self.assertTrue(b.finished)
  self.move(self.a,'ready',ready=True);r=self.move(self.b,'ready',ready=True);self.assertEqual(r['match'],2);self.assertIsNot(b,self.s.rooms[self.code]['battle']);self.assertFalse(r['battle']['finished'])
 def test_waiting_reaction_expires_without_hanging_room(self):
  self.start('assassin','mage');b=self.s.rooms[self.code]['battle'];b.current=b.hero1;b._order=[b.hero1,b.hero2];b._index=0;b.hero1.restore_energy(999)
  self.move(self.a,'turn',skill='vital_cut');self.now+=16;r=self.s.state(self.code,self.b);self.assertFalse(r['battle']['pending'])
 def test_surrender_owns_seat_and_leave_closes_for_both(self):
  self.start();b=self.s.rooms[self.code]['battle'];self.move(self.b,'surrender');self.assertIs(b.winner,b.hero1);self.move(self.a,'leave')
  with self.assertRaises(RoomError):self.s.state(self.code,self.b)
 def test_room_expiry_and_memory_cap(self):
  self.now+=7201
  with self.assertRaises(RoomError) as e:self.s.state(self.code,self.a)
  self.assertEqual(e.exception.status,410)
  self.s.MAX_ROOMS=1;self.s.create('new','Новый')
  with self.assertRaises(RoomError):self.s.create('more','Другой')

 def test_malformed_legacy_reaction_rolls_back_without_losing_pending(self):
  self.start('ogre','mage');room=self.s.rooms[self.code];b=room['battle'];b.current=b.hero1;b._order=[b.hero1,b.hero2];b._index=0;b.hero1.restore_energy(999)
  r=self.move(self.a,'turn',skill='feast');pid=r['pending_id'];r=self.move(self.a,'begin',pending_id=pid);before=r['battle'];version=r['revision']
  with self.assertRaises(RoomError):self.move(self.a,'react',pending_id=pid,choice={'picked':5})
  after=self.s.state(self.code,self.a);self.assertEqual(after['revision'],version)
  self.assertEqual(after['battle']['pending'],before['pending']);self.assertEqual(after['battle']['log'],before['log'])
  for old,new in zip(before['heroes'],after['battle']['heroes']):
   for field in ('id','hp','energy','effects','summon'):self.assertEqual(old.get(field),new.get(field))
   self.assertEqual([(s['key'],s['available'],s['cooldown_left']) for s in old['skills']],[(s['key'],s['available'],s['cooldown_left']) for s in new['skills']])
  self.move(self.a,'react',pending_id=pid,choice='timeout');self.assertFalse(self.s.state(self.code,self.a)['battle']['pending'])
 def test_non_string_hero_selection_is_a_client_error(self):
  for key in ({},[],True,5,None):
   with self.assertRaises(RoomError):self.move(self.a,'choose',hero=key)

class OnlineHTTP(unittest.TestCase):
 def setUp(self):
  from online_app import app
  self.app=app;self.a=app.test_client();self.b=app.test_client();self.c=app.test_client();self.headers={'X-Arena-Client':'online'}
 def post(self,c,path,data):return c.post(path,json=data,headers=self.headers)
 def test_session_cookie_and_no_local_save_dev_or_legacy_battle_routes(self):
  r=self.post(self.a,'/api/online/rooms',{'name':'HTTP'});self.assertEqual(r.status_code,200);self.assertIn('HttpOnly',r.headers['Set-Cookie']);self.assertIn('SameSite=Lax',r.headers['Set-Cookie']);code=r.json['code'];self.assertEqual(self.a.get('/api/online/rooms/'+code).status_code,200);self.assertEqual(self.b.get('/api/online/rooms/'+code).status_code,403)
  for path in ['/api/heroes','/api/players','/api/load','/api/save','/api/test_arena/battle','/api/battles/1/turn']:
   self.assertEqual(self.post(self.c,path,{}).status_code,404,path)
  self.assertEqual(self.a.get('/api/classes/wolf').status_code,404)
 def test_cross_origin_post_and_missing_custom_header_rejected(self):
  self.assertEqual(self.a.post('/api/online/rooms',json={}).status_code,403)
  r=self.a.post('/api/online/rooms',json={},headers={**self.headers,'Origin':'https://other.example'});self.assertEqual(r.status_code,403)
 def test_secure_cookie_behind_https_and_room_page_uses_shared_minigames(self):
  r=self.a.post('/api/online/rooms',json={'name':'HTTPS'},headers=self.headers,base_url='https://localhost');self.assertIn('Secure;',r.headers['Set-Cookie']);self.assertNotIn('session',str(r.json));page=self.a.get('/online').text;self.assertIn('window.ONLINE_MODE=true',page);self.assertIn('/static/v56.js',page);self.assertIn('/static/online.js',page)

if __name__=='__main__':unittest.main()
