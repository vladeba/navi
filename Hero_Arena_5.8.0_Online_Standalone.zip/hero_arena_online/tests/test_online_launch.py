"""Cross-platform tunnel selection and verified downloads, without network mocks hiding combat."""
import hashlib,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import share_online as share

class Launch(unittest.TestCase):
 def test_windows_launchers_use_ascii_and_crlf(self):
  root=Path(__file__).resolve().parents[1]
  for name in ('start_online.bat','share_online.bat'):
   data=(root/name).read_bytes();data.decode('ascii')
   self.assertGreater(data.count(b'\r\n'),0)
   self.assertEqual(data.count(b'\r\n'),data.count(b'\n'))
   self.assertIn(b'cd /d "%~dp0"\r\n',data)
 def test_supported_platforms_pin_official_asset_hashes(self):
  for system,machine in [('Windows','AMD64'),('Linux','x86_64'),('Linux','aarch64'),('Darwin','arm64'),('Darwin','x86_64')]:
   name,digest=share.asset_for(system,machine);self.assertIn('cloudflared',name);self.assertEqual(len(digest),64);int(digest,16)
  with self.assertRaises(RuntimeError):share.asset_for('Unknown','unknown')
 def test_error_endpoint_is_never_presented_as_an_invitation(self):
  self.assertIsNone(share.public_url('failed: Post "https://api.trycloudflare.com/tunnel"'))
  self.assertEqual(share.public_url('https://four-random-words-here.trycloudflare.com'),'https://four-random-words-here.trycloudflare.com/online')
 def test_download_hash_mismatch_never_installs_or_executes_binary(self):
  with tempfile.TemporaryDirectory() as temp:
   with patch.object(share,'asset_for',return_value=('cloudflared-linux-amd64','0'*64)),patch.object(share.urllib.request,'urlopen',return_value=io.BytesIO(b'wrong')):
    with self.assertRaises(RuntimeError):share.connector(Path(temp))
   self.assertFalse((Path(temp)/'cloudflared').exists())
 def test_verified_download_is_cached_and_corruption_redownloaded(self):
  payload=b'verified-test-binary';expected=hashlib.sha256(payload).hexdigest()
  with tempfile.TemporaryDirectory() as temp,patch.object(share,'asset_for',return_value=('cloudflared-linux-amd64',expected)):
   folder=Path(temp)
   with patch.object(share.urllib.request,'urlopen',return_value=io.BytesIO(payload)) as fetch:binary=share.connector(folder);self.assertEqual(binary.read_bytes(),payload);fetch.assert_called_once()
   with patch.object(share.urllib.request,'urlopen') as fetch:self.assertEqual(share.connector(folder),binary);fetch.assert_not_called()
   binary.write_bytes(b'corrupt')
   with patch.object(share.urllib.request,'urlopen',return_value=io.BytesIO(payload)) as fetch:share.connector(folder);fetch.assert_called_once()
 def test_legacy_app_cannot_be_accidentally_shared(self):
  with patch.object(share.urllib.request,'urlopen',return_value=io.BytesIO(b'{"status":"ok","version":"5.6.0"}')):
   with self.assertRaises(RuntimeError):share.check_server(5000)
  with patch.object(share.urllib.request,'urlopen',return_value=io.BytesIO(b'{"status":"ok","version":"5.8.0"}')):share.check_server(5000)

if __name__=='__main__':unittest.main()
