/* Solo review controls: only timestamped physical input is submitted. */
(function(){'use strict';
const{setup,circle,line,text}=window.arenaMiniUI;
const near=(p,q,r)=>Math.hypot(p.x-q[0],p.y-q[1])<=r;
MINIGAMES.arena600=function(o,head){
 const mode=o.mode,buttons=mode==='charge'?'<button class="btn" id="rvHold">Реветь</button>':mode==='shadows'?[0,1,2].map(i=>`<button class="btn rvLane" data-i="${i}">Укрытие ${i+1}</button>`).join(''):mode==='lock'?'<button class="btn" id="rvTurn">Повернуть</button>':mode==='bluff'?[0,1,2].map(i=>`<button class="btn rvCard" data-i="${i}">🂠 ${i+1}</button>`).join(''):'';
 const r=setup(o,head,esc(o.instruction),buttons);r.state.actions=[];r.state.placements=[];
 let down=null,drag=null,placed=new Set(),angle=0;
 const ready=()=>r.elapsed()>=o.prepare_ms;
 if(mode==='charge'){
  const b=document.getElementById('rvHold');b.onpointerdown=e=>{e.preventDefault();if(!ready()||down!==null)return;b.setPointerCapture(e.pointerId);down=r.elapsed();r.state.down_ms=down};b.onpointerup=()=>{if(down===null)return;r.state.up_ms=r.elapsed();r.finish()};b.onpointercancel=b.onpointerup;
 }
 if(mode==='bluff')document.querySelectorAll('.rvCard').forEach(b=>b.onclick=()=>{if(!ready())return;r.state.actions.push({ms:r.elapsed(),card:+b.dataset.i});r.finish()});
 if(mode==='shadows')document.querySelectorAll('.rvLane').forEach(b=>b.onclick=()=>{if(!ready())return;const ms=r.elapsed(),w=o.waves.find(w=>ms<w.ms&&ms>=w.ms-650*o.factor);if(!w||r.state.actions.some(a=>a.wave===w.ms))return;r.state.actions.push({ms,lane:+b.dataset.i,wave:w.ms})});
 if(mode==='lock')document.getElementById('rvTurn').onclick=()=>{if(!ready()||r.state.actions.length>=3)return;r.state.actions.push({ms:r.elapsed(),angle});if(r.state.actions.length===3)r.finish()};
 const record=(p,t)=>{if(r.state.points.at(-1)?.t!==t)r.state.points.push({t,x:p.x,y:p.y})};
 const move=r.svg.onpointermove;r.svg.onpointermove=e=>{move(e);const p=r.pos(e);if(mode==='pocket'&&drag)record(p,r.elapsed());if(mode==='lock'&&(e.buttons||e.pointerType==='touch'))angle=(Math.atan2(p.y-130,p.x-180)*180/Math.PI+360)%360};
 r.svg.onpointerdown=e=>{e.preventDefault();if(!ready())return;const p=r.pos(e),t=r.elapsed();r.svg.setPointerCapture(e.pointerId);
  if(mode==='lock'&&(e.buttons||e.pointerType==='touch'))angle=(Math.atan2(p.y-130,p.x-180)*180/Math.PI+360)%360;
  if(mode==='sight'){r.state.actions.push({ms:t,x:p.x,y:p.y});r.finish()}
  if(mode==='roots'||mode==='rune_join'){const i=o.sources.findIndex((q,i)=>!placed.has(i)&&near(p,q,35));if(i>=0)drag={i,p,t}}
  if(mode==='pocket'&&near(p,[60,200],40)){drag={p,t};r.state.down_ms=t;record(p,t)}
 };
 r.svg.onpointerup=e=>{if(!drag)return;const p=r.pos(e),a=drag;drag=null;if(mode==='pocket'){r.state.up_ms=r.elapsed();record(p,r.state.up_ms);r.finish();return}r.state.placements.push({part:a.i,down_ms:a.t,up_ms:r.elapsed(),x0:a.p.x,y0:a.p.y,x1:p.x,y1:p.y});if(near(p,o.targets[a.i],40))placed.add(a.i);if(placed.size===o.targets.length)r.finish()};
 r.svg.onpointercancel=()=>drag=null;
 r.animate(t=>{
  let out='';
  if(mode==='sight'){const q=(t-o.prepare_ms)/(5000*o.factor),x=180+40*Math.sin(q*6.28),y=120+15*Math.sin(q*4);out=circle(x,y,48,'#66864d44','#a8c48b')+circle(x,y,32,'#8dbb6655','#cfdfa1')+text(180,245,'НАЖМИТЕ ПО ЦЕЛИ',16)}
  if(mode==='charge'){const v=down===null?0:(t-down)/(1400*o.factor);out=`<rect x="30" y="120" width="300" height="35" fill="#272330"/><rect x="155" y="120" width="100" height="35" fill="#68a564"/>`+line(30+250*Math.min(1.2,v),110,30+250*Math.min(1.2,v),165,'#fff0b4',4)+text(180,70,v>=.5&&v<=.9?'ОТПУСКАЙТЕ':'ЗАЖМИТЕ → ЗЕЛЁНОЕ → ОТПУСТИТЕ',14)}
  if(mode==='roots'||mode==='rune_join'){o.targets.forEach((p,i)=>{out+=line(...o.sources[i],...p,'#74836566',3)+circle(...p,34,placed.has(i)?'#71a45f':'#77777722','#b8cd9b')+text(p[0],p[1]+8,mode==='roots'?'⌁':['ᚱ','ᚨ','ᚦ'][i],28);if(!placed.has(i)){const q=drag?.i===i?[r.cursor.x,r.cursor.y]:o.sources[i];out+=circle(...q,25,'#7c9262','#d4e4b0')+text(q[0],q[1]+8,mode==='roots'?'⌁':['ᚱ','ᚨ','ᚦ'][i],25)}})}
  if(mode==='lock'){const i=r.state.actions.length,a=o.angles[Math.min(2,i)]*Math.PI/180;out=circle(180,130,75,'#312a3e','#bca16e')+circle(180+65*Math.cos(a),130+65*Math.sin(a),28,'#65945b88','#acd48c')+line(180,130,180+67*Math.cos(angle*Math.PI/180),130+67*Math.sin(angle*Math.PI/180),'#f7e7bb',6)+text(180,25,`ШТИФТЫ ${i}/3`,18)+text(180,245,'ЗАЖМИТЕ ОТМЫЧКУ → МЕТКА → ПОВЕРНУТЬ',12)}
  if(mode==='pocket')out=line(60,200,300,60,'#80aa6666',80)+line(60,200,300,60,'#c2d894',3)+text(60,210,'👛',30)+circle(300,60,27,'#71a461','#d0e4b5')+text(180,245,'КОШЕЛЁК → СВЕТЛЫЙ ВЫХОД',15);
  if(mode==='bluff')out=text(180,80,'ЛЮБАЯ КАРТА ДАЁТ ЗАЩИТУ',16)+text(180,130,'ДВЕ ИЗ ТРЁХ — СИЛЬНЫЕ',14)+text(180,185,'🂠     🂠     🂠',46);
  if(mode==='shadows'){const w=o.waves.find(w=>t<w.ms+120*o.factor);for(let i=0;i<3;i++)out+=circle(70+i*110,130,42,w&&i===w.unsafe?'#d7bd6955':'#34304c','#a58aad')+text(70+i*110,140,w&&i===w.unsafe?'☀':'👤',30);if(t>o.waves.at(-1).ms+150)r.finish()}
  r.svg.innerHTML=out;r.status(!ready()?'Приготовьтесь…':mode==='roots'||mode==='rune_join'?`Готово ${placed.size}/${o.targets.length}`:o.instruction);
  document.querySelectorAll('#rvHold,#rvTurn,.rvLane,.rvCard').forEach(b=>b.disabled=!ready());
 });
};
})();
