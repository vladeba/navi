"""Review tasks: readable controls, timed input replay, explicit partial rewards."""
import copy,math,random
from .skills import MiniGameSkill,Skill
from .effects import (Shield,DodgeBuff,DamageReduction,Berserk,Announcement)
from .minigames_56 import Replay,records,integer,number,events,near

STARS={('archer','aimed_shot'):2,('ogre','roar'):2,('ogre','ogre_spear'):2,
 ('shade','twins'):3,('shade','skull'):3,('dwarf','rune_stance'):2,
 ('goblin','lockpick'):2,('goblin','steal'):2,('goblin','cups'):2,
 ('mersey','execution_swing'):4,('mersey','slit_gaze'):4,
 ('hunter','traps'):3,('gnoll','hyena_laugh'):3,('centaur','totem_pulse'):3,
 ('aarakocra','dive'):3,('gambler','bluff_card'):1,('gambler','card_draw'):1,
 ('keltazar','blood_game'):1,('feliss','opening_sting'):3,('getou','raise_bones'):4,
 ('getou','puppet_threads'):3,('catfolk','pounce'):3,('cyclops','ram_horn'):4,
 ('bluetroll','catch_return'):4,('bluetroll','twin_spin'):4,('druid','root_chains'):2}
STARS.update({('hunter','mark_shot'):2,('gnoll','bone_dice'):2,('centaur','harp_curse'):3,
 ('paladin','dawn_circle'):2,('spiderqueen','spiderlings'):2,('spiderqueen','queen_bite'):2,
 ('pandaren','ignite'):2,('lightelf','star_arrow'):2,('lightelf','light_pillar'):4,
 ('getou','raise_zombie'):2})
def difficulty(hero,key):return 4 if key=='foe_catch_shadow' else STARS.get((hero,key),3)

NEW={('archer','aimed_shot'):('sight',3600,'Наведите на круг, дождитесь зелёного прицела и нажмите «Выстрел».',2),
 ('ogre','roar'):('charge',2800,'Зажмите «Реветь» и отпустите в широкой зелёной области.',2),
 ('ogre','ogre_spear'):('sight',3400,'Наведите на большой круг и нажмите «Бросить».',2),
 ('druid','root_chains'):('roots',4200,'Перетащите два корня из нижних кружков на светлые контуры у ног.',2),
 ('dwarf','rune_stance'):('rune_join',4500,'Перетащите три половинки рун к таким же видимым знакам.',2),
 ('shade','twins'):('shadows',4200,'Перед вспышкой выберите тёмное укрытие. Три вспышки, светлое место опасно.',3),
 ('goblin','lockpick'):('lock',4600,'Зажмите отмычку и поверните к зелёной метке. Отпустите: угол сохранится. Нажмите «Повернуть». Три штифта.',2),
 ('goblin','steal'):('pocket',3600,'Проведите кошелёк по светлой дорожке к выходу, не задевая колокольчики.',2),
 ('gambler','bluff_card'):('bluff',3200,'Выберите закрытую карту. Любой исход даёт защиту; две карты из трёх сильнее.',1)}

class ReviewGame(Replay,MiniGameSkill):
    game='arena600';PREP=600;AI_WEIGHTS=(35,45,15,5);TIERS=('Идеально','Хорошо','Частично','Неудача')
    def pick_reactor(self,user,target,is_human):return user
    def is_available(self,user):return self.original600.is_available(user)
    @property
    def deals_damage(self):return bool(getattr(self.original600,'deals_damage',False))
    def describe_for(self,user):
        return self.original600.describe_for(user)+' · '+self.hint600
    def game_params(self,user,target):
        o=self.params(user);o.update(mode=self.mode600,instruction=self.hint600,label=self.name)
        if self.mode600 in ('roots','rune_join'):
            n=2 if self.mode600=='roots' else 3
            o.update(sources=[[80+i*200/(n-1),215] for i in range(n)],targets=[[80+i*200/(n-1),100] for i in range(n)])
        if self.mode600=='shadows':o['waves']=[{'ms':o['prepare_ms']+int(t*o['factor']),'unsafe':random.randrange(3)} for t in (1050,2050,3050)]
        if self.mode600=='lock':o['angles']=[random.randint(30,330) for _ in range(3)]
        return o
    def tier_from(self,c,o):
        if not isinstance(c,dict):return 3
        mode=o['mode'];elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);prep=o['prepare_ms']
        if elapsed<prep:return 3
        if mode=='bluff':
            a=events(c,'actions',o,1)
            return 0 if len(a)==1 and integer(a[0].get('card'),hi=2)>=0 else 3
        if mode=='charge':
            down=integer(c.get('down_ms'),hi=elapsed);up=integer(c.get('up_ms'),hi=elapsed)
            if down<prep or up<=down:return 3
            value=(up-down)/(1400*o['factor']);return 0 if .5<=value<=.9 else 1 if .35<=value<=1.05 else 2
        if mode=='sight':
            a=events(c,'actions',o,1)
            if not a:return 3
            t=a[0]['ms'];q=(t-prep)/(5000*o['factor']);pos=[180+40*math.sin(q*6.28),120+15*math.sin(q*4)]
            d=math.dist([number(a[0].get('x')),number(a[0].get('y'))],pos)
            return 0 if d<=32 else 1 if d<=48 else 3
        if mode in ('roots','rune_join'):
            placed=set()
            for a in records(c,'placements',64):
                if not isinstance(a,dict):continue
                i=integer(a.get('part'),hi=len(o['targets'])-1)
                down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
                if i<0 or down<prep or up-down<80*o['factor']:continue
                if near((number(a.get('x0')),number(a.get('y0'))),o['sources'][i],35) and near((number(a.get('x1')),number(a.get('y1'))),o['targets'][i],40):placed.add(i)
            return 0 if len(placed)==len(o['targets']) else 1 if placed else 3
        if mode=='lock':
            acts=events(c,'actions',o,3);n=0
            for i,a in enumerate(acts):
                d=abs((number(a.get('angle'))-o['angles'][i]+180)%360-180);n+=d<=32
            return 0 if n==3 else 1 if n==2 else 2 if n else 3
        if mode=='shadows':
            acts=events(c,'actions',o,3);n=0
            for w in o['waves']:
                match=next((a for a in acts if 0<=w['ms']-a['ms']<=650*o['factor']),None)
                if match and integer(match.get('lane'),hi=2)>=0 and match['lane']!=w['unsafe']:n+=1
            return 0 if n==3 else 1 if n==2 else 3
        if mode=='pocket':
            down=integer(c.get('down_ms'),hi=elapsed);up=integer(c.get('up_ms'),hi=elapsed)
            if down<prep or up<=down:return 3
            from .minigames_56 import trace
            pts=[dict(t=t,x=x,y=y) for t,x,y in trace(c,o) if down<=t<=up]
            if len(pts)<3 or up-down<100*o['factor']:return 3
            start=pts[0];end=pts[-1]
            if not near((start['x'],start['y']),(60,200),40) or not near((end['x'],end['y']),(300,60),40):return 3
            errors=sum(abs(p['y']-(235-.58*p['x']))>42 for p in pts)
            return 0 if errors==0 else 1 if errors<=len(pts)*.15 else 3
        return 3
    def ai_score(self,user,target):return self.original600.ai_score(user,target)
    def apply(self,user,target,tier,data):
        from .review_600 import LastStrikeBoost
        if self.mode600=='bluff':
            success=tier<3 and random.random()<2/3
            user.add_effect(DodgeBuff(2 if success else 1,22 if success else 10))
            if success:user.add_effect(DamageReduction(2,12,title='Блеф'))
            return ['🂡 Блеф: '+('сильная карта — +22% уклонения, −12% урона на 2 хода.' if success else 'малая карта — +10% уклонения на ход.')]
        if self.mode600=='shadows':
            from .heroes_42 import ShadowTwins
            n=2 if tier==0 else 1 if tier==1 else 0
            if n:user.add_effect(ShadowTwins(3,n))
            if tier==0:user.add_effect(LastStrikeBoost())
            return ['👥 Двойников: %s. %s'%(n,'Следующий Удар из тени +10%.' if tier==0 else '')]
        old=self.original600
        if tier==3:return ['Попытка не удалась.']
        if self.mode600 in ('roots','rune_join') and tier>0:
            if self.mode600=='roots':
                from .effects_42 import Rooted
                logs,_=self.strike(user,target,old.multiplier);target.add_effect(Rooted(1));return logs
            from .heroes_42 import _ArmorUp
            user.add_effect(_ArmorUp(1,2));user.fuse=0;return ['ᚱ Неполная руна: +2 брони на ход.']
        if self.mode600=='lock':
            return old.apply(user,target,min(tier,len(old.TIERS)-1),data)
        return old._perform(user,target)
    def _perform(self,user,target):return self.apply(user,target,self.ai_tier(user,target),None)


def adapt_games(hero,skills):
    out=[]
    for old in skills:
        config=NEW.get((hero.type_key,old.key))
        if not config:out.append(old);continue
        mode,limit,hint,stars=config
        new=ReviewGame(old.key,old.name,hint,cost=old.cost,cooldown=old.cooldown,icon=old.icon)
        new.effect=getattr(old,"effect",None);new.group=old.group;new.min_turn=old.min_turn;new.once_per_battle=old.once_per_battle;new.original600=old;new.mode600=mode;new.hint600=hint;new.TIME_LIMIT_MS=limit
        if (hero.type_key,old.key)==('druid','root_chains'):new.cost=18;old.cost=18
        out.append(new)
    return out


def install_updates():
    from . import minigames_58 as m58,minigames_59 as m59
    from .minigames_54 import DouseSkillMG
    from .heroes_42 import CatchShadowSkill,ShadowStrike
    from .review_600 import LastStrikeBoost,NextBlind
    # Exact timers and spec changes; never silently modify the combat reward.
    m58.SPECS['assassin','vital_cut']['period']=1100
    m58.SPECS['feliss','opening_sting'].update(period=1150,width=.055)
    m59.SPECS['catfolk','pounce']['limit']=5400
    for (hero,key),spec in m59.SPECS.items():
        if hero=='darkknight' and spec['mode']=='assembly':spec['limit']=10200
    # Modern params remain the same protocol used by replay validation and UI.
    old_params=m58.ModernGame.game_params
    def params(self,user,target):
        o=old_params(self,user,target);key=(user.type_key,self.key);f=o['factor'];prep=o['prepare_ms']
        if key==('hunter','traps'):
            o['waves']=[dict(lane=random.randrange(3),start=round((self.PREP+100+i*800)*f),end=round((self.PREP+900+i*800)*f),ms=round((self.PREP+650+i*800)*f)) for i in range(5)]
        if key==('gnoll','hyena_laugh'):
            o['sequence']=[random.randrange(3) for _ in range(4)];o['show_until']=prep+round(1800*f)
        if key==('centaur','totem_pulse'):
            o['nodes']=[[180+90*math.cos(i*math.tau/7),135+75*math.sin(i*math.tau/7)] for i in range(7)];o['nodes'].append(o['nodes'][0]);o['radius']=32
        if key==('aarakocra','dive'):
            o['gates']=[dict(x=x,ms=round((self.PREP+950+i*1000)*f)) for i,x in enumerate([80,250,110,270])]
        return o
    m58.ModernGame.game_params=params
    old_tier=m58.ModernGame.tier_from
    def tier(self,c,o):
        # These modes need a variable total; the old code hard-coded three.
        if o['mode']=='echo':
            answers=events(c,'actions',o,len(o['sequence']))
            if any(a['ms']<o['show_until'] for a in answers):return 3
            n=sum(integer(a.get('lane'),hi=2)==o['sequence'][i] for i,a in enumerate(answers))
            return m58._tier_count(n,len(o['sequence']))
        if o['mode']=='lanes' and len(o['waves'])==5:
            acts=events(c,'actions',o,5);used=set();n=0
            for a in acts:
                i=next((i for i,e in enumerate(o['waves']) if e['start']<=a['ms']<=e['end'] and abs(a['ms']-e['ms'])<=250*o['factor'] and integer(a.get('lane'),hi=2)==e['lane'] and i not in used),None)
                if i is not None:used.add(i);n+=1
            self._last_hits600=n
            return m58._tier_count(n,5)
        if o['mode']=='steer' and len(o['gates'])==4:
            from .minigames_56 import trace,at
            pts=trace(c,o);elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms'])
            if not pts:return 3
            n=sum(g['ms']<=elapsed and abs(at(pts,g['ms'])[0]-g['x'])<=39 for g in o['gates'])
            return m58._tier_count(n,4)
        return old_tier(self,c,o)
    m58.ModernGame.tier_from=tier
    old_result=m58.ModernGame.result_data
    def result(self,c,o):
        if o['mode']=='lanes' and len(o['waves'])==5:
            self.tier_from(c,o);return {'trap_hits':getattr(self,'_last_hits600',0)}
        return old_result(self,c,o)
    m58.ModernGame.result_data=result
    old_apply=m58.ModernGame.apply
    def apply(self,user,target,tier,data):
        logs=old_apply(self,user,target,tier,data)
        if user.type_key=='hunter' and self.key=='traps':
            hits=(data or {}).get('trap_hits',(5,4,2,0)[tier]);n=user.heal(3*hits)
            logs.append('🪤 %s капканов: +%s HP.'%(hits,n))
        return logs
    m58.ModernGame.apply=apply
    m58.SPECS['hunter','traps'].update(slow=(3,2),hint='Пять следов: выберите дорожку при пересечении зелёной полосы. Каждый успех лечит на 3 HP.',reward='Пять капканов: ×1.25 и −2 скорости на 3 хода; каждый пойманный след лечит 3 HP, максимум 15.')
    m58.SPECS['gnoll','hyena_laugh'].update(hint='Запомните четыре стрелки, затем повторите. Во время показа нажимать не нужно.',reward='Четыре верных ответа: ×1.2, кража до 18 ресурса и замедление на ход; три — меньшая награда.')
    m58.SPECS['centaur','totem_pulse']['hint']='Соедините семь тотемов по номерам и вернитесь к первому.'
    m58.SPECS['aarakocra','dive'].update(hint='Проведите птицу через четыре чередующихся просвета. Они видны заранее.',reward='Четыре просвета: ×2.15, пробой 40% брони и кровотечение 3 HP на 3 хода.')
    # Each douse target must physically fit the unchanged 2.8 second clock.
    DouseSkillMG.game_params=lambda self,u,t:{'count':6,'icon':'🍺','spawn_ms':330,'life_ms':550}
    def douse_tier(self,c,o):
        n=integer(c.get('hits'),hi=6) if isinstance(c,dict) else -1
        return 0 if n==6 else 1 if n>=4 else 2 if n>=1 else 3
    DouseSkillMG.tier_from=douse_tier
    # Partial success still gives 3/4/5 turns, not an accidental eight-turn buff.
    # Matched UI and backend: both caught blades count as caught. Gold stays narrow
    # and the UI explicitly distinguishes a catch from an ideal catch.
    # Slight radius tolerance matches the drawn handle's full visible stroke.
    old_shadow=ShadowStrike._perform
    def shadow(self,u,t):
        boost=next((e for e in u.get_effects() if isinstance(e,LastStrikeBoost)),None)
        old=self.multiplier;old_dodged=self.DODGED_MULT
        if boost:self.multiplier*=1.1;self.DODGED_MULT*=1.1
        try:return old_shadow(self,u,t)
        finally:
            self.multiplier=old;self.DODGED_MULT=old_dodged
            if boost in u._effects:u._effects.remove(boost)
    ShadowStrike._perform=shadow
