"""Pair-local data reuse: unchanged matchups and render-only fast mode checks."""
import argparse,json,random,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--out',required=True);p.add_argument('--full-vs-fast',action='store_true');args=p.parse_args()
sys.path.insert(0,args.project)
from models import HERO_CLASSES,Battle,Character,hp_journal
keys=list(HERO_CLASSES) if args.full_vs_fast else [k for k in HERO_CLASSES if k!='getou']
methods={n:getattr(Battle,n) for n in ('_add_log','_log_many','_capture_arena_result')};record=hp_journal.record

def fight(a,b,seed,fast):
 for name,method in methods.items():setattr(Battle,name,(lambda *a,**kw:None) if fast else method)
 hp_journal.record=(lambda *a:None) if fast else record
 random.seed(seed);Character._next_id=Battle._next_id=1
 x,y=HERO_CLASSES[a]('A'),HERO_CLASSES[b]('B');battle=Battle(x,y);win=battle.fight()
 return [1 if win is x else 0 if win is y else .5,battle.round,x.hp,y.hp]

rows=[]
for i in range(100):
 a=keys[i%len(keys)];b=keys[(i*7+9)%len(keys)];seed=543000+i
 if args.full_vs_fast and i%2==0:a='mage'
 result=fight(a,b,seed,False)
 if args.full_vs_fast:assert result==fight(a,b,seed,True),(a,b,seed)
 rows.append({'a':a,'b':b,'seed':seed,'result':result})
Path(args.out).write_text(json.dumps(rows,indent=2))
print('100 engine checks complete:',args.project,'full-vs-fast',args.full_vs_fast)
