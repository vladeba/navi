import os
import json
import unittest
from collections import Counter

from models import HERO_CLASSES, SKIN_THEMES, Character, DamageSkill, Poison, Stun
from services.game_service import GameService


class NewHeroes830Tests(unittest.TestCase):
    def test_both_heroes_are_playable_with_complete_kits_and_skins(self):
        service = GameService()
        roster = {entry['type']: entry for entry in service.list_classes()}
        for key in ('keggo', 'grod'):
            with self.subTest(hero=key):
                hero = HERO_CLASSES[key]('Проверка')
                self.assertTrue(hero.creatable)
                self.assertFalse(hero.secret)
                self.assertIn(key, roster)
                self.assertEqual(len(hero.skills), 7)
                card = service.class_card(key)
                self.assertTrue(card['passive'])
                self.assertEqual(len([s for s in card['skills'] if s['is_minigame']]), 3)
                self.assertEqual(len(SKIN_THEMES[key]), 15)
                catalog = GameService.skin_catalog(key)
                self.assertEqual(len(catalog), 15)
                self.assertEqual(Counter(entry['rarity'] for entry in catalog),
                                 {'common': 5, 'rare': 4, 'epic': 3, 'legendary': 2, 'mythic': 1})
                self.assertTrue(all(entry['available'] for entry in catalog))
                self.assertTrue(os.path.isfile(os.path.join('static', 'images', f'{key}.jpg')))

    def test_keggo_records_last_successful_enemy_damage_and_mimics_it(self):
        keggo = HERO_CLASSES['keggo']('Кегго')
        keggo.dodge = 0
        attacker = HERO_CLASSES['warrior']('Враг')
        attacker.crit_chance = 0
        skill = DamageSkill('venom_hit', 'Ядовитый удар', '', multiplier=1.3,
                            accuracy=1, effect=lambda: Poison(2, 10), effect_chance=1)
        skill.execute(attacker, keggo)
        self.assertIsNotNone(keggo.last_enemy_damage_skill)
        self.assertIs(keggo.last_enemy_effect_type, Poison)

        before = attacker.hp
        result = keggo.skills['mimic']._perform(keggo, attacker)
        self.assertLess(attacker.hp, before)
        self.assertTrue(any('ослабленную копию' in line for line in result))
        self.assertEqual(keggo.mimic_resist_type, Poison)
        self.assertEqual(keggo.mimic_resist_turns, 1)
        poisoned = Poison(2, 10)
        keggo.add_effect(poisoned)
        self.assertEqual(poisoned.power, 7)
        from unittest.mock import patch
        keggo.mimic_resist_type = Stun
        with patch('models.heroes830.random.random', return_value=.1):
            self.assertFalse(keggo.add_effect(Stun(1)))
        self.assertIsNone(keggo.last_enemy_damage_skill)

    def test_tongue_lash_returns_combat_logs_and_drains_energy_on_hit(self):
        keggo = HERO_CLASSES['keggo']('Кегго')
        target = HERO_CLASSES['warrior']('Враг')
        target.dodge = 0
        target.restore_energy(20)
        logs = keggo.skills['tongue']._perform(keggo, target)
        self.assertIsInstance(logs, list)
        self.assertEqual(target.energy, 20)
        self.assertTrue(any('вытянул 10 энергии' in line for line in logs))

    def test_grod_skill_cost_tax_scales_with_grods_health(self):
        grod = HERO_CLASSES['grod']('Грод')
        enemy = HERO_CLASSES['warrior']('Враг')
        enemy.opponent = grod
        skill = enemy.skills['heavy_strike'] if 'heavy_strike' in enemy.skills else next(
            s for s in enemy.skills.values() if s.cost > 0)
        base_cost = skill.cost
        self.assertEqual(enemy.skill_cost(skill), int(__import__('math').ceil(base_cost * 1.10)))
        grod.hp = round(grod.max_hp * .25)
        self.assertEqual(enemy.skill_cost(skill), int(__import__('math').ceil(base_cost * 1.35)))
        self.assertEqual(grod.to_dict()['breath_tax'], 35)

    def test_all_six_minigames_accept_a_valid_solution_not_a_claimed_score(self):
        from tests.solutions810 import winning810
        enemy = HERO_CLASSES['warrior']('Враг')
        count = 0
        for key in ('keggo', 'grod'):
            hero = HERO_CLASSES[key](key)
            for skill in hero.skills.values():
                if not skill.reaction:
                    continue
                count += 1
                options = skill.public_options(hero, enemy)
                json.dumps(options, allow_nan=False)
                self.assertEqual(skill.tier_from(winning810(skill, options), options), 0)
                self.assertEqual(skill.tier_from({'elapsed_ms': options['time_limit_ms'] - 1,
                                                  'score': 9999, 'hits': 999}, options), 3)
        self.assertEqual(count, 6)

    def test_hybrid_role_display_fix_remains_included(self):
        vervelt = HERO_CLASSES['vervelt']('Вервельт')
        jotunlok = HERO_CLASSES['jotunlok']('Йотунлок')
        self.assertEqual((vervelt.to_dict()['role'], jotunlok.to_dict()['role']), ('warrior', 'tank'))
        self.assertEqual(vervelt.role, 'tank')
        self.assertEqual(jotunlok.role, 'warrior')


if __name__ == '__main__':
    unittest.main()
