"""Reachability solutions expressed only as real bounded player inputs."""
import math
from collections import deque

def path_choice(o,coords,duration=3000,start=None):
 start=o['prepare_ms']+100 if start is None else start
 points=[dict(t=start+round(i*duration/(len(coords)-1)),x=x,y=y) for i,(x,y) in enumerate(coords)]
 return dict(elapsed_ms=start+duration+50,points=points,holds=[dict(down_ms=start,up_ms=start+duration)])
def controls(o,m):
 a=[];held=set();x=v=0.;pressure=35.;stamina=100.;f=o.get('phase',0)
 for i in range(round(o['duration']/25)):
  tm=o['prepare_ms']+i*25;want=set()
  if m=='water_balance':
   z=-x*.16-v*1.3-math.sin(i*.032+f)*.25
   if z>.015:want={'right'}
   elif z<-.015:want={'left'}
  elif m=='shield_wrestle':want={'right'}
  elif m=='pressure_manage':want={'fuel'} if pressure<79 else set()
  elif m=='bear_hug':
   if x<.8:want.add('left')
   if v<.8:want.add('right')
  elif m=='rabbit_escape':
   nextb=next((b for b in o['obstacles'] if b['ms']>=tm),o['obstacles'][-1]);target=(o.get('control_target',.7) if nextb['lane']==0 else 0)
   z=(target-x)*o.get('control_gain',1)-v*o.get('control_damping',1)
   if z>.035:want={'right'}
   elif z<-.035:want={'left'}
  elif m=='bear_balance':
   z=(o.get('control_target',.8)-x)*o.get('control_gain',.5)-v*o.get('control_damping',1.6)-math.sin(i*.025+f)*.333
   if z>.008:want={'right'}
   elif z<-.008:want={'left'}
  if i:
   changes=[(k,False) for k in sorted(held-want)]+[(k,True) for k in sorted(want-held)]
   for j,(k,down) in enumerate(changes):a.append(dict(ms=tm-len(changes)+j,key=k,down=down))
   held=want
  d=int('right' in held)-int('left' in held)
  if m=='water_balance':v=(v+d*.055+math.sin(i*.032+f)*.018)*.98;x+=v*.08
  elif m=='pressure_manage':
   pressure+=.5 if 'fuel' in held else -.12
   if 'vent' in held:pressure-=.9
   pressure=max(0,min(110,pressure))
  elif m=='rabbit_escape':v=(v+d*.035)*.92;x=max(-1,min(1,x+v*.12))
  elif m=='bear_hug':x=max(0,min(1,x+(.006 if 'left' in held else -.003)));v=max(0,min(1,v+(.006 if 'right' in held else -.003)))
  elif m=='bear_balance':v=(v+d*.018+math.sin(i*.025+f)*.006)*.98;x+=v*.07
 return dict(elapsed_ms=o['prepare_ms']+o['duration']+20,actions=a)

def winning810(s,o):
 m=o['mode'];p=o['prepare_ms'];c=dict(elapsed_ms=o['time_limit_ms']-1,actions=[])
 def add(**v):c['actions'].append(dict(ms=p+100+len(c['actions'])*50,**v))
 if m=='bear_balance':
  for target in (.65,.8,.95):
   for gain in (.15,.3,.5,.8):
    for damping in (.6,1,1.6,2.4):
     c0=controls(dict(o,control_target=target,control_gain=gain,control_damping=damping),m)
     if s.tier_from(c0,o)==0:return c0
  raise AssertionError('No reachable bear balance')
 if m=='rabbit_escape':
  for target in (.6,.7,.85,-.6,-.7):
   for gain in (.6,1,1.5,2):
    for damping in (.6,1,1.6,2):
     c0=controls(dict(o,control_target=target,control_gain=gain,control_damping=damping),m)
     if s.tier_from(c0,o)==0:return c0
  raise AssertionError('No reachable rabbit escape')
 if m in ('water_balance','shield_wrestle','pressure_manage','bear_hug'):return controls(o,m)


 if m=='water_pipes':
  for i,(v,t) in enumerate(zip(o['turns'],o['solution'])):
   for _ in range((t-v)%4):add(i=i)
 elif m in ('water_pressure','song_intervals'):
  target=o['target'] if m=='water_pressure' else [o['base'],o['base']+o['intervals'][0],o['base']+sum(o['intervals'])]
  for i,n in enumerate(target):
   for _ in range(n):add(i=i,delta=1)
 elif m=='poison_mix':
  add(i=1,delta=1);add(i=2,delta=1);add(i=2,delta=1)
 elif m=='dual_tune':
  delta=o['target'][1]-o['initial'][1]
  for _ in range(delta):add(i=1,delta=1)
  n=o['target'][0]-o['initial'][0]-delta
  for _ in range(abs(n)):add(i=0,delta=1 if n>0 else -1)
 elif m=='shield_track':
  c['points']=[dict(t=a['ms'],x=180+70*math.cos(a['angle']),y=130+70*math.sin(a['angle'])) for a in o['arrows']]
 elif m=='spear_arc':
  tm=(o['target'][0]-65)/10;vy=(o['target'][1]-205-.5*o['gravity']*tm*tm)/tm;add(x=65-10/.22,y=205-vy/.22,x0=65,y0=205,down_ms=p+10,up_ms=p+210);c['actions'][-1]['ms']=p+210
 elif m=='knife_weave':
  for i,k in enumerate(o['knives']):
   d=k['ms']+round(1200*o['factor']);up=d+round(300*o['factor']);y=35+(d-k['ms'])*.07/o['factor'];c['actions'].append(dict(ms=up,i=i,down_ms=d,up_ms=up,x0=k['x'],y0=y,x1=k['x'],y1=y-80))
 elif m in ('sword_cuts','wire_connect'):

  c['cuts']=[];c['points']=[]
  for i,(start,end) in enumerate(zip(o['starts'],o['ends'])):
   d=p+100+i*1400;route=[start,end]
   if m=='wire_connect' and i==0:route=[start,[90,100],[245,100],end]
   duration=1000;c['cuts'].append(dict(down_ms=d,up_ms=d+duration,x0=start[0],y0=start[1],x1=end[0],y1=end[1]))
   for j,pt in enumerate(route):c['points'].append(dict(t=d+round(j*duration/(len(route)-1)),x=pt[0],y=pt[1]))
 elif m in ('trap_place','bear_summon'):
  for i,(x,y) in enumerate(o.get('spots',o.get('slots',[]))):add(i=i,x=x,y=y)
 elif m=='clone_shuffle':add(i=o['order'].index(0),j=o['safe'])
 elif m=='mask_logic':
  for i,(x,y) in enumerate(zip(o['faces'],o['labels'])):
   if x!=y:add(i=i)
 elif m=='armor_deduce':add(i=o['weak'])
 elif m=='song_contour':return path_choice(o,[(x,130+o['amplitude']*math.sin((x-40)/280*math.tau*o['wave'])) for x in range(40,321,2)],5000)
 elif m=='shadow_route':
  for d in range(p+100,p+13000,200):
   trial=path_choice(o,[o['origin'],[180,130],o['target']],800,d)
   if s.tier_from(trial,o)==0:return trial
  raise AssertionError('No reachable shadow path')
 elif m=='saw_resistance':return path_choice(o,[(x,130) for x in range(45,316,3)],6000)
 elif m=='bear_aim':return path_choice(o,[o['origin'],o['target']],500)
 elif m=='echo_memory':
  for i,v in enumerate(o['sequence']):c['actions'].append(dict(ms=p+o['reveal']+100+i*200,i=v))
 elif m=='choir_cancel':
  for v,ms in zip(o['voices'],o['voice_ms']):
   c['actions'] += [dict(ms=ms,tone=o['opposite'][v],down=True),dict(ms=ms+o['voice_window'],tone=o['opposite'][v],down=False)]
 elif m=='gear_fit':
  add(i=o['teeth'].index(o['target_teeth']))
  for _ in range(o['angle']):add(rotate=True)
 elif m=='rabbit_summon':
  for i in range(1,6):add(i=o['stitches'].index(i))
 elif m=='rabbit_hops':
  queue=deque([(o['start'],[])]);seen={o['start']}
  while queue:
   i,route=queue.popleft()
   if i==o['goal']:
    for v in route:add(i=v)
    break
   for j in range(25):
    if j not in seen and j not in o['water'] and abs(i//5-j//5)+abs(i%5-j%5)==1:seen.add(j);queue.append((j,route+[j]))
 elif m=='rabbit_combo':
  for k in o['combo']:add(key=k)
 else:raise AssertionError(m)
 return c

def winning_legacy(s,o):
 m=o['mode'];p=o['prepare_ms'];c=dict(elapsed_ms=o['time_limit_ms']-1,actions=[])
 def add(**v):c['actions'].append(dict(ms=p+200+len(c['actions'])*400,**v))
 if m=='stone_mend':
  c['holds']=[];c['points']=[]
  for i,(x,y) in enumerate(o['nodes']):
   d=p+100+i*800;up=d+round(350*o['factor']);c['holds'].append(dict(node=i,down_ms=d,up_ms=up));c['points'] += [dict(t=d,x=x,y=y),dict(t=up,x=x,y=y)]
 elif m in ('stone_steps','titan_pillar'):
  for i,x in enumerate(o['targets']):add(i=i,x=x)
 elif m=='wolf_leap':return path_choice(o,[o['start'],[120,45],[230,45],o['end']],2200)
 elif m=='wolf_compress':
  pain=0.;blood=100.;wounds=0;down=False;step=max(1,round(25*o['factor']));cool=False
  for i in range(o['duration']//step):
   if pain>=87:cool=True
   if pain<62:cool=False
   new=not cool
   tm=p+i*step
   if new!=down:c['actions'].append(dict(ms=tm,side='compress',down=new));down=new
   if down:pain+=.45;blood-=.6
   else:pain=max(0,pain-.8);blood=min(100,blood+.08)
   if blood<=0 and pain<90:wounds+=1;blood=80
   if wounds==3:break
  c['elapsed_ms']=min(o['time_limit_ms']-1,p+o['duration']+20)
 elif m=='shell_tide':
  for i,a in enumerate([min(o['waves'])-.1,max(o['waves'])+.1]):add(i=i,x=180+75*math.cos(a),y=130+75*math.sin(a))
 elif m=='ice_trident':
  center=o['targets'][1];angle=math.atan2(o['targets'][2][1]-center[1],o['targets'][2][0]-center[0]);n=round(angle/(math.pi/12))
  for _ in range(abs(n)):add(rotate=1 if n>0 else -1)
  add(x=center[0],y=center[1])
 elif m=='titan_fall':return path_choice(o,o['nodes'],3000)
 elif m=='titan_fist':
  for cracks in o['cracks']:add(i=max(range(3),key=lambda k:cracks[k]))
 elif m=='sand_cut':
  coords=[(180+78*math.cos(i*math.tau*1.02/120),130+78*math.sin(i*math.tau*1.02/120)) for i in range(121)]+[(180,130),(180,235)]
  return path_choice(o,coords,5000)
 elif m=='sand_avoid':
  # Brute-force a small family of physical on/off schedules, not a quality flag.
  for duration in (800,1100,1400,1800,2300,3000):
   for delay in range(0,1800,150):
    trial=dict(elapsed_ms=p+o['duration']+20,actions=[dict(ms=p+delay,side='right',down=True),dict(ms=p+delay+duration,side='right',down=False)])
    if s.tier_from(trial,o)==0:return trial
  return dict(elapsed_ms=p+o['duration']+20,actions=[dict(ms=p,side='right',down=True)])
 elif m=='barbarian_pull':
  for i in range(12):
   d=p+100+i*550;up=d+round(300*o['factor']);c['actions'].append(dict(ms=up,side='left' if i%2==0 else 'right',down_ms=d,up_ms=up,dy=100))
 elif m=='barbarian_hunt':c['points']=[dict(t=p+100+i*1200,x=x,y=y) for i,(x,y) in enumerate(o['tracks'])]
 elif m=='gladiator_reflect':
  a=o['goal']/2;add(x=180+70*math.cos(a),y=130+70*math.sin(a))
 elif m=='gladiator_steady':c['points']=[dict(t=t,x=180-28*math.sin((t-p)/1000*1.3+o['phase']),y=130-18*math.cos((t-p)/1000*1.7)) for t in range(p,p+o['duration']+1,25)]
 elif m=='gladiator_break':
  for i in (3,4,5):
   for _ in range(o['plates'][i]):add(i=i)
 else:raise AssertionError(m)
 return c
