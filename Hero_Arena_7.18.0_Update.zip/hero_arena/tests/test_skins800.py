import tempfile,unittest
from pathlib import Path
from collections import Counter
from services.game_service import GameService
from models import HERO_CLASSES
from solo_app import app

HEROES=('buattila','afill')
EXPECTED={'common':6,'rare':5,'epic':4,'legendary':3,'mythic':2}
class SkinPatch800(unittest.TestCase):
 def test_catalog_has_all_unique_available_skins(self):
  client=app.test_client()
  for hero in HEROES:
   with self.subTest(hero=hero):
    entries=GameService.skin_catalog(hero)
    expected=dict(EXPECTED);expected['legendary']=5 if hero=='afill' else 3
    self.assertEqual(Counter(s['rarity'] for s in entries),expected)
    self.assertEqual(len({s['skin'] for s in entries}),sum(expected.values()))
    self.assertEqual(len({s['name'] for s in entries}),sum(expected.values()))
    for s in entries:
     self.assertTrue(s['available'],s)
     response=client.get(s['image']);self.assertEqual(response.status_code,200,s)
     self.assertTrue(response.data.startswith(b'\xff\xd8\xff'),s);response.close()
