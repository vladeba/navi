from solutions810 import winning_legacy
import unittest,math
from unittest.mock import patch
from models import HERO_CLASSES
from models.effects import Bleed,Poison,Shield
from services.game_service import GameService
class AfillTest(unittest.TestCase):
 def setUp(self):self.h=HERO_CLASSES['afill']('Афилл');self.t=HERO_CLASSES['warrior']('Цель')
 def test_kit_and_name(self):self.assertEqual(GameService().class_card('afill')['hero_name'],'Афилл');self.assertEqual(self.h.role,'warrior');self.assertEqual(len(self.h.skills),7);self.assertEqual(sum(bool(s.reaction) for s in self.h.skills.values()),3)
 def test_weapons(self):
  h=self.h;t=self.t
  with patch.object(h,'hit_chance',return_value=1):
   h.skills['attack']._perform(h,t);self.assertEqual(h.weapon_style,'меч');self.assertTrue(t.has_effect(Bleed))
   h.skills['spear']._perform(h,t);self.assertEqual(h.weapon_style,'копьё');self.assertTrue(t.has_effect(Poison))
   h.skills['mace']._perform(h,t);self.assertEqual(h.weapon_style,'булава');self.assertEqual(h.skills['mace'].armor_pierce,.45)
  h.skills['block']._perform(h,t);self.assertEqual(h.weapon_style,'щит');self.assertTrue(h.has_effect(Shield))
 def test_games_correct_inputs(self):
  for key in ('parry','aim','smash'):
   s=self.h.skills[key];o=s.public_options(self.h,self.t);p=o['prepare_ms'];c={'elapsed_ms':o['time_limit_ms']-1};self.assertEqual(s.tier_from(c,o),3)
   if o['game']=='legacy810':
    self.assertEqual(s.tier_from(winning_legacy(s,o),o),0,key);continue
   if key=='parry':c['actions']=[dict(ms=b['ms'],side=b['side']) for b in o['beats']]
   elif key=='smash':c['actions']=[dict(ms=b) for b in o['beats']]
   else:
    c['actions']=[]
    for i in range(3):
     ms=p+800+i*1000;q=(ms-p)/o['period']*math.tau+i*1.2;c['actions'].append(dict(ms=ms,x=180+90*math.sin(q),y=130+40*math.cos(q)))
   self.assertEqual(s.tier_from(c,o),0)
