import unittest
from models import HERO_CLASSES
from services.game_service import GameService
class TitanTest(unittest.TestCase):
 def setUp(self):self.h=HERO_CLASSES['gordonos']('Гордонос');self.t=HERO_CLASSES['warrior']('Враг')
 def test_kit_and_pride(self):
  h=self.h;self.assertEqual(len(h.skills),8);self.assertEqual(sum(bool(s.reaction) for s in h.skills.values()),3);self.assertEqual(h.to_dict()['roles'],['tank','warrior']);self.assertEqual(GameService().class_card('gordonos')['hero_name'],'Гордонос')
  for i in range(7):h.note_attack(True)
  self.assertEqual(h.pride,5);self.assertAlmostEqual(h.damage_multiplier(),1.4);h.note_attack(False);self.assertEqual(h.pride,5)
 def test_two_real_hits_each_grant_one_charge(self):
  from unittest.mock import patch
  h=self.h;t=self.t
  with patch.object(h,'hit_chance',return_value=1):h.skills['double']._perform(h,t)
  self.assertEqual(h.pride,2)
 def test_fall_requires_max_and_punishes_failure(self):
  h=self.h;s=h.skills['fall'];h.pride=4;self.assertFalse(s.is_available(h));h.pride=5;self.assertTrue(s.is_available(h));before=h.hp;s.apply(h,self.t,3,None);self.assertEqual(h.pride,0);self.assertEqual(before-h.hp,round(h.max_hp*.25))
 def test_fall_requires_the_entire_fracture_gesture(self):
  from solutions810 import winning_legacy
  h=self.h;h.pride=5;s=h.skills['fall'];o=s.public_options(h,self.t);c=winning_legacy(s,o);self.assertEqual(s.tier_from(c,o),0)
  c['points']=[dict(t=o['prepare_ms']+100,x=0,y=0)];self.assertEqual(s.tier_from(c,o),3)
