import copy,json,math,random,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from models import HERO_CLASSES,Battle,Character
from models.rikz_609 import (Rikz,Focus609,Rhythm609,ExposedRhythm,UnmaskedGuard,gallery_result)
from models.effects import Stun,Antiheal,Effect

def hero(k='rikz'):
 h=HERO_CLASSES[k](k);h.configure_arena();h.reset();return h

def answer(s,o):
 if isinstance(s,Rhythm609):return dict(elapsed_ms=o['notes'][-1]['ms']+10,actions=[dict(ms=n['ms'],lane=n['lane']) for n in o['notes']])
 good=[t for t in o['targets'] if t['good']]
 if o['mode']=='fan':return dict(elapsed_ms=o['time_limit_ms']-10,cuts=[dict(ms=t['start']+100+j,x0=t['x']-5,y0=t['y'],x1=t['x']+5,y1=t['y']) for j,t in enumerate(good)])
 return dict(elapsed_ms=o['time_limit_ms']-10,clicks=[dict(id=t['id'],ms=t['start']+100,x=t['x'],y=t['y']) for t in good])

class Rikz609(unittest.TestCase):
 def setUp(self):self.h=hero();self.t=hero('warrior');self.h.opponent=self.t;self.t.opponent=self.h
 def battle(self,enemy='warrior'):
  h,t=HERO_CLASSES['rikz']('R'),HERO_CLASSES[enemy]('T');b=Battle(h,t,mode='manual');b.start();b.current=h;b._order=[h,t];b._index=0;h.restore_energy(999);h.turn_number=10;return h,t,b
 def respond(self,b,win=True):
  p=b.pending
  if not win:b.react('timeout');return
  c=answer(p['skill'],p['options']);p['secret']['started']=time.time()-c['elapsed_ms']/1000;p['secret']['deadline']=time.time()+10;b.react(c)
 def test_roster_role_and_fastest(self):
  self.assertEqual(len(HERO_CLASSES),64);self.assertEqual(self.h.role,'trickster');self.assertTrue(all(self.h.get_speed()>hero(k).get_speed() for k in HERO_CLASSES if k!='rikz'))
 def test_kit_three_regular_and_three_games(self):
  skills=list(self.h.skills.values());self.assertEqual(len(skills),7);self.assertEqual(sum(bool(s.reaction) for s in skills),3);self.assertFalse(self.h.can_use(self.h.skills['ghost_rhythm']))
  for s in skills:self.assertNotIn('кинжал',s.name+s.description);self.assertNotIn('клинк',s.name+s.description)
 def test_mask_cast_starts_free_upkeep(self):
  h,t,b=self.battle();energy=h.energy;b.play_turn('ghost_mask');self.assertTrue(h.mask_active);self.assertEqual(h.energy,energy-20);self.assertEqual(b.pending['skill'].key,'ghost_rhythm');self.assertEqual(b.current,h)
  energy=h.energy;self.respond(b);self.assertEqual(h.energy,energy);self.assertEqual(h.mask_level,1);self.assertIs(b.current,t);self.assertEqual(t.turn_number,1)
 def test_failed_upkeep_heals_once_and_advances_once(self):
  h,t,b=self.battle();h.hp=80;b.play_turn('ghost_mask');self.respond(b,False);self.assertFalse(h.mask_active);self.assertEqual(h.hp,87);self.assertIs(b.current,t);self.assertEqual(sum(isinstance(e,UnmaskedGuard) for e in h.get_effects()),1)
  h.drop_mask();self.assertEqual(h.hp,87)
 def test_free_voluntary_removal_ignores_mask_cooldown(self):
  h,t,b=self.battle();h.mask_active=True;h.hp=70;h.spend_energy(h.energy);h.set_cooldown('ghost_mask',5);self.assertTrue(h.can_use(h.skills['ghost_mask']));b.play_turn('ghost_mask');self.assertFalse(h.mask_active);self.assertEqual(h.energy,0);self.assertEqual(h.hp,77);self.assertIs(b.current,t);self.assertIsNone(b.pending)
 def test_guard_two_own_turns_no_stacking(self):
  h=self.h;h.mask_active=True;h.drop_mask();self.assertAlmostEqual(h.armor_total(),.7);h.start_turn();self.assertAlmostEqual(h.armor_total(),.7);h.start_turn();self.assertAlmostEqual(h.armor_total(),.7);h.start_turn();self.assertAlmostEqual(h.armor_total(),.3)
  for _ in range(2):h.mask_active=True;h.drop_mask()
  self.assertAlmostEqual(h.armor_total(),.7)
 def test_removal_respects_antiheal(self):
  self.h.mask_active=True;self.h.hp=80;self.h.add_effect(Antiheal(3));self.h.drop_mask();self.assertEqual(self.h.hp,80)
 def test_focus_actually_subtracts_from_mask(self):
  h=self.h;h.mask_active=True;h.mask_level=8;before=h.get_dodge();s=Focus609('f','f','f');s.apply(self.t,h,0,None);self.assertAlmostEqual(h.get_dodge(),before-.45);self.assertTrue(h.mask_active)
  h.start_turn();h.start_turn();self.assertLess(h.get_dodge(),before);h.start_turn();self.assertAlmostEqual(h.get_dodge(),before)
 def test_roots_can_reduce_entire_mask(self):
  class Roots(Effect):
   def dodge_bonus(self):return -1
  self.h.mask_active=True;self.h.add_effect(Roots(2));self.assertEqual(self.h.get_dodge(),0)
 def test_focus_only_every_four_enemy_actions(self):
  h,t,b=self.battle();h.mask_active=True;h.focus_clock=3;b.current=t;b._order=[t,h];b._index=0;energy=t.energy;b.play_turn('attack');self.assertIsInstance(b.pending['skill'],Focus609);self.assertIs(b.pending['reactor'],t);self.assertEqual(h.focus_clock,0);hp=h.hp
  self.respond(b);self.assertEqual(h.hp,hp);self.assertTrue(h.mask_active);self.assertIs(b.current,h);self.assertEqual(t.energy,energy+15)
 def test_damage_game_then_upkeep_does_not_repeat_damage(self):
  h,t,b=self.battle();h.mask_active=True;energy=h.energy;b.play_turn('trick_flurry');self.assertEqual(b.pending['skill'].key,'trick_flurry');self.respond(b);self.assertEqual(b.pending['skill'].key,'ghost_rhythm');hp=t.hp;self.assertLess(hp,t.max_hp);self.respond(b);self.assertEqual(t.hp,hp);self.assertEqual(h.energy,energy-26);self.assertIs(b.current,t)
 def test_lethal_attack_does_not_launch_upkeep(self):
  h,t,b=self.battle();h.mask_active=True;t.hp=1;h.skills['attack'].fixed_hit=1;b.play_turn('attack');self.assertTrue(b.finished);self.assertIsNone(b.pending)
 def test_both_rikz_queue_no_lost_or_duplicate_turn(self):
  h,t,b=self.battle('rikz');h.mask_active=t.mask_active=True;t.focus_clock=3;h.skills['attack'].fixed_hit=1;b.play_turn('attack');self.assertIsInstance(b.pending['skill'],Rhythm609);self.respond(b);self.assertIsInstance(b.pending['skill'],Focus609);self.assertIs(b.pending['actor'],h);self.respond(b);self.assertIs(b.current,t);self.assertIsNone(b.pending)
 def test_reset_clears_transient_mask_and_counters(self):
  self.h.mask_active=True;self.h.mask_level=8;self.h.focus_clock=3;self.h.drop_mask();self.h.reset();self.assertFalse(self.h.mask_active);self.assertEqual(self.h.mask_level,0);self.assertEqual(self.h.focus_clock,0);self.assertFalse(self.h.get_effects())
 def test_all_eight_stages_and_wrong_input(self):
  s=self.h.skills['ghost_rhythm'];previous=(99999,99999)
  for level in range(1,9):
   self.h.mask_active=True;self.h.mask_level=level-1;o=s.public_options(self.h,self.t);c=answer(s,o);self.assertEqual(o['level'],level);self.assertEqual(s.tier_from(c,o),0);self.assertLess(o['window'],previous[0]);self.assertLess(o['notes'][1]['ms']-o['notes'][0]['ms'],previous[1]);previous=(o['window'],o['notes'][1]['ms']-o['notes'][0]['ms']);c['actions'][0]['lane']=(c['actions'][0]['lane']+1)%3;self.assertEqual(s.tier_from(c,o),1)
 def test_gallery_perfect_clicks_swipes_and_traps(self):
  for key in ('trick_flurry','spectral_fan'):
   s=self.h.skills[key];o=s.public_options(self.h,self.t);c=answer(s,o);self.assertEqual(s.tier_from(c,o),0,(key,c));self.assertEqual(s.tier_from({'hits':999,'elapsed_ms':4000},o),3)
   if key=='trick_flurry':
    bad=next(t for t in o['targets'] if not t['good']);c['clicks'].append(dict(id=bad['id'],ms=bad['start']+101,x=bad['x'],y=bad['y']));c['clicks'].sort(key=lambda x:x['ms']);self.assertGreater(s.tier_from(c,o),0)
 def test_replay_rejects_future_and_out_of_bounds(self):
  s=self.h.skills['trick_flurry'];o=s.public_options(self.h,self.t);secret=s.secret_pick(o);c=answer(s,o);self.h.hp=80;hp=self.t.hp;s.resolve(self.h,self.t,c,secret);self.assertEqual(self.t.hp,hp)
  c['clicks'][0]['x']=999;c['clicks'][0]['y']=999;self.assertGreater(s.tier_from(c,o),0)
 def test_no_profile_or_result_based_rule_in_execution(self):
  h,t,b=self.battle();before=(h.max_hp,h.base_damage if hasattr(h,'base_damage') else h.get_damage(),h.get_dodge());h.perfect=True;self.assertEqual((h.max_hp,h.get_damage(),h.get_dodge()),before)

class RikzPractice609(unittest.TestCase):
 def setUp(self):
  import solo_app
  from services import GameService
  self.app=solo_app;self.old=solo_app.service;self.temp=tempfile.TemporaryDirectory();solo_app.service=GameService(str(Path(self.temp.name)/'accounts.json'));solo_app.service.seed(include_player=False);self.c=solo_app.app.test_client()
 def tearDown(self):self.app.service=self.old;self.temp.cleanup()
 def test_stage_picker_backend_and_validation(self):
  for level in range(1,9):
   r=self.c.post('/api/practice',json=dict(hero='rikz',skill='ghost_rhythm',level=level));self.assertEqual(r.status_code,200,r.json);self.assertEqual(r.json['pending']['options']['level'],level);self.assertTrue(r.json['heroes'][0]['rikz_mode']['mask'])
  for level in (0,9,True,'8',None):self.assertEqual(self.c.post('/api/practice',json=dict(hero='rikz',skill='ghost_rhythm',level=level)).status_code,400)
 def test_new_class_metadata_guide_assets(self):
  r=self.c.get('/api/classes/rikz');self.assertEqual(r.status_code,200);self.assertEqual(sum(bool(s['reaction']) for s in r.json['skills']),3)
  for s in r.json['skills']:
   if s['reaction']:self.assertTrue(s.get('difficulty_label'))
  for url in ('/static/rikz609.js','/static/images/rikz.jpg'):
   with self.c.get(url) as response:self.assertEqual(response.status_code,200)
 def test_countergame_can_be_practised(self):
  r=self.c.post('/api/practice',json=dict(hero='rikz',skill='foe_rikz_focus'));self.assertEqual(r.status_code,200,r.json);self.assertEqual(r.json['pending']['options']['mode'],'focus');self.assertTrue(r.json['heroes'][1]['rikz_mode']['mask'])
 def test_mask_removal_button_matches_block_state(self):
  h=hero();h.mask_active=True;h.set_cooldown('ghost_mask',5);d=h.skills['ghost_mask'].to_dict(h);self.assertTrue(d['available']);self.assertEqual(d['cooldown_left'],0);h.block_skills(['ghost_mask'],2);self.assertFalse(h.skills['ghost_mask'].to_dict(h)['available'])
 def test_shortened_game_scales_all_spawns(self):
  h=hero();t=hero('warrior')
  for key in ('trick_flurry','spectral_fan'):
   s=h.skills[key];s._time_multiplier=.7;o=s.public_options(h,t);self.assertTrue(all(p['end']<o['time_limit_ms'] for p in o['targets']));self.assertEqual(s.tier_from(answer(s,o),o),0)
 def test_skin_count_rarities_and_files(self):
  from collections import Counter
  from services import GameService
  c=GameService.skin_catalog('rikz');self.assertEqual(Counter(x['rarity'] for x in c),dict(common=5,rare=7,epic=6,legendary=4,mythic=1))
  self.assertEqual(len({x['skin'] for x in c}),23);self.assertTrue(all(x['available'] for x in c))
 def test_create_save_load_rikz(self):
  from services import GameService
  s=self.app.service;p=s.create_player(dict(username='rikztest',password='test123'));h=s.create_hero(dict(type='rikz',name='Проверка Рикза',player_id=p.id));h.skin='slate';s.save();fresh=GameService(s.save_path);fresh.load();copy=fresh.get_hero(h.id);self.assertEqual(copy.type_key,'rikz');self.assertEqual(copy.skin,'slate');self.assertFalse(copy.mask_active)
