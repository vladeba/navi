import unittest,math
from models import HERO_CLASSES
from models.effects import Shield
from services.game_service import GameService
class KsairTest(unittest.TestCase):
 def setUp(self):self.h=HERO_CLASSES['ksair']('Ксаир');self.t=HERO_CLASSES['warrior']('Цель')
 def test_kit_and_profile(self):
  self.assertEqual(len(self.h.skills),7);self.assertEqual(sum(bool(s.reaction) for s in self.h.skills.values()),4);self.assertEqual(GameService().class_card('ksair')['hero_name'],'Ксаир')
 def test_true_damage_bypasses_shield_and_armor_only_on_ideal(self):
  t=self.t;h=self.h;t.armor=50;t.add_effect(Shield(3,100));before=t.hp;g=h.skills['timing'];g.apply(h,t,0,None)
  self.assertLess(t.hp,before);self.assertEqual(next(e.power for e in t.get_effects() if isinstance(e,Shield)),100)
  t.hp=t.max_hp;g.apply(h,t,1,None);self.assertEqual(t.hp,t.max_hp)
 def test_cut_requires_full_rotation_and_center_crossing(self):
  from solutions810 import winning_legacy
  g=self.h.skills['timing'];o=g.public_options(self.h,self.t);c=winning_legacy(g,o);self.assertEqual(g.tier_from(c,o),0)
  self.assertEqual(g.tier_from({'elapsed_ms':o['time_limit_ms']-1},o),3)
  c['points']=c['points'][:20];self.assertNotEqual(g.tier_from(c,o),0)
 def test_two_turn_sweep(self):
  g=self.h.skills['sweep'];o=g.public_options(self.h,self.t);start=o['prepare_ms']+100;pts=[]
  for i in range(101):
   q=math.tau*2.1*i/100;pts.append({'t':start+i*60,'x':180+85*math.cos(q),'y':130+85*math.sin(q)})
  end=pts[-1]['t'];c={'elapsed_ms':end+10,'points':pts,'holds':[{'down_ms':start,'up_ms':end}]};self.assertEqual(g.tier_from(c,o),0)
 def test_linked_blades_all_random_positions_are_solvable(self):
  from collections import deque
  g=self.h.skills['align']
  for _ in range(30):
   o=g.public_options(self.h,self.t);q=deque([(tuple(o['initial']),[])]);seen=set();solution=None
   while q:
    state,path=q.popleft()
    if state in seen:continue
    seen.add(state)
    if state==(0,0,0):solution=path;break
    for i in range(3):
     nxt=list(state);nxt[i]=(nxt[i]+1)%4;nxt[(i+1)%3]=(nxt[(i+1)%3]+1)%4;q.append((tuple(nxt),path+[i]))
   self.assertIsNotNone(solution);c={'elapsed_ms':o['time_limit_ms']-1,'actions':[{'ms':o['prepare_ms']+200+i*200,'ring':v} for i,v in enumerate(solution)]};self.assertEqual(g.tier_from(c,o),0)
