import unittest,time,tempfile,json,random
from pathlib import Path
from unittest.mock import patch
from models import HERO_CLASSES,Battle
from models.effects import Shield,Antiheal
from models.acheron_612 import (Acheron,RoyalAegis,BloodMark,MaintainBlood,grant_shield,aegis,blast_values,self_wound)

def hero(k='acheron'):
 h=HERO_CLASSES[k](k);h.configure_arena();h.reset();return h

def plan(s,o):
 if o['mode']=='seal':return dict(elapsed_ms=2200,placements=[dict(ms=600+i*500,part=i,x0=a[0],y0=a[1],x1=b[0],y1=b[1]) for i,(a,b) in enumerate(zip(o['sources'],o['targets']))])
 if o['mode']=='bastion':return dict(elapsed_ms=2200,cuts=[dict(ms=600+i*350,x0=a[0],y0=a[1],x1=b[0],y1=b[1]) for i,(a,b) in enumerate(zip(o['nodes'],o['nodes'][1:]))])
 return dict(elapsed_ms=o['notes'][-1]['ms']+20,actions=[dict(ms=n['ms'],lane=n['lane']) for n in o['notes']])

class Acheron612(unittest.TestCase):
 def setUp(self):self.h=hero();self.t=hero('warrior');self.h.opponent=self.t;self.t.opponent=self.h
 def battle(self,kind='warrior'):
  h,t=HERO_CLASSES['acheron']('A'),HERO_CLASSES[kind]('T');b=Battle(h,t,mode='manual');b.start();b.current=h;b._order=[h,t];b._index=0;h.restore_energy(999);h.turn_number=10;return h,t,b
 def respond(self,b,success=True):
  if not success:b.react('timeout');return
  p=b.pending
  if p['options']['game']=='acheron612':c=plan(p['skill'],p['options'])
  else:
   from test_rikz609 import answer
   c=answer(p['skill'],p['options'])
  p['secret']['started']=time.time()-c['elapsed_ms']/1000;p['secret']['deadline']=time.time()+10;b.react(c)
 def mark(self,h,t,q=2):h.blood_target=t;h.blood_charges=q;t.add_effect(BloodMark(h))
 def test_roster_kit_and_role(self):
  self.assertEqual(len(HERO_CLASSES),64);self.assertEqual(self.h.role,'warrior');self.assertEqual(len(self.h.skills),8);self.assertEqual(sum(bool(s.reaction) for s in self.h.skills.values()),4)
 def test_three_shields_have_shared_cap(self):
  for k in ('royal','mirror','blood'):grant_shield(self.h,k,1000)
  self.assertEqual(aegis(self.h).power,int(self.h.max_hp*.35));self.assertEqual(len([e for e in self.h.get_effects() if isinstance(e,RoyalAegis)]),1)
 def test_twenty_percent_leaks_once_across_three_shields(self):
  for k in ('royal','mirror','blood'):grant_shield(self.h,k,25)
  hp=self.h.hp;old=aegis(self.h).power;self.h.take_damage(30,ignore_armor=True,attacker=self.t);self.assertEqual(hp-self.h.hp,6);self.assertEqual(old-aegis(self.h).power,24)
 def test_armor_before_leak_and_overflow_after_capacity(self):
  self.h.armor=5;grant_shield(self.h,'royal',5);hp=self.h.hp;self.h.take_damage(35,attacker=self.t);self.assertEqual(hp-self.h.hp,25);self.assertIsNone(aegis(self.h))
 def test_shield_piercing_and_antiheal(self):
  grant_shield(self.h,'royal',50);self.t.shield_pierce=.5;hp=self.h.hp;self.h.take_damage(30,ignore_armor=True,attacker=self.t);self.assertEqual(hp-self.h.hp,15)
  self.h.reset();grant_shield(self.h,'royal',50);self.h.add_effect(Antiheal(3));self.t.shield_pierce=0;hp=self.h.hp;self.h.take_damage(30,ignore_armor=True,attacker=self.t);self.assertEqual(hp-self.h.hp,18)
 def test_refresh_does_not_stack_and_parts_expire_independently(self):
  grant_shield(self.h,'royal',20);grant_shield(self.h,'royal',20);self.assertEqual(aegis(self.h).power,20);self.h.start_turn();grant_shield(self.h,'mirror',20)
  for _ in range(3):self.h.start_turn()
  self.assertNotIn('royal',aegis(self.h).parts);self.assertEqual(aegis(self.h).power,20);self.h.start_turn();self.assertIsNone(aegis(self.h))
 def test_blast_spends_only_remaining_shield_once(self):
  grant_shield(self.h,'royal',30);self.h.take_damage(20,ignore_armor=True,attacker=self.t);raw,wound=blast_values(self.h);hp=self.h.hp;self.h.skills['shatter_crown']._perform(self.h,self.t);self.assertEqual(hp-self.h.hp,wound);self.assertIsNone(aegis(self.h));self.assertFalse(self.h.skills['shatter_crown'].is_available(self.h));self.assertLess(raw,27)
 def test_special_shield_blast_traits(self):
  grant_shield(self.h,'royal',20);a=blast_values(self.h);self.h.reset();grant_shield(self.h,'mirror',20);b=blast_values(self.h);self.h.reset();grant_shield(self.h,'blood',20);c=blast_values(self.h);self.assertEqual(a[0],b[0]);self.assertEqual(a[1],b[1]*2);self.assertGreater(c[0],a[0])
 def test_self_wound_bypasses_armor_shields_and_can_kill(self):
  self.h.armor=50;self.h.add_effect(Shield(3,100));hp=self.h.hp;self_wound(self.h,17);self.assertEqual(hp-self.h.hp,17);self.h.hp=4;self_wound(self.h,17);self.assertEqual(self.h.hp,0)
 def test_simultaneous_blast_death_is_draw(self):
  h,t,b=self.battle();grant_shield(h,'royal',20);h.hp=blast_values(h)[1];t.hp=1;b.play_turn('shatter_crown');self.assertTrue(b.finished);self.assertTrue(b.draw)
 def test_heal_respects_antiheal(self):
  self.h.hp=50;self.h.add_effect(Antiheal(3));self.h.skills['royal_blood']._perform(self.h,self.t);self.assertEqual(self.h.hp,50)
 def test_initial_mark_does_not_launch_double_game(self):
  h,t,b=self.battle();old=h.energy;b.play_turn('blood_art');self.assertEqual(h.energy,old-25);self.respond(b);self.assertEqual(h.blood_charges,1);self.assertIsNone(b.pending);self.assertIs(b.current,t)
 def test_mark_upkeep_is_free_and_does_not_repeat_attack(self):
  h,t,b=self.battle();self.mark(h,t);h.skills['attack'].fixed_hit=1;b.play_turn('attack');self.assertIsInstance(b.pending['skill'],MaintainBlood);hp=t.hp;energy=h.energy;self.respond(b);self.assertEqual(t.hp,hp);self.assertEqual(h.energy,energy);self.assertEqual(h.blood_charges,3);self.assertIs(b.current,t)
 def test_failed_upkeep_loses_one_and_zero_removes_mark(self):
  s=MaintainBlood('m','m','m');self.mark(self.h,self.t,2);s.apply(self.h,self.t,3,None);self.assertEqual(self.h.blood_charges,1);s.apply(self.h,self.t,3,None);self.assertFalse(self.h.blood_charges);self.assertFalse(any(isinstance(e,BloodMark) for e in self.t.get_effects()))
 def test_cleansed_mark_cannot_be_maintained_or_detonated(self):
  self.mark(self.h,self.t,4);self.t._effects=[];state=self.h.to_dict();self.assertEqual(state['acheron_state']['mark_charges'],0);self.assertFalse(self.h.blood_target);self.assertTrue(self.h.skills['blood_art'].reaction);self.assertFalse(self.h.post_action_games(self.t))
 def test_mark_cap_five_and_early_explosion_costs_turn_not_energy(self):
  h,t,b=self.battle();self.mark(h,t,5);MaintainBlood('m','m','m').apply(h,t,0,None);self.assertEqual(h.blood_charges,5);h.blood_charges=3;h.spend_energy(h.energy);h.set_cooldown('blood_art',4);self.assertTrue(h.can_use(h.skills['blood_art']));self.assertIsNone(h.skills['blood_art'].reaction);b.play_turn('blood_art');self.assertEqual(h.energy,0);self.assertFalse(h.blood_charges);self.assertIs(b.current,t);self.assertIsNone(b.pending)
 def test_mark_damage_increases_and_reset_removes_enemy_badge(self):
  self.mark(self.h,self.t,1);low=self.h.mark_damage();self.h.blood_charges=5;self.assertGreater(self.h.mark_damage(),low*5);self.h.reset();self.assertFalse(any(isinstance(e,BloodMark) for e in self.t.get_effects()))
 def test_rikz_focus_and_acheron_maintenance_share_one_action_queue(self):
  h,t,b=self.battle('rikz');self.mark(h,t);t.mask_active=True;t.focus_clock=3;h.skills['attack'].fixed_hit=1;b.play_turn('attack');self.assertIsInstance(b.pending['skill'],MaintainBlood);self.respond(b);self.assertEqual(b.pending['skill'].key,'foe_rikz_focus');hp=t.hp;self.respond(b);self.assertEqual(t.hp,hp);self.assertIs(b.current,t);self.assertIsNone(b.pending)
 def test_four_games_accept_real_plans_and_reject_claimed_scores(self):
  for s in self.h.skills.values():
   if not s.reaction:continue
   o=s.public_options(self.h,self.t);self.assertEqual(s.tier_from(plan(s,o),o),0,s.key);self.assertGreater(s.tier_from({'hits':999,'elapsed_ms':3000},o),0)
 def test_bastion_requires_continuous_ordered_trace(self):
  s=self.h.skills['blood_bastion'];o=s.public_options(self.h,self.t);c=plan(s,o);c['cuts'][1]['x0']+=60;self.assertEqual(s.tier_from(c,o),3)
 def test_replay_rejects_instant_forged_future_inputs(self):
  s=self.h.skills['royal_seal'];o=s.public_options(self.h,self.t);c=plan(s,o);s.resolve(self.h,self.t,c,s.secret_pick(o));self.assertIsNone(aegis(self.h))

class AcheronAPI612(unittest.TestCase):
 def setUp(self):
  import solo_app
  from services import GameService
  self.app=solo_app;self.old=solo_app.service;self.temp=tempfile.TemporaryDirectory();solo_app.service=GameService(str(Path(self.temp.name)/'accounts.json'));solo_app.service.seed(include_player=False);self.c=solo_app.app.test_client()
 def tearDown(self):self.app.service=self.old;self.temp.cleanup()
 def test_metadata_and_all_practice_games(self):
  r=self.c.get('/api/classes/acheron');self.assertEqual(r.status_code,200);self.assertEqual(sum(bool(s['reaction']) for s in r.json['skills']),4)
  for s in r.json['skills']:
   if s['reaction']:self.assertTrue(s['difficulty_label']);q=self.c.post('/api/practice',json={'hero':'acheron','skill':s['key']});self.assertEqual(q.status_code,200,q.json)
  q=self.c.post('/api/practice',json={'hero':'acheron','skill':'blood_upkeep'});self.assertEqual(q.status_code,200,q.json);self.assertEqual(q.json['heroes'][0]['acheron_state']['mark_charges'],2)
 def test_create_save_load_and_transient_state_reset(self):
  from services import GameService
  s=self.app.service;p=s.create_player({'username':'Acheron test','password':'testing'});h=s.create_hero({'type':'acheron','name':'Наследник','player_id':p.id});h.blood_charges=5;s.save();fresh=GameService(s.save_path);fresh.load();loaded=fresh.get_hero(h.id);self.assertIsInstance(loaded,Acheron);self.assertEqual(loaded.blood_charges,0);self.assertIs(loaded.skills['blood_art'].owner,loaded)
