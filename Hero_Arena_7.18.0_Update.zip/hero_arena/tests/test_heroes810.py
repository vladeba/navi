import unittest
from unittest.mock import patch
from models import HERO_CLASSES
from models.character import Character
from models.battle import Battle
from models.effects import Bleed, Shield
from models.heroes810 import Fear, Courage

class NewHeroes810(unittest.TestCase):
 def hero(self,key):return HERO_CLASSES[key](key)
 def test_atlargas_must_surface_after_two_underwater_actions(self):
  h=self.hero('atlargas');t=self.hero('warrior');h.begin_action(h.skills['dive'],t);h.action810('dive',t);h.after_action(t)
  self.assertTrue(h.submerged);self.assertFalse(h.can_use(h.skills['attack']))
  for _ in range(2):h.begin_action(h.skills['heal'],t);h.action810('heal',t);h.after_action(t)
  self.assertFalse(h.submerged);self.assertEqual(h.tide,3)
  h.action810('breach',t);self.assertEqual(h.tide,0)
 def test_frida_shield_absorption_arms_one_attack(self):
  h=self.hero('frida');t=self.hero('warrior');h.add_effect(Shield(3,20));h.take_damage(14,attacker=t)
  self.assertTrue(h.riposte);base=h.damage_multiplier();h.note_attack(False);h.after_action(t)
  self.assertFalse(h.riposte);self.assertAlmostEqual(base-h.damage_multiplier(),.2)
 def test_jester_forms_rebuild_without_resetting_cooldowns(self):
  h=self.hero('plutarch');t=self.hero('warrior');white=h.get_dodge();h.set_cooldown('poison',3);cool=h.cooldown_left('poison')
  self.assertEqual(len(h.to_dict()['skills']),6);h.action810('switch',t)
  self.assertEqual(len(h.to_dict()['skills']),5);self.assertIn('dash',h.skills);self.assertNotIn('poison',h.skills)
  self.assertLess(h.get_dodge(),white);h.action810('switch',t);self.assertEqual(h.cooldown_left('poison'),cool)
 def test_fear_panic_and_repeat_protection(self):
  h=self.hero('warrior');h.add_effect(Fear())
  with patch('models.heroes810.random.random',return_value=0):logs,ok=h.start_turn()
  self.assertFalse(ok);self.assertTrue(h.has_effect(Courage));self.assertLess(h.hp,h.max_hp)
 def test_yaisha_songs_do_not_damage_and_attacks_spend_notes(self):
  h=self.hero('yaisha');t=self.hero('warrior');hp=t.hp
  for _ in range(7):h.action810('hum',t)
  self.assertEqual(t.hp,hp);self.assertEqual(h.notes,5)
  h.skills['attack']._perform(h,t);self.assertEqual(h.notes,0)
 def test_machine_survives_overkill_with_pilot_and_one_explosion(self):
  h=self.hero('dindau');t=self.hero('warrior');h.opponent=t;before=t.hp
  h.take_damage(1000,attacker=t)
  self.assertEqual(h.hp,1);self.assertFalse(h.machine_alive);self.assertEqual(set(h.skills),{'attack'});self.assertEqual(before-t.hp,15)
  h.take_damage(10,attacker=t);self.assertEqual(h.hp,0);self.assertEqual(before-t.hp,15)
  h.reset();self.assertEqual(h.hp,278);self.assertEqual(len(h.skills),8)
 def test_wear_skips_once_then_repair_is_possible(self):
  h=self.hero('dindau');t=self.hero('warrior');h.wear=9;h.begin_action(h.skills['attack'],t);h.on_own_turn_end()
  self.assertEqual(h.wear,10);self.assertFalse(h.start_turn()[1]);self.assertTrue(h.start_turn()[1])
  self.assertFalse(h.can_use(h.skills['attack']));self.assertTrue(h.can_use(h.skills['repair']))
  h.action810('repair',t);h.on_own_turn_end();self.assertEqual(h.wear,7);self.assertTrue(h.can_use(h.skills['attack']))
  h.wear=5;h.on_own_turn_end();self.assertEqual(h.wear,6)
 def test_connie_redirects_attacks_effects_and_waits_two_actions(self):
  h=self.hero('connie');t=self.hero('warrior');h.summon_toy('rabbit');p=h.plush
  self.assertIs(h.pick_defender(t),p);h.add_effect(Bleed(2,3));self.assertTrue(p.has_effect(Bleed));self.assertFalse(h.has_effect(Bleed))
  hp=h.hp;h.take_damage(1000,attacker=t);self.assertIsNone(h.plush);self.assertEqual(h.hp,hp)
  self.assertEqual(set(h.skills),{'attack','house','rabbit','bear'})
  h.start_turn();self.assertFalse(h.can_use(h.skills['bear']));h.start_turn();self.assertFalse(h.can_use(h.skills['bear']));h.start_turn();self.assertTrue(h.can_use(h.skills['bear']))
  h.summon_toy('bear');self.assertEqual(h.plush.hp,155);self.assertEqual(len(h.skills),6)
  h.take_damage(1000,attacker=t);self.assertIsNone(h.plush)
  for _ in range(3):h.start_turn()
  self.assertFalse(h.can_use(h.skills['rabbit']));self.assertFalse(h.can_use(h.skills['bear']))
 def test_connie_first_and_toy_health_exact(self):
  h=self.hero('connie');self.assertEqual(h.hp,50)
  b=Battle(h,self.hero('assassin'),mode='manual',ai_ids=set());b.start();self.assertIs(b.current,h)
  h.summon_toy('rabbit');self.assertEqual(h.plush.hp,125)
 def test_connie_old_bleed_pauses_while_protected(self):
  h=self.hero('connie');h.add_effect(Bleed(3,5));h.summon_toy('bear');hp=h.hp;dur=h._effects[0].duration
  h.start_turn();self.assertEqual(h.hp,hp);self.assertEqual(h._effects[0].duration,dur)

 def test_two_support_actions_grant_warm_stitch(self):
  from models.connie810 import WarmStitch
  h=self.hero('connie');h.summon_toy('rabbit');h.action810('mend',self.hero('warrior'));h.action810('ribbon',self.hero('warrior'))
  self.assertTrue(h.plush.has_effect(WarmStitch));self.assertEqual(h.support_stitches,0)

 def test_tuned_saws_apply_bonus_before_it_is_consumed(self):
  h=self.hero('dindau');t=self.hero('warrior');t.armor=0;h.puzzle_reward('tune',t,0);before=t.hp
  with patch('models.skills.random.random',return_value=.5),patch('models.skills.random.uniform',return_value=1):h.skills['attack']._perform(h,t)
  self.assertEqual(before-t.hp,16);self.assertTrue(h.saw_boost);h.on_own_turn_end();self.assertFalse(h.saw_boost)
