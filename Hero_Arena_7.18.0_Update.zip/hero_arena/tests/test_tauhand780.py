from solutions810 import winning_legacy
import unittest
from models import HERO_CLASSES,Battle
from models.effects import Burn,Bleed,Poison,Acid,Shield
from services.game_service import GameService
class TauhandTests(unittest.TestCase):
 def setUp(self):
  self.h=HERO_CLASSES['tauhand']('Тауханд');self.t=HERO_CLASSES['warrior']('Враг');self.h.configure_arena();self.h.reset()
 def test_roster_and_highest_base_armor(self):
  self.assertEqual(len(self.h.skills),7);self.assertEqual(sum(s.reaction=='minigame' for s in self.h.skills.values()),3)
  self.assertGreater(self.h.armor,max(c('x').armor for k,c in HERO_CLASSES.items() if k!='tauhand'))
  self.assertEqual(GameService().class_card('tauhand')['hero_name'],'Тауханд')
 def test_cracks_only_large_health_loss_and_repair(self):
  h=self.h;threshold=h.max_hp*.12
  for _ in range(8):h.take_damage(10,ignore_armor=True)
  self.assertEqual(h.cracks,0)
  h.add_effect(Shield(2,100));h.take_damage(40,ignore_armor=True);self.assertEqual(h.cracks,0)
  h._effects=[];h.hp=h.max_hp
  for _ in range(4):h.take_damage(40,ignore_armor=True)
  self.assertEqual(h.cracks,3);self.assertEqual(h.armor_total(),4)
  h.skills['repair']._perform(h,self.t);self.assertEqual(h.cracks,0);self.assertEqual(h.armor_total(),10)
 def test_selective_dot_resistance(self):
  for effect in (Burn(2,20),Bleed(2,20),Poison(2,20),Acid(2,20)):
   self.h.hp=self.h.max_hp;before=self.h.hp;effect.on_turn_start(self.h);d=before-self.h.hp
   self.assertEqual(d,20 if isinstance(effect,Acid) else 3)
 def test_games_correct_inputs(self):
  for key in ('hammer','mending','march'):
   g=self.h.skills[key];o=g.public_options(self.h,self.t);c={'elapsed_ms':o['time_limit_ms']-1}
   self.assertEqual(g.tier_from(c,o),3)
   if o['game']=='legacy810':
    self.assertEqual(g.tier_from(winning_legacy(g,o),o),0,key);continue
   if key=='hammer':c['actions']=[{'ms':o['impact']}]
   elif key=='mending':c['actions']=[{'ms':o['prepare_ms']+200+i*200,'node':i} for i in range(5)]
   else:c['actions']=[{'ms':b['ms'],'side':b['side']} for b in o['beats']]
   self.assertEqual(g.tier_from(c,o),0)
