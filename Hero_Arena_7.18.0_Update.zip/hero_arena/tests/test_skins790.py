import tempfile,unittest
from pathlib import Path
from collections import Counter
from services.game_service import GameService
from models import HERO_CLASSES
from solo_app import app

HEROES=('tauhand','vervelt','gormadont','jotunlok','gordonos','ksair')
EXPECTED={'common':6,'rare':5,'epic':4,'legendary':3,'mythic':2}
class SkinPatch790(unittest.TestCase):
 def test_catalog_has_all_unique_available_skins(self):
  client=app.test_client()
  for hero in HEROES:
   with self.subTest(hero=hero):
    entries=GameService.skin_catalog(hero)
    expected=dict(EXPECTED);expected['legendary']=4 if hero=='jotunlok' else 3
    self.assertEqual(Counter(s['rarity'] for s in entries),expected)
    self.assertEqual(len({s['skin'] for s in entries}),sum(expected.values()))
    self.assertEqual(len({s['name'] for s in entries}),sum(expected.values()))
    for s in entries:
     self.assertTrue(s['available'],s)
     response=client.get(s['image']);self.assertEqual(response.status_code,200,s)
     self.assertTrue(response.data.startswith(b'\xff\xd8\xff'),s);response.close()
 def test_buy_equip_save_and_reload(self):
  with tempfile.TemporaryDirectory() as td:
   path=str(Path(td)/'save.json');svc=GameService(path);ids=[]
   for hero in HEROES:
    player=svc.create_player({'username':'Тестер '+hero,'password':'test123'});player.gold=100000
    h=svc.create_hero({'type':hero,'name':'Герой '+hero,'player_id':player.id})
    for entry in svc.skin_catalog(hero):svc.buy_skin(player.id,{'type':hero,'skin':entry['skin']})
    key='new790_16';svc.equip_skin(h.id,{'skin':key,'player_id':player.id})
    self.assertTrue(player.owns_skin(hero,key));self.assertEqual(h.skin,key);ids.append((player.id,h.id,hero,key))
   svc.save();again=GameService(path);again.load()
   for pid,hid,hero,key in ids:
    self.assertEqual(again.get_hero(hid).skin,key);self.assertTrue(again.get_player(pid).owns_skin(hero,key));self.assertEqual(len([s for s in again.get_player(pid).owned_skins if s.startswith(hero+':')]),21 if hero=='jotunlok' else 20)
 def test_gevaudan_is_legendary(self):
  skin=next(s for s in GameService.skin_catalog('vervelt') if s['name']=='Жеводанский зверь');self.assertEqual(skin['rarity'],'legendary')
