import unittest,math
from models import HERO_CLASSES
from models.effects import Burn,Poison
from services.game_service import GameService
class JotunTest(unittest.TestCase):
 def setUp(self):self.h=HERO_CLASSES['jotunlok']('Йотунлок');self.t=HERO_CLASSES['warrior']('Враг')
 def test_roster(self):
  h=self.h;self.assertEqual(len(h.skills),7);self.assertEqual(sum(bool(s.reaction) for s in h.skills.values()),2);self.assertEqual(GameService().class_card('jotunlok')['hero_name'],'Йотунлок')
 def test_resource_dependent_skills_are_not_copyable(self):
  for key in ('gather','thrust','shield','rupture'):self.assertFalse(self.h.skills[key].copyable)
 def test_frost_and_burn(self):
  h=self.h;h.skills['gather']._perform(h,self.t);self.assertEqual(h.frost,2);h.skills['shield']._perform(h,self.t);self.assertEqual(h.frost,0)
  h._effects=[];before=h.hp;Burn(2,20).on_turn_start(h);self.assertEqual(before-h.hp,30)
  before=h.hp;Poison(2,20).on_turn_start(h);self.assertEqual(before-h.hp,20)
 def test_puzzles_solutions_and_failures(self):
  h=self.h;g=h.skills['crystal'];o=g.public_options(h,self.t)
  from itertools import combinations
  choice=next(c for c in combinations(range(5),3) if sum(o['values'][i] for i in c)==10)
  c={'elapsed_ms':o['time_limit_ms']-1,'actions':[{'ms':o['prepare_ms']+200+i*300,'shard':v} for i,v in enumerate(choice)]};self.assertEqual(g.tier_from(c,o),0)
  from solutions810 import winning_legacy
  g=h.skills['trident'];o=g.public_options(h,self.t)
  self.assertEqual(g.tier_from(winning_legacy(g,o),o),0);self.assertEqual(g.tier_from({'elapsed_ms':o['time_limit_ms']-1},o),3)
