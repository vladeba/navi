import unittest,tempfile
from pathlib import Path
from collections import Counter
from services.game_service import GameService
from models import HERO_CLASSES
from models.connie810 import Plush
from solo_app import app
class Update810(unittest.TestCase):
 def test_all_skin_sets_and_matching_toy_portraits_exist(self):
  root=Path(__file__).resolve().parents[1];client=app.test_client()
  for key in ('anivriza','atlargas','frida','plutarch','yaisha','dindau','connie'):
   entries=GameService.skin_catalog(key);self.assertEqual(Counter(s['rarity'] for s in entries),dict(common=5,rare=4,epic=3,legendary=2,mythic=1))
   self.assertEqual(len({s['name'] for s in entries}),15)
   for e in entries:
    self.assertTrue(e['available']);r=client.get(e['image']);self.assertEqual(r.status_code,200);self.assertTrue(r.data.startswith(b'\xff\xd8\xff'));r.close()
  h=HERO_CLASSES['connie']('Конни')
  for s in GameService.skin_catalog('connie'):
   h.skin=s['skin']
   for kind in ('rabbit','bear'):
    p=Plush(h,kind);self.assertIn(s['skin'],p.image);r=client.get(p.image);self.assertEqual(r.status_code,200);r.close()
 def test_loading_old_save_adds_all_new_npcs_and_preserves_user(self):
  with tempfile.TemporaryDirectory() as td:
   path=str(Path(td)/'save.json');svc=GameService(path);p=svc.create_player(dict(username='Игрок теста',password='test123'));p.gold=321
   h=svc.create_hero(dict(type='warrior',name='Личный герой',player_id=p.id));old=svc.create_hero(dict(type='paladin',name='Серена',npc=True));svc.save()
   loaded=GameService(path);loaded.load()
   self.assertEqual(loaded.get_player(p.id).gold,321);self.assertEqual(loaded.get_hero(h.id).name,'Личный герой');self.assertEqual(loaded.get_hero(old.id).name,'Лиадра')
   for k in ('anivriza','atlargas','frida','plutarch','yaisha','dindau','connie'):self.assertTrue(any(x.npc and x.type_key==k for x in loaded._heroes.values()),k)

 def test_battle_only_skin_matches_the_active_toy_without_changing_saved_skin(self):
  from models.battle import Battle
  h=HERO_CLASSES['connie']('c');b=Battle(h,HERO_CLASSES['warrior']('t'),mode='manual',ai_ids=set());b.start();h.summon_toy('bear')
  b.skin_override[h.id]='new810_13';d=b._hero_view(h)
  self.assertIn('connie_new810_13.jpg',d['image']);self.assertIn('connie_new810_13_bear.jpg',d['puppet810']['image']);self.assertIsNone(h.skin)
