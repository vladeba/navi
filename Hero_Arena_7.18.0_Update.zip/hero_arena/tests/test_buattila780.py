from solutions810 import winning_legacy
import unittest,math
from models import HERO_CLASSES
from services.game_service import GameService
class BuattilaTest(unittest.TestCase):
 def setUp(self):self.h=HERO_CLASSES['buattila']('Буаттила');self.t=HERO_CLASSES['warrior']('Цель')
 def test_kit(self):
  h=self.h;self.assertEqual(h.role,'warrior');self.assertEqual(len(h.skills),7);self.assertEqual(sum(bool(s.reaction) for s in h.skills.values()),3);self.assertEqual(GameService().class_card('buattila')['hero_name'],'Буаттила')
 def test_damage_thresholds_and_healing(self):
  h=self.h;h.hp=h.max_hp;self.assertAlmostEqual(h.damage_multiplier(),1.0);h.hp=int(h.max_hp*.75);self.assertAlmostEqual(h.damage_multiplier(),1.1);h.hp=int(h.max_hp*.5);self.assertAlmostEqual(h.damage_multiplier(),1.2);h.hp=1;self.assertAlmostEqual(h.damage_multiplier(),1.3);h.hp=h.max_hp;self.assertAlmostEqual(h.damage_multiplier(),1.0)
 def test_games_fail_without_input_and_perfect_solutions(self):
  h=self.h
  for key in ('chain','rhythm','hunt'):
   g=h.skills[key];o=g.public_options(h,self.t);c={'elapsed_ms':o['time_limit_ms']-1};self.assertEqual(g.tier_from(c,o),3);p=o['prepare_ms']
   if o['game']=='legacy810':
    self.assertEqual(g.tier_from(winning_legacy(g,o),o),0,key);continue
   if key=='chain':
    start=p+100;c['points']=[dict(t=start+i*400,x=x,y=y) for i,(x,y) in enumerate(o['nodes'])];c['holds']=[dict(down_ms=start,up_ms=start+1600)]
   elif key=='rhythm':c['actions']=[dict(ms=v['ms'],side=v['side']) for v in o['beats']]
   else:
    c['actions']=[]
    for i in range(3):
     ms=p+800+i*1000;q=(ms-p)/o['period']*math.tau+i*1.2;c['actions'].append(dict(ms=ms,x=180+90*math.sin(q),y=130+40*math.cos(q)))
   self.assertEqual(g.tier_from(c,o),0,key)
