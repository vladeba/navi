"""Anivriza: evasion lasts through exactly one opposing action."""
import math, random
from .character import Character
from .skills import Skill, DamageSkill, MiniGameSkill
from .effects import Shield, Bleed
from .minigames_56 import Replay, events, integer, number

class WingGuard(Skill):
 def _perform(self,u,t):
  n=round(u.max_hp*.09);u.add_effect(Shield(3,n));return [f'🪶 Крылья прикрывают: щит {n}.']

class FlightGame(Replay,MiniGameSkill):
 game='anivriza810';reactor='user';hero_target=True;PREP=600;TIME_LIMIT_MS=14000
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,43,25,10)
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);o.update(mode=self.mode,instruction=self.prompt)
  if self.mode=='route':
   # A random wall with one passage: plan a route, no click timing.
   o.update(blocked=[7,12,17],start=20,goal=4)
   gap=random.choice([7,12,17]);o['blocked'].remove(gap)
  elif self.mode=='dive':o.update(target=[random.randint(180,290),random.randint(70,180)],wind=random.choice([-30,-20,20,30]),origin=[65,205])
  else:o.update(feathers=random.sample(list(range(6)),6),wanted=random.sample(list(range(6)),3))
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict) or integer(c.get('elapsed_ms'),hi=o['time_limit_ms'])<o['prepare_ms']:return 3
  a=events(c,'actions',o,30)
  if not a:return 3
  if self.mode=='route':
   pos=o['start'];seen={pos}
   for v in a:
    nxt=integer(v.get('cell'),hi=24)
    if nxt<0 or nxt in o['blocked'] or abs(nxt//5-pos//5)+abs(nxt%5-pos%5)!=1:return 3
    pos=nxt;seen.add(pos)
   return 0 if pos==o['goal'] and len(a)<=8 else 1 if pos==o['goal'] else 2 if len(seen)>=5 else 3
  if self.mode=='dive':
   if len(a)!=1:return 3
   v=a[0];x=number(v.get('x'));y=number(v.get('y'))
   d=math.dist([x+o['wind'],y],o['target'])
   return 0 if d<=12 else 1 if d<=25 else 2 if d<=45 else 3
  chosen=[integer(v.get('feather'),hi=5) for v in a]
  if len(chosen)!=3 or len(set(chosen))!=3:return 3
  n=sum(o['feathers'][i]==v for i,v in zip(chosen,o['wanted']) if i>=0)
  return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
 def apply(self,u,t,tier,data):
  if tier==3:return ['🪶 Приём не удался.']
  if self.mode=='feathers':
   n=round(u.max_hp*(.15,.1,.05)[tier]);u.add_effect(Shield(3,n));return [f'🪶 Перья собраны: щит {n}.']
  return self.strike(u,t,({'route':(1.45,1.15,.65),'dive':(1.7,1.25,.6)}[self.mode][tier]))[0]

def trial(key,name,prompt,mode,cost,cd):
 s=FlightGame(key,name,prompt,cost=cost,cooldown=cd,icon='🪶');s.mode=mode;s.prompt=prompt;return s

class Anivriza(Character):
 hero_class,type_key,resource_name,role='Гарпия','anivriza','выносливость','trickster'
 PASSIVE_NOTES=('Рваный полёт: любое попадание даёт +35 процентных пунктов уклонения до завершения одного следующего действия противника. Бонус не складывается и расходуется также после лечения или защиты врага.',)
 def __init__(self,name,level=1):
  self.flight_ready=False
  super().__init__(name,max_hp=195,base_damage=12,armor=1.5,level=level,speed=9,dodge=.16,crit_chance=.14,max_energy=100,energy_regen=12,start_energy=70)
 def note_attack(self,hit):
  super().note_attack(hit)
  if hit:self.flight_ready=True
 def get_dodge(self):return min(.75,super().get_dodge()+(.35 if self.flight_ready else 0))
 def on_opponent_action_finished(self,actor):self.flight_ready=False
 def _on_reset(self):self.flight_ready=False
 def to_dict(self):
  d=super().to_dict();d['flight_ready']=self.flight_ready;d['resource810']='Рваный полёт: +35% уклонения до конца действия врага' if self.flight_ready else 'Попадание подготовит рваный полёт';return d
 def _create_skills(self):return [
  DamageSkill('attack','Удар когтями','Обычная атака.',icon='🦅'),
  DamageSkill('tear','Рваный след','Удар ×1.1 и кровотечение 3 HP на два хода.',multiplier=1.1,effect=lambda:Bleed(2,3),effect_chance=1,cost=18,cooldown=3,icon='🩸'),
  WingGuard('guard','Под крылом','Щит 9% HP на два хода.',cost=18,cooldown=3,icon='🪶'),
  DamageSkill('swoop','Короткий налёт','Быстрая точная атака ×1.15.',multiplier=1.15,accuracy=1.05,cost=16,cooldown=2,icon='🦅'),
  trial('route','Скальный проход','Постройте короткий путь от нижней левой клетки к верхней правой, обходя скалы.','route',22,4),
  trial('dive','Пикирование по ветру','Зажмите гарпию и протяните линию к точке удара с поправкой на ветер, затем отпустите.','dive',24,4),
  trial('feathers','Порядок оперения','Сравните перья с образцом и выберите три в указанном порядке.','feathers',20,4)]
