"""Seven 8.1 heroes: their resources and transformations are server-owned."""
import random
from pathlib import Path
from .character import Character
from .skills import Skill, DamageSkill
from .effects import Effect, Shield, Bleed, Poison, Stun, Evasion
from .games810 import game

class Agile(Evasion):
 name="Ловкий отход";icon="🪶"
 def dodge_bonus(self):return self.power

class Weaken(Effect):
 name='Убаюкивающая песня';icon='🎵'
 def damage_bonus(self):return -self.power
class Distract(Effect):
 name='Манящий голос';icon='🎶'
 def dodge_bonus(self):return -self.power
class FalseNote(Effect):
 name='Сбитый ритм';icon='♭'
 def accuracy_bonus(self):return -self.power
class Courage(Effect):
 name='Собраться с духом';icon='🕯';positive=True
class Fear(Effect):
 name='Страх';icon='😨'
 def __init__(self,duration=1,power=5):super().__init__(duration,power);self.skip=False
 def on_turn_start(self,owner):
  owner.add_effect(Courage(3));roll=random.random();self.skip=roll<.2
  if self.skip:
   loss=owner.take_damage(self.power,ignore_armor=True);return [f'😨 Паника: пропуск действия и {loss} урона.']
  if roll<.65:owner.add_effect(FalseNote(1,.25));return ['😨 Дрожащие руки: точность этого действия снижена на 25%.']
  return ['🕯 Противник справился со страхом.']
 def prevents_action(self):return self.skip

def frighten(target):
 if not target.has_effect(Courage) and not target.has_effect(Fear):target.add_effect(Fear());return ['😨 Страх на следующее действие.']
 return ['🕯 Противник уже переживает страх или защищён от повторной паники.']

class Action(Skill):
 copyable=False
 def __init__(self,key,name,description,fn,**kw):super().__init__(key,name,description,**kw);self.fn=fn
 def _perform(self,u,t):return u.action810(self.fn,t)
 def ai_score(self,u,t):return u.action_score810(self.fn,t)

def act(k,n,d,fn=None,cost=0,cd=0):return Action(k,n,d,fn or k,cost=cost,cooldown=cd)
def attack(k,n,d='Обычная атака.',**kw):return DamageSkill(k,n,d,**kw)

class Atlargas(Character):
 hero_class,type_key,resource_name,role='Нага','atlargas','сила прилива','warrior'
 PASSIVE_NOTES=('Глубины: под водой входящий урон снижен на 40%; можно провести два собственных действия. За каждое подводное действие один заряд прилива, максимум 3. После двух действий обязательное всплытие. На поверхности после трёх действий урон снижен на 15%, пока не погрузишься. Прорыв и Удар из пучины расходуют прилив.',)
 def __init__(self,name,level=1):
  self.submerged=False;self.tide=0;self.depth_actions=0;self.dry=0
  super().__init__(name,max_hp=250,base_damage=13,armor=3,level=level,speed=5,dodge=.06,crit_chance=.1,max_energy=100,energy_regen=13,start_energy=70)
 def _on_reset(self):self.submerged=False;self.tide=0;self.depth_actions=0;self.dry=0
 def can_use(self,s):
  if self.submerged and s.key not in ('heal','current','vortex','breach','surge'):return False
  if not self.submerged and s.key in ('heal','vortex','breach','surge'):return False
  return super().can_use(s)
 def take_damage(self,amount,ignore_armor=False,attacker=None):return super().take_damage(amount*(.6 if self.submerged else 1),ignore_armor,attacker)
 def damage_multiplier(self):return super().damage_multiplier()*(.85 if self.dry>=3 else 1)
 def begin_action(self,s,t):self._was_under=self.submerged;self._action=s.key
 def after_action(self,t):
  if self.submerged and getattr(self,'_was_under',False):
   self.depth_actions+=1;self.tide=min(3,self.tide+1);self.heal(4)
   if self.depth_actions>=2:self.submerged=False;self._events.append('🌊 Вынужденное всплытие: две подводные попытки закончились.')
  elif not self.submerged:self.dry+=1
 def action810(self,k,t):
  if k=='dive':self.submerged=True;self.depth_actions=0;self.dry=0;self.tide=min(3,self.tide+1);return ['🌊 Атларгас уходит под воду: защита 40%.']
  if k=='heal':return [f'🌊 Глубины восстанавливают {self.heal(15)} HP.']
  charge=self.tide;self.tide=0;self.submerged=False
  s=DamageSkill('breach_hit','Прорыв из глубины','',multiplier=.8+.25*charge)
  return s._perform(self,t)+[f'🌊 Израсходовано прилива: {charge}.']
 def action_score810(self,k,t):return 30 if k=='dive' and self.dry>=2 else 25 if k=='heal' and self.hp<self.max_hp*.65 else 18
 def to_dict(self):
  d=super().to_dict();d.update(combat_form='Под водой' if self.submerged else 'На поверхности',resource810=f'Прилив {self.tide}/3 · сухость {self.dry}/3');return d
 def _create_skills(self):return [attack('attack','Удар трезубцем'),act('dive','Нырок','Погружение на два действия; +1 прилив.',cost=12,cd=3),act('heal','Целительные глубины','Под водой: лечение 15 HP, дополнительное восстановление глубин 4 HP.'),act('breach','Прорыв из глубины','Всплытие и удар ×0.8 +0.25 за заряд.',cost=14),game('current','Подводное течение','water_pipes','atlargas',20,3),game('vortex','Глаз водоворота','water_balance','atlargas',18,3),game('surge','Удар из пучины','water_pressure','atlargas',24,4)]
 def puzzle_reward(self,k,t,tier):
  if tier==3:return ['🌊 Течение вырвалось из-под контроля.']
  if k=='current':self.tide=min(3,self.tide+(2,1,1)[tier]);self.add_effect(Shield(3,(20,14,7)[tier]));return ['🌊 Течение укрощено: прилив и щит.']
  if k=='vortex':return [f'🌊 Водоворот восстановил {self.heal((25,18,9)[tier])} HP.']
  charge=self.tide;self.tide=0;self.submerged=False
  return self.skills[k].strike(self,t,(1.25,1,.6)[tier]+.23*charge)[0]

class Frida(Character):
 hero_class,type_key,resource_name,role='Валькирия','frida','выносливость','warrior'
 PASSIVE_NOTES=('Ответ валькирии: если щит поглотил урон, следующий удар получает +20% урона. Бонус не складывается и расходуется после попытки атаковать.',)
 def __init__(self,name,level=1):
  self.riposte=False;self.did_attack=False
  super().__init__(name,max_hp=238,base_damage=13,armor=3,level=level,speed=6,dodge=.08,crit_chance=.1,max_energy=100,energy_regen=13,start_energy=70)
 def _on_reset(self):self.riposte=False;self.did_attack=False
 def take_damage(self,amount,ignore_armor=False,attacker=None):
  before=sum(e.power for e in self.get_effects() if isinstance(e,Shield));d=super().take_damage(amount,ignore_armor,attacker)
  if sum(e.power for e in self.get_effects() if isinstance(e,Shield))<before:self.riposte=True
  return d
 def damage_multiplier(self):return super().damage_multiplier()+(.2 if self.riposte else 0)
 def note_attack(self,hit):super().note_attack(hit);self.did_attack=True
 def after_action(self,t):
  if self.did_attack:self.riposte=False;self.did_attack=False
 def action810(self,k,t):self.add_effect(Shield(3,26));return ['🛡 Стена щита: 26 HP.']
 def action_score810(self,k,t):return 22 if not any(isinstance(e,Shield) for e in self.get_effects()) else 2
 def to_dict(self):
  d=super().to_dict();d['resource810']='Ответ готов: +20% к следующему удару' if self.riposte else 'Щит подготовит ответный удар';return d
 def _create_skills(self):return [attack('attack','Удар мечом'),act('guard','Стена щита','Щит на 26 HP на два хода.',cost=18,cd=3),attack('rush','Рывок валькирии','Удар ×1.3.',multiplier=1.3,cost=18,cooldown=2),game('circle','Круговая защита','shield_track','frida',20,4),game('spear','Полёт копья','spear_arc','frida',22,3),game('clash','Столкновение щитов','shield_wrestle','frida',22,4),game('assault','Последний натиск','sword_cuts','frida',25,4)]
 def puzzle_reward(self,k,t,tier):
  if tier==3:return ['🛡 Приём сорван.']
  if k=='circle':self.add_effect(Shield(3,(34,24,12)[tier]));return ['🛡 Круговая защита укреплена.']
  logs=self.skills[k].strike(self,t,({'spear':(1.6,1.2,.6),'clash':(1.15,.9,.5),'assault':(1.8,1.3,.7)}[k][tier]))[0]
  if k=='clash':self.add_effect(Shield(3,(18,12,6)[tier]))
  return logs

class JesterStrike(DamageSkill):
 copyable=False

class Plutarch(Character):
 hero_class,type_key,resource_name,role='Шут','plutarch','хитрость','trickster'
 PASSIVE_NOTES=('Две стороны: белая +12% уклонения, но −25% урона. Чёрная +25% урона и +15% крита, но −8% уклонения. Переключение стоит действие и имеет перезарядку 2 хода. Поставленные ловушки и яды сохраняются. После страха два действия защиты от повторной паники.',)
 def __init__(self,name,level=1):
  self.side='white';self.trap=False;self.clone=False
  super().__init__(name,max_hp=170,base_damage=13,armor=1,level=level,speed=8,dodge=.14,crit_chance=.12,max_energy=100,energy_regen=13,start_energy=75)
 def _on_reset(self):self.side='white';self.trap=False;self.clone=False;self._rebuild()
 def _rebuild(self):
  self.skills={s.key:s for s in self._create_skills()}
 def damage_multiplier(self):return super().damage_multiplier()*(.75 if self.side=='white' else 1.25)
 def get_dodge(self):return max(0,min(.75,super().get_dodge()+(.12 if self.side=='white' else -.08)))
 def get_crit(self):return min(1,super().get_crit()+(.15 if self.side=='black' else 0))
 def take_damage(self,amount,ignore_armor=False,attacker=None):
  if self.clone and attacker is not None:self.clone=False;self._events.append('🎭 Двойник принял удар.');return 0
  return super().take_damage(amount,ignore_armor,attacker)
 def action810(self,k,t):
  if k=='switch':self.side='black' if self.side=='white' else 'white';self._rebuild();return [f'🎭 Теперь {"белая" if self.side=="white" else "чёрная"} сторона.']
  self.add_effect(Agile(1,.18));return ['🎭 Белая маска: +18% уклонения до следующего собственного хода.']
 def action_score810(self,k,t):return 24 if k=='switch' and ((self.side=='white' and (self.trap or t.has_effect(Poison))) or (self.side=='black' and self.hp<60)) else 8
 def _create_skills(self):
  switch=act('switch','Перевернуть маску','Сменить сторону, расходуя действие.',cd=2)
  if self.side=='white':return [JesterStrike('attack','Шутливый укол','Слабая атака.'),act('mask','Белая маска','+18% уклонения до следующего своего хода.',cost=15,cd=3),game('trap','Коробка с сюрпризом','trap_place','plutarch',18,3),game('clones','Три Плутарха','clone_shuffle','plutarch',18,4),game('poison','Ядовитое угощение','poison_mix','plutarch',20,3),game('fear','Смешно до дрожи','mask_logic','plutarch',22,4),switch]
  return [JesterStrike('attack','Чёрный выпад','Сильный удар.'),JesterStrike('backstab','За спиной','Удар ×1.25 и +15% шанса крита.',multiplier=1.25,crit_bonus=.15,cost=20,cooldown=3),game('dash','Прыжок в темноте','shadow_route','plutarch',22,3),game('knives','Танец кинжалов','knife_weave','plutarch',24,4),game('joke','Злая шутка','armor_deduce','plutarch',26,4),switch]
 def to_dict(self):
  d=super().to_dict();d['combat_form']='Белая сторона' if self.side=='white' else 'Чёрная сторона';d['form_side']=self.side;d['controls810']=[s for s in d['skills'] if s['key']=='switch'];d['skills']=[s for s in d['skills'] if s['key']!='switch'];return d
 def puzzle_reward(self,k,t,tier):
  if tier==3:return ['🃏 Фокус провалился.']
  if k=='trap':self.trap=True;return ['🪤 Ловушка взведена: следующая атака врага нанесёт ему 8 урона и активирует яд.']
  if k=='clones':self.clone=True;return ['🎭 Двойник примет следующий прямой удар.']
  if k=='poison':t.add_effect(Poison(3,(5,4,2)[tier]));return ['☠ Ядовитое угощение действует три хода.']
  if k=='fear':return frighten(t)
  return self.skills[k].strike(self,t,({'dash':(1.4,1.1,.6),'knives':(1.5,1.15,.6),'joke':(1.7,1.2,.6)}[k][tier]))[0]
 def on_opponent_action_finished(self,actor):
  if self.trap and getattr(actor,'_last_attack810',False):
   self.trap=False;actor.take_damage(8,ignore_armor=True,attacker=self);actor.add_effect(Poison(2,3))

class NoteStrike(DamageSkill):
 copyable=False
 def _perform(self,u,t):
  notes=u.notes;u.notes=0;old=self.multiplier;self.multiplier=.65+.22*notes
  try:return super()._perform(u,t)+[f'🎵 Потрачено нот: {notes}.']
  finally:self.multiplier=old
class Yaisha(Character):
 hero_class,type_key,resource_name,role='Сирена','yaisha','дыхание','light'
 PASSIVE_NOTES=('Мелодия до 5 нот: песни не наносят урон, но ослабляют врага и добавляют ноты. Выпад и Последняя нота расходуют весь запас. Оглушение отнимает одну ноту. Песенные дебаффы одного вида обновляются, но не суммируются.',)
 def __init__(self,name,level=1):
  self.notes=0
  super().__init__(name,max_hp=200,base_damage=12,armor=1.5,level=level,speed=6,dodge=.12,crit_chance=.08,max_energy=100,energy_regen=14,start_energy=70)
 def _on_reset(self):self.notes=0
 def start_turn(self):
  stunned=self.has_effect(Stun);r=super().start_turn()
  if stunned:self.notes=max(0,self.notes-1)
  return r
 def action810(self,k,t):
  if k=='guard':self.add_effect(Shield(3,22));return ['🌊 Уход под волну: щит 22 HP.']
  t.add_effect(Weaken(3,.15) if k=='hum' else Distract(3,.15));self.notes=min(5,self.notes+1);return [f'🎶 Песня ослабляет врага без урона; нот {self.notes}/5.']
 def action_score810(self,k,t):return 25 if k in ('hum','lure') and self.notes<3 else 20 if k=='guard' and self.hp<80 else 5
 def _create_skills(self):return [NoteStrike('attack','Выпад глубин','Расходует все ноты: ×0.65 +0.22 за ноту.'),act('hum','Тихий напев','Без урона: −15% урона врага на два хода и +1 нота.',cost=10,cd=2),act('lure','Манящий голос','Без урона: −15% уклонения на два хода и +1 нота.',cost=10,cd=2),act('guard','Уход под волну','Щит 22 HP на два хода.',cost=18,cd=3),game('tide','Песня прилива','song_contour','yaisha',18,3),game('echo','Эхо грота','echo_memory','yaisha',18,3),game('choir','Сбивчивый хор','choir_cancel','yaisha',20,4),game('finale','Последняя нота','song_intervals','yaisha',24,4)]
 def to_dict(self):d=super().to_dict();d['resource810']=f'Мелодия {self.notes}/5';return d
 def puzzle_reward(self,k,t,tier):
  if tier==3:return ['🎵 Мелодия сорвалась.']
  if k=='finale':
   notes=self.notes;self.notes=0;return self.skills[k].strike(self,t,(1.1,.85,.5)[tier]+.24*notes)[0]
  self.notes=min(5,self.notes+(2 if tier==0 else 1))
  t.add_effect(Weaken(3,(.25,.2,.1)[tier]) if k=='tide' else Distract(3,(.2,.15,.08)[tier]) if k=='echo' else FalseNote(3,(.2,.15,.08)[tier]))
  return [f'🎶 Песня наложила ослабление, нот {self.notes}/5.']

class MachineStrike(DamageSkill):
 copyable=False
 def __init__(self,*a,wear=0,**kw):super().__init__(*a,**kw);self.wear=wear
 def _perform(self,u,t):u.wear=min(10,u.wear+self.wear);return super()._perform(u,t)
class PilotStrike(Skill):
 def _perform(self,u,t):return [f'🔧 Удар ключом: {t.pick_defender(u).take_damage(3,ignore_armor=True,attacker=u)} урона.']
class Dindau(Character):
 hero_class,type_key,resource_name,role='Механик','dindau','давление','warrior'
 PASSIVE_NOTES=('Машина: 277 HP, броня 5; пилот: 1 HP. Гибель машины вызывает один взрыв 15 урона, после чего остаётся только удар ключом на 3. Износ +1 после работающего действия, сильные приёмы добавляют ещё. На 10 машина теряет ближайший ход, затем доступны только ремонт и замена шестерни, пока не снизится износ. Ремонт не воскрешает уничтоженную машину.',)
 def __init__(self,name,level=1):
  self.machine_hp=277;self.pilot_hp=1;self.machine_alive=True;self.wear=0;self.stall_skip=False;self.saw_boost=False;self._building=True
  super().__init__(name,max_hp=278,base_damage=14,armor=5,level=level,speed=4,dodge=.02,crit_chance=.08,max_energy=100,energy_regen=14,start_energy=75);self._building=False
 @property
 def hp(self):return Character.hp.fget(self)
 @hp.setter
 def hp(self,value):
  if getattr(self,'_building',True):Character.hp.fset(self,value);return
  old=Character.hp.fget(self);delta=int(value)-old
  if delta<0 and self.machine_alive:
   self.machine_hp=max(0,self.machine_hp+delta)
   if self.machine_hp==0:
    self.machine_alive=False;self._armor=0;self.skills={'attack':PilotStrike('attack','Удар ключом','Единственная атака пилота: 3 урона.')}
    self._events.append('💥 Машина уничтожена! Дин-дау остался с 1 HP.')
    foe=getattr(self,'_combat_target',None) or self.opponent
    if foe is not None and foe.is_alive():foe.take_damage(15,ignore_armor=True,attacker=self);self._events.append('💥 Взрыв машины: 15 урона до поглощения щитом.')
  elif delta<0:self.pilot_hp=max(0,self.pilot_hp+delta)
  elif delta>0 and self.machine_alive:self.machine_hp=min(277,self.machine_hp+delta)
  Character.hp.fset(self,self.machine_hp+self.pilot_hp)
 def _on_reset(self):
  self.machine_hp=277;self.pilot_hp=1;self.machine_alive=True;self.wear=0;self.stall_skip=False;self.saw_boost=False;self._armor=5
  Character.hp.fset(self,278);self.skills={s.key:s for s in self._create_skills()}
 def can_use(self,s):
  if not self.machine_alive:return s.key=='attack'
  if self.wear>=10 and s.key not in ('repair','gear'):return False
  return super().can_use(s)
 def start_turn(self):
  logs,ok=super().start_turn()
  if self.machine_alive and self.stall_skip:self.stall_skip=False;return logs+['⚙ Машина заглохла: ход потерян. В следующий ход доступен ремонт.'],False
  return logs,ok
 def begin_action(self,s,t):self._repair_action=s.key in ('repair','gear','wires');self._had_boost=self.saw_boost
 def note_attack(self,hit):super().note_attack(hit);self.saw_boost=False
 def damage_multiplier(self):return super().damage_multiplier()*(1.2 if self.saw_boost else 1)
 def after_action(self,t):
  if self.machine_alive and not getattr(self,'_repair_action',False):
   before=self.wear;self.wear=min(10,self.wear+1)
   if self.wear==10 and before<10:self.stall_skip=True
  if self.machine_alive and self.wear==10 and not getattr(self,'_stall_announced',False):self.stall_skip=True;self._stall_announced=True
  if self.wear<10:self._stall_announced=False
 def action810(self,k,t):self.wear=max(0,self.wear-4);return [f'🔧 Быстрый ремонт: износ {self.wear}/10.']
 def action_score810(self,k,t):return 60 if self.wear>=7 else -5
 def _create_skills(self):return [MachineStrike('attack','Удар пилой','Обычная атака машины.'),MachineStrike('double','Двойной распил','Удар ×1.5; дополнительно +2 износа.',multiplier=1.5,wear=2,cost=20,cooldown=2),act('repair','Быстрый ремонт','Снижает износ на 4. Не восстанавливает HP.'),game('gear','Замена шестерни','gear_fit','dindau',0,0),game('wires','Проводка под напряжением','wire_connect','dindau',16,3),game('tune','Настройка пил','dual_tune','dindau',16,3),game('saws','Линия распила','saw_resistance','dindau',22,3),game('overdrive','Аварийный разгон','pressure_manage','dindau',24,4)]
 def to_dict(self):
  d=super().to_dict();d.update(resource810=(f'Износ {self.wear}/10'+(' · ЗАГЛОХ' if self.wear>=10 else '')+(' · Пилы +20%' if self.saw_boost else '')) if self.machine_alive else 'Машина уничтожена · пилот 1 HP',machine_alive810=self.machine_alive,hp_split=True,hp_bars=[dict(id='machine',label='Машина',hp=self.machine_hp,max=277,icon='⚙',color='#bc9a52'),dict(id='pilot',label='Дин-дау',hp=self.pilot_hp,max=1,icon='🔧',color='#80bf66')]);return d
 def puzzle_reward(self,k,t,tier):
  if k=='gear':self.wear=max(0,self.wear-(7,5,2,0)[tier]);return [f'🔧 Износ после замены: {self.wear}/10.']
  if k=='wires':
   if tier==3:self.wear=min(10,self.wear+2);return ['⚡ Короткое замыкание: +2 износа.']
   return [f'🔧 Восстановлено {self.heal((34,24,12)[tier])} HP машины.']
  if k=='tune':
   if tier==3:self.wear=min(10,self.wear+2);return ['⚙ Перегрузка: +2 износа.']
   self.saw_boost=True;return ['⚙ Следующая атака +20% урона.']
  self.wear=min(10,self.wear+(3 if k=='overdrive' else 1))
  return self.skills[k].strike(self,t,((1.9,1.35,.7,0) if k=='overdrive' else (1.6,1.2,.6,0))[tier])[0] if tier<3 else ['⚙ Пилы заклинило.']
