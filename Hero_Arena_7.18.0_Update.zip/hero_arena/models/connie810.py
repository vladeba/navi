"""Connie controls exactly one plush; the owner's HP is never a second target."""
from pathlib import Path
from .character import Character
from .effects import Shield, Stun, Evasion
from .skills import Skill, DamageSkill
from .heroes810 import act, attack, Agile
from .games810 import game

class WarmStitch(Shield):
    name="Тёплый шов";icon="🪡"

class Plush(Character):
    hero_class, type_key, role = 'Плюшевый друг', 'connie_plush', 'light'
    def __init__(self, owner, kind):
        self.owner, self.kind = owner, kind
        rabbit=kind=='rabbit'
        super().__init__('Ушастик' if rabbit else 'Мишутка',max_hp=125 if rabbit else 155,base_damage=10 if rabbit else 17,armor=1 if rabbit else 3,speed=8 if rabbit else 3,dodge=.28 if rabbit else .03,crit_chance=.1)
    def take_damage(self,amount,ignore_armor=False,attacker=None):
        real=super().take_damage(amount,ignore_armor,attacker)
        if not self.is_alive():self.owner.dismiss()
        return real
    @property
    def image(self):
        hero=self.owner;kind='rabbit' if self.kind=='rabbit' else 'bear'
        filename=f'connie_{hero.skin}_{kind}.jpg' if hero.skin else ''
        if filename and (Path(__file__).resolve().parents[1]/'static/images/skins'/filename).exists():return '/static/images/skins/'+filename
        return '/static/images/connie_'+kind+'.jpg'

class ToyAttack(DamageSkill):
    copyable=False
    def _single_hit(self,u,t,force_hit=False):
        if not u.plush:return '',0
        u._last_attack810=True
        return super()._single_hit(u.plush,t,force_hit)

class Connie(Character):
    hero_class,type_key,resource_name,role='Кукловодка','connie','воображение','light'
    PASSIVE_NOTES=('Потому что я маленькая: Конни всегда получает первую инициативу (при двух Конни — случайный порядок). Мягкие друзья: пока жива одна игрушка, Конни недосягаема; атаки и новые дебаффы получает игрушка. Старые эффекты урона на Конни приостановлены. Каждая игрушка призывается один раз; после её гибели два собственных действия без призыва. Поддержка расходует ход вместо атаки игрушки. Тёплый шов: каждое второе действие поддержки даёт игрушке дополнительный щит на 8 HP.',)
    def __init__(self,name,level=1):
        self.plush=None;self.used_toys=set();self.recall=0;self.support_stitches=0
        super().__init__(name,max_hp=50,base_damage=4,armor=0,level=level,speed=4,dodge=.05,crit_chance=.05,max_energy=100,energy_regen=14,start_energy=80)
    @property
    def hp(self):return Character.hp.fget(self)
    @hp.setter
    def hp(self,value):
        try:old=Character.hp.fget(self)
        except AttributeError:old=None
        if old is not None and self.plush and value<old:
            self.plush.take_damage(old-value,ignore_armor=True);return
        Character.hp.fset(self,value)
    ALWAYS_FIRST=True
    def roll_initiative(self):return super().roll_initiative()
    def _on_reset(self):self.plush=None;self.used_toys=set();self.recall=0;self.support_stitches=0;self.rebuild()
    def rebuild(self):self.skills={s.key:s for s in self._create_skills()}
    def summon_toy(self,kind):
        if self.plush or self.recall or kind in self.used_toys:return ['🧸 Сейчас этого друга нельзя позвать.']
        self.used_toys.add(kind);self.plush=Plush(self,kind);self.support_stitches=0;self.rebuild()
        return [f'🧸 {self.plush.name} защищает Конни.']
    def dismiss(self):
        if self.plush is None:return
        name=self.plush.name;self.plush=None;self.recall=2 if getattr(self,"_pet_tick810",False) else 3;self.rebuild();self._events.append(f'🧸 {name} больше не может сражаться. Конни доступна для атак; до призыва два действия.')
    def pick_defender(self,attacker):
        self._hit_defender810=self.plush
        return self.plush if self.plush and self.plush.is_alive() else self
    def take_damage(self,amount,ignore_armor=False,attacker=None):
        return self.plush.take_damage(amount,ignore_armor,attacker) if self.plush else super().take_damage(amount,ignore_armor,attacker)
    def add_effect(self,e):
        if self.plush:return self.plush.add_effect(e)
        old=getattr(self,"_hit_defender810",None)
        if old is not None and not old.is_alive():return False
        return super().add_effect(e)
    def start_turn(self):
        if self.recall:self.recall=max(0,self.recall-1)
        if not self.plush:return super().start_turn()
        # Owner's old effects are paused while she is unreachable.
        saved=self._effects;self._effects=[]
        try:logs,ok=super().start_turn()
        finally:self._effects=saved
        pet=self.plush
        if pet:
            self._pet_tick810=True
            try:p_logs,p_ok=pet.start_turn()
            finally:self._pet_tick810=False
            logs+=p_logs;pet.fatigue=self.fatigue
            if not pet.is_alive():self.dismiss()
            elif not p_ok:return logs,False
        return logs,ok
    def can_use(self,s):
        if s.key in ('rabbit','bear') and (self.recall or s.key in self.used_toys):return False
        return super().can_use(s)
    def get_damage(self):return self.plush.get_damage() if self.plush else super().get_damage()
    def on_opponent_action_finished(self,actor):self._hit_defender810=None
    def action810(self,k,t):
        if k=='house':self.add_effect(Shield(3,23));return ['🏠 Я в домике: щит 23 HP.']
        if self.plush:
            logs=[f'🪡 Заштопано {self.plush.heal(14)} HP.'] if k=='mend' else ['🎀 Поддержка игрушки.']
            if k!='mend':self.plush.add_effect(Agile(1,.12) if self.plush.kind=='rabbit' else Shield(3,20))
            self.support_stitches+=1
            if self.support_stitches>=2:
                self.support_stitches=0;self.plush.add_effect(WarmStitch(3,8));logs.append('🪡 Тёплый шов: дополнительный щит 8 HP.')
            return logs
        return []
    def action_score810(self,k,t):return 28 if k=='house' and not self.plush else 25 if k=='mend' and self.plush and self.plush.hp<self.plush.max_hp*.65 else 12
    def _create_skills(self):
        if not self.plush:return [attack('attack','Слабый удар','Слабая автоатака Конни.'),act('house','Я в домике','Щит на 23 HP на два хода.',cost=12,cd=3),game('rabbit','Позвать Ушастика','rabbit_summon','connie',0,0),game('bear','Позвать Мишутку','bear_summon','connie',0,0)]
        if self.plush.kind=='rabbit':
            kit=[ToyAttack('attack','Прыжок-удар','Точная атака Ушастика.',accuracy=1.05,hits=2,multiplier=.6),game('trail','Заячья тропа','rabbit_hops','connie',18,3),game('flurry','Лапки-молнии','rabbit_combo','connie',20,3),game('escape','Ускользающий прыжок','rabbit_escape','connie',18,4)]
        else:kit=[ToyAttack('attack','Тяжёлая лапа','Мощная, но неточная атака Мишутки.',accuracy=.8),game('hug','Медвежьи объятия','bear_hug','connie',20,4),game('hammer','Плюшевый молот','bear_aim','connie',22,3),game('charge','Неуклюжий натиск','bear_balance','connie',22,4)]
        return kit+[act('mend','Заштопать друга','Восстановить 14 HP игрушке.',cost=16,cd=3),act('ribbon','Ленточка удачи' if self.plush.kind=='rabbit' else 'Крепкий шов','Кролик: +12% уклонения до следующего хода; медведь: щит 20 HP.',cost=16,cd=3)]
    def puzzle_reward(self,k,t,tier):
        if k in ('rabbit','bear'):
            if tier==3:return ['🧸 Друг не услышал зов. Попробуйте ещё раз.']
            logs=self.summon_toy(k)
            if self.plush and tier==0:self.plush.add_effect(Shield(2,8))
            return logs
        if tier==3 or not self.plush:return ['🧸 Приём не удался.']
        p=self.plush
        if k=='escape':p.add_effect(Agile(1,(.2,.14,.07)[tier]));return ['🐰 Ушастик готов уклониться.']
        m={'trail':(1.4,1.1,.6),'flurry':(1.65,1.2,.6),'hug':(1.05,.8,.4),'hammer':(1.55,1.15,.6),'charge':(1.5,1.1,.6)}[k][tier]
        self._last_attack810=True
        self.skills[k].accuracy=1.05 if p.kind=="rabbit" else .8
        logs,d=self.skills[k].strike(p,t,m,force=False)
        if k=='hug' and tier==0 and d>0:t.add_effect(Stun(1))
        return logs
    def to_dict(self):
        d=super().to_dict();p=self.plush
        d['resource810']=('Управление: '+p.name+f' · тёплый шов {self.support_stitches}/2') if p else f'До нового призыва: {max(0,self.recall-1)} действий'
        d['puppet810']=dict(name=p.name,hp=p.hp,max_hp=p.max_hp,image=p.image,kind=p.kind,dodge=p.get_dodge(),damage=p.get_damage(),effects=[e.to_dict() for e in p.get_effects()]) if p else None
        d['unreachable810']=bool(p)
        if not p and len(self.used_toys)==2:d['resource810']='Оба друга больше не могут сражаться'
        return d
