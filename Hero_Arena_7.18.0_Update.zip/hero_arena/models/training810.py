"""Expanded form descriptions for the training card, without mutating live heroes."""
def forms(key):
 if key not in ('plutarch','connie','dindau'):return []
 from . import HERO_CLASSES
 from .character import Character
 saved=Character._next_id
 def entry(name,h,hp=None,dodge=None,damage=None):
  return dict(name=name,hp=h.max_hp if hp is None else hp,dodge=round(100*(h.get_dodge() if dodge is None else dodge)),damage=round(h.get_damage()*h.damage_multiplier() if damage is None else damage,1),skills=[dict(name=s.name,description=s.describe_for(h)) for s in h.skills.values() if not s.reaction and s.key!='switch'])
 try:
  result=[]
  if key=='plutarch':
   h=HERO_CLASSES[key]('Плутарх');result.append(entry('Белая сторона',h));h.side='black';h._rebuild();result.append(entry('Чёрная сторона',h))
  elif key=='connie':
   for kind in ('rabbit','bear'):
    h=HERO_CLASSES[key]('Конни');h.summon_toy(kind);p=h.plush;result.append(entry(p.name,h,hp=p.max_hp,dodge=p.get_dodge(),damage=p.get_damage()))
  else:
   h=HERO_CLASSES[key]('Дин-дау');h.take_damage(1000);result.append(entry('Пилот после взрыва',h,hp=1,dodge=h.get_dodge(),damage=3))
  return result
 finally:Character._next_id=saved
