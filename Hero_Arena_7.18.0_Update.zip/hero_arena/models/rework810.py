"""Replace repetitive 7.8 inputs without changing their combat rewards."""
import math,random
from types import MethodType
from .minigames_56 import Replay,events,integer,number,trace,at,records
from .games810 import tier

RULES={
'wolf_compress':'Зажимайте повязку пробелом или кнопкой. Сжимайте три раны, чередуя давление и отдых: кровотечение должно остановиться, а боль не достигать 100.',
'stone_mend':'Зажимайте каждую трещину и удерживайте сварку не меньше 0.3 секунды. Почините пять разных участков.',
'stone_steps':'Перенесите три тяжёлые стопы на опоры по очереди. Ставьте центр тяжести внутрь узкой площадки.',
'wolf_leap':'Зажмите волка, проведите через верхний разрыв преграды и отпустите на добыче.',
'shell_tide':'Растяните дугу панциря за два конца так, чтобы укрыть все направления волн. Дуга не должна превышать 120°.',
'ice_trident':'Передвигайте трезубец и поворачивайте его кнопками. Совместите все три острия с трещинами льда.',
'titan_fall':'Проведите кулак через четыре точки разлома одним непрерывным жестом. Неудача сохраняет прежнюю расплату гордыни.',
'titan_pillar':'Сложите четыре опоры снизу вверх: перетащите каждый блок на указанную площадку, удерживая центр в пределах опоры.',
'titan_fist':'Разломите три плиты: у каждой выберите самую широкую сквозную трещину. Сравнивайте ширину линий.',
'sand_avoid':'A/D изменяют скорость вращения с инерцией. Сделайте оборот по часовой стрелке, не встречая красный сектор.',
'sand_cut':'Зажмите рукоять, сделайте полный оборот по часовой стрелке, затем проведите клинок через центр к нижней метке.',
'barbarian_pull':'Зажмите рукоять и тяните цепь вниз не менее чем на 80 делений. Сделайте двенадцать тяжёлых рывков, чередуя левую и правую цепь.',
'barbarian_hunt':'Ведите факел по туману и найдите три следа по порядку. Следующий след виден только при приближении.',
'gladiator_reflect':'Поверните щит мышью так, чтобы отражённый выпад пошёл в зелёную мишень. На поле показана точная геометрия.',
'gladiator_steady':'Ведите прицел, компенсируя дрожь руки и боковой ветер. Держите оба перекрестия вместе 7 секунд.',
'gladiator_break':'Пять ударов булавой. Разбейте непрерывный проход слева направо через бронепластины; цифры показывают прочность.'}
REPLACEMENTS={
 'tauhand':{'mending':'stone_mend','step':'stone_steps'},
 'vervelt':{'leap':'wolf_leap','stitch':'wolf_compress'},
 'gormadont':{'tide':'shell_tide'},
 'jotunlok':{'trident':'ice_trident'},
 'gordonos':{'fall':'titan_fall','pillar':'titan_pillar','fist':'titan_fist'},
 'ksair':{'avoid':'sand_avoid','timing':'sand_cut'},
 'buattila':{'rhythm':'barbarian_pull','hunt':'barbarian_hunt'},
 'afill':{'parry':'gladiator_reflect','spear':'gladiator_steady','mace':'gladiator_break'}}

class LegacyInputs:
 def game_params(self,u,t):
  m=self.mode;o=self.params(u);o.update(mode=m,hero_type=u.type_key,instruction=RULES[m],duration=round(7000*o['factor']))
  if m=='wolf_compress':o.update(duration=round(16000*o['factor']))
  elif m=='stone_mend':o.update(nodes=[[60,70],[180,60],[300,70],[110,180],[250,180]])
  elif m in ('stone_steps','titan_pillar'):o.update(targets=[90,230,145] if m=='stone_steps' else [110,135,115,140],widths=[65,55,45] if m=='stone_steps' else [100,85,70,55])
  elif m=='wolf_leap':o.update(start=[40,210],end=[310,65],wall=[155,85,50,175])
  elif m=='shell_tide':
   center=random.uniform(-2.2,-.8);o.update(waves=[center-.7+i*.28 for i in range(6)])
  elif m=='ice_trident':
   angle=random.randrange(12)*math.pi/12;c=[random.randint(145,215),random.randint(110,150)];o.update(targets=[[c[0]+x*math.cos(angle),c[1]+x*math.sin(angle)] for x in (-45,0,45)])
  elif m=='titan_fall':o.update(nodes=[[80,180],[180,50],[280,180],[180,230]])
  elif m=='titan_fist':o.update(cracks=[random.sample([2,5,8],3) for _ in range(3)])
  elif m=='barbarian_hunt':o.update(tracks=[[75,170],[180,70],[290,165]])
  elif m=='gladiator_reflect':o.update(goal=random.choice([-2.4,-1.9,-1.2,-.7]))
  elif m=='gladiator_steady':o.update(phase=random.uniform(0,6.28))
  elif m=='gladiator_break':o.update(plates=[random.randint(1,3) for _ in range(3)]+[1,2,2]+[random.randint(1,3) for _ in range(3)],budget=5)
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  end=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);prep=o['prepare_ms'];m=self.mode
  if end<prep:return 3
  a=events(c,'actions',o,100);pts=trace(c,o)
  if m=='wolf_compress':
   if not a:return 3
   idx=0;down=False;blood=100.;pain=0.;wounds=0
   for tm in range(prep,min(end,prep+o['duration']),max(1,round(25*o['factor']))):
    while idx<len(a) and a[idx]['ms']<=tm:
     if a[idx].get('side')=='compress':down=a[idx].get('down') is True
     idx+=1
    if down:blood-=.6;pain+=.45
    else:blood=min(100,blood+.08);pain=max(0,pain-.8)
    if pain>=100:return 3
    if blood<=0 and pain<90:
     wounds+=1;blood=80
     if wounds==3:return 0
   return 1 if wounds==2 else 2 if wounds==1 else 3
  if m=='stone_mend':
   seen=set();last=prep-1
   for h in records(c,'holds',5):
    i=integer(h.get('node'),hi=4);d=integer(h.get('down_ms'),lo=prep,hi=end);up=integer(h.get('up_ms'),lo=prep,hi=end)
    if i<0 or d<=last or up-d<300*o['factor']:return 3
    if math.dist(at(pts,d),o['nodes'][i])>25 or any(math.dist(at(pts,tm),o['nodes'][i])>25 for tm in range(d,up+1,25)):return 3
    last=up;seen.add(i)
   return tier(len(seen),5)
  if m in ('stone_steps','titan_pillar'):
   n=0
   for i,v in enumerate(a):
    if i>=len(o['targets']) or v.get('i')!=i:return 3
    n+=abs(number(v.get('x'))-o['targets'][i])<o['widths'][i]*.22
   return tier(n,len(o['targets']))
  if m=='shell_tide':
   ends={}
   for v in a:
    if v.get('i') not in (0,1):return 3
    ends[v['i']]=math.atan2(number(v.get('y'))-130,number(v.get('x'))-180)
   if len(ends)!=2:return 3
   span=(ends[1]-ends[0])%math.tau
   if span>math.pi*2/3:return 3
   return tier(sum((angle-ends[0])%math.tau<=span for angle in o['waves']),6)
  if m=='ice_trident':
   center=[70,210];angle=0
   for v in a:
    if v.get('rotate') in (-1,1):angle+=v['rotate']*math.pi/12
    elif 'x' in v:center=[number(v.get('x')),number(v.get('y'))]
    else:return 3
   tips=[[center[0]+x*math.cos(angle),center[1]+x*math.sin(angle)] for x in (-45,0,45)]
   return tier(sum(math.dist(x,y)<15 for x,y in zip(tips,o['targets'])),3)
  if m in ('wolf_leap','titan_fall','sand_cut'):
   holds=records(c,'holds',1)
   if len(holds)!=1 or not pts:return 3
   h=holds[0];d=integer(h.get('down_ms'),lo=prep,hi=end);up=integer(h.get('up_ms'),lo=prep,hi=end)
   if d<0 or up-d<500*o['factor']:return 3
   path=[at(pts,tm) for tm in range(d,up+1,25)]
   if m=='wolf_leap':
    if math.dist(path[0],o['start'])>25 or math.dist(path[-1],o['end'])>25:return 3
    hits=sum(155<x<205 and y>85 for x,y in path);return 0 if not hits else 2 if hits<len(path)*.1 else 3
   if m=='titan_fall':
    n=0
    for p in path:
     if n<4 and math.dist(p,o['nodes'][n])<27:n+=1
    return tier(n,4)
   angles=[];progress=0;after=False
   for x,y in path:
    radius=math.hypot(x-180,y-130)
    if progress>=math.tau*.95:
     if radius<25:after=True
    elif 55<=radius<=100:
     angle=math.atan2(y-130,x-180)
     if angles:progress+=max(0,min(.5,(angle-angles[-1]+math.pi)%math.tau-math.pi))
     angles.append(angle)
   return 0 if progress>=math.tau*.95 and after and math.dist(path[-1],[180,235])<25 else 2 if progress>=math.pi else 3
  if m=='titan_fist':return tier(sum(v.get('i')==max(range(3),key=lambda k:o['cracks'][j][k]) for j,v in enumerate(a[:3])) if len(a)==3 else 0,3)
  if m=='barbarian_pull':
   if len(a)>12:return 3
   n=0;last=prep-10000
   for i,v in enumerate(a):
    if v.get('side')!=('left' if i%2==0 else 'right') or v['ms']-last<180*o['factor'] or number(v.get('dy'))<80 or number(v.get('up_ms'))-number(v.get('down_ms'))<200*o['factor']:return 3
    n+=1;last=v['ms']
   return tier(n,12)
  if m=='barbarian_hunt':
   n=0
   for tm,x,y in pts:
    if tm>=prep and n<3 and math.dist([x,y],o['tracks'][n])<23:n+=1
   return tier(n,3)
  if m=='gladiator_reflect':
   if not a:return 3
   v=a[-1];angle=math.atan2(number(v.get('y'))-130,number(v.get('x'))-180);reflected=2*angle;diff=abs((reflected-o['goal']+math.pi)%math.tau-math.pi)
   return 0 if diff<.12 else 1 if diff<.25 else 2 if diff<.45 else 3
  if m=='gladiator_steady':
   if end<prep+o['duration']-100 or not pts:return 3
   good=0;total=0
   for tm in range(prep,prep+o['duration'],25):
    x,y=at(pts,tm);q=(tm-prep)/1000;cx=x+28*math.sin(q*1.3+o['phase']);cy=y+18*math.cos(q*1.7)
    good+=math.hypot(cx-180,cy-130)<22;total+=1
   return tier(good,total*.85)
  if m=='sand_avoid':
   if end<prep+o['duration']-100:return 3
   held=set();idx=0;angle=0.;speed=0.;hits=0;progress=0.
   for tm in range(prep,prep+o['duration'],25):
    while idx<len(a) and a[idx]['ms']<=tm:
     v=a[idx];key=v.get('side');held.add(key) if v.get('down') else held.discard(key);idx+=1
    speed=(speed+(.003 if 'right' in held else 0)-(.003 if 'left' in held else 0))*.985;angle+=speed;progress+=max(0,speed)
    danger=-(tm-prep)/1900;diff=abs((angle-danger+math.pi)%math.tau-math.pi);hits+=diff<.18
   return 0 if progress>=math.tau and hits<15 else 1 if progress>=math.pi*1.5 and hits<40 else 2 if progress>=math.pi else 3
  if m=='gladiator_break':
   if len(a)>o['budget']:return 3
   plates=o['plates'][:]
   for v in a:
    i=integer(v.get('i'),hi=8)
    if i<0 or plates[i]==0:return 3
    plates[i]-=1
   reached={i for i in (0,3,6) if plates[i]==0};todo=list(reached)
   while todo:
    i=todo.pop()
    for j in range(9):
     if j not in reached and plates[j]==0 and abs(i//3-j//3)+abs(i%3-j%3)==1:reached.add(j);todo.append(j)
   return 0 if reached & {2,5,8} else 2 if sum(x==0 for x in plates)>=2 else 3
  return 3

def install(classes):
 for hero,modes in REPLACEMENTS.items():
  cls=classes[hero];original=cls._create_skills
  def create(self,_original=original,_modes=modes):
   skills=_original(self)
   for s in skills:
    mode=_modes.get(getattr(s,'MODE',None))
    if mode:
     s.mode=mode;s.game='legacy810';s.TIME_LIMIT_MS=18000;s.description=RULES[mode];s.prompt=RULES[mode]
     s.game_params=MethodType(LegacyInputs.game_params,s);s.tier_from=MethodType(LegacyInputs.tier_from,s)
   return skills
  cls._create_skills=create
