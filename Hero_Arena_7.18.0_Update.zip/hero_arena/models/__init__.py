"""Пакет моделей (классов предметной области)."""
from .item import (Item, Weapon, Potion, Katana, OrdinaryKatana, Yoshirin, Kyocherin, Masamune, KATANAS,
                   Consumable, Kunai, HealingPotion, EnergyPotion, Bomb, CONSUMABLES, SKINS)
from .inventory import Inventory
from .character import (Character, Warrior, Mage, Archer, Ogre, Spartan, Assassin,
                        Samurai, Druid, Monk, DarkElf, Owlbeast, HERO_CLASSES)
from .effects import (Announcement, Effect, DamageOverTime, Burn, Bleed, DeepBleed, Poison, Acid,
                      DarkCurse, Stun, Regeneration, Shield, StoneSkin, StoneShield, Berserk,
                      Evasion, Invisibility, CounterStance, Contract, Antiheal, Intimidated)
from .skills import (Skill, DamageSkill, HealSkill, SelfBuffSkill, BackstabSkill, LifestealSkill,
                     SummonSkill, ReactionSkill, ContractSkill, WeaknessSkill, DebuffSkill)
from .summons import Summon, Bear, Falcon, Snake, Hamster, WaterSpirit, BEASTS, random_beast
from .player import Player
from .battle import Battle
from .heroes_new import (Musketeer, Pagan, Minotaur, Croc, DarkKnight, Wolf, GhostCat, BloodBear, GreatDeer, DruidBoss,
                         Mob, NEW_HEROES, MOBS)
from .skills import MiniGameSkill, ChoiceSkill
from .summons import Deer, Clone, SkeletonSquad, BeastCompanion
from .item import (SmokeBomb, StunWardCharm, CleansingScroll, RegenElixir, PoisonVial, Whetstone, HunterNet,
                   LuckTalisman, RARITIES)
from .skin_themes import SKIN_THEMES
from .story import STORY, Location, Stage, StoryBattle
from .heroes_42 import (GazLow, Satyr, Ghoul, Rhino, Durrila, Orc, Dwarf, LightElf, Nefruit, NEW_HEROES_42,
                        CatchShadowSkill, BogatyrStrike, AimDodgeSkill)
from .heroes_54 import (Aarakocra, Hunter, Gnoll, Centaur, BlueTroll, Paladin, Catfolk, BeastLord,
                        SpiderQueen, Ranger, Pandaren, Gambler, NEW_HEROES_54, DEFAULT_NAMES_54)
from .summons import OwlNephews, Decoy, ForestSpirit


# 4.3: случайность моделей — через прокси (генератор конкретного боя, см. models/rng.py)
from . import rng as _rng, battle as _b, character as _c, heroes_42 as _h42, heroes_new as _hn, item as _it, \
    minigames as _mg, minigames_42 as _mg42, skills as _sk, summons as _su, story as _st
from . import heroes_54 as _h54, minigames_54 as _mg54, mage_skills as _mage
from .heroes_55 import Keltazar,Feliss,Cyclops,Mersey,Leon
from .necromancy_55 import Getou
from . import heroes_55 as _h55, rituals_55 as _r55, necromancy_55 as _n55
_rng.install(_b, _c, _h42, _hn, _h54, _it, _mg, _mg42, _mg54, _mage, _h55, _r55, _n55, _sk, _su, _st)

from . import passives_56 as _p56
_p56.install(HERO_CLASSES)

from . import minigames_56 as _mg56
_rng.install(_mg56)
_mg56.install(HERO_CLASSES)

from . import minigames_58 as _mg58, rework_58 as _rw58
_rng.install(_mg58)
_rw58.install(HERO_CLASSES)

from . import minigames_59 as _mg59
_rng.install(_mg59)
_mg59.install(HERO_CLASSES)

from . import review_600 as _review600
_rng.install(_review600)
_review600.install(HERO_CLASSES)
from . import games_600 as _games600
_rng.install(_games600)
_games600.install_updates()
_review600.finish_install(HERO_CLASSES)
_review600.finish_details(HERO_CLASSES)
_review600.install_katana(HERO_CLASSES)
_review600.refresh_descriptions(HERO_CLASSES)

from . import review_601 as _review601
_review601.install(HERO_CLASSES)

from . import review_602 as _review602
_rng.install(_review602)
_review602.install(HERO_CLASSES)


from .arena_rules import ARENA_HP as _hp605
_hp605['mage']=181
from .mage_skills import IceAssemblySkill as _ice605
_ice605.ABSORB=[27,23,18,9]

def _install_readable605():
    for kind,C in HERO_CLASSES.items():
        factory=C._create_skills
        def create(self,_factory=factory,_kind=kind):
            skills=_factory(self)
            for sk in skills:
                if (_kind,sk.key) in {('warrior','armor_fix'),('ogre','feast'),('spartan','read_enemy'),('druid','forest_call'),('owlbeast','nephews'),('pagan','prayer'),('pagan','werewolf'),('croc','shell_puzzle'),('goblin','cups'),('goblin','lockpick'),('satyr','dance'),('satyr','forest_spirit'),('rhino','mud_bath'),('lightelf','constellation'),('shade','twins'),('pandaren','douse')}:
                    actual=getattr(sk,'original600',sk);actual.deals_damage=False
                if _kind=='mage' and sk.key=='ice_shield':
                    sk.description='Мини-игра плетения контура: щит 27/23/18/9 урона; идеал держится 3 хода'
                if _kind=='musketeer' and sk.key=='musket_shot':
                    sk.description=f"×{sk.multiplier:g}, точность {sk.accuracy*100:g}%, пробивает {sk.armor_pierce*100:g}% брони. Нужен заряд"
                if _kind=='musketeer' and sk.key=='bayonet':
                    sk.description=f"×{sk.multiplier:g}, шанс замедления {sk.effect_chance*100:g}% на 2 хода"
                if _kind=='shade' and sk.key=='twins':
                    sk.description='Три укрытия: выбирайте тёмное перед вспышкой. Три успеха — два двойника; два успеха — один.'
                    if hasattr(sk,'original600'):sk.original600.description=sk.description
                if sk.key=='read_enemy' and _kind=='spartan':
                    sk.describe_for=lambda user,sk=sk:sk.description+f' · перезарядка {sk.cooldown} х.'
            return skills
        C._create_skills=create
_install_readable605()

from . import rikz_609 as _rikz609
_rng.install(_rikz609)
_rikz609.install(HERO_CLASSES)

from . import acheron_612 as _acheron612
_rng.install(_acheron612)
_acheron612.install(HERO_CLASSES)

from . import heroes730 as _heroes730
_rng.install(_heroes730)
_heroes730.install(HERO_CLASSES)

from . import cosmetics730 as _cosmetics730

from . import cosmetics740 as _cosmetics740

from . import variety740 as _variety740
_rng.install(_variety740)
_variety740.install()

# Three 7.4 heroes and their paired form portraits.
from .arsteyd740 import Arsteyd
from .hermione740 import Hermione
from .nikea740 import Nikeya
from . import arsteyd_games740 as _arsteyd_games740, nikea_games740 as _nikea_games740
_rng.install(_arsteyd_games740, _nikea_games740)
HERO_CLASSES.update({'arsteyd':Arsteyd,'hermione':Hermione,'nikea':Nikeya})
from .newhero_skins740 import SKINS740 as _skins740
SKIN_THEMES.update(_skins740)
from .jeanpierre750 import JeanPierre
from . import jeanpierre750 as _jeanpierre750
_rng.install(_jeanpierre750)
HERO_CLASSES['jeanpierre']=JeanPierre
from .rat_skins750 import SKINS750 as _rat_skins750
SKIN_THEMES['jeanpierre']=_rat_skins750
from .skin_additions760 import ADDITIONS760 as _skin_additions760
for _hero760,_entries760 in _skin_additions760.items():
    _known760={item[1] for item in SKIN_THEMES[_hero760]}
    SKIN_THEMES[_hero760].extend(item for item in _entries760 if item[1] not in _known760)

from .tauhand780 import Tauhand
HERO_CLASSES['tauhand'] = Tauhand

from .vervelt780 import Vervelt
from . import vervelt780 as _vervelt780
_rng.install(_vervelt780)
HERO_CLASSES['vervelt']=Vervelt

from .gormadont780 import Gormadont
from . import gormadont780 as _gormadont780
_rng.install(_gormadont780)
HERO_CLASSES['gormadont']=Gormadont

from .jotunlok780 import Jotunlok
from . import jotunlok780 as _jotunlok780
_rng.install(_jotunlok780)
HERO_CLASSES['jotunlok']=Jotunlok

from .gordonos780 import Gordonos
from . import gordonos780 as _gordonos780
_rng.install(_gordonos780)
HERO_CLASSES['gordonos']=Gordonos

from .ksair780 import Ksair
from . import ksair780 as _ksair780
_rng.install(_ksair780)
HERO_CLASSES['ksair']=Ksair

from .skins_790 import SKINS790 as _skins790
for _hero790, _entries790 in _skins790.items():
    SKIN_THEMES.setdefault(_hero790, []).extend(_entries790)

from .buattila780 import Buattila
from . import buattila780 as _buattila780
_rng.install(_buattila780)
HERO_CLASSES['buattila']=Buattila

from .afill780 import Afill
from . import afill780 as _afill780
_rng.install(_afill780)
HERO_CLASSES['afill']=Afill

from .skins_800 import SKINS800 as _skins800
for _hero800, _entries800 in _skins800.items():
    SKIN_THEMES.setdefault(_hero800, []).extend(_entries800)

from .anivriza810 import Anivriza
from . import anivriza810 as _anivriza810
_rng.install(_anivriza810)
HERO_CLASSES["anivriza"]=Anivriza

SKIN_THEMES["anivriza"]=[('common', 'new810_01', 'Ночной дозор', 'Облик «Ночной дозор».'), ('common', 'new810_02', 'Буревестница', 'Облик «Буревестница».'), ('common', 'new810_03', 'Пепельное перо', 'Облик «Пепельное перо».'), ('common', 'new810_04', 'Лесной ветер', 'Облик «Лесной ветер».'), ('common', 'new810_05', 'Скальная охотница', 'Облик «Скальная охотница».'), ('rare', 'new810_06', 'Снежная сова', 'Облик «Снежная сова».'), ('rare', 'new810_07', 'Воронья разведчица', 'Облик «Воронья разведчица».'), ('rare', 'new810_08', 'Пустынный гриф', 'Облик «Пустынный гриф».'), ('rare', 'new810_09', 'Певчая гроза', 'Облик «Певчая гроза».'), ('epic', 'new810_10', 'Хранительница гнезда', 'Облик «Хранительница гнезда».'), ('epic', 'new810_11', 'Часовая склепа', 'Облик «Часовая склепа».'), ('epic', 'new810_12', 'Золотая охотница', 'Облик «Золотая охотница».'), ('legendary', 'new810_13', 'Королева падали', 'Облик «Королева падали».'), ('legendary', 'new810_14', 'Стражница ледяного пика', 'Облик «Стражница ледяного пика».'), ('mythic', 'new810_15', 'Последняя мать гнезда', 'Облик «Последняя мать гнезда».')]

from . import games810 as _games810, heroes810 as _heroes810, connie810 as _connie810
_rng.install(_games810, _heroes810, _connie810)
from .heroes810 import Atlargas, Frida, Plutarch, Yaisha, Dindau
from .connie810 import Connie
HERO_CLASSES.update({'atlargas':Atlargas,'frida':Frida,'plutarch':Plutarch,'yaisha':Yaisha,'dindau':Dindau,'connie':Connie})

from . import rework810 as _rework810
_rng.install(_rework810)
_rework810.install(HERO_CLASSES)

from .skins810 import SKINS810
SKIN_THEMES.update(SKINS810)
