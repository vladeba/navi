"""Distinct physical puzzles; all qualities are replayed by the server."""
import math, random
from .skills import MiniGameSkill
from .minigames_56 import Replay, events, integer, number, trace, at, records

DESCRIPTIONS={
'water_pipes':'Поверните четыре секции, чтобы вода прошла от входа слева к выходу справа. Стрелки показывают соединения.',
'water_balance':'Удерживайте ← и →, сопротивляясь вращению водоворота. Держитесь в светлом внутреннем кольце 7 секунд.',
'water_pressure':'Распределите 8 порций воды между тремя камерами по их ёмкостям. Избегайте переполнения.',
'shield_track':'Ведите щит мышью вокруг центра и закрывайте направления летящих стрел. Это непрерывное сопровождение.',
'spear_arc':'Оттяните копьё от стартовой точки и отпустите. Пунктир показывает дугу полёта с учётом тяжести.',
'shield_wrestle':'Толкайте щит клавишей D, отпуская для восстановления сил. Не истощайте выносливость; вытесните врага вправо.',
'sword_cuts':'Сделайте четыре отдельных разреза через отмеченные пары концов. Направление разреза указано стрелкой.',
'trap_place':'Перетащите три ловушки на три разных пересечения пути. Подсказка показывает, где пройдёт противник.',
'clone_shuffle':'Меняйте местами настоящего шута и кукол, чтобы настоящий оказался вне двух линий удара.',
'poison_mix':'Добавляйте и убирайте ингредиенты. Соберите рецепт по весам, не превышая общую вместимость котла.',
'mask_logic':'Выберите все маски, у которых выражение противоречит подписи. Сравнивайте два признака, не скорость.',
'shadow_route':'Зажмите фигурку и проведите за спину цели, не попадая в движущийся луч света.',
'knife_weave':'Поймайте каждый падающий кинжал мышью и подбросьте его вверх быстрым движением. Нужны захват и бросок.',
'armor_deduce':'Прочтите три подсказки о броне и укажите единственный открытый участок.',
'song_contour':'Ведите голос вдоль волны слева направо, удерживая линию внутри светлой полосы.',
'echo_memory':'Запомните пять звуков, затем повторите их на клавишах после исчезновения образца.',
'choir_cancel':'Удерживайте противоположный тон, пока звучит каждый чужой голос. Нужно погасить помеху устойчивым звуком; короткий клик не засчитывается.',
'song_intervals':'Настройте три ноты: первая задана, следующая выше на указанный интервал. Настраивайте высоту ползунками.',
'gear_fit':'Найдите шестерню с нужным числом зубцов, затем поверните её в верное положение.',
'wire_connect':'Соедините три пары контактов отдельными проводами, обходя красные зоны короткого замыкания.',
'dual_tune':'Два регулятора связаны: правый меняет обе пилы. Настройте обе скорости на зелёные отметки.',
'saw_resistance':'Зажмите пилу и ведите по разрезу. На толстых участках двигайтесь медленно, иначе пила заклинит.',
'pressure_manage':'Включайте подачу топлива и сбрасывайте давление клапаном. Пройдите дистанцию, не перегрев двигатель.',
'rabbit_summon':'Найдите дорожку из пяти настоящих следов кролика: у каждого следующего на один стежок больше.',
'bear_summon':'Перетащите четыре заплаты в соответствующие выемки плюшевого сердца.',
'rabbit_hops':'Проведите прыжки по клеткам: чередуйте белые и тёмные камни, обходя воду.',
'rabbit_combo':'Выполните последовательность парных движений лап: клавиши A, D и обе вместе. После нажатия обеих отпустите их.',
'rabbit_escape':'Удерживайте A и D для смены полосы, уклоняйтесь от катящихся камней. Ушастик продолжает движение по инерции.',
'bear_hug':'Сведите лапы вокруг движущейся цели: A двигает левую, D правую. Поймайте цель, не столкнув лапы раньше времени.',
'bear_aim':'Замахнитесь мышью от молота и резко проведите через цель. Нужны направление и скорость, а не клик.',
'bear_balance':'Наклоняйте площадку клавишами A и D, направляя тяжёлого Мишутку к цели и удерживая равновесие.'}

REWARDS={'water_pipes': 'Успех даёт прилив и щит.', 'water_balance': 'Успех восстанавливает здоровье.', 'water_pressure': 'Всплытие с усиленным ударом, расходует весь прилив.', 'shield_track': 'Успех создаёт щит.', 'spear_arc': 'Точный бросок наносит урон.', 'shield_wrestle': 'Урон и небольшой щит.', 'sword_cuts': 'Сильная атака мечом.', 'trap_place': 'Взводит ловушку на следующую атаку врага: 8 урона и яд.', 'clone_shuffle': 'Двойник поглощает один прямой удар.', 'poison_mix': 'Накладывает яд на три хода.', 'mask_logic': 'Страх: 20% пропуск действия и 5 урона; 45% −25% точности на одно действие; 35% обычное действие. После него два действия защиты от повторения.', 'shadow_route': 'Точный выпад из-за спины.', 'knife_weave': 'Серия атак.', 'armor_deduce': 'Мощный завершающий удар.', 'song_contour': 'Без прямого урона: ослабляет урон врага и добавляет ноты.', 'echo_memory': 'Без прямого урона: снижает уклонение и добавляет ноты.', 'choir_cancel': 'Без прямого урона: снижает точность и добавляет ноты.', 'song_intervals': 'Атака с расходом всех накопленных нот.', 'gear_fit': 'Снижает износ, доступна и при заглохшей машине.', 'wire_connect': 'Чинит HP машины; провал даёт +2 износа.', 'dual_tune': 'Следующая атака машины +20%; провал даёт +2 износа.', 'saw_resistance': 'Атака пилой, дополнительный износ +1.', 'pressure_manage': 'Сильная атака, дополнительный износ +3.', 'rabbit_summon': 'Призывает Ушастика (125 HP). Каждый друг доступен один раз.', 'bear_summon': 'Призывает Мишутку (155 HP). Каждый друг доступен один раз.', 'rabbit_hops': 'Быстрая атака Ушастика.', 'rabbit_combo': 'Серия точных ударов.', 'rabbit_escape': 'Повышает уклонение Ушастика на одно действие.', 'bear_hug': 'При идеальном выполнении и попадании оглушает на одно действие.', 'bear_aim': 'Мощный, но неточный удар Мишутки.', 'bear_balance': 'Тяжёлый натиск с риском промаха.'}

def tier(n,total):return 0 if n>=total else 1 if n>=total*.7 else 2 if n>=total*.35 else 3

def simulation(mode,o,actions):
 """Replay held controls at 25ms steps, not client-supplied positions/scores."""
 a=iter(actions);nxt=next(a,None);held=set();x=0.;v=0.;stamina=100.;pressure=35.;progress=0.;good=0;hits=0;captured=False
 duration=o.get('duration',7000);start=o['prepare_ms'];steps=round(duration/25)
 for i in range(steps):
  tm=start+i*25
  while nxt and nxt['ms']<=tm:
   key=nxt.get('key');down=nxt.get('down')
   if key in ('left','right','fuel','vent') and isinstance(down,bool):held.add(key) if down else held.discard(key)
   nxt=next(a,None)
  direction=int('right' in held)-int('left' in held)
  if mode=='water_balance':
   v=(v+direction*.055+math.sin(i*.032+o['phase'])*.018)*.98;x+=v*.08
   good+=abs(x)<.8
  elif mode=='shield_wrestle':
   push='right' in held and stamina>2;stamina=max(0,min(100,stamina+(-.65 if push else .8)));x+=.012 if push else -.006
   good+=x>.15 and stamina>0
  elif mode=='pressure_manage':
   pressure+=.5 if 'fuel' in held else -.12
   if 'vent' in held:pressure-=.9
   pressure=max(0,min(110,pressure));progress+=max(0,pressure-20)*.004
   if pressure>90:hits+=1
   good+=25<=pressure<=80
  elif mode=='rabbit_escape':
   v=(v+direction*.035)*.92;x=max(-1,min(1,x+v*.12))
   for b in o['obstacles']:
    if abs(tm-b['ms'])<13:
     if abs(x-b['lane'])>.42:good+=1
  elif mode=='bear_hug':
   # Each control moves a different paw; capture must occur near the target.
   x=min(1,x+(.006 if 'left' in held else -.003));v=min(1,v+(.006 if 'right' in held else -.003));x=max(0,x);v=max(0,v)
   target=.5+.16*math.sin(i*.04+o['phase'])
   leftpos=x*.5;rightpos=1-v*.5
   if rightpos-leftpos<.25 and leftpos<target<rightpos:captured=True
  elif mode=='bear_balance':
   v=(v+direction*.018+math.sin(i*.025+o['phase'])*.006)*.98;x+=v*.07
   if abs(x)>1.3:hits+=1
   good+=.4<x<1.1
 if mode=='shield_wrestle':return 0 if x>=.75 else 1 if x>=.4 else 2 if x>0 else 3
 if mode=='pressure_manage':return 0 if progress>55 and hits<5 else 1 if progress>40 and hits<25 else 2 if progress>20 else 3
 if mode=='rabbit_escape':return tier(good,len(o['obstacles']))
 if mode=='bear_hug':return 0 if captured else 2 if x+v>.7 else 3
 if mode=='bear_balance':return 0 if .6<x<1.1 and hits==0 else 1 if x>.4 and hits<20 else 2 if x>0 else 3
 return tier(good,steps*.85)

class Puzzle(Replay,MiniGameSkill):
 game='heroes810';reactor='user';hero_target=True;PREP=700;TIME_LIMIT_MS=18000
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,43,25,10);copyable=False
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);o.update(mode=self.mode,instruction=DESCRIPTIONS[self.mode],duration=round(7000*o['factor']),phase=random.uniform(0,6.28))
  m=self.mode
  if m=='water_pipes':
   turns=[random.randrange(4) for _ in range(4)];solution=[0,2,1,3]
   if turns==solution:turns[0]=(turns[0]+1)%4
   o.update(turns=turns,solution=solution)
  elif m=='water_pressure':o.update(target=[2,3,3],budget=8)
  elif m=='shield_track':o.update(arrows=[dict(ms=round((2000+i*950)*o['factor']),angle=random.uniform(-math.pi,math.pi)) for i in range(6)])
  elif m=='spear_arc':o.update(origin=[65,205],target=[random.randint(225,290),random.randint(100,165)],gravity=.045)
  elif m=='knife_weave':o.update(knives=[dict(ms=round((1500+i*1800)*o['factor']),x=x) for i,x in enumerate((80,180,280))])
  elif m in ('sword_cuts',):o.update(starts=[[55,65],[300,100],[65,170],[300,220]][:3 if m=='knife_weave' else 4],ends=[[300,75],[60,120],[300,185],[60,225]][:3 if m=='knife_weave' else 4])
  elif m=='trap_place':o.update(spots=[[80,100],[180,160],[280,95]],traps=[[55,225],[155,225],[255,225]])
  elif m=='clone_shuffle':o.update(order=random.sample([0,1,2],3),safe=random.randrange(3))
  elif m=='poison_mix':o.update(weights=[2,3,5],target=13,limit=5)
  elif m=='mask_logic':
   faces=random.choices([0,1],k=6);labels=random.choices([0,1],k=6)
   if faces==labels:labels[0]=1-labels[0]
   o.update(faces=faces,labels=labels)
  elif m=='shadow_route':o.update(origin=[40,210],target=[315,55],lamp=[180,130])
  elif m=='armor_deduce':
   target=random.randrange(6);o.update(weak=target,clues=[f'Ряд: {target//3+1}',f'Столбец: {target%3+1}','Только один участок подходит всем подсказкам'])
  elif m=='song_contour':o.update(wave=random.choice([1,1.5,2]),amplitude=random.randint(35,60))
  elif m=='echo_memory':o.update(sequence=[random.randrange(4) for _ in range(5)],reveal=round(3500*o['factor']))
  elif m=='choir_cancel':o.update(voices=[random.randrange(3) for _ in range(4)],opposite=[2,1,0],voice_ms=[round((1500+i*1600)*o['factor']) for i in range(4)],voice_window=round(1000*o['factor']))
  elif m=='song_intervals':o.update(base=random.randint(1,3),intervals=[random.randint(1,3),random.randint(1,3)])
  elif m=='gear_fit':o.update(teeth=random.sample([6,8,10,12],4),target_teeth=random.choice([6,8,10,12]),angle=random.randrange(4))
  elif m=='wire_connect':o.update(starts=[[40,60],[40,130],[40,200]],ends=[[320,60],[320,130],[320,200]],obstacles=[[130,30,40,55],[190,145,40,55]])
  elif m=='dual_tune':o.update(initial=[random.randrange(6),random.randrange(6)],target=[4,7])
  elif m=='saw_resistance':o.update(start=[45,130],end=[315,130],thick=[140,220],min_ms=round(2200*o['factor']))
  elif m=='rabbit_summon':o.update(stitches=random.sample(list(range(1,7)),6))
  elif m=='bear_summon':o.update(pieces=random.sample(list(range(4)),4),slots=[[105,75],[255,75],[105,165],[255,165]])
  elif m=='rabbit_hops':o.update(start=20,goal=4,water=[6,8,16,18])
  elif m=='rabbit_combo':o.update(combo=['left','both','right','left','right','both'])
  elif m=='rabbit_escape':o.update(obstacles=[dict(ms=round((1700+i*900)*o['factor']),lane=(0 if i in (0,3) else 1 if i==2 else -1 if i==5 else random.choice([-1,0,1]))) for i in range(6)])
  elif m=='bear_aim':o.update(target=[random.randint(210,285),130],origin=[65,130])
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);a=events(c,'actions',o,400);m=self.mode
  if elapsed<o['prepare_ms']:return 3
  if not a and not c.get('points') and not c.get('cuts') and not c.get('holds'):return 3
  if m in ('water_balance','shield_wrestle','pressure_manage','rabbit_escape','bear_hug','bear_balance'):
   if elapsed<o['prepare_ms']+o['duration']-100 or not a:return 3
   return simulation(m,o,a)
  if m=='water_pipes':
   turns=o['turns'][:]
   for v in a:
    i=integer(v.get('i'),hi=3)
    if i<0:return 3
    turns[i]=(turns[i]+1)%4
   return tier(sum(x==y for x,y in zip(turns,o['solution'])),4)
  if m in ('water_pressure','poison_mix','song_intervals','dual_tune'):
   vals=[0,0,0] if m!='dual_tune' else o['initial'][:]
   for v in a:
    i=integer(v.get('i'),hi=len(vals)-1);delta=v.get('delta')
    if i<0 or delta not in (-1,1) or isinstance(delta,bool):return 3
    vals[i]+=delta
    if m=='dual_tune' and i==1:vals[0]+=delta
    if any(x<0 or x>12 for x in vals):return 3
   if m=='water_pressure':return tier(sum(x==y for x,y in zip(vals,o['target'])) if sum(vals)<=o['budget'] else 0,3)
   if m=='poison_mix':return 0 if sum(x*w for x,w in zip(vals,o['weights']))==o['target'] and sum(vals)<=o['limit'] else 2 if abs(sum(x*w for x,w in zip(vals,o['weights']))-o['target'])<=3 and sum(vals)<=o['limit'] else 3
   target=o['target'] if m=='dual_tune' else [o['base'],o['base']+o['intervals'][0],o['base']+sum(o['intervals'])]
   return tier(sum(x==y for x,y in zip(vals,target)),len(vals))
  if m=='shield_track':
   pts=trace(c,o)
   if not pts:return 3
   n=0
   for arrow in o['arrows']:
    if arrow['ms']>elapsed:continue
    x,y=at(pts,arrow['ms']);angle=math.atan2(y-130,x-180);diff=abs((angle-arrow['angle']+math.pi)%math.tau-math.pi)
    n+=diff<.36 and math.hypot(x-180,y-130)>35
   return tier(n,6)
  if m=='spear_arc':
   if len(a)!=1:return 3
   v=a[0];x=number(v.get('x'));y=number(v.get('y'))
   x0=number(v.get('x0'));y0=number(v.get('y0'))
   down=integer(v.get('down_ms'),lo=o['prepare_ms'],hi=elapsed);up=integer(v.get('up_ms'),lo=o['prepare_ms'],hi=elapsed)
   if math.dist((x0,y0),o['origin'])>24 or x>o['origin'][0]-25 or up-down<120*o['factor'] or up-down>900*o['factor']:return 3
   vx=(o['origin'][0]-x)*.22;vy=(o['origin'][1]-y)*.22
   if vx<=0:return 3
   tm=(o['target'][0]-o['origin'][0])/vx;hit=o['origin'][1]+vy*tm+.5*o['gravity']*tm*tm
   d=abs(hit-o['target'][1]);return 0 if d<12 else 1 if d<25 else 2 if d<45 else 3
  if m=='knife_weave':
   seen=set();n=0
   for v in a:
    i=integer(v.get('i'),hi=2);d=integer(v.get('down_ms'),lo=o['prepare_ms'],hi=elapsed);up=integer(v.get('up_ms'),lo=o['prepare_ms'],hi=elapsed)
    if i<0 or i in seen or d<0:return 3
    seen.add(i);knife=o['knives'][i];y=35+(d-knife['ms'])*.07/o['factor']
    n+=knife['ms']<=d and 25<=y<=235 and math.dist([number(v.get('x0')),number(v.get('y0'))],[knife['x'],y])<24 and 80*o['factor']<=up-d<=700*o['factor'] and number(v.get('y1'))<=number(v.get('y0'))-40
   return tier(n,3)
  if m in ('sword_cuts','wire_connect'):

   cuts=records(c,'cuts',len(o['starts']));n=0;last=o['prepare_ms']-1
   for i,v in enumerate(cuts):
    down=integer(v.get('down_ms'),lo=o['prepare_ms'],hi=elapsed);up=integer(v.get('up_ms'),lo=o['prepare_ms'],hi=elapsed)
    if down<=last or up-down<80:return 3
    last=up;p=(number(v.get('x0')),number(v.get('y0')));q=(number(v.get('x1')),number(v.get('y1')))
    good=math.dist(p,o['starts'][i])<25 and math.dist(q,o['ends'][i])<25
    if m=='wire_connect':
     pts=trace(c,o)
     if not pts:good=False
     for tm in range(down,up+1,20):
      x,y=at(pts,tm)
      if any(rx<x<rx+w and ry<y<ry+h for rx,ry,w,h in o['obstacles']):good=False
    n+=good
   return tier(n,len(o['starts']))
  if m in ('trap_place','bear_summon'):
   n=3 if m=='trap_place' else 4;placed={}
   for v in a:
    i=integer(v.get('i'),hi=n-1)
    if i<0:return 3
    placed[i]=(number(v.get('x')),number(v.get('y')))
   targets=o['spots'] if m=='trap_place' else o['slots']
   if m=='trap_place':return tier(sum(any(math.dist(p,q)<23 for p in placed.values()) for q in targets),n)
   return tier(sum(i in placed and math.dist(placed[i],targets[i])<23 for i in range(n)),n)
  if m=='clone_shuffle':
   order=o['order'][:]
   for v in a:
    i=integer(v.get('i'),hi=2);j=integer(v.get('j'),hi=2)
    if min(i,j)<0:return 3
    order[i],order[j]=order[j],order[i]
   return 0 if order[o['safe']]==0 else 3
  if m=='mask_logic':
   chosen=set()
   for v in a:
    i=integer(v.get('i'),hi=5)
    if i<0:return 3
    chosen.symmetric_difference_update({i})
   wanted={i for i in range(6) if o['faces'][i]!=o['labels'][i]}
   return 0 if chosen==wanted else 2 if chosen and len(chosen^wanted)<=2 else 3
  if m in ('shadow_route','song_contour','saw_resistance','bear_aim'):
   pts=trace(c,o);holds=records(c,'holds',1)
   if len(holds)!=1 or not pts:return 3
   h=holds[0];d=integer(h.get('down_ms'),lo=o['prepare_ms'],hi=elapsed);up=integer(h.get('up_ms'),lo=o['prepare_ms'],hi=elapsed)
   if d<0 or up-d<150:return 3
   samples=[(tm,*at(pts,tm)) for tm in range(d,up+1,25)];start=at(pts,d);end=at(pts,up)
   if m=='song_contour':
    if start[0]>65 or end[0]<300:return 3
    n=sum(abs(y-(130+o['amplitude']*math.sin((x-40)/280*math.tau*o['wave'])))<20 for _,x,y in samples);return tier(n,len(samples)*.9)
   if m=='shadow_route':
    if math.dist(start,o['origin'])>25 or math.dist(end,o['target'])>25:return 3
    safe=0
    for tm,x,y in samples:
     angle=math.atan2(y-130,x-180);beam=(tm-o['prepare_ms'])/1600+o['phase'];diff=abs((angle-beam+math.pi)%math.tau-math.pi)
     safe+=diff>.3 or math.hypot(x-180,y-130)<20
    return tier(safe,len(samples))
   if m=='saw_resistance':
    if math.dist(start,o['start'])>25 or math.dist(end,o['end'])>25 or up-d<o['min_ms']:return 3
    thick_fast=any(140<x<220 and abs(x-x0)>7 for (_,x0,_),(_,x,_) in zip(samples,samples[1:]))
    return 0 if not thick_fast and all(abs(y-130)<20 for _,x,y in samples) else 2
   if math.dist(start,o['origin'])>35:return 3
   hits=[(tm,x,y) for tm,x,y in samples if math.dist((x,y),o['target'])<25]
   return 0 if hits and up-d<900 else 1 if hits else 3
  if m=='armor_deduce':return 0 if len(a)==1 and integer(a[0].get('i'),hi=5)==o['weak'] else 3
  if m=='echo_memory':
   if any(v['ms']<o['prepare_ms']+o['reveal'] for v in a):return 3
   return tier(sum(v.get('i')==target for v,target in zip(a,o['sequence'])) if len(a)==5 else 0,5)
  if m=='choir_cancel':
   hits=0
   for voice,start in zip(o['voices'],o['voice_ms']):
    if start+o['voice_window']>elapsed:continue
    held=set();idx=0;good=0;total=0
    for tm in range(o['prepare_ms'],start+o['voice_window'],25):
     while idx<len(a) and a[idx]['ms']<=tm:
      note=integer(a[idx].get('tone'),hi=2)
      if note<0:return 3
      held.add(note) if a[idx].get('down') is True else held.discard(note);idx+=1
     if tm>=start:total+=1;good+=held=={o['opposite'][voice]}
    hits+=good>=total*.85
   return tier(hits,4)

  if m=='gear_fit':
   chosen=None;angle=0
   for v in a:
    if v.get('rotate'):angle=(angle+1)%4
    else:chosen=integer(v.get('i'),hi=3)
   return 0 if chosen is not None and chosen>=0 and o['teeth'][chosen]==o['target_teeth'] and angle==o['angle'] else 2 if chosen is not None and chosen>=0 and o['teeth'][chosen]==o['target_teeth'] else 3
  if m=='rabbit_summon':return tier(sum(o['stitches'][integer(v.get('i'),hi=5)]==i+1 for i,v in enumerate(a) if integer(v.get('i'),hi=5)>=0) if len(a)==5 else 0,5)
  if m=='rabbit_hops':
   pos=o['start'];n=0
   for v in a:
    nxt=integer(v.get('i'),hi=24)
    if nxt<0 or nxt in o['water'] or abs(nxt//5-pos//5)+abs(nxt%5-pos%5)!=1:return 3
    pos=nxt;n+=1
   return 0 if pos==o['goal'] and n<=10 else 1 if pos==o['goal'] else 2 if n>=5 else 3
  if m=='rabbit_combo':
   if len(a)!=len(o['combo']):return 3
   return tier(sum(v.get('key')==key for v,key in zip(a,o['combo'])),len(a))
  return 3
 def apply(self,u,t,tier,data):return u.puzzle_reward(self.key,t,tier)
 def ai_score(self,u,t):
  if self.key in ('rabbit','bear'):return 50
  if self.key=='gear' and getattr(u,'wear',0)>=7:return 65
  return 18

def game(key,name,mode,hero,cost,cd):
 s=Puzzle(key,name,DESCRIPTIONS[mode]+" "+REWARDS[mode],cost=cost,cooldown=cd,icon='🎮');s.mode=mode;s.hero=hero;return s
