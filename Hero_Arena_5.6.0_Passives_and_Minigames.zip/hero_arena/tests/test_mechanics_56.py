"""Behavioral coverage of the new innates and replayed physical controls."""
import itertools,math,random,time,unittest
from unittest.mock import patch
from models import HERO_CLASSES
from models.lore import passive_text
from models import passives_56 as p,minigames_56 as m
from models.effects import Bleed,Shield,GodGift

def hero(k):
 h=HERO_CLASSES[k](k);h.configure_arena();h.reset();return h

def winning(skill,o):
 c={'elapsed_ms':o['time_limit_ms']-10};g=o['game'];f=o['factor'];prep=o['prepare_ms']
 if g in ('hunt_lead_56','star_lead_56'):
  c['shots']=[]
  for i in range(o['count']):
   t=prep+100+i*round(500*f);x,y=m.moving_star(o,t+o['travel_ms']);c['shots'].append(dict(ms=t,x=x-o['wind'],y=y))
 elif g=='knife_flick_56':
  c['cuts']=[dict(down_ms=prep+100+i*400,up_ms=prep+250+i*400,x0=180,y0=232,x1=x,y1=y) for i,(x,y) in enumerate(o['targets'])]
 elif g=='spirit_guide_56':
  c['drags']=[dict(node=i,down_ms=prep+10+i*350,up_ms=prep+200+i*350,x0=x,y0=y,x=180,y=130) for i,(x,y) in enumerate(o['spirits'])]
 elif g=='nest_catch_56':
  c['points']=[dict(t=t,x=b['x'],y=225) for b in o['birds'] for t in (b['land']-100,b['land']+100)]
 elif g=='night_focus_56':
  c['points']=[dict(t=t,x=e['x'],y=e['y']) for e in o['eyes'] for t in (e['start'],e['end'])];c['clicks']=[dict(ms=e['start']+round(300*f),x=e['x'],y=e['y']) for e in o['eyes']]
 elif g=='soul_tether_56':
  c['points']=[dict(t=t,x=x,y=y) for i,(x,y) in enumerate(o['souls']) for t in (prep+i*450,prep+i*450+350)]
 elif g=='stone_stack_56':
  c['clicks']=[];t=prep+20
  for i in range(4):
   while abs(180+110*math.sin(2*math.pi*(t+o['phases'][i])/o['periods'][i])-o['slots'][i])>8:t+=1
   c['clicks'].append(dict(ms=t));t+=150
 elif g=='shadow_erase_56':
  c['points']=[dict(t=prep+10+i*300+j*50,x=x+dx,y=y+dy) for i,(x,y) in enumerate(o['seals']) for j,(dx,dy) in enumerate(((-12,-12),(12,-12),(12,12),(-12,12)))];c['holds']=[dict(down_ms=prep,up_ms=prep+1500)]
 elif g=='light_prism_56':
  bits=next(list(b) for b in itertools.product((0,1),repeat=3) if m.beam_path(o,b)[1]);c['clicks']=[dict(node=i,ms=prep+100+i*100) for i in range(3) if bits[i]!=o['initial'][i]];t=prep+600
  while m.phase_error(t,o['period'],o['phase'])>10:t+=1
  c['fire_ms']=t
 elif g=='star_pattern_56':
  c['drags']=[dict(node=i,down_ms=prep+50+i*300,up_ms=prep+200+i*300,x0=a[0],y0=a[1],x=b[0],y=b[1]) for i,(a,b) in enumerate(zip(o['nodes'],o['slots']))];c['elapsed_ms']=prep+1450
 elif g=='dawn_focus_56':
  down=prep+100;up=down+round(2800*f);c.update(down_ms=down,up_ms=up);c['points']=[dict(t=t,x=m.at(o['path'],t)[0],y=m.at(o['path'],t)[1]) for t in range(down,up+1,20)]
 elif g=='machete_route_56':c['actions']=[dict(hand=e['hand'],ms=e['ms']) for e in o['events']]
 elif g=='vital_cut_56':
  up=o['beats'][1];down=up-round(600*f);c.update(down_ms=down,up_ms=up);c['points']=[dict(t=round(down+(up-down)*i/12),x=o['entry'][0]+(o['exit'][0]-o['entry'][0])*i/12,y=o['entry'][1]+(o['exit'][1]-o['entry'][1])*i/12) for i in range(13)]
 return c

class Innates56(unittest.TestCase):
 def test_all_heroes_have_passives_without_duplicate_new_innates(self):
  self.assertEqual(len(p.NEW),15);self.assertEqual(len(p.PRESERVED),11);self.assertFalse(set(p.NEW)&set(p.PRESERVED))
  for k in HERO_CLASSES:self.assertTrue(passive_text(HERO_CLASSES[k]),k)
  self.assertNotIn('assassin',p.NEW);self.assertNotIn('lightelf',p.NEW)
 def test_queries_and_ai_do_not_consume_rng_or_change_passive_state(self):
  for k in p.NEW:
   h=hero(k);t=hero('warrior');h.opponent=t;before=random.getstate();old=dict(getattr(h,'_passive56',{}))
   for _ in range(3):
    h.get_speed();p.crit(h,t)
    for s in h.skills.values():h.hit_chance(s,t) if hasattr(s,'accuracy') else None;s.ai_score(h,t)
   self.assertEqual(old,getattr(h,'_passive56',{}),k);self.assertEqual(before,random.getstate(),k)
 def test_archer_precision_caps_resets_and_does_not_change_skill_accuracy(self):
  h=hero('archer');s=h.skills['attack'];other=next(s for s in h.skills.values() if s.key!='attack');p.paid(h,s)
  for _ in range(5):p.attack_noted(h,True)
  self.assertEqual(p.accuracy(h,s),.06);self.assertEqual(p.accuracy(h,other),0)
  p.attack_noted(h,False);self.assertEqual(p.accuracy(h,s),0);p.attack_noted(h,True);p.paid(h,other);self.assertEqual(p.accuracy(h,s),0)
 def test_low_health_dark_reserve_centaur_and_doused_income(self):
  h=hero('darkelf');h.spend_energy(h.energy);h.hp=h.max_hp*.3;p.turn_start(h);self.assertEqual(h.energy,0);h.hp-=1;p.turn_start(h);self.assertEqual(h.energy,3)
  h=hero('centaur');h.spend_energy(h.energy);h.turn_number=2;p.turn_start(h);self.assertEqual(h.energy,0);h.turn_number=3;p.turn_start(h);self.assertEqual(h.energy,3)
  h=hero('pandaren');t=hero('warrior');h.opponent=t;h.spend_energy(h.energy);t.doused_turns=2;p.turn_start(h);self.assertEqual(h.energy,2)
 def test_reload_and_god_gift_income(self):
  h=hero('musketeer');h.spend_energy(h.energy);p.paid(h,h.skills['reload']);self.assertEqual(h.energy,3)
  h=hero('pagan');h.spend_energy(h.energy);p.turn_start(h);self.assertEqual(h.energy,0);h.add_effect(GodGift(next(iter(GodGift.GODS)),3,1));p.turn_start(h);self.assertEqual(h.energy,2)
 def test_goblin_miss_once_per_turn_and_reset(self):
  h=hero('goblin');h.spend_energy(h.energy);p.attack_noted(h,False);p.attack_noted(h,False);self.assertEqual(h.energy,3);h.turn_number+=1;p.attack_noted(h,False);self.assertEqual(h.energy,6);h.reset();self.assertEqual(h._passive56,{})
 def test_real_hp_damage_required_for_ghoul_and_bleeding_troll(self):
  t=hero('warrior');h=hero('ghoul');h.hp=20;s=h.skills['attack'];p.landed(h,t,s,0);self.assertEqual(h.hp,20);p.landed(h,t,s,5);self.assertEqual(h.hp,22);p.landed(h,t,s,5);self.assertEqual(h.hp,22)
  h=hero('bluetroll');h.spend_energy(h.energy);p.landed(h,t,s,5);self.assertEqual(h.energy,0);t.add_effect(Bleed(2,3));p.landed(h,t,s,0);self.assertEqual(h.energy,0);p.landed(h,t,s,5);p.landed(h,t,s,5);self.assertEqual(h.energy,2)
 def test_gnoll_actual_victim_threshold_and_speed(self):
  h=hero('gnoll');t=hero('warrior');t.hp=t.max_hp*.35;self.assertEqual(p.crit(h,t),0);t.hp-=1;self.assertEqual(p.crit(h,t),.04)
  h=hero('aarakocra');h.hp=h.max_hp*.75;self.assertEqual(p.speed(h),0);h.hp+=1;self.assertEqual(p.speed(h),1)
 def test_paladin_once_and_preserves_existing_shield(self):
  h=hero('paladin');h.hp=20;h.add_effect(Shield(2,70));p.turn_start(h);self.assertFalse(h._passive56.get('ward_used'));h._effects=[];p.turn_start(h);self.assertTrue(h._passive56['ward_used']);self.assertEqual(next(e.power for e in h._effects if isinstance(e,Shield)),round(h.max_hp*.04));h._effects=[];p.turn_start(h);self.assertFalse(h.has_effect(Shield))
 def test_hunter_resource_only_when_changing_paid_damage_skill(self):
  h=hero('hunter');s=[x for x in h.skills.values() if isinstance(x,m.DamageSkill) and x.key!='attack' and x.cost>0];self.assertGreaterEqual(len(s),2);h.spend_energy(h.energy);p.paid(h,s[0]);self.assertEqual(h.energy,0);p.paid(h,s[1]);self.assertEqual(h.energy,2);p.paid(h,s[0]);self.assertEqual(h.energy,2);h.turn_number+=1;p.paid(h,s[1]);self.assertEqual(h.energy,4)
 def test_gambler_color_switch_only_once(self):
  h=hero('gambler');cards=[s for s in h.skills.values() if getattr(s,'COLOR',None)];self.assertGreaterEqual(len(cards),2);h.spend_energy(h.energy);h.last_card_color=cards[0].COLOR;s=next(s for s in cards if s.COLOR!=h.last_card_color);p.paid(h,s);p.paid(h,s);self.assertEqual(h.energy,2)
 def test_spider_mother_requires_live_pet(self):
  h=hero('spiderqueen');h.hp=20;p.turn_start(h);self.assertEqual(h.hp,20)
  class Pet:
   def is_alive(self):return True
  h.summon=Pet();p.turn_start(h);self.assertEqual(h.hp,22)

 def test_passives_are_connected_to_real_paid_hits_and_reset(self):
  h=hero('archer');t=hero('warrior');s=h.skills['attack'];s.pay(h);s._single_hit(h,t,force_hit=True);self.assertEqual(p.accuracy(h,s),.02);h.reset();self.assertEqual(p.accuracy(h,s),0)
  h=hero('ghoul');h.hp=20;s=h.skills['attack'];t=hero('warrior');t.add_effect(Shield(3,999));s.pay(h);s._single_hit(h,t,force_hit=True);self.assertEqual(h.hp,20);t._effects=[];s._single_hit(h,t,force_hit=True);self.assertEqual(h.hp,22)
 def test_ghoul_actual_intercept_and_antiheal(self):
  from models.summons import Bear
  from models.effects import Antiheal
  h=hero('ghoul');h.hp=20;t=hero('druid');t.summon=Bear(t);s=h.skills['attack']
  with patch.object(t,'pick_defender',return_value=t.summon):s._single_hit(h,t,force_hit=True)
  self.assertEqual(h.hp,22);self.assertEqual(t.hp,t.max_hp);self.assertLess(t.summon.hp,t.summon.max_hp)
  h.turn_number+=1;h.add_effect(Antiheal(2));s._single_hit(h,t,force_hit=True);self.assertEqual(h.hp,22)
 def test_begin_turn_hook_alive_only_and_no_reroll(self):
  h=hero('centaur');h.turn_number=2;h.spend_energy(h.energy);h.start_turn();self.assertGreaterEqual(h.energy,3);h.hp=0;h.spend_energy(h.energy);p.turn_start(h);self.assertEqual(h.energy,0)

class Games56(unittest.TestCase):
 def games(self):
  for key,sk in m.ADAPTERS:
   h=hero(key);yield h,h.skills[sk]
  for key,sk in [('bluetroll','machete_cross'),('assassin','vital_cut')]:
   h=hero(key);yield h,h.skills[sk]
 def test_all_fourteen_games_have_replayable_ideal_and_no_input_failure(self):
  target=hero('warrior');count=0
  for h,s in self.games():
   with self.subTest(s.game):
    o=s.public_options(h,target);c=winning(s,o);self.assertEqual(s.tier_from(c,o),0,c);self.assertEqual(s.tier_from({},o),len(s.TIERS)-1)
   count+=1
  self.assertEqual(count,14)
 def test_eight_mirror_templates_always_solvable_initial_not_solved(self):
  h=hero('lightelf');s=h.skills['light_pillar']
  for _ in range(160):
   o=s.public_options(h,hero('warrior'));self.assertFalse(m.beam_path(o,o['initial'])[1]);self.assertTrue(any(m.beam_path(o,b)[1] for b in itertools.product((0,1),repeat=3)))
 def test_resolver_rejects_forged_score_future_expired_and_nonfinite_inputs(self):
  for h,s in self.games():
   t=hero('warrior');o=s.public_options(h,t);c=winning(s,o);secret={'options':o,'started':time.time()-20,'deadline':time.time()+10}
   with patch.object(s,'apply',side_effect=lambda u,t,tier,data:tier):
    self.assertEqual(s.resolve(h,t,c,secret),0,s.game)
    for bad in [None,{'hits':999,'score':999,'elapsed_ms':o['time_limit_ms']},{**c,'elapsed_ms':0},{**c,'elapsed_ms':float('nan')},{**c,'points':[{'t':True,'x':1,'y':1}]}]:
     self.assertEqual(s.resolve(h,t,bad,secret),len(s.TIERS)-1,(s.game,bad))
    self.assertEqual(s.resolve(h,t,c,{**secret,'started':time.time()}),len(s.TIERS)-1)
    self.assertEqual(s.resolve(h,t,c,{**secret,'deadline':time.time()-1}),len(s.TIERS)-1)
 def test_real_clock_compression_games_remain_solvable(self):
  for h,s in self.games():
   # Complex manual vectors have physical durations; test timed mechanics that
   # explicitly scale both targets and input windows.
   if s.game in ('knife_flick_56','spirit_guide_56','soul_tether_56','shadow_erase_56','star_pattern_56'):continue
   s._time_multiplier=.7;o=s.public_options(h,hero('warrior'));c=winning(s,o);self.assertEqual(s.tier_from(c,o),0,s.game)
 def test_troll_existing_skills_and_flight_acceleration(self):
  h=hero('bluetroll');t=hero('warrior');s=h.skills['recall_cut'];self.assertIn('catch_return',h.skills);self.assertIn('twin_spin',h.skills);self.assertFalse(s.is_available(h));h.thrown_machetes=[{'turns':3}];self.assertTrue(s.is_available(h));s._perform(h,t);self.assertEqual(h.thrown_machetes[0]['turns'],2);h.thrown_machetes[0]['turns']=1;self.assertFalse(s.is_available(h))
 def test_machete_return_damage_derived_from_hand_timing_can_be_lethal(self):
  h=hero('bluetroll');s=h.skills['machete_cross'];t=hero('warrior');o=s.public_options(h,t);c=winning(s,o);self.assertEqual(m.blade_result(c,o),(0,0));c['actions']=c['actions'][:2];self.assertEqual(m.blade_result(c,o),(2,2));h.hp=1;s.apply(h,t,3,{'bad_catches':2});self.assertFalse(h.is_alive())
 def test_vital_cut_ideal_critical_and_other_tiers_restore_skill(self):
  h=hero('assassin');t=hero('warrior');s=h.skills['vital_cut'];saved=s.crit_bonus
  with patch.object(s,'strike',return_value=([],1)) as hit:
   s.apply(h,t,0,None);self.assertEqual(hit.call_args.kwargs['pierce'],.25)
  self.assertEqual(s.crit_bonus,saved)

if __name__=='__main__':unittest.main()
