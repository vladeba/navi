"""Select the runnable original suite statements; never invent historical fixtures.

The two image-history comparisons need external /workspace/hero_arena_v44_backup,
which was not supplied. All other original top-level statements and assertions
execute unchanged. This is a selected run, not an unmodified full-suite pass.
"""
import ast
import json
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
SOURCE = ROOT / 'test_api.py'
text = SOURCE.read_text()
tree = ast.parse(text, filename=str(SOURCE))
selected = []
skipped = []
for node in tree.body:
    historical = [x.value for x in ast.walk(node)
                  if isinstance(x, ast.Constant) and isinstance(x.value, str)
                  and x.value.startswith('/workspace/hero_arena_v44_backup/')]
    if historical:
        assert isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
        assert isinstance(node.value.func, ast.Name) and node.value.func.id == 'ok'
        skipped.append({'line': node.lineno, 'required_paths': historical,
                        'reason': 'historical external fixture not supplied'})
    else:
        selected.append(node)
assert len(skipped) == 2, skipped
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
os.environ.pop('COLLECT', None)
scope = {'__name__': '__main__', '__file__': str(SOURCE)}
for item in skipped:
    print('UNRUN historical comparison:', json.dumps(item, ensure_ascii=False), flush=True)
error = None
try:
    # No assertion is rewritten or forced to pass. Only runnable targets selected.
    for node in selected:
        code = compile(ast.Module(body=[node], type_ignores=[]), str(SOURCE), 'exec')
        exec(code, scope)
except BaseException as exc:
    error = f'{type(exc).__name__}: {exc}'
    traceback.print_exc()
result = {'passed_checks': scope.get('passed', 0),
          'failed_checks': scope.get('failed', []),
          'unrun_historical_comparisons': skipped,
          'error': error,
          'scope': 'selected original suite; not an unmodified full-suite pass'}
Path('available_suite_result.json').write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('FINAL_SELECTED_SUITE_RESULT', json.dumps(result, ensure_ascii=False), flush=True)
sys.exit(1 if error or result['failed_checks'] else 0)
