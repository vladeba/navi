"""Small class-specific innates; existing innate mechanics are never replaced."""
from .effects import Shield,Bleed,GodGift

NEW = {
 'archer':('Пристрелка','попадания обычной стрелой дают +2% точности следующей обычной стреле (до +6%); промах или другое действие сбрасывает серию'),
 'darkelf':('Теневой резерв','в начале своего хода при HP ниже 30% получает ещё 3 тьмы'),
 'musketeer':('Пороховой запас','перезарядка дополнительно восстанавливает 3 пороха'),
 'pagan':('Старая вера','в начале своего хода при действующем даре бога получает 2 веры'),
 'goblin':('Запасной план','первый собственный промах за свой ход возвращает 3 хитрости'),
 'ghoul':('Живучая падаль','первый удар с реальным уроном за свой ход лечит 2 HP, если собственные HP ниже 50%; запрет лечения действует'),
 'aarakocra':('Попутный ветер','скорость +1, пока собственные HP выше 75%'),
 'hunter':('Смена арсенала','другая платная атакующая способность после предыдущей возвращает 2 ресурса, не чаще раза за свой ход'),
 'gnoll':('Чутьё слабости','крит +4% по цели с HP ниже 35%'),
 'centaur':('Ритм табуна','каждый третий собственный ход дополнительно восстанавливает 3 духа'),
 'bluetroll':('Запах крови','первый удар с реальным уроном по уже кровоточащей цели за свой ход возвращает 2 ярости'),
 'paladin':('Долг хранителя','раз за бой в начале своего хода при HP ниже 35% получает щит на 4% максимальных HP на 2 хода, если другого щита нет'),
 'spiderqueen':('Мать выводка','в начале своего хода при живом паучьем призыве лечит 2 HP; запрет лечения действует'),
 'pandaren':('Тёплый хмель','в начале своего хода, пока основной противник облит брагой, получает 2 браги'),
 'gambler':('Мелкая сдача','смена цвета карты дополнительно восстанавливает 2 азарта, не чаще раза за свой ход'),
}
PRESERVED = {
 'warrior':'«Вальхалла»: раз за бой при HP ниже 30% с шансом 67% блокирует 1–2 умения врага на 2 хода; обычная атака возвращает 15 ярости',
 'samurai':'«Судьба клинка»: в начале боя получает случайную катану; свойства катаны действуют автоматически, включая легендарную Масамунэ',
 'darkknight':'«Последняя клятва»: раз за бой после прямого урона при HP ниже 25% получает несмертие на 2 хода; получение удара восстанавливает тьму',
 'rhino':'«Толстая шкура»: пока есть щит, броня +1',
 'orc':'«Кровожадность»: удары топором возвращают 8% нанесённого урона в HP, под Боевым рёвом — 18%',
 'dwarf':'«Запал»: повторные удары топором копят запал и со второго ранят дворфа; удар молотом сбрасывает запал',
 'lightelf':'«Сияние»: +10% к множителю урона, пока HP выше 70%',
 'shade':'«Ускользание»: даже точный приём мини-игры может промахнуться с шансом 75% от уклонения Тени; периодический урон сильнее на 15%; после уклонения усилен Удар из тени',
 'catfolk':'«Смена такта»: первый удар после смены формы усилен; долгое пребывание в одной форме снижает урон; свойства человеческой и кошачьей форм действуют автоматически',
 'beastlord':'«Ярость наездника»: после гибели кодоя личный урон +15%, усиливается призыв стаи; кодой не воскрешается обычным лечением',
 'ranger':'«Углубление ран»: обычная атака, стрела кровоточия и удар копьём увеличивают силу уже имеющегося кровотечения на 1',
}

def install(classes):
    for key,(title,text) in NEW.items():
        cls=classes[key]
        cls.PASSIVE_NOTES=tuple(getattr(cls,'PASSIVE_NOTES',()))+(f'«{title}»: {text}',)
    for key,text in PRESERVED.items():
        cls=classes[key];cls.PASSIVE_NOTES=tuple(getattr(cls,'PASSIVE_NOTES',()))+(text,)

def state(h):
    if not hasattr(h,'_passive56'):h._passive56={}
    return h._passive56

def reset(h):
    if h.type_key in NEW:h._passive56={}

def _restore(h,n,label):
    before=h.energy;h.restore_energy(n);got=h.energy-before
    return [f'✦ {label}: {h.name} +{got} {h.resource_name}.'] if got else []

def turn_start(h):
    k=h.type_key
    if k not in NEW or not h.is_alive():return []
    label=NEW[k][0]
    if k=='darkelf' and h.hp<h.max_hp*.3:return _restore(h,3,label)
    if k=='pagan' and h.has_effect(GodGift):return _restore(h,2,label)
    if k=='centaur' and h.turn_number%3==0:return _restore(h,3,label)
    if k=='pandaren' and getattr(getattr(h,'opponent',None),'doused_turns',0)>0:return _restore(h,2,label)
    if k=='spiderqueen' and h.summon is not None and h.summon.is_alive():
        healed=h.heal(max(1,round(2*h.power_scale())))
        return [f'🕷 {label}: {h.name} +{healed} HP.'] if healed else []
    if k=='paladin' and h.hp<h.max_hp*.35 and not h.has_effect(Shield) and not state(h).get('ward_used'):
        state(h)['ward_used']=True;p=max(1,round(h.max_hp*.04));h.add_effect(Shield(2,p))
        return [f'🛡 {label}: {h.name} получает щит {p}, один раз за бой.']
    return []

def paid(h,skill):
    k=h.type_key
    if k not in NEW:return
    s=state(h);s['action']=skill.key
    if k=='archer' and skill.key!='attack':s['precision']=0
    if k=='musketeer' and skill.key=='reload':h._events.extend(_restore(h,3,NEW[k][0]))
    if k=='hunter':
        from .skills import DamageSkill
        if isinstance(skill,DamageSkill) and skill.key!='attack' and skill.cost>0:
            previous=s.get('weapon');s['weapon']=skill.key
            if previous and previous!=skill.key and s.get('arsenal_turn')!=h.turn_number:
                s['arsenal_turn']=h.turn_number;h._events.extend(_restore(h,2,NEW[k][0]))
    if k=='gambler':
        color=getattr(skill,'COLOR',None)
        if color and getattr(h,'last_card_color',None) not in (None,color) and s.get('color_turn')!=h.turn_number:
            s['color_turn']=h.turn_number;h._events.extend(_restore(h,2,NEW[k][0]))

def attack_noted(h,hit):
    k=h.type_key
    if k=='archer':
        s=state(h)
        if s.get('action')=='attack':s['precision']=min(3,s.get('precision',0)+1) if hit else 0
    if k=='goblin' and not hit:
        s=state(h)
        if s.get('miss_turn')!=h.turn_number:s['miss_turn']=h.turn_number;h._events.extend(_restore(h,3,NEW[k][0]))

def accuracy(h,skill):
    return .02*getattr(h,'_passive56',{}).get('precision',0) if h.type_key=='archer' and skill.key=='attack' else 0

def speed(h):return 1 if h.type_key=='aarakocra' and h.hp>h.max_hp*.75 else 0

def crit(h,victim):return .04 if h.type_key=='gnoll' and victim.hp<victim.max_hp*.35 else 0

def landed(h,victim,skill,hp_lost):
    k=h.type_key
    if hp_lost<=0 or k not in ('ghoul','bluetroll') or not h.is_alive():return
    s=state(h)
    if s.get('hit_turn')==h.turn_number:return
    if k=='ghoul' and h.hp<h.max_hp*.5:
        s['hit_turn']=h.turn_number;got=h.heal(max(1,round(2*h.power_scale())))
        if got:h._events.append(f'✦ {NEW[k][0]}: {h.name} +{got} HP.')
    if k=='bluetroll' and any(isinstance(e,Bleed) for e in getattr(victim,'_effects',[])):
        s['hit_turn']=h.turn_number;h._events.extend(_restore(h,2,NEW[k][0]))
