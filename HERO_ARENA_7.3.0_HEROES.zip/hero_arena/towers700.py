"""Local column progression and endpoints. Accounts use the existing manual save."""
import uuid,random,re,copy,os
from datetime import datetime,timezone
from flask import request,jsonify
from models import HERO_CLASSES
from models.lore import NAMES
from models.tower_data import SIZES,TITLES,SPECIAL,BOSSES,GARRISONS,portrait
from models.tower_battle import TowerBattle,TowerEnemy
from models.tower_storage import save_columns

def install(app,get_service):
 def account(pid):return get_service().get_player(int(pid))
 def state(p):
  s=p.columns;s.setdefault('progress',{});s.setdefault('run',None)
  r=s.get('run')
  if r and len(r['opponents'])==SIZES[r['column']-1]-2:
   old_size=len(r['opponents']);at=next((i for i,e in enumerate(r['opponents']) if e['special']),old_size)
   used={e['key'] for e in r['opponents']}|{r['hero']};candidates=[k for k in HERO_CLASSES if k not in used];random.SystemRandom().shuffle(candidates)
   extra=[dict(key=k,special=False,name=NAMES.get(k,k),image='/images/'+k) for k in candidates[:2]]
   r['opponents'][at:at]=extra
   if r['cursor']>at:r['cursor']+=2
   r['message']='Столб расширен: добавлены два соперника. Прежние победы и жизни сохранены.'
   s['version']=2;persist(p)
  s['version']=2
  return s
 def idle():
  if any(not b.finished for b in get_service()._battles.values()):raise ValueError('Сначала завершите текущий бой')
 def run_for(p):
  r=state(p)['run']
  if not r:raise ValueError('Сначала выберите героя и столб')
  return r
 def persist(p):
  first=not os.path.exists(get_service().save_path)
  try:save_columns(get_service(),p)
  except OSError as e:raise ValueError('Не удалось сохранить прогресс столбов. Проверьте доступ к папке data.') from e
  if first:
   storage=app.extensions.get('storage606',{});storage['dirty']=False;storage['last_saved']=datetime.now(timezone.utc).isoformat()
 def choose(p,r,key,skin=None):
  if key not in HERO_CLASSES:raise ValueError('Выберите канонического героя')
  if r['column']==5 and not all(i in state(p)['progress'].get(key,[]) for i in (1,2,3,4)):
   raise ValueError('Для пятого столба этот герой должен пройти первые четыре')
  if skin and not p.owns_skin(key,skin):raise ValueError('Этот облик не куплен')
  # A newly selected hero must never face their own duplicate.
  used={e['key'] for e in r['opponents']}
  for e in r['opponents'][r['cursor']-1:]:
   if not e['special'] and e['key']==key:
    replacement=next(k for k in HERO_CLASSES if k!=key and k not in used)
    used.add(replacement);e.update(key=replacement,name=NAMES.get(replacement,replacement),image='/images/'+replacement)
  r.update(hero=key,name=NAMES.get(key,key),skin=skin)
 def public(p):
  s=state(p);r=s.get('run');progress=s['progress']
  return dict(player_id=p.id,heroes=[dict(key=k,name=NAMES.get(k,k),image='/images/'+k,completed=progress.get(k,[]),fifth_unlocked=all(i in progress.get(k,[]) for i in (1,2,3,4)),skins=[x.split(':',1)[1] for x in p.owned_skins if x.startswith(k+':')],skin_names={s['skin']:s['name'] for s in get_service().skin_catalog(k) if p.owns_skin(k,s['skin'])}) for k in HERO_CLASSES],
   columns=[dict(number=i+1,size=n,title=TITLES[i]) for i,n in enumerate(SIZES)],garrisons=GARRISONS,run=r,stories_deferred=True)
 def settle(b):
  if not b.finished or b.result_applied:return
  p=account(b.player_id);r=run_for(p)
  if r['id']!=b.run_id:raise ValueError('Забег уже сменился')
  previous=copy.deepcopy(p.columns)
  b.result_applied=True;r['battle_id']=None
  if b.winner is b.hero1:
   r['cursor']+=1;r['checkpoint']=0;r['status']='ready';r['message']='Противник повержен. Перед следующим боем HP и ресурс восстановятся.'
   if r['cursor']>SIZES[r['column']-1]:
    done=state(p)['progress'].setdefault(b.hero1.type_key,[])
    if r['column'] not in done:done.append(r['column']);done.sort()
    r['status']='won';r['message']='Столб пройден! Победа засчитана: '+b.hero1.name+'. Прогресс сохранён в аккаунте.'
  else:
   r['lives']-=1;r['checkpoint']=b.phase_checkpoint;r['status']='ready';r['message']='Поражение. Можно повторить бой с тем же противником.'
   if r['lives']==0:
    column=r['column'];r['checkpoint']=0
    if column<=2:r['cursor']=1;r['lives']=5;r['message']='Жизни закончились. Возврат на первый бой с 5 жизнями.'
    elif column==3:r['cursor']=max(1,r['cursor']-3);r['lives']=5;r['message']='Жизни закончились. Возврат на 3 ступени назад с 5 жизнями.'
    else:
     r['life_cap']-=1
     if r['life_cap']==0:r['status']='lost';r['message']='Вы проиграли. Новый забег начинается с первого боя.'
     else:
      back=3 if column==4 else 5;r['cursor']=max(1,r['cursor']-back);r['lives']=r['life_cap'];r['message']=f'Откат на {back} ступеней. Новый запас жизней: {r["lives"]}.'
  try:persist(p)
  except Exception:
   p.columns=previous;b.result_applied=False;raise
 def battle_for(bid,pid):
  b=get_service().get_battle(bid)
  if not isinstance(b,TowerBattle) or b.player_id!=int(pid):raise PermissionError('Выберите аккаунт этого забега')
  r=run_for(account(pid))
  if r['id']!=b.run_id:raise ValueError('Этот бой относится к завершённому забегу')
  return b
 def response(b):
  b.run_ai();settle(b);p=account(b.player_id);r=run_for(p)
  if not b.finished and b.phase_checkpoint!=r.get('checkpoint',0):r['checkpoint']=b.phase_checkpoint;persist(p)
  d=b.to_dict();d['tower_run']=r;return jsonify(d)
 @app.get('/api/towers')
 def columns_get():
  pid=request.args.get('player_id')
  if not pid:raise ValueError('Создайте или загрузите аккаунт')
  return jsonify(public(account(pid)))
 @app.post('/api/towers/start')
 def columns_start():
  idle();d=request.get_json() or {};p=account(d.get('player_id',0));key=d.get('hero');column=d.get('column')
  if key not in HERO_CLASSES or type(column) is not int or not 1<=column<=5:raise ValueError('Выберите канонического героя и столб')
  if column==5 and not all(i in state(p)['progress'].get(key,[]) for i in (1,2,3,4)):raise ValueError('Для пятого столба пройдите первые четыре этим героем')
  skin=d.get('skin')
  if skin and not p.owns_skin(key,skin):raise ValueError('Этот облик не куплен')
  ordinary=[k for k in HERO_CLASSES if k!=key];random.SystemRandom().shuffle(ordinary);opponents=[]
  for step in range(1,SIZES[column-1]+1):
   special=SPECIAL[column].get(step)
   opponents.append(dict(key=special or ordinary.pop(),special=bool(special),name=BOSSES[special]['name'] if special else ''))
  for entry in opponents:
   if not entry['special']:entry['name']=NAMES.get(entry['key'],entry['key'])
   entry['image']=portrait(entry['key']) if entry['special'] and entry['key']!='gnuss' else '/static/images/story/gnuss.jpg' if entry['key']=='gnuss' else '/images/'+entry['key']
  r=dict(id=uuid.uuid4().hex,player_id=p.id,hero=key,name=NAMES.get(key,key),skin=skin,column=column,opponents=opponents,cursor=1,lives=7 if column==5 else 5,life_cap=7 if column==5 else 5,checkpoint=0,status='ready',battle_id=None,message='Выберите поддержку перед встречей с боссом.')
  state(p)['run']=r;persist(p);return jsonify(public(p))
 @app.post('/api/towers/hero')
 def columns_hero():
  idle();d=request.get_json() or {};p=account(d.get('player_id',0));r=run_for(p)
  if r['status']!='ready':raise ValueError('Менять героя можно между боями')
  choose(p,r,d.get('hero'),d.get('skin'));persist(p);return jsonify(public(p))
 @app.post('/api/towers/fight')
 def columns_fight():
  idle();d=request.get_json() or {};p=account(d.get('player_id',0));r=run_for(p)
  if r['status'] not in ('ready','active'):raise ValueError('Этот забег завершён')
  choose(p,r,d.get('hero',r['hero']),d.get('skin',r.get('skin')))
  step=r['cursor']
  if not 1<=step<=len(r['opponents']):raise ValueError('Все ступени уже пройдены')
  entry=r['opponents'][step-1];foe=TowerEnemy(entry['key']) if entry['special'] else HERO_CLASSES[entry['key']](entry['name'])
  is_boss=entry['special'] and not BOSSES[entry['key']].get('minor')
  g=d.get('garrison',r.get('garrison'))
  if is_boss and g not in GARRISONS:raise ValueError('Выберите гарнизон')
  if is_boss:r['garrison']=g
  persist(p)
  h=HERO_CLASSES[r['hero']](r['name']);h.owner_id=p.id;h.skin=r.get('skin');h.test_ephemeral=True
  b=TowerBattle(h,foe,r,step,g,r.get('checkpoint',0));get_service()._battles[b.id]=b;r['battle_id']=b.id;r['status']='active'
  b.start();return response(b)
 @app.get('/api/towers/battles/<int:bid>')
 def columns_battle_get(bid):return response(battle_for(bid,request.args.get('player_id',0)))
 @app.post('/api/towers/battles/<int:bid>/<action>')
 def columns_action(bid,action):
  d=request.get_json() or {};b=battle_for(bid,d.get('player_id',0))
  if action=='turn':
   if b.current is not b.hero1:raise ValueError('Сейчас не ход игрока')
   b.play_turn(d.get('skill'),d.get('target_id'))
  elif action=='react':b.react(d.get('choice'))
  elif action=='scene':b.resume_scene(d.get('scene_id'))
  elif action=='counter':b.counter(d.get('skill'))
  elif action=='kill':
   if not account(b.player_id).dev_mode:raise PermissionError('«Убить» доступно только в режиме разработчика')
   if b.finished:raise ValueError('Бой уже завершён')
   b.pending=None;b.scene=None;b.hero2.hp=0;b._check_end()
  elif action in ('surrender','cancel'):
   if b.finished:raise ValueError('Бой уже завершён')
   b._finish(b.hero2)
  else:raise ValueError('Неизвестное действие столбов')
  return response(b)
 @app.post('/api/towers/leave')
 def columns_leave():
  idle();p=account((request.get_json() or {}).get('player_id',0));r=run_for(p)
  r['status']='abandoned';r['battle_id']=None;persist(p);return jsonify(public(p))
 @app.before_request
 def tower_guard():
  match=re.fullmatch(r'/api/battles/(\d+)/(\w+)',request.path)
  if match:
   b=get_service()._battles.get(int(match.group(1)))
   if isinstance(b,TowerBattle) and match.group(2)!='begin':raise ValueError('Управление этим боем доступно в режиме столбов')
  if request.path=='/api/battles' and request.method=='POST' and any(isinstance(b,TowerBattle) and not b.finished for b in get_service()._battles.values()):raise ValueError('Сначала завершите бой столба')
