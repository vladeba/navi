/* Boss arenas use replayed mouse/keyboard input; hitboxes match the drawings. */
(function(){'use strict';
const {setup,circle,line,text}=arenaMiniUI;
let audio=null,soundEnabled=localStorage.getItem('towerSound700')!=='0';
function sound(freq=600,duration=.065){if(!soundEnabled)return;try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();if(audio.state!=='running')return;const tone=audio.createOscillator(),gain=audio.createGain();tone.frequency.value=freq;gain.gain.setValueAtTime(.035,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);tone.connect(gain);gain.connect(audio.destination);tone.start();tone.stop(audio.currentTime+duration)}catch{}}
document.addEventListener('pointerdown',e=>{if(!e.target.closest('#towers,.tower-mini'))return;try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();audio.resume().catch(()=>{})}catch{}},{passive:true});
MINIGAMES.tower700=(o,head)=>{
 const field=['field','heart'].includes(o.mode),heart=o.mode==='heart',weak=o.mode==='weak';
 const help=weak?'Дождитесь зелёного кольца и нажмите по движущейся метке. Три независимые попытки.':heart?'Оставайтесь внутри движущегося зелёного круга. Мышь или WASD/стрелки.':field?'Двигайтесь мышью или WASD/стрелками. Покиньте круг до его взрыва.':o.mode==='lanes'?'Уходите в подсвеченную безопасную полосу: 1/2/3 или ←/↓/→.':'Нажмите нужную кнопку, когда кольцо станет золотым. Клавиши 1/2/3.';
 const actions=field||weak?'':[0,1,2].map(i=>`<button class="btn tower-key" id="towerKey${i}">${i+1}</button>`).join('');
 const r=setup(o,head,help,actions);r.svg.closest('.ritual55').classList.add('tower-mini');r.svg.style.backgroundImage=`linear-gradient(#111722bb,#151b27b8),url("${o.background}")`;
 const host=r.svg.closest('.ritual55');host.style.position='relative';const mute=document.createElement('button');mute.className='btn small ghost';mute.style.cssText='position:absolute;right:8px;top:8px;z-index:3;min-height:26px;padding:3px 7px';mute.title='Звуковые сигналы испытаний';mute.setAttribute('aria-label','Включить или выключить звуковые сигналы');mute.textContent=soundEnabled?'♪':'♪ ×';mute.onclick=()=>{soundEnabled=!soundEnabled;localStorage.setItem('towerSound700',soundEnabled?'1':'0');mute.textContent=soundEnabled?'♪':'♪ ×'};host.append(mute);const sounded=new Set();
 r.state.actions=[];let hits=0,resolved=new Set(),feedback='',feedbackAt=-500;const pressed=new Set();
 const mark=(t,i)=>{const n=o.beats[i],q=(t-n.ms)/850;return[180+85*Math.sin(q+o.phase+i),125+45*Math.sin(q*.7+i)]};
 function active(t){return o.beats.findIndex((n,i)=>!resolved.has(i)&&t>=n.ms-o.warning&&t<=n.ms+o.window)}
 function action(lane){if(r.session.done)return;const t=r.elapsed();if(t<o.prepare_ms)return;r.state.actions.push({ms:t,lane});const i=active(t);if(i<0)return;const n=o.beats[i],early=n.kind==='lanes'?o.warning:o.window,good=n.lane===lane&&t>=n.ms-early&&t<=n.ms+o.window;if(good){resolved.add(i);hits++;feedback='Уклонение!'}else feedback='Мимо';feedbackAt=t;}
 if(!field&&!weak){
  for(let i=0;i<3;i++)document.getElementById('towerKey'+i).onpointerdown=e=>{e.preventDefault();action(i)};
  const keys=e=>{if(e.repeat||r.session.done)return;const lane={Digit1:0,Digit2:1,Digit3:2,Numpad1:0,Numpad2:1,Numpad3:2,ArrowLeft:0,ArrowDown:1,ArrowRight:2}[e.code];if(lane!==undefined){e.preventDefault();action(lane)}};document.onkeydown=keys;r.session.keydown=keys;
  r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e);if(p.y>60)action(Math.max(0,Math.min(2,Math.floor(p.x/120))))};
 }
 if(weak){r.svg.onpointerdown=e=>{e.preventDefault();const t=r.elapsed(),p=r.pos(e),i=active(t);if(i<0)return;const n=o.beats[i],pos=mark(t,i);r.state.actions.push({ms:t,x:p.x,y:p.y});const good=Math.abs(t-n.ms)<=o.window&&Math.hypot(p.x-pos[0],p.y-pos[1])<=o.radius;resolved.add(i);if(good)hits++;feedback=good?'Попадание!':'Промах';feedbackAt=t;if(resolved.size===o.beats.length)r.session.timers.push(setTimeout(r.finish,140));};}
 if(field){
  r.setCursor({x:180,y:225});r.svg.onpointermove=e=>r.setCursor(r.pos(e));r.svg.onpointerdown=e=>{e.preventDefault();r.setCursor(r.pos(e))};
  const key=e=>{if(r.session.done)return;if(['KeyW','KeyA','KeyS','KeyD','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code)){e.preventDefault();pressed.add(e.code)}};document.onkeydown=key;r.session.keydown=key;document.onkeyup=e=>pressed.delete(e.code);window.onblur=()=>pressed.clear();
 }
 let last=0;
 r.animate(t=>{
  let out='';const i=active(t),n=i>=0?o.beats[i]:null;
  if(t<o.prepare_ms){r.svg.innerHTML=text(180,130,'ПРИГОТОВЬТЕСЬ',24);r.status(help);last=t;return;}
  for(let j=0;j<o.beats.length;j++)if(!sounded.has(j)&&t>=o.beats[j].ms-(field?400:120)){sounded.add(j);sound(field?280:440+o.beats[j].lane*140)}
  if(field){
   const dt=Math.max(0,Math.min(40,t-last)),p={...r.cursor},speed=.22*dt;
   if(pressed.has('KeyA')||pressed.has('ArrowLeft'))p.x-=speed;if(pressed.has('KeyD')||pressed.has('ArrowRight'))p.x+=speed;if(pressed.has('KeyW')||pressed.has('ArrowUp'))p.y-=speed;if(pressed.has('KeyS')||pressed.has('ArrowDown'))p.y+=speed;
   p.x=Math.max(12,Math.min(348,p.x));p.y=Math.max(38,Math.min(248,p.y));r.setCursor(p);
   out=`<rect x="8" y="35" width="344" height="216" rx="12" fill="#0a132244" stroke="#b6a17c"/>`;
   const lastPoint=r.state.points.at(-1),sample={t,x:p.x,y:p.y};if(lastPoint?.t===t)r.state.points[r.state.points.length-1]=sample;else r.state.points.push(sample);
   if(heart){const x=180+100*Math.sin(t/2300),y=145+55*Math.sin(t/1700);out+=circle(x,y,64,'#78a37b55','#c2e7b2',3)+text(180,25,'ДЕРЖИТЕСЬ ВНУТРИ БЕЗОПАСНОЙ ОБЛАСТИ',12);for(let j=0;j<o.beats.length;j++)if(t>=o.beats[j].ms&&!resolved.has(j)){resolved.add(j);const ms=o.beats[j].ms,good=Math.hypot(p.x-(180+100*Math.sin(ms/2300)),p.y-(145+55*Math.sin(ms/1700)))<=55;if(good)hits++;feedback=good?'В безопасной области':'Удар Разлома';feedbackAt=t;}}
   else for(let j=0;j<o.hazards.length;j++){const h=o.hazards[j],delta=h.ms-t;if(delta>o.warning||delta< -240)continue;const blast=delta<=0;out+=circle(h.x,h.y,h.r,blast?'#dc5934aa':'#d88d3733',blast?'#ffad72':'#f7d398')+circle(h.x,h.y,Math.max(5,h.r*Math.max(0,delta/o.warning)),'none','#ffe2b8',2);if(blast&&!resolved.has(j)){resolved.add(j);const good=Math.hypot(p.x-h.x,p.y-h.y)>h.r+9;if(good)hits++;feedback=good?'Ушли от огня':'Попадание огня';feedbackAt=t;}}
   out+=circle(p.x,p.y,9,'#a6d8ce','#f6efc4',2)+text(p.x,p.y+4,'◆',10,'#173943');
  }else if(weak){
   out+=text(180,30,'УДАРЬТЕ ПО ОТКРЫВШЕЙСЯ МЕТКЕ',13);
   if(n){const pos=mark(t,i),good=Math.abs(t-n.ms)<=o.window,approach=Math.max(0,Math.min(1,(n.ms-t)/o.warning));out+=circle(...pos,o.radius,good?'#749b55':'#5a3a37',good?'#d6ef98':'#e7b281',3)+circle(...pos,o.radius+35*approach,'none',good?'#def3a6':'#d6ac7c',3)+text(pos[0],pos[1]+9,'✦',27);}
  }else{
   const kind=n?.kind||o.mode,labels=kind==='stance'?['Нырок','Шаг','Прыжок']:kind==='lanes'?['Влево','Укрытие','Вправо']:['I','II','III'];
   for(let j=0;j<3;j++){const safe=n&&n.lane===j,good=n&&Math.abs(t-n.ms)<=o.window;
    if(kind==='lanes'){out+=`<rect x="${12+j*116}" y="58" width="104" height="175" rx="10" fill="${safe?'#6b956355':'#833b3655'}" stroke="${safe?'#d6ec9b':'#a36e64'}" stroke-width="2"/>`+text(64+j*116,140,safe?'↓':'⚠',34,safe?'#e6efbd':'#e5a08b')+text(64+j*116,211,j+1,20);}
    else{if(o.mode==='portals')out+=`<path d="M${34+j*110} 200V110Q${70+j*110} 62 ${106+j*110} 110V200Z" fill="#32293eaa" stroke="${safe?'#edb575':'#777384'}" stroke-width="3"/>`;out+=circle(70+j*110,143,36,safe&&good?'#8ba365':'#293340',safe?'#eccf8d':'#788397',2)+text(70+j*110,150,kind==='stance'?['↓','↔','↑'][j]:j+1,25);if(safe){const q=Math.max(0,Math.min(1,(n.ms-t)/o.warning));out+=circle(70+j*110,143,36+28*q,'none',good?'#e9f8b3':'#e8b47b',3)}}
    const b=document.getElementById('towerKey'+j);if(b)b.textContent=(j+1)+' · '+labels[j];
   }
   const title=o.mode==='portals'?(i===o.beats.length-1?'НАПРАВЬТЕ ПОСЛЕДНЮЮ ВОЛНУ В ПЕЧАТЬ':'ПРОЙДИТЕ ЧЕРЕЗ ОТКРЫТЫЕ ВРАТА'):o.mode==='trial'?(kind==='lanes'?'I · ОБХОД УДАРОВ':kind==='timing'?'II · ТОЧНАЯ РЕАКЦИЯ':'III · СМЕШАННАЯ СЕРИЯ'):kind==='lanes'?'ВЫБЕРИТЕ БЕЗОПАСНУЮ ПОЛОСУ':kind==='stance'?'ПРОЧИТАЙТЕ ДВИЖЕНИЕ ПРОТИВНИКА':'НАЖМИТЕ ПРИ ЗОЛОТОМ КОЛЬЦЕ';out+=text(180,30,title,12);
  }
  last=t;r.svg.innerHTML=out;const message=t-feedbackAt<500?feedback:weak?'Дождитесь зелёного кольца':field?'Двигайтесь — круги показывают место взрыва':n?'Следите за предупреждением':'Приготовьтесь к следующему удару';r.status(`${weak?'Попадания':'Уклонения'}: ${hits}/${o.beats.length} · ${message}`);
  if(t>o.beats.at(-1).ms+o.window+200)r.finish();
 });
};
})();
