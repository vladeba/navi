"""Server-scored physical inputs for column bosses and bonus openings."""
import math,random
from .skills import MiniGameSkill
from .minigames_56 import Replay,events,trace,at,near,number
from .effects import Shield
from .tower_data import BOSSES,background

def offensive(s):return bool(getattr(s,'deals_damage',hasattr(s,'multiplier')))
def pure_damage(victim,amount,attacker=None):
 before=victim.hp;victim.hp-=max(0,round(amount));actual=before-victim.hp
 if hasattr(victim,'_stats605'):victim._stats605['taken']+=actual
 if attacker is not None and hasattr(attacker,'_stats605'):attacker._stats605['damage']+=actual
 return actual
def moving_mark(o,t,i):
 n=o['beats'][i];q=(t-n['ms'])/850
 return (180+85*math.sin(q+o['phase']+i),125+45*math.sin(q*.7+i))
def safe_heart(t):return (180+100*math.sin(t/2300),145+55*math.sin(t/1700))

class TowerGame(Replay,MiniGameSkill):
 game='tower700';reactor='target';copyable=False;deals_damage=True;hero_target=True
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(25,43,25,7)
 def __init__(self,key,name,spec,boss_key,bonus=None):
  self.spec=spec;self.boss_key=boss_key;self.bonus=bonus;self.TIME_LIMIT_MS=spec['seconds']*1000
  if bonus:self.reactor='user'
  self.prompt='Следите за предупреждениями. 1/2/3 — уклонения; в поле огня перемещайтесь мышью или WASD.'
  super().__init__(key,name,self.prompt,icon='🔥' if not bonus else '🎯',cooldown=0)
 def game_params(self,u,t):
  spec=self.spec;mode=spec['mode'];count=spec['count'];limit=self.TIME_LIMIT_MS;prep=700
  step=(limit-prep-600)/max(1,count);beats=[]
  for i in range(count):
   kind=mode
   if mode=='trial':kind=('lanes' if i<count//3 else 'timing' if i<count*2//3 else 'stance')
   beats.append(dict(ms=round(prep+step*(i+1)),lane=random.randrange(3),kind=kind))
  hazards=[dict(ms=b['ms'],x=random.randrange(50,311),y=random.randrange(70,221),r=random.randrange(42,64)) for b in beats]
  arena=BOSSES[self.boss_key]['arena']
  b=getattr(u,'_battle',None)
  if b and hasattr(b,'arena_key'):arena=b.arena_key
  return dict(mode=mode,prepare_ms=prep,beats=beats,hazards=hazards,window=260 if self.boss_key in ('euron','zaferon') else 220,warning=850,
   radius=30,phase=random.random()*6.28,background=background(arena),hero_type=getattr(u,'type_key',''),instruction=self.prompt,boss_key=self.boss_key)
 def count_hits(self,c,o):
  mode=o['mode'];beats=o['beats'];actions=events(c,'actions',o,100)
  if mode in ('field','heart'):
   path=trace(c,o)
   if len(path)<3:return 0
   if mode=='heart':return sum(b['ms']<=c.get('elapsed_ms',0) and math.dist(at(path,b['ms']),safe_heart(b['ms']))<=55 for b in beats)
   return sum(h['ms']<=c.get('elapsed_ms',0) and math.dist(at(path,h['ms']),(h['x'],h['y']))>h['r']+9 for h in o['hazards'])
  hits=0;used=set()
  for i,b in enumerate(beats):
   for j,a in enumerate(actions):
    if j in used:continue
    if mode=='weak':
     if not b['ms']-o['warning']<=a['ms']<=b['ms']+o['window']:continue
     good=abs(a['ms']-b['ms'])<=o['window'] and near((number(a.get('x')),number(a.get('y'))),moving_mark(o,a['ms'],i),o['radius'])
     used.add(j)
     if good:hits+=1
     break
    else:
     window=o['warning'] if b['kind']=='lanes' else o['window']
     good=a.get('lane')==b['lane'] and b['ms']-window<=a['ms']<=b['ms']+o['window']
    if good:used.add(j);hits+=1;break
  # Flooding buttons must not outperform reading the cues.
  if mode!='weak':hits=max(0,hits-max(0,len(actions)-len(beats)-2))
  return hits
 def to_dict(self,u=None):
  d=super().to_dict(u);stars=5 if self.spec['seconds']>=12 else 3 if self.boss_key in ('euron','deyron_knight') or self.bonus else 4
  d.update(difficulty=stars,difficulty_label='Сложность: '+'★'*stars+'☆'*(5-stars)+f' ({stars}/5)');return d
 def tier_from(self,c,o):
  n=self.count_hits(c,o);total=len(o['beats']);return 0 if n>=total*.9 else 1 if n>=total*.65 else 2 if n else 3
 def result_data(self,c,o):return dict(hits=self.count_hits(c,o),total=len(o['beats']))
 def apply(self,u,t,tier,data):
  total=self.spec['count'];hits=(data or {}).get('hits',round(total*(1,.75,.35,0)[tier]));total=(data or {}).get('total',total)
  if self.bonus:
   self._defender=u
   if self.bonus=='fallback':
    value=pure_damage(t,t.max_hp*(.10,.06,.03,0)[tier],u);return [f'🎯 Контрудар: {value} урона по {t.name}.']
   rates=(.10,.06,.03,0) if self.bonus=='euron' else (.12,.08,.04,0)
   # Exactly three marks for Zaferon, independent attempts with partial reward.
   if self.bonus=='zaferon':rate=.04*hits
   else:rate=rates[tier]
   value=pure_damage(t,t.max_hp*rate,u)
   return [f'🎯 {u.name}: попадания {hits}/{total}; {value} урона по {t.name}.']
  self._defender=t
  failed=max(0,total-hits);raw=round(self.spec['power']*failed/max(1,total)*(1-.35*t.get_dodge())*(1+u.fatigue))
  value=t.take_damage(raw,attacker=u) if raw else 0
  b=getattr(u,'_battle',None)
  lines=[f'🔥 {self.name}: уклонения {hits}/{total}; {value} урона по {t.name}.']+t.pop_events()
  if b and hasattr(b,'defense_result'):lines+=b.defense_result(self,tier,hits,total)
  return lines
 def result_logs(self,u,tier,logs,timed_out=False):
  return super().result_logs(getattr(self,'_defender',u),tier,logs,timed_out)
 def _perform(self,u,t):
  player=u if self.bonus else t
  tier=0 if getattr(player,'perfect',False) else random.choices(range(4),self.AI_WEIGHTS)[0]
  return self.apply(u,t,tier,None)

class KnightGame(TowerGame):
 reactor='user'
 def apply(self,u,t,tier,data):
  self._defender=u
  if self.key=='knight_ward':
   power=round(u.max_hp*(.12,.10,.06,0)[tier]);u.add_effect(Shield(3,power))
   return [f'🛡 Дейрон укрепляет доспех: щит {power}.']
  raw=round(u.get_damage()*(2.1,1.7,1.1,0)[tier]);damage=t.take_damage(raw,attacker=u) if raw else 0
  return [f'⚔ {self.name}: {damage} урона по {t.name}.']+t.pop_events()
 def _perform(self,u,t):
  tier=0 if getattr(u,'perfect',False) else random.choices(range(4),self.AI_WEIGHTS)[0]
  return self.apply(u,t,tier,None)

class CounterGame(MiniGameSkill):
 """Reuse the hero's actual minigame without paying or changing its cooldown."""
 reactor='user';copyable=False
 def __init__(self,original):
  self.original=original;self.game=original.game;self.TIME_LIMIT_MS=original.TIME_LIMIT_MS;self.prompt=original.prompt
  super().__init__('tower_counter',original.name,'Бесплатное пробитие: выполните свою мини-игру.',icon='🎯')
 def public_options(self,u=None,t=None):return self.original.public_options(u,t)
 def secret_pick(self,o=None):return self.original.secret_pick(o)
 def check_choice(self,c):return self.original.check_choice(c)
 def resolve(self,u,t,c,secret):
  cooldown=u._cooldowns.get(self.original.key);logs=self.original.resolve(u,t,c,secret)
  if cooldown is None:u._cooldowns.pop(self.original.key,None)
  else:u._cooldowns[self.original.key]=cooldown
  latest=getattr(u,'_last_minigame605',{});tier=latest.get('tier');tier=3 if tier is None else tier
  extra=pure_damage(t,t.max_hp*(.10,.06,.03,0)[min(3,tier)],u)
  return list(logs)+[f'🎯 Пробитие защиты Гнусса: дополнительно {extra} урона.']
