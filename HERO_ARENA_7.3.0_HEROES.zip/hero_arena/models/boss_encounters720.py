"""Boss-specific playable encounters and stage direction."""
import random

def episode(name,mode,seconds,count,power,variant=0):
 return dict(name=name,mode=mode,seconds=seconds,count=count,power=power,variant=variant)
EPISODES={
'euron':[episode('Под лезвием чемпиона','halberd',16,14,74),episode('Разорвать кровавые цепи','chains',18,17,82)],
'zaferon':[episode('Осколки запретной печати','seal_hunt',19,20,88),episode('Память древних знаков','seal_memory',20,20,88),episode('Орбиты опустошения','seal_orbit',20,23,94),episode('Удержать связывающую печать','seal_binding',20,21,92),episode('Путь через запретные врата','seal_path',20,22,94),episode('Отразить копьё Опустошителя','seal_rebound',18,16,96)],
'deyron_knight':[episode('Скрестить клинки','sword_duel',15,12,62),episode('Руны проклятого клинка','blade_runes',16,15,65),episode('Клятва рыцаря','knight_guard',16,15,62)],
'deyron_demon':[episode('Рука, разрывающая мир','demon_hand',19,24,108)],
'succubus':[episode('Танец настоящей тени','mirror_dance',20,22,110)],
'garrarat':[episode('Арена расколота','fracture',22,25,125),episode('Орбита демонической секиры','axe_orbit',20,24,120),episode('Обломки мироздания','meteor_cover',23,24,128),episode('Гравитация бездны','gravity',22,24,124)],
'tassirion':[episode('Пробить строй легиона','formation',21,24,116),episode('Сжечь знамёна Преисподней','war_banners',23,24,120),episode('Осада военачальника','command_volley',22,24,124)],
'gnuss':[episode('Столбы пламени','fire_columns',19,21,102),episode('Ливень огненных шаров','ember_rain',20,25,108),episode('Кольца огненной пасти','fire_rings',20,20,108),episode('Мост над лавой','lava_bridge',22,22,112)],
'gnuss_true':[episode('Бег сквозь Преисподнюю','inferno_run',23,30,142),episode('Обрушение лавовых плит','eruption',24,27,146),episode('Сердце раскалённой печи','furnace',23,26,142),episode('Буря истинного демона','firestorm',24,28,148),episode('Последнее извержение','volcano_final',25,30,154)],
'gorr_gall':[episode('Раскол престолов','throne_blade',22,26,140),episode('Бег по краю Разлома','rift_run',22,26,144),episode('Легион последнего владыки','siege_legion',24,28,150),episode('Замкнуть демонические врата','portal_weave',24,28,154),episode('Мир уходит из-под ног','collapse',26,32,160),episode('Последний приговор','last_judgement',30,36,182)]}
MODE_RULES={
'halberd':('runner','Перепрыгивайте низкие взмахи, пригибайтесь под высокими, уходите от удара сверху.'),
'chains':('chains','Подойдите к трём цепям и удерживайте E, чтобы порвать их. Уходите из-под ударов.'),
'seal_hunt':('collect','Соберите шесть осколков одной печати на площадке, избегая копий и импульсов опустошения.'),
'seal_memory':('sequence','Руны вспыхивают по порядку. Подойдите к нужной и нажмите E; неверный знак обжигает.'),
'seal_orbit':('orbit','Собирайте осколки между вращающимися лучами. Перепрыгивайте ударные кольца.'),
'seal_binding':('capture','Удерживайте E у трёх узлов связывающей печати, прерываясь для уклонений.'),
'seal_path':('portals','Пройдите три портала печати по порядку. Подходите к вратам и нажимайте E, обходя лучи.'),
'seal_rebound':('duel','Подойдите к Опустошителю и отражайте копьё клавишей E на золотой вспышке. Тяжёлые удары требуют рывка.'),
'core_strike':('strike','Три выстрела в открывающееся слабое место. Нажимайте с упреждением: снаряд летит 0,22 секунды. Мышь/касание — выстрел; WASD — прицел, E — выстрел.'),
'seal_forge':('forge','Нажимайте на кольца печати, чтобы совместить светлые разрывы наверху. E — разбить собранную печать.'),
'sword_duel':('duel','Подходите для парирования: E на золотой вспышке. Уходите от тяжёлого рубящего удара.'),
'blade_runes':('sequence','Разбейте руны в указанном порядке клавишей E. Рыцарь отсекает путь клинком.'),
'knight_guard':('capture','Удерживайте E у трёх знаков клятвы. Прерывайтесь, чтобы уйти из-под меча.'),
'demon_hand':('hand','Уходите от ладони, перепрыгивайте взмахи. При захвате быстро чередуйте A и D. E — удар по открытой руке.'),
'mirror_dance':('mirror','Настоящая суккуб отбрасывает тень. Подойдите к ней и нажмите E на золотой вспышке; не атакуйте отражения.'),
'fracture':('platform','Пол трескается и проваливается. Уходите на целые плиты; перепрыгивайте ударную волну.'),
'axe_orbit':('orbit','Секира вращается вокруг Гаррарата. Меняйте дистанцию и собирайте три якоря; низкие волны можно перепрыгнуть.'),
'meteor_cover':('cover','Перед обрушением спрячьтесь у подсвеченного каменного укрытия. Укрытия подсвечиваются перед каждым залпом.'),
'gravity':('gravity','Бездонный провал тянет внутрь. Удерживайте E у якорей по краям, сопротивляйтесь притяжению.'),
'formation':('formation','Пробирайтесь сквозь разрывы движущегося строя и разрушьте три командных знака клавишей E.'),
'war_banners':('capture','Подойдите к трём знамёнам и удерживайте E, чтобы сжечь их. Стойка делает вас уязвимым для залпа.'),
'command_volley':('cover','Отряды готовят залп. Добегите до отмеченной баррикады прежде, чем полетят копья.'),
'fire_columns':('runner','Земля светится перед выбросом пламени. Уходите от столбов, перепрыгивайте низкие огненные волны.'),
'ember_rain':('rain','Следите за тенями огненных шаров и меняйте направление. Соберите охлаждающие искры.'),
'fire_rings':('rings','Ударные кольца расширяются от Гнусса. Прыгайте, когда кольцо пересекает ваши ноги.'),
'lava_bridge':('platform','Прыжками пересекайте рушащийся лавовый мост и доберитесь до трёх холодных знаков.'),
'inferno_run':('runner','Столбы, низкие волны и высокие огненные шары идут вместе. Бегите, прыгайте, пригибайтесь.'),
'eruption':('platform','Лавовые плиты исчезают одна за другой. Меняйте островки и прыгайте через трещины.'),
'furnace':('heat','Жар нарастает. Подойдите к холодному клапану и удерживайте E, чтобы охладиться; избегайте выбросов.'),
'firestorm':('cover','Ветер сносит к огню. Укройтесь от метеоров у подсвеченных скал; ищите следующую подсвеченную скалу.'),
'volcano_final':('collect','Соберите три ледяных ядра среди извержения, затем удержите позицию до конца атаки.'),
'throne_blade':('duel','Отражайте удары Раскола престолов клавишей E на золотой вспышке. От тяжёлого замаха уходите рывком.'),
'rift_run':('portals','Доберитесь до светящихся врат и нажмите E для перехода. Не стойте в лучах Разлома.'),
'siege_legion':('legion','Уничтожьте трёх демонов клавишей E рядом с ними, уклоняясь от клинков и огня.'),
'portal_weave':('portals','Замкните три портала по указанному порядку клавишей E; волны владыки преследуют героя.'),
'collapse':('haven','Держитесь на движущемся островке над бездной. Прыгайте через расходящиеся кольца.'),
'last_judgement':('final','Три акта: уничтожьте стражей, переживите обрушение, разбейте ядро. Смотрите на текущую цель.')}
# Stable platform coordinates are part of the replay protocol.
NODES=[(19,51),(76,70),(27,81),(79,40),(49,50),(54,82)]
def params(spec,boss_key,arena,hero_image):
 mode=spec['mode'];family,help_text=MODE_RULES[mode];duration=spec['seconds']*1000
 seed=random.randint(1,999999);rng=random.Random(seed);n=spec['count'];prep=3200 if family=='sequence' else 1000;gap=(duration-prep-(2300 if family=='platform' else 1500))/max(1,n)
 hazards=[]
 for i in range(n):
  kind='blast';x=rng.uniform(17,83);y=rng.uniform(42,84);r=rng.uniform(10,15)
  if family=='strike':kind='heart';x=50;y=52;r=5
  elif family=='runner':kind=('pillar','wave','high')[i%3];y=77;x=(22,76,49,85,32)[i%5];r=13
  elif family in ('orbit','rings'):kind=('orbit' if family=='orbit' else 'ring') if i%3 else 'ring' if family=='orbit' else 'blast';x=50;y=54;r=24+i%3*10
  elif family in ('platform','gravity'):kind='tile' if i%3 else 'wave';x=(20,50,80)[i%3];y=(46,70,84)[(i//3)%3];r=14
  elif family=='formation':kind='wall';x=(25,52,78)[i%3];y=60;r=12
  elif family=='hand':kind=('grab','sweep','blast')[i%3];r=17
  elif family=='cover':
   kind='meteor' if i%4==0 else 'blast'
   if kind=='meteor':x,y=50,62
   r=13
  elif family in ('duel','mirror'):kind='parry' if i%3 else 'cleave';x,y=([24,50,76][(seed+i)%3] if family=='mirror' else 50),54;r=27 if kind=='cleave' else 18
  elif family in ('portals','legion','final'):kind=('beam','wave','blast')[i%3];x=20+(i*27)%65;y=58;r=12
  elif family=='heat':kind='blast';r=14
  hazards.append(dict(ms=round((2300 if family=='cover' else prep+700)+i*((duration-3100)/max(1,n) if family=='cover' else gap)),x=round(x,3),y=round(y,3),r=round(r,3),kind=kind,cover=(i//4)%3,warning=1100 if kind=='meteor' else 720 if boss_key=='euron' else 600 if boss_key in ('zaferon','deyron_knight') else 520,index=i))
 count=6 if family in ('collect','sequence','orbit') and boss_key=='zaferon' else 3
 objects=[dict(x=x,y=y,index=i) for i,(x,y) in enumerate(NODES[:count])]
 if family in ('runner','rings','duel','mirror','haven','strike'):objects=[]
 if family=='final':objects.append(dict(x=50,y=55,index=3))
 return dict(mode=mode,family=family,instruction=help_text,time_limit_ms=duration,prepare_ms=prep,seed=seed,order=rng.sample(list(range(len(objects))),len(objects)),hazards=hazards,objects=objects,background=arena,hero_image=hero_image,boss_key=boss_key,
             body=('/static/images/towers/'+boss_key+'.jpg') if boss_key in ('deyron_knight','succubus') else '/static/images/towers/bodies/'+boss_key+'.webp',initial_angles=[2,5,3],step_ms=20)
