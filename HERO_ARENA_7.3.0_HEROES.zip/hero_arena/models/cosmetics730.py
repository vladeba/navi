"""7.3 skin redesigns: stable ownership keys, new visual concepts."""
from .skin_themes import SKIN_THEMES
SKIN_PATCHES = {('aarakocra', 'blood'): ('Проводник караванов',
                          'caravan guide, ochre woven scarf, saddlecloth leather shoulder guards with travel '
                          'knots, sandstone cliff trail behind'),
 ('aarakocra', 'frost'): ('Прибрежный разведчик',
                          'coastal scout, dark teal waxed cloak, rope clasp, salt weathered spear and brass '
                          'fishhook pendant, grey seacliff behind'),
 ('aarakocra', 'gold'): ('Дозорный перевала',
                         'mountain scout, canvas hood folded back, blue grey short cape, leather cross '
                         'straps, misty pine mountain pass'),
 ('aarakocra', 'iron_talon'): ('Железный коготь',
                               'rebuild rare skin: steel segmented talon gauntlet, riveted breastplate and '
                               'dark olive tabard, exposed feather crest, iron raven clasp, ruined frontier '
                               'watchtower'),
 ('aarakocra', 'thunder_spear'): ('Громовое копьё',
                                  'rebuild rare skin: storm conductor spear with forked metal head, '
                                  'articulated copper vambrace and engraved shoulder guard, sharp electric '
                                  'blue eye, controlled thin lightning on weapon, windmill ridge at dusk'),
 ('beastlord', 'blood'): ('Ловчий солончаков',
                          'common: rider turns head over shoulder, hide shoulder wrap, white chalk marks and '
                          'bone clasp, kodo grey mottled hide with woven muzzle strap, dry salt flats'),
 ('beastlord', 'braid'): ('Косички',
                          'common: rider with clearly braided beard and tied hair, sleeves of rough linen, '
                          'looks sideways while tightening saddle belt, kodo broad short horn and simple '
                          'harness, birch woodland'),
 ('beastlord', 'dust_b'): ('Пыльный путь',
                           'common: rider crouches forward in saddle one hand shading brow, tan hood folded '
                           'onto shoulders and rolled blanket, kodo walks in side profile with mud splashed '
                           'tusks, dusty roadside'),
 ('beastlord', 'gold'): ('Дорожный наездник',
                         'common: three quarter side view of rider leaning down to check reins; wool vest '
                         'and leather wrist wraps, simple curved axe, kodo has leather pack saddle and short '
                         'bristled mane, river crossing backdrop'),
 ('beastlord', 'ironkodo'): ('Железный кодой',
                             'epic total redesign: rider thick segmented cavalry plate, raised visor showing '
                             'scarred face, one heavy hooked war axe held down, forward battle crouch. Kodo '
                             'stocky steel plated siege mount, broad armored head and reinforced angular '
                             'horn, charging diagonally through broken gate. Keep man and mount legible '
                             'close, no tiny rider'),
 ('beastlord', 'khan'): ('Хан степей',
                         'legendary total redesign: mounted khan shown from low angle three quarter frontal, '
                         'mature braided beard without skull hood, fur lined lamellar armor and tall '
                         'horsehair crest, one hand raises unique crescent axe, other reins; muscular dark '
                         'kodo rears half step, bronze horn guards and woven barding, subdued steppe '
                         'encampment dawn'),
 ('beastlord', 'stable'): ('У стойла',
                           'common: rider sits sideways in saddle brushing kodo neck, simple sleeveless '
                           'tunic and grooming comb, kodo lowered head beside hay, barn door daylight; frame '
                           'rider and animal close'),
 ('beastlord', 'worldbeasts'): ('Повелитель первозданных',
                                'mythic total redesign: fierce rider as primordial shaman with antler crown, '
                                'bark and obsidian armor, luminous white eye and stone double headed axe, '
                                'leaning sideways leading charge. Kodo transformed into huge living root and '
                                'granite primordial beast with moss mane, antler like horns and jade '
                                'fissures. Intimate powerful portrait of BOTH man and mount, stormy ancient '
                                'forest subordinate'),
 ('catfolk', 'blood'): ('Ловчая подворотен',
                        'common female cat human rogue, patched burgundy short jacket, fingerless cloth '
                        'gloves, small steel claw bracer, narrow lantern alley, same recognizable face'),
 ('catfolk', 'gold'): ('Посыльная гильдии',
                       'common female cat human rogue, leather courier vest and cream hood down, brass '
                       'message tube at belt, modest closed neckline, hand resting on satchel, slate town '
                       'bridge dawn'),
 ('catfolk', 'rooftop_c'): ('Крыши',
                            'common rooftop scout, short charcoal hood down and practical belt with rope '
                            'hooks, crouched slightly on chimney edge waist up, face clearly visible, blue '
                            'moonlit slate roof'),
 ('centaur', 'worldbard'): ('Певец мира',
                            'legendary woodland male centaur, chest up near camera with partial equine '
                            'shoulder, braided silver beard, crown of living antlers, layered emerald '
                            'embroidered ceremonial coat, holding unique harp grown from curling wood and '
                            'crystal strings rather than plain staff. Turned singing profile, warm '
                            'illuminated face, ancient grove quietly behind, no tiny full body'),
 ('croc', 'blood'): ('Тростниковый ловчий',
                     'common crocodile humanoid, natural green scales, reed shoulder cape, net floats and '
                     'leather wraps, stone studded mace, marsh reeds dusk'),
 ('croc', 'frost'): ('Каменщик плотины',
                     'common crocodile humanoid, natural brown green scales, rough canvas work apron and '
                     'simple iron shoulder plate, square stone hammer, old dam and running water'),
 ('croc', 'gold'): ('Переправщик',
                    'common crocodile humanoid, natural olive grey scales, blue linen waistcoat, rope '
                    'bandolier, wooden ferry pole with iron cap, calm river landing'),
 ('gambler', 'blood'): ('Игрок речного порта',
                        'common male gambler, navy waistcoat with striped rolled sleeves and red '
                        'neckerchief, dark narrow hat, harbor ferry cabin, cards held low'),
 ('gambler', 'frost'): ('Счётчик долгов',
                        'common male gambler, charcoal double breasted vest and ivory shirt collar, plain '
                        'silver watch chain, brown felt hat, ledger visible beneath cards, cool lamplit '
                        'counting room'),
 ('gambler', 'gold'): ('Дорожный картёжник',
                       'common male gambler, faded green scarf and tan leather short overcoat, travel pouch '
                       'and stitched hat brim, holding worn cards near chest, inn porch on country road'),
 ('gambler', 'gun_g'): ('Картёжник с пистолетом',
                        'rare gambler, ivory linen shirt and charcoal gunfighter coat, beautiful engraved '
                        'flintlock visibly held in off hand, cards fanned against shoulder, leather '
                        'cartridge belt and torn hat brim, rain wet wooden saloon balcony'),
 ('gambler', 'knife_g'): ('Карты и нож',
                          'rare gambler distinct burgundy brocade waistcoat, fitted leather bracer with '
                          'three throwing knives visible and one between fingers, tilted shorter hat with '
                          'brass pin, side glance at opponent, poker den green lamps'),
 ('gambler', 'night_g'): ('Ночной',
                          'common gambler, indigo short cape over grey coat, small hood clasp, dark felt hat '
                          'and single fingerless glove, cards held sideways, quiet blue lit street under '
                          'awning'),
 ('gambler', 'pub'): ('В таверне',
                      'common charismatic male gambler same hat and face, simple open brown travel coat with '
                      'bone buttons, off hand lifting pewter mug, three worn cards in other hand, tavern '
                      'window with soft daylight'),
 ('ghoul', 'gravedigger'): ('Могильщик',
                            'common gaunt ghoul wearing patched leather burial apron and dark wool cap, '
                            'shovel leaned across shoulder, dangling keys, hunched three quarter pose, small '
                            'crypt courtyard grey daylight'),
 ('ghoul', 'rags_ghoul'): ('Лохмотья',
                           'common gaunt male ghoul with recognizably sunken green eyes, layered rough '
                           'burlap grave wraps tied by rope with bone toggle, hood down exposing sparse grey '
                           'hair, one claw gripping cloth, cemetery stone wall dawn'),
 ('ghoul', 'rainy_ghoul'): ('Под дождём',
                            'common gaunt ghoul in waxed dark brown rain cloak with broad collar, wet claw '
                            'gripping hood edge, cold breath and wet face, dripping church porch, no black '
                            'silhouette hiding details'),
 ('hunter', 'beastking'): ('Король охоты',
                           'legendary male hunter in white saber cat skull crown rather than bull hood, '
                           'braided beard with bone bands, layered pelt mantle and deep red lamellar armor, '
                           'massive serrated crescent cleaver raised beside head, roaring expression, ruined '
                           'hunting hall'),
 ('hunter', 'blood'): ('Ловец кабанов',
                       'common rugged male hunter, boar hide shoulder wrap, short dark hair and tied beard, '
                       'leather forearm guards with rope snares, broad cleaver, muddy oak thicket'),
 ('hunter', 'bloodmoon_h'): ('Охотник кровавой луны',
                             'legendary hunter as nocturnal predator, hoodless scarred face half masked by '
                             'carved wolf jaw, long charcoal fur cape, dark red rune marked cuirass, moon '
                             'silver hooked axe across shoulders, looking back with predatory focus, moonlit '
                             'reed marsh quiet not dominant'),
 ('hunter', 'camp'): ('Лагерный охотник',
                      'common male hunter in rolled sleeve hunting shirt with fur vest open, sitting close '
                      'to camera stirring small pot with wooden ladle, axe leaned beside shoulder, warm '
                      'modest campsite'),
 ('hunter', 'feast_h'): ('Пир охотника',
                         'common male hunter seated at rough table, horned hood folded back showing dark '
                         'hair, leather apron with bone buttons, carving venison with hunting knife, '
                         'restrained camp hearth background, face close'),
 ('hunter', 'frost'): ('Следопыт нагорья',
                       'common male hunter, grey wool hood and checkered shoulder blanket, worn belt with '
                       'flint and map pouch, small pick axe, cool rocky moor'),
 ('hunter', 'gold'): ('Лесной обходчик',
                      'common rugged smiling male hunter, plain green hood and brown padded vest instead of '
                      'horned trophy hood, small antler clasp, practical hatchet, fern lined woodland trail'),
 ('hunter', 'wildlord'): ('Владыка дебрей',
                          'legendary male hunter as sovereign of wild groves, regal antler helm revealing '
                          'stern aged face, moss green scale and bark armor, two handed antler edged axe '
                          'diagonally across body, fierce tracking stance leaning toward viewer, quiet '
                          'forest waterfall'),
 ('leon', 'eclipse_heart'): ('Сердце затмения',
                             'lion humanoid LEON as eclipse sovereign, massive lion face and upper body fill '
                             'frame, obsidian and ivory segmented armor, half his mane floats as black solar '
                             'corona with fine embers, crescent crown integrated into mane not floating '
                             'architecture, forward lunging pose with open claw and black glass sword, '
                             'fierce glowing amber eyes, dim eclipsed battlefield secondary'),
 ('leon', 'first_roar'): ('Первый рык мироздания',
                          'lion humanoid LEON as primordial storm emperor, very close bust and waist '
                          'portrait, regal blue black mane threaded with tiny star sparks, broad pearl and '
                          'dark thundersteel armor with sculpted lion shoulder, powerful roaring face angled '
                          'upward, massive clawed gauntlet in foreground gripping unique branching '
                          'thunderblade, mantle of translucent storm silk, subdued misty sky temple, NO '
                          'distant throne NO tiny hero'),
 ('leon', 'oath_of_pride'): ('Клятва прайда',
                             'lion humanoid king LEON, close waist up lion face dominant, powerful three '
                             'quarter duelist pose, mane braided with dark jade rings, forest green '
                             'embroidered royal brigandine and pale fur half cape, broad single edged royal '
                             'sword held diagonally across foreground, one scar through brow and resolute '
                             'snarl, understated rainy palace balcony'),
 ('minotaur', 'blood'): ('Воин каменного круга',
                         'common massive bull humanoid, natural black brown hide, linen wraps and slate '
                         'shoulder plates, stone rune pendants, broad iron axe, overgrown stone ring in '
                         'woodland'),
 ('minotaur', 'gold'): ('Страж кузницы',
                        'common massive bull humanoid, natural brown hide, soot stained leather apron over '
                        'plain iron breastplate, leather horn bands, long handled smith hammer, dim forge '
                        'doorway'),
 ('musketeer', 'blood'): ('Городской караульный',
                          'common moustached musketeer, dark green short cape with simple guard badge, '
                          'leather chest straps, narrow brim felt hat, practical musket, guardhouse brick '
                          'arch'),
 ('musketeer', 'frost'): ('Полевой егерь',
                          'common moustached musketeer, cream quilted shoulder coat and moss hood folded '
                          'down, simple wooden musket with repair bands, hunting pouch, grey early spring '
                          'birchwood'),
 ('musketeer', 'gold'): ('Пограничный стрелок',
                         'common lean moustached musketeer, brown slouch hat without grand feather, buff '
                         'leather jerkin and blue neck scarf, weathered matchlock, border milestone '
                         'background'),
 ('owlbeast', 'blood'): ('Совух бурелома',
                         'common owl bear hybrid with dark barred feathers and russet ear tufts, pale cheek '
                         'facial disk, bark caught in shoulder plumage, fallen timber ravine'),
 ('owlbeast', 'fluffy'): ('Пушистый',
                          'common owl bear hybrid same recognizable owl face, exceptionally layered soft '
                          'tawny feather neck ruff but still dangerous wild beast, broader cheek tufts, '
                          'short dark horns, claws partly folded, moss bank background'),
 ('owlbeast', 'frost'): ('Пещерный совух',
                         'common owl bear hybrid natural charcoal and pale grey speckled feathers, thick '
                         'short neck ruff and amber eyes, worn grey claws, shallow limestone cavern with '
                         'daylight opening'),
 ('owlbeast', 'gold'): ('Камышовый совух',
                        'common owl bear hybrid natural tan mottled feathers, reed tufts around neck, small '
                        'ear horns and broad beak, brown claws, marsh at early morning'),
 ('paladin', 'blood'): ('Паломница клятвы',
                        'common female paladin, cream travel cape with stitched red oath knot, leather belt '
                        'and scuffed steel shoulder guard, practical mace with square head, hillside shrine'),
 ('paladin', 'frost'): ('Стражница переправы',
                        'common female paladin, navy padded mantle over plain metal armor, short braided '
                        'hair, shield with simple bridge emblem, iron flanged mace, riverside watchpost'),
 ('paladin', 'gold'): ('Дозор рассвета',
                       'common stern female paladin with same dark hair, simple matte steel cuirass with '
                       'linen surcoat, blue shield edge and small sun pin, frontier chapel courtyard'),
 ('ranger', 'blood'): ('Тропница вереска',
                       'common blonde elf ranger, violet grey wool scarf and charcoal leather arms, braided '
                       'hair with one wooden bead, small bone arrow charms, heathland path'),
 ('ranger', 'bloodmoon'): ('Кровавая луна',
                           'epic blonde elf ranger as lunar night huntress, half mask carved from pale bone '
                           'showing eyes, black and burgundy armored hunting coat, swept back silver braids, '
                           'crescent tipped spear and spectral hound silhouette subtle, dynamic sideways '
                           'draw stance, ruined lunar temple'),
 ('ranger', 'crimson_trail'): ('Алый след',
                               'epic blonde elf ranger as red feather falcon tracker, asymmetric crimson '
                               'lacquer armor with articulated shoulder, short layered copper red cloak, '
                               'hooked wing shaped spear, one knee raised on root three quarter front '
                               'facing, stern face, amber forest dusk'),
 ('ranger', 'frost'): ('Речная дозорная',
                       'common blonde elf ranger, blue waxed shoulder cape and rope clasp over natural brown '
                       'armor, recurve bow and short simple spear, river reeds mist'),
 ('ranger', 'gold'): ('Лесная связная',
                      'common blonde elf female ranger, pale sage hood down, practical brown leather jacket '
                      'with stitched leaves and message tube at belt, simple ash spear and bow, autumn alder '
                      'wood'),
 ('ranger', 'pathfinder_stars'): ('Прокладывающая путь по звёздам',
                                  'mythic blonde elf ranger transformed astral trailfinder, luminous '
                                  'constellation markings across sharp face, long floating silver braid, '
                                  'flowing midnight and pearl layered armor with orbiting navigation rings, '
                                  'bow spear hybrid of starlight crossing foreground, stepping through small '
                                  'star portal in three quarter frontal pose, character fills frame and '
                                  'cosmic aurora only background'),
 ('ranger', 'pine'): ('Сосновый',
                      'common blonde elf ranger, moss hood folded back, pine cone clasp and needle pattern '
                      'wrist wraps, hair in loose side braid, simple wooden spear, open pine glade daytime'),
 ('ranger', 'quiet'): ('Тихий',
                       'common blonde elf ranger, ash grey shawl with feather clasp and soft leather boots '
                       'hinted, hair tied back and hand holding bow vertical close to shoulder, quiet snowy '
                       'birch edge'),
 ('ranger', 'warden'): ('Хранительница границ',
                        'legendary blonde elf ranger as ancient frontier sentinel, regal living bronze and '
                        'ivy armor, crown of arrow shaped leaves, elaborate split tip spear planted '
                        'diagonally, commanding forward stance and hand raised signalling halt, new '
                        'elaborate braided updo, subdued ancient gateway')}
LEON_NEW = [('legendary', 'oath_of_pride', 'Клятва прайда', 'lion humanoid king LEON, close waist up lion face dominant, powerful three quarter duelist pose, mane braided with dark jade rings, forest green embroidered royal brigandine and pale fur half cape, broad single edged royal sword held diagonally across foreground, one scar through brow and resolute snarl, understated rainy palace balcony'), ('mythic', 'eclipse_heart', 'Сердце затмения', 'lion humanoid LEON as eclipse sovereign, massive lion face and upper body fill frame, obsidian and ivory segmented armor, half his mane floats as black solar corona with fine embers, crescent crown integrated into mane not floating architecture, forward lunging pose with open claw and black glass sword, fierce glowing amber eyes, dim eclipsed battlefield secondary'), ('mythic', 'first_roar', 'Первый рык мироздания', 'lion humanoid LEON as primordial storm emperor, very close bust and waist portrait, regal blue black mane threaded with tiny star sparks, broad pearl and dark thundersteel armor with sculpted lion shoulder, powerful roaring face angled upward, massive clawed gauntlet in foreground gripping unique branching thunderblade, mantle of translucent storm silk, subdued misty sky temple, NO distant throne NO tiny hero')]
for hero,items in list(SKIN_THEMES.items()):
 revised=[]
 for rarity,key,name,desc in items:
  if (hero,key) in SKIN_PATCHES:
   name,_concept=SKIN_PATCHES[hero,key];desc='Обновлённый образ «'+name+'»'
  if hero=='leon' and key in ('desertcrown','astral','worldend'):rarity='legendary'
  revised.append((rarity,key,name,desc))
 SKIN_THEMES[hero]=revised
for entry in LEON_NEW:
 if not any(s[1]==entry[1] for s in SKIN_THEMES['leon']):
  rarity,key,name,_concept=entry;SKIN_THEMES['leon'].append((rarity,key,name,'Новый образ Леона «'+name+'»'))
