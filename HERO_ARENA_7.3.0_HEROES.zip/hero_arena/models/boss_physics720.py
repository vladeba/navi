"""Fixed-step replay: inputs determine movement, jumping, objectives and collisions."""
import math
DT=.02
KEYS={'left','right','up','down','jump','dash','use'}
def distance(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])
def clamp(x,a,b):return max(a,min(b,x))
def initial(o):
 return dict(t=0,x=50.,y=78.,z=0.,vz=0.,keys={},jump_at=-9999,dash_at=-9999,use_at=-9999,grab_until=0,escape=0,last_escape='',heat=0.,hits=[],resolved=[],done=[],progress=[0.]*len(o['objects']),parries=0,wrong=0,angles=o['initial_angles'][:],forged=False,shots=[])
def stage(o,t):return 0 if o['family']!='final' else min(2,int(max(0,t-1000)/(o['time_limit_ms']-1000)*3))
def near_node(s,o,r=10):return next((i for i,n in enumerate(o['objects']) if distance(s,n)<=r),-1)
def step(s,o,inputs):
 t=s['t']+20;s['t']=t;family=o['family'];pressed=set()
 for a in inputs:
  if a.get('kind')=='shot':
   if family=='strike' and t>=o['prepare_ms'] and len(s['shots'])<3 and (not s['shots'] or a['ms']-s['shots'][-1]['ms']>=300):s['shots'].append(dict(a))
   continue
  if a.get('kind')=='rotate':
   if family=='forge' and type(a.get('ring')) is int and 0<=a['ring']<3:
    s['angles'][a['ring']]=(s['angles'][a['ring']]+1)%8;s['use_at']=t
   continue
  k=a.get('key')
  if k not in KEYS:continue
  down=a.get('down') is True
  if down and not s['keys'].get(k):pressed.add(k)
  s['keys'][k]=down
 if t<o['prepare_ms']:return
 if family=='forge':
  if 'use' in pressed and all(v==0 for v in s['angles']):s['forged']=True
  return
 keys=s['keys'];dx=int(keys.get('right',False))-int(keys.get('left',False));dy=int(keys.get('down',False))-int(keys.get('up',False))
 if family=='runner':dy=0;s['y']=78.
 if 'jump' in pressed and s['z']==0 and t-s['jump_at']>=600:s['vz']=78.;s['jump_at']=t
 if 'dash' in pressed and t-s['dash_at']>=1050:s['dash_at']=t
 speed=74 if t-s['dash_at']<180 else 32
 if s['grab_until']>t:
  speed=6
  for key in ('left','right'):
   if key in pressed and key!=s['last_escape']:s['escape']+=1;s['last_escape']=key
  if s['escape']>=6:s['grab_until']=0;s['escape']=0
 length=max(1,math.hypot(dx,dy));s['x']+=dx/length*speed*DT;s['y']+=dy/length*speed*DT
 if family=='gravity':
  d=max(6,math.hypot(s['x']-50,s['y']-60));s['x']+=(50-s['x'])/d*12*DT;s['y']+=(60-s['y'])/d*12*DT
 if o['mode']=='firestorm':s['x']+=7*DT
 s['x']=clamp(s['x'],8,92);s['y']=clamp(s['y'],36,89)
 s['vz']-=235*DT;s['z']=max(0,s['z']+s['vz']*DT)
 if s['z']==0:s['vz']=0
 node=near_node(s,o)
 if family in ('collect','orbit','rain','platform') and node>=0 and node not in s['done']:s['done'].append(node)
 if family in ('capture','chains','gravity','heat') and keys.get('use') and node>=0:
  s['progress'][node]+=DT
  if s['progress'][node]>=.75 and node not in s['done']:s['done'].append(node)
  if family=='heat':s['heat']=max(0,s['heat']-90*DT)
 if family=='heat':s['heat']=min(110,s['heat']+8*DT)
 if 'use' in pressed and t-s['use_at']>=300:
  s['use_at']=t
  if family=='strike' and len(s['shots'])<3:s['shots'].append(dict(ms=t,x=s['x'],y=s['y']))
  if family=='sequence' and node>=0:
   if len(s['done'])<len(o['order']) and node==o['order'][len(s['done'])]:s['done'].append(node)
   else:s['wrong']+=1
  if family=='portals' and node>=0:
   if node==len(s['done']):
    s['done'].append(node);n=o['objects'][(node+1)%len(o['objects'])];s['x'],s['y']=100-n['x'],clamp(120-n['y'],36,89)
   else:s['wrong']+=1
  if family=='formation' and node>=0 and node not in s['done']:s['done'].append(node)
  if family in ('legion','final') and node>=0 and (family!='final' or (stage(o,t)==0 and node<3) or (stage(o,t)==2 and node==3 and all(i in s['done'] for i in range(3)))):
   s['progress'][node]+=1
   if s['progress'][node]>=3 and node not in s['done']:s['done'].append(node)
  if family in ('duel','mirror','hand'):
   candidates=[h for h in o['hazards'] if h['kind']=='parry' and h['index'] not in s['resolved'] and abs(t-h['ms'])<=170 and distance(s,h)<=16]
   if candidates:s['parries']+=1;s['resolved'].append(candidates[0]['index'])
   elif family=='mirror':s['wrong']+=1
  if family=='hand' and node>=0 and node not in s['done']:s['done'].append(node)
 # Every attack is evaluated across its visible active lifetime, once per hazard.
 for h in o['hazards']:
  i=h['index'];age=t-h['ms'];kind=h['kind'];life=1700 if kind=='tile' else 1200 if kind in ('orbit','wall') else 800 if kind in ('ring','wave') else 480
  if i in s['resolved'] or age<0:continue
  bad=False
  if age<=life:
   d=distance(s,h);dash=t-s['dash_at']<180
   if kind in ('blast','pillar','tile','grab'):bad=d<h['r']+2 if kind!='pillar' else abs(s['x']-h['x'])<h['r']
   if kind=='tile' and s['z']>5:bad=False
   if kind=='wave':bad=abs(s['x']-(100-age/8))<9 and abs(s['y']-74)<23 and s['z']<6
   if kind=='high':bad=abs(s['x']-h['x'])<h['r'] and not keys.get('down')
   if kind=='ring':bad=abs(d-(7+age*.065))<5 and s['z']<6
   if kind=='beam':bad=abs(s['x']-h['x'])<7 and not dash
   if kind=='orbit':bad=math.hypot(s['x']-(50+h['r']*math.cos((t-h['ms'])*.004+i)),s['y']-(54+h['r']*math.sin((t-h['ms'])*.004+i)))<7 and s['z']<8
   if kind=='wall':bad=abs(s['x']-(age/12))<8 and abs(s['y']-(44+(i%3)*18))>9 and s['z']<5
   if kind=='sweep':bad=abs(s['y']-h['y'])<13 and s['z']<7
   if kind=='meteor':bad=distance(s,o['objects'][h.get('cover',i%len(o['objects']))])>9
   if kind in ('parry','cleave'):bad=d<h['r'] and not dash
   if family in ('haven','final') and (family!='final' or stage(o,t)==1):
    center=dict(x=50+22*math.sin(t/1900),y=63+13*math.sin(t/1500));bad=bad or distance(s,center)>21
   if family=='gravity':bad=bad or math.hypot(s['x']-50,s['y']-60)<12
   if family=='heat':bad=bad or s['heat']>=100
   if bad:
    s['hits'].append(i);s['resolved'].append(i)
    if kind=='grab':s['grab_until']=t+1700;s['escape']=0;s['last_escape']=''
  if age>life and i not in s['resolved']:
   s['resolved'].append(i)
   if kind=='meteor' and h.get('cover',i%len(o['objects'])) not in s['done']:s['done'].append(h.get('cover',i%len(o['objects'])))

def result(s,o,elapsed):
 if o['family']=='strike':
  used=set()
  for shot in s['shots']:
   impact=shot['ms']+220
   if impact>elapsed:continue
   x=50+17*math.sin(impact/850+o['seed']);y=52+8*math.sin(impact/670+o['seed'])
   for h in o['hazards']:
    if h['index'] not in used and abs(impact-h['ms'])<=200 and math.hypot(shot['x']-x,shot['y']-y)<=5:used.add(h['index']);break
  return dict(quality=len(used)/3,hits=0,avoided=len(used),total=3,objectives=len(used),goals=3,parries=0,forged=False)
 total=len(o['hazards']);complete=sum(h['ms']+(1700 if h['kind']=='tile' else 1200 if h['kind'] in ('orbit','wall') else 800)<=elapsed for h in o['hazards']);avoided=max(0,complete-len(s['hits']))
 family=o['family'];goals=len(o['objects']);done=len(s['done'])
 if family in ('runner','rings','haven'):goal=1.
 elif family in ('duel','mirror'):goal=min(1,s['parries']/max(1,sum(h['kind']=='parry' for h in o['hazards'])*.6))
 elif family=='forge':goal=1. if s['forged'] else sum(v==0 for v in s['angles'])/3
 else:goal=min(1,done/max(1,goals))
 safe=avoided/max(1,total);quality=safe*(.65+.35*goal) if family!='forge' else goal
 quality=max(0,quality-s['wrong']*.05)
 if elapsed<o['time_limit_ms']-600 and family!='forge':quality*=elapsed/o['time_limit_ms']
 return dict(quality=round(quality,6),hits=len(s['hits']),avoided=avoided,total=total,objectives=done,goals=goals,parries=s['parries'],forged=s['forged'])
def replay(c,o):
 empty=dict(quality=0,hits=len(o['hazards']),avoided=0,total=len(o['hazards']),objectives=0,goals=len(o['objects']),parries=0,forged=False)
 if not isinstance(c,dict):return empty
 elapsed=c.get('elapsed_ms');actions=c.get('actions')
 if type(elapsed) is not int or not 0<=elapsed<=o['time_limit_ms'] or not isinstance(actions,list) or len(actions)>600:return empty
 last=-1
 for a in actions:
  if not isinstance(a,dict) or type(a.get('ms')) is not int:return empty
  if not 0<=a['ms']<=elapsed or a['ms']<last:return empty
  if a.get('kind')=='shot':
   if any(isinstance(a.get(k),bool) or not isinstance(a.get(k),(int,float)) or not math.isfinite(a[k]) or not 0<=a[k]<=100 for k in ('x','y')):return empty
  elif a.get('kind')=='rotate':
   if type(a.get('ring')) is not int or not 0<=a['ring']<3:return empty
  elif a.get('key') not in KEYS or type(a.get('down')) is not bool:return empty
  last=a['ms']
 s=initial(o);j=0
 for tick in range(20,elapsed+1,20):
  events=[]
  while j<len(actions) and actions[j]['ms']<=tick:events.append(actions[j]);j+=1
  step(s,o,events)
 return result(s,o,elapsed)
