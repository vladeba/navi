"""Acheron: royal shield reserves, risky detonation and maintained blood art."""
import math,random
from .character import Character
from .skills import Skill,DamageSkill,MiniGameSkill
from .effects import Effect,Shield,Antiheal
from .minigames_56 import Replay,events,number,integer,near

SHIELD_NAMES={'royal':'Королевская печать','mirror':'Зеркало бездны','blood':'Кровавый бастион'}

class RoyalAegis(Shield):
    name,icon,positive='Щиты Ахерона','🛡',True
    def __init__(self):
        self.parts={};self.duration=4
    @property
    def power(self):return sum(p['hp'] for p in self.parts.values())
    @power.setter
    def power(self,value):
        remaining=max(0,int(value))
        for key in list(self.parts):
            amount=min(self.parts[key]['hp'],remaining);self.parts[key]['hp']=amount;remaining-=amount
        self.parts={k:p for k,p in self.parts.items() if p['hp']>0}
    def tick(self):
        for p in self.parts.values():p['turns']-=1
        self.parts={k:p for k,p in self.parts.items() if p['turns']>0 and p['hp']>0}
        self.duration=max((p['turns'] for p in self.parts.values()),default=0)
    def modify_incoming(self,owner,damage,attacker):
        leak=max(.2,min(1,getattr(attacker,'shield_pierce',0)))
        passed=min(damage,math.ceil(damage*leak));absorbed=min(self.power,max(0,damage-passed))
        if owner.has_effect(Antiheal):absorbed//=2
        remaining=absorbed
        for key in sorted(self.parts,key=lambda k:(self.parts[k]['turns'],k)):
            part=self.parts[key];used=min(part['hp'],remaining);part['hp']-=used;remaining-=used
            if not remaining:break
        self.parts={k:p for k,p in self.parts.items() if p['hp']>0}
        if not self.power:self.duration=0
        return damage-absorbed,[f'🛡 Щиты {owner.name}: поглощено {absorbed}; минимум {passed} урона проходит сквозь защиту.']
    def to_dict(self):
        d=super().to_dict();d['parts']=[dict(kind=k,name=SHIELD_NAMES[k],hp=p['hp'],turns=p['turns']) for k,p in self.parts.items()];d['help']='Поглощают до 80% урона после брони. Остаток идёт в HP. При запрете лечения поглощение ослаблено. Взрывается только оставшаяся прочность.';return d

def aegis(h):return next((e for e in h.get_effects() if isinstance(e,RoyalAegis)),None)
def grant_shield(h,kind,amount):
    e=aegis(h)
    if e is None:e=RoyalAegis();h.add_effect(e)
    old=e.parts.get(kind,{}).get('hp',0);other=e.power-old
    actual=min(max(0,round(amount)),max(0,math.floor(h.max_hp*.35)-other))
    if actual:e.parts[kind]=dict(hp=actual,turns=4);e.duration=max(e.duration,4)
    return actual

def blast_values(h):
    e=aegis(h)
    if not e:return 0,0
    damage=sum(p['hp']*(1.2 if k=='blood' else .9) for k,p in e.parts.items())
    self_damage=sum(p['hp']*(.1 if k=='mirror' else .2) for k,p in e.parts.items())
    return round(damage*h.damage_multiplier()*(1+h.fatigue)),math.ceil(self_damage)

def self_wound(h,amount):
    before=h.hp;h.hp-=max(0,amount);taken=before-h.hp
    if hasattr(h,'_stats605'):h._stats605['taken']+=taken
    return taken

class BloodMark(Effect):
    name,icon='Метка демонической крови','🩸'
    def __init__(self,source):self.source=source;self.duration=999
    @property
    def power(self):return self.source.blood_charges
    def tick(self):pass
    def is_expired(self):return not self.source.is_alive() or self.source.blood_charges<=0
    def to_dict(self):
        d=super().to_dict();d['name']=f'Метка крови {self.power}/5';d['duration']=None;d['help']=f'{self.source.name}: {self.power}/5 зарядов. Поддерживает после собственных действий; может взорвать раньше максимума.';return d

class AcheronGame(Replay,MiniGameSkill):
    game='acheron612';hero_target=True;deals_damage=False;PREP=400;TIME_LIMIT_MS=4200
    TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(30,43,22,5);TIER_VALUE=(1,.8,.5,0)
    MODE='seal'
    def game_params(self,u,t):
        factor=max(.2,getattr(self,'_time_multiplier',1));base=dict(mode=self.MODE,prepare_ms=round(400*factor),hero_type='acheron',instruction=self.prompt,factor=factor)
        if self.MODE=='seal':
            base.update(sources=random.sample([[65,207],[180,207],[295,207]],3),targets=[[100,88],[180,66],[260,88]],runes=random.sample(['♜','◇','♛','✦','☾','♝'],3),radius=25)
        elif self.MODE=='mirror':
            base.update(notes=[dict(lane=random.randrange(3),ms=round((800+580*i)*factor)) for i in range(4)],window=round(180*factor))
        elif self.MODE=='bastion':
            points=[[65,175],[90,76],[180,42],[270,76],[295,175]]
            if random.random()<.5:points.reverse()
            base.update(nodes=points,radius=23)
        else:base.update(notes=[dict(lane=random.randrange(3),ms=round((700+600*i)*factor)) for i in range(3)],window=round(220*factor),time_limit_ms=round(2600*factor))
        return base
    def tier_from(self,c,o):
        if o['mode']=='seal':
            found=set()
            for e in events(c,'placements',o,12):
                k=integer(e.get('part'),hi=2)
                if k<0 or k in found:continue
                a=(number(e.get('x0')),number(e.get('y0')));b=(number(e.get('x1')),number(e.get('y1')))
                if near(a,o['sources'][k],o['radius']) and near(b,o['targets'][k],o['radius']):found.add(k)
            n=len(found);return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
        if o['mode']=='bastion':
            cuts=events(c,'cuts',o,300);n=0;last=None
            from .rikz_609 import segment_distance
            for e in cuts:
                a=(number(e.get('x0'),lo=0,hi=360),number(e.get('y0'),lo=0,hi=260));b=(number(e.get('x1'),lo=0,hi=360),number(e.get('y1'),lo=0,hi=260))
                if -999 in a+b:return 3
                if last is None:
                    if not near(a,o['nodes'][0],o['radius']):return 3
                    n=1
                elif not near(last,a,1):return 3
                while n<len(o['nodes']) and segment_distance(o['nodes'][n],a,b)<=o['radius']:n+=1
                last=b
            return 0 if n==5 else 1 if n>=3 else 2 if n>=1 else 3
        actions=events(c,'actions',o,12);used=set();hits=0
        for e in actions:
            for i,n in enumerate(o['notes']):
                if i not in used and e.get('lane')==n['lane'] and abs(e['ms']-n['ms'])<=o['window']:
                    used.add(i);hits+=1;break
        errors=len(actions)-hits;score=max(0,hits-errors)
        total=len(o['notes']);return 0 if score==total else 1 if score>=total-1 else 2 if score==1 else 3

class ShieldGame(AcheronGame):
    KIND='royal';FRACTIONS=(.15,.12,.08,0)
    prompt='Перетащите три символа герба в совпадающие контуры. Каждый символ имеет свой знак.'
    def apply(self,u,t,tier,data):
        amount=round(u.max_hp*self.FRACTIONS[tier]);value=grant_shield(u,self.KIND,amount) if amount else 0
        return [f'🛡 {u.name}: {SHIELD_NAMES[self.KIND]}, прочность {value}. Общий предел щитов {math.floor(u.max_hp*.35)}; 20% урона проходит в HP.']
    def ai_score(self,u,t):
        from .ai import tier_average,threat
        t=u.opponent or t
        e=aegis(u);old=e.parts.get(self.KIND,{}).get('hp',0) if e else 0;other=(e.power if e else 0)-old
        amount=tier_average(self,u,[u.max_hp*x for x in self.FRACTIONS]);added=max(0,min(amount,math.floor(u.max_hp*.35)-other)-old)
        return min(added,threat(t,u)*2.7)*.9+added*.12
class MirrorGame(ShieldGame):
    MODE='mirror';KIND='mirror';FRACTIONS=(.12,.10,.07,0)
    prompt='Нажмите 1/2/3, когда отражение достигнет золотой полосы. Четыре импульса; лишние нажатия снижают результат.'
class BastionGame(ShieldGame):
    MODE='bastion';KIND='blood';FRACTIONS=(.12,.10,.07,0)
    prompt='Зажмите первый узел и проведите по точкам 1 → 5. Кровавый щит сильнее при взрыве.'

class RoyalHeal(Skill):
    FRACTION=.10
    copyable=False;hero_target=True
    def _perform(self,u,t):
        value=u.heal(round(u.max_hp*self.FRACTION));return [f'👑 Королевская кровь {u.name}: +{value} HP.']+u.pop_events()
    def ai_score(self,u,t):
        from .ai import healing
        return healing(u,round(u.max_hp*self.FRACTION))
class ShatterCrown(Skill):
    copyable=False;hero_target=True
    def is_available(self,u):return bool(aegis(u) and aegis(u).power)
    def _perform(self,u,t):
        damage,wound=blast_values(u);e=aegis(u)
        if e:e.parts={};e.duration=0
        real=t.take_damage(damage,attacker=u);lost=self_wound(u,wound)
        return [f'💥 Разрыв венца {u.name}: {real} урона по {t.name}; {lost} HP самому Ахерону сквозь его защиту. Все щиты потрачены.']+t.pop_events()
    def ai_score(self,u,t):
        from .ai import threat
        t=u.opponent or t
        damage,wound=blast_values(u)
        if not damage or wound>=u.hp:return 0
        real=max(1,damage-t.armor_total());reserve=aegis(u).power
        return real-wound*.9-min(reserve,threat(t,u)*1.8)*.55+(12 if real>=t.hp else 0)
    def to_dict(self,u=None):
        d=super().to_dict(u)
        if u:
            damage,wound=blast_values(u);d['description']+=f' Сейчас: до {damage} урона до брони цели; себе {wound} HP. Может погубить Ахерона.'
        return d

class BloodArt(AcheronGame):
    MODE='blood';TIME_LIMIT_MS=2600;owner=None
    prompt='Нажмите 1/2/3 при вспышке нужной кровавой руны. Три импульса: два и более сохраняют метку.'
    @property
    def reaction(self):return None if self.owner and self.owner.blood_charges else 'minigame'
    def pay(self,u):
        if not u.blood_charges:super().pay(u)
    def _perform(self,u,t):
        if u.blood_charges:return u.burst_mark(t)
        return super()._perform(u,t)
    def apply(self,u,t,tier,data):
        if tier>=2:return ['🩸 Кровавая печать сорвалась: метка не наложена.']
        u.clear_mark();u.blood_target=t;u.blood_charges=1;u._skip_blood612=True;t.add_effect(BloodMark(u))
        return [f'🩸 {u.name} накладывает метку на {t.name}: 1/5 зарядов. После следующих действий её нужно поддерживать.']
    def ai_score(self,u,t):
        t=u.opponent or t
        if u.blood_charges:
            damage=u.mark_damage();return max(0,damage-t.armor_total())+12 if u.blood_charges==5 or damage>=t.hp else 0
        return 26 if t.hp>u.get_damage()*2 else 0
    def to_dict(self,u=None):
        d=super().to_dict(u)
        if u and u.blood_charges:d.update(name=f'Взорвать метку ({u.blood_charges}/5)',cost=0,cooldown_left=0,description=f'Немедленный взрыв: до {u.mark_damage()} урона до брони цели. Тратит ход; метка исчезает. Можно дождаться пяти зарядов.',reaction=None,is_minigame=False)
        return d
class MaintainBlood(AcheronGame):
    AI_WEIGHTS=(45,40,12,3)
    MODE='blood';TIME_LIMIT_MS=2600
    prompt='Поддержите метку: нажмите 1/2/3 при вспышках трёх рун. Два попадания дают +1 заряд; срыв снимает один.'
    def pending_valid(self,u,t):
        u._sync_mark();return u.blood_charges>0 and u.blood_target is t
    def apply(self,u,t,tier,data):
        if not self.pending_valid(u,t):return ['🩸 Метка уже исчезла.']
        u.blood_charges=max(0,min(5,u.blood_charges+(1 if tier<2 else -1)))
        if not u.blood_charges:u.clear_mark();u.set_cooldown('blood_art',3);return ['🩸 Поддержание сорвано: последний заряд потерян, метка исчезает.']
        return [f'🩸 Метка на {t.name}: {u.blood_charges}/5 зарядов.'+(' Можно взорвать максимальную метку.' if u.blood_charges==5 else '')]

class Acheron(Character):
    hero_class,type_key,resource_name,role='Полудемон','acheron','власть','warrior'
    PASSIVE_NOTES=('«Наследник двух кровей»: три щита имеют общий предел 35% HP. 20% урона после брони проходит сквозь них. Щиты можно взорвать, ранив врага и себя. Метка крови накапливает до 5 зарядов и требует поддержания после собственных действий.',)
    def __init__(self,name,level=1):
        self.blood_target=None;self.blood_charges=0;self._skip_blood612=False
        super().__init__(name,max_hp=225,base_damage=13,armor=2.2,level=level,speed=5,dodge=.05,crit_chance=.1,max_energy=100,energy_regen=12,start_energy=65)
    def _create_skills(self):
        art=BloodArt('blood_art','Искусство демонической крови','Наложить метку: поддержание после каждого действия даёт до 5 зарядов. Повторное нажатие взрывает её раньше. Срыв поддержания: −1 заряд.',cost=25,cooldown=4,icon='🩸');art.owner=self
        return [DamageSkill('attack','Удар наследника','Бесплатная обычная атака',accuracy=.95,icon='⚔'),
            RoyalHeal('royal_blood','Королевская кровь','Восстановить 10% максимального HP. Запрет лечения действует.',cost=25,cooldown=5,icon='👑'),
            ShatterCrown('shatter_crown','Разрыв венца','Взорвать оставшиеся щиты: ×0.9 прочности, кровавый ×1.2. Себе 20% прочности, зеркальный 10%. Бьёт героя противника.',cost=10,cooldown=2,icon='💥'),
            DamageSkill('heir_lunge','Выпад наследника','Недорогая атака ×1.3 с пробитием 25% брони',multiplier=1.3,armor_pierce=.25,cost=12,cooldown=2,icon='🗡'),
            ShieldGame('royal_seal','Королевская печать','Соберите три части герба. Щит 15%/12%/8% HP по качеству; срыв без щита. 3 собственных хода.',cost=22,cooldown=3,icon='♛'),
            MirrorGame('abyss_mirror','Зеркало бездны','Четыре импульса 1/2/3. Щит 12%/10%/7% HP; его взрыв ранит Ахерона вдвое слабее. 3 собственных хода.',cost=18,cooldown=3,icon='🔮'),
            BastionGame('blood_bastion','Кровавый бастион','Проведите по 5 узлам. Щит 12%/10%/7% HP; его взрыв наносит ×1.2 вместо ×0.9 прочности. 3 собственных хода.',cost=20,cooldown=3,icon='🛡'),art]
    def _on_reset(self):self.clear_mark();self._skip_blood612=False
    def clear_mark(self):
        target=self.blood_target
        if target:target._effects=[e for e in target._effects if not (isinstance(e,BloodMark) and e.source is self)]
        self.blood_target=None;self.blood_charges=0
    def _sync_mark(self):
        if self.blood_charges and (not self.blood_target or not self.blood_target.is_alive() or not any(isinstance(e,BloodMark) and e.source is self for e in self.blood_target._effects)):
            self.clear_mark();self.set_cooldown('blood_art',3)
    def _can_use_strict(self,s):
        self._sync_mark()
        if s.key=='blood_art' and self.blood_charges:return self.blocked_left(s.key)==0
        return super()._can_use_strict(s)
    def mark_damage(self):
        q=self.blood_charges;return round(self.get_damage()*(.9*q+.1*q*q)*self.damage_multiplier()*(1+self.fatigue))
    def burst_mark(self,t):
        target=self.blood_target
        if not target or not target.is_alive():self.clear_mark();return ['🩸 Цель метки уже недоступна.']
        damage=self.mark_damage();q=self.blood_charges;self.clear_mark();self.set_cooldown('blood_art',3)
        real=target.take_damage(damage,attacker=self)
        return [f'🩸 {self.name} взрывает метку ({q}/5): {real} урона по {target.name}.']+target.pop_events()
    def post_action_games(self,foe):
        self._sync_mark()
        if self._skip_blood612:self._skip_blood612=False;return []
        if not self.blood_charges:return []
        if not self.blood_target or not self.blood_target.is_alive():self.clear_mark();return []
        return [(MaintainBlood('blood_upkeep','Поддержать метку','Три руны; два попадания сохраняют и усиливают метку. Ошибка снимает заряд.',icon='🩸'),self,self.blood_target)]
    def to_dict(self):
        self._sync_mark();d=super().to_dict();e=aegis(self);damage,wound=blast_values(self)
        d['acheron_state']=dict(shields=e.to_dict()['parts'] if e else [],shield_total=e.power if e else 0,shield_cap=math.floor(self.max_hp*.35),leak_percent=20,blast_damage=damage,blast_self=wound,mark_charges=self.blood_charges,mark_target=self.blood_target.name if self.blood_target else None,mark_damage=self.mark_damage())
        return d

def install(classes):
    classes['acheron']=Acheron
    from .tuning_602 import PAIR_DAMAGE
    from .tuning_612 import ACHERON_PAIRS
    PAIR_DAMAGE.update(ACHERON_PAIRS)
    from .acheron_skins612 import install_skins
    install_skins()
    from .arena_rules import ARENA_HP,ARENA_DAMAGE
    ARENA_HP['acheron']=225;ARENA_DAMAGE['acheron']=.8
    from .lore import NAMES,LORE
    NAMES['acheron']='Ахерон';LORE['acheron']='Наследник королевского рода и демонической крови. Ахерон носит печати трона как защиту — и разбивает их, когда цена победы становится выше цены собственной крови.'
    from .games_600 import STARS
    STARS.update({('acheron','royal_seal'):3,('acheron','abyss_mirror'):4,('acheron','blood_bastion'):3,('acheron','blood_art'):4,('acheron','blood_upkeep'):3})
