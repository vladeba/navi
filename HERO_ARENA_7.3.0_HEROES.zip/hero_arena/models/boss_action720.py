"""Playable boss episodes, scored solely by replayed physical inputs."""
from .tower_games import TowerGame,pure_damage
from .boss_encounters720 import params,MODE_RULES
from .boss_physics720 import replay
from .tower_data import background

class ActionGame(TowerGame):
 game='boss_action720';AI_WEIGHTS=(8,34,38,20)
 def __init__(self,key,name,spec,boss_key,bonus=None):
  super().__init__(key,name,spec,boss_key,bonus)
  self.prompt=MODE_RULES[spec['mode']][1]
 def game_params(self,u,t):
  b=getattr(u,'_battle',None);arena=b.arena_key if b and hasattr(b,'arena_key') else self.boss_key
  player=u if self.bonus else t
  d=params(self.spec,self.boss_key,background(arena),player.image)
  if b and self.boss_key=='gorr_gall' and b.phase==3:d['body']='/static/images/towers/bodies/gorr_true.webp'
  return d
 def tier_from(self,c,o):
  q=replay(c,o)['quality']
  if o['family']=='strike':return 0 if q>=.99 else 1 if q>=.66 else 2 if q>0 else 3
  return 0 if q>=.92 else 1 if q>=.72 else 2 if q>=.30 else 3
 def result_data(self,c,o):return replay(c,o)
 def apply(self,u,t,tier,data):
  if data is None:data=dict(quality=(1,.78,.42,0)[tier],hits=(0,4,10,self.spec['count'])[tier],avoided=round(self.spec['count']*(1,.78,.42,0)[tier]),total=self.spec['count'])
  if self.bonus:
   self._defender=u;rate=((.18,.12,.06,0) if self.bonus=='zaferon' else (.10,.06,.03,0))[tier];damage=pure_damage(t,t.max_hp*rate,u)
   return [f'✦ {self.name}: {damage} урона по {t.name}.']
  self._defender=t
  failure=1-data['quality'];raw=round((self.spec['power']+t.max_hp*.12)*failure)
  pierce=round(raw*.25) if getattr(getattr(u,'_battle',None),'is_boss',False) else 0
  value=(pure_damage(t,pierce,u)+t.take_damage(raw-pierce,ignore_armor=False,attacker=u)) if raw else 0
  b=getattr(u,'_battle',None)
  goal=f', цели {data.get("objectives",0)}/{data["goals"]}' if data.get('goals') else ''
  lines=[f'🔥 {self.name}: столкновения {data["hits"]}{goal}; {value} урона по {t.name}.']+t.pop_events()
  if b and hasattr(b,'defense_result'):lines+=b.defense_result(self,tier,data['avoided'],data['total'])
  return lines
 def to_dict(self,u=None):
  d=super().to_dict(u);d.update(difficulty=4 if self.boss_key in ('euron','deyron_knight') else 5,difficulty_label='Физическое испытание · WASD, прыжок, рывок, взаимодействие');return d
