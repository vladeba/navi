"""7.3: fair physical tasks and small, explicitly requested hero revisions."""
import copy, math, random
from .skills import MiniGameSkill
from .minigames_56 import Replay,events,records,integer,number,near,trace,at
from .minigames_59 import flight,count_tier

CONFIG={
 ('pagan','thunder'):('sparks',5000,'Соедините три искры Перуна по номерам: нажимайте светящиеся руны.'),
 ('pagan','werewolf'):('forms',18000,'Выберите зверя: волк — скорость и серия ударов; медведь — броня и щит; ворон — уклонение и пробитие. У каждого свой обряд. На выбор и обряд — 18 секунд.'),
 ('minotaur','bone_wall'):('bones',6500,'Перетащите три костяные опоры на подходящие контуры стены.'),
 ('croc','mud_shell'):('mud',6500,'Укройте панцирь тремя пластами грязи: перетащите их на контуры.'),
 ('ghoul','lunge'):('lunge',5000,'Два выпада: нажмите «Выпад», когда острие попадёт в зелёную зону; золотой центр — идеально.'),
 ('ghoul','devour'):('morsels',5000,'Соберите три куска пищи, нажимая на них. Подсказки показывают порядок.'),
 ('hunter','net'):('net',6500,'Закрепите три узла сети: перетащите поплавки на светящиеся крепления.'),
 ('centaur','totem_heal'):('totem',8000,'Соберите тотем снизу вверх: перетащите четыре резные части по номерам.'),
 ('paladin','bless'):('dawn',4500,'Зажмите кнопку света и отпустите, когда луч окажется в зелёной области.'),
 ('catfolk','agility'):('shadow',5500,'Две вспышки: выбирайте подсвеченное тёмное укрытие. Места видны заранее.'),
 ('catfolk','rake'):('paws',4800,'Три мягких выпада: нажмите по трём целям с когтями в указанном порядке.'),
 ('beastlord','kodo_guard'):('kodo',6500,'Перенесите три пластины на контуры защитного панциря кодоя.'),
 ('cyclops','stone_flesh'):('stone',6000,'Закрепите три слоя каменной кожи. Нажимайте «Закрепить» в широкой зелёной области; уже закреплённые слои остаются на месте.'),
}
FORMS={
 'wolf':dict(name='🐺 Волк',benefit='Полная сила, 4 хода: +4 скорости; обычная атака — два удара по ×0.84 и кровотечение.',task='Охота: поймайте три следа по порядку.'),
 'bear':dict(name='🐻 Медведь',benefit='Полная сила, 4 хода: +4 брони, щит 28% HP; атака ×1.7 с шансом оглушения 21%.',task='Стойкость: удерживайте защиту во время трёх ударов.'),
 'raven':dict(name='🐦‍⬛ Ворон',benefit='Полная сила, 4 хода: +28% уклонения; обычная атака ×1.28 игнорирует броню.',task='Полёт: ведите ворона через три воздушных прохода.'),
}

def count_grade(n,total):return 0 if n==total else 1 if n>=max(2,total-1) else 2 if n else 3

def sight_position(o,t,index):
 q=(t-o['prepare_ms'])/(5000*o['factor']);return 180+40*math.sin(q*6.28+index*1.7),120+15*math.sin(q*4+index)

def sight_grade(c,o):
 acts=events(c,'actions',o,3);n=perfect=0
 for i,a in enumerate(acts):
  if i and a['ms']-acts[i-1]['ms']<260*o['factor']:return 3
  d=math.dist((number(a.get('x')),number(a.get('y'))),sight_position(o,a['ms'],i))
  n+=d<=o['radius'];perfect+=d<=o['centers'][i]
 return 0 if perfect==3 else 1 if n==3 else 2 if n else 3

class HeroGame(Replay,MiniGameSkill):
 game='hero730';PREP=600;TIERS=('Идеально','Хорошо','Частично','Неудача');AI_WEIGHTS=(55,30,12,3)
 def pick_reactor(self,u,t,is_human):return u
 def is_available(self,u):return self.original730.is_available(u)
 def ai_score(self,u,t):return self.original730.ai_score(u,t)
 def ai_choice(self,u,t,tier):return self.original730.ai_choice(u,t,min(2,tier)) if self.key=='werewolf' else None
 def describe_for(self,u):
  if self.key=='werewolf':return self.prompt+' · '+ ' '.join(v['name']+': '+v['benefit'] for v in FORMS.values())
  reward='Поглощение 17/16/11/5 урона на два следующих прямых удара.' if self.key=='stone_flesh' else self.original730.describe_for(u)
  return reward+' · '+self.prompt+' · Полное выполнение сохраняет исходную силу приёма; частичное слабее.'
 def game_params(self,u,t):
  o=self.params(u);o.update(mode=self.mode730,instruction=self.prompt,reward='Полное выполнение — исходный эффект. Частичное — ослабленный эффект.',label=self.name,count=3)
  if self.mode730=='forms':o.update(forms=FORMS,reward='3 успеха: полная сила 4 хода; 2: ослабленная форма 4 хода; 0–1: слабая форма 2 хода.')
  if self.mode730 in ('bones','mud','net','totem','kodo'):
   n=4 if self.mode730=='totem' else 3
   o.update(count=n,sources=[[45+i*270/max(1,n-1),220] for i in range(n)],targets=[[180,178-i*43] for i in range(n)] if n==4 else [[95,120],[180,80],[265,120]],radius=29)
  if self.mode730 in ('sparks','morsels','paws'):o['targets']=[[80,115],[180,75],[280,135]]
  if self.mode730 in ('stone','lunge'):o.update(beats=[round((1450+i*(1600 if self.mode730=='stone' else 2000))*o['factor']) for i in range(3 if self.mode730=='stone' else 2)],good_ms=round((300 if self.mode730=='stone' else 240)*o['factor']),perfect_ms=round((160 if self.mode730=='stone' else 100)*o['factor']))
  if self.mode730=='shadow':o['waves']=[dict(ms=round((1900+i*2100)*o['factor']),lane=random.randrange(3)) for i in range(2)]
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);mode=o['mode'];f=o['factor'];prep=o['prepare_ms']
  if elapsed<prep:return 3
  if mode=='forms':
   form=c.get('form');start=integer(c.get('form_ms'),lo=prep,hi=elapsed)
   if form not in FORMS or start<prep:return 3
   actions=events(c,'actions',o,12);n=0
   if form=='wolf':
    used=set()
    for a in actions:
     i=integer(a.get('part'),hi=2)
     if i<0 or i in used or i!=len(used) or a['ms']<start+400*f:continue
     p=wolf_target(a['ms']-start,i,f)
     if near((number(a.get('x')),number(a.get('y'))),p,30):used.add(i)
    n=len(used)
   elif form=='bear':
    holds=records(c,'holds',12)
    for beat in [start+round(t*f) for t in (1500,2900,4300)]:
     n+=any(isinstance(h,dict) and prep<=integer(h.get('down_ms'),hi=elapsed)<=beat-120*f and beat+120*f<=integer(h.get('up_ms'),hi=elapsed) and 0<integer(h.get('up_ms'),hi=elapsed)-integer(h.get('down_ms'),hi=elapsed)<=1200*f for h in holds)
   else:
    pts=trace(c,o)
    n=sum(beat<=elapsed and abs(at(pts,beat)[0]-x)<=40 for x,beat in [(95,start+round(1600*f)),(255,start+round(3000*f)),(165,start+round(4400*f))]) if pts and integer(c.get('engaged_ms'),hi=elapsed)>=start else 0
   return count_grade(n,3)
  if mode in ('sparks','morsels','paws'):
   used=set()
   for a in events(c,'actions',o,12):
    i=integer(a.get('part'),hi=2)
    if i==len(used) and near((number(a.get('x')),number(a.get('y'))),o['targets'][i],30):used.add(i)
   return count_grade(len(used),3)
  if mode in ('bones','mud','net','totem','kodo'):
   used=set();last=-1
   for a in records(c,'placements',32):
    if not isinstance(a,dict):return 3
    i=integer(a.get('part'),hi=o['count']-1);down=integer(a.get('down_ms'),hi=elapsed);up=integer(a.get('up_ms'),hi=elapsed)
    if i<0 or i in used or down<prep or down<=last or up-down<80*f:continue
    last=up
    if mode=='totem' and i!=len(used):continue
    if near((number(a.get('x0')),number(a.get('y0'))),o['sources'][i],o['radius']) and near((number(a.get('x1')),number(a.get('y1'))),o['targets'][i],o['radius']):used.add(i)
   return count_grade(len(used),o['count'])
  if mode in ('lunge','stone'):
   used=set();gold=good=0
   for a in events(c,'actions',o,len(o['beats'])):
    err,i=min([(abs(a['ms']-t),i) for i,t in enumerate(o['beats']) if i not in used],default=(1e9,-1))
    if i>=0:used.add(i)
    gold+=err<=o['perfect_ms'];good+=err<=o['good_ms']
   return 0 if gold==len(o['beats']) else 1 if good==len(o['beats']) else 2 if good else 3
  if mode=='dawn':
   down=integer(c.get('down_ms'),hi=elapsed);up=integer(c.get('up_ms'),hi=elapsed)
   if down<prep or up<=down:return 3
   q=(up-down)/(2000*f);return 0 if .55<=q<=.85 else 1 if .35<=q<=1.05 else 2 if .18<=q<=1.2 else 3
  if mode=='shadow':
   acts=events(c,'actions',o,8);n=sum(any(w['ms']-800*f<=a['ms']<=w['ms'] and integer(a.get('lane'),hi=2)==w['lane'] for a in acts) for w in o['waves'])
   return 0 if n==2 else 2 if n else 3
  return 3
 def result_data(self,c,o):return {'form':c.get('form')} if self.key=='werewolf' else None
 def apply(self,u,t,tier,data):
  old=self.original730
  if self.key=='werewolf':return old.apply(u,t,(0,1,2,2)[tier],data)
  if isinstance(old,MiniGameSkill):return old.apply(u,t,tier,data)
  if tier==3:return ['Приём не выполнен; ресурс и ход потрачены.']
  sk=copy.copy(old)
  if tier==2:
   if hasattr(sk,'multiplier'):sk.multiplier*=.5
   if self.key=='totem_heal':
    from .effects import Regeneration
    healed=u.heal(int(u.max_hp*.06));u.add_effect(Regeneration(2,max(1,int(u.max_hp*.015))));return ['Неполный тотем: +%s HP, слабая регенерация на 2 хода.'%healed]
   if self.key=='mud_shell':
    from .effects import ShellStance,Burn
    u._effects=[e for e in u.get_effects() if not isinstance(e,Burn)];u.add_effect(ShellStance(1));return ['Неполный панцирь: стойка на 1 ход, горение снято.']
   if hasattr(sk,'effects'):
    fs=[]
    for make in sk.effects:
     def weakened(make=make):
      e=make() if callable(make) else copy.copy(make)
      if hasattr(e,'power'):e.power*=.5
      if hasattr(e,'duration'):e.duration=max(1,math.ceil(e.duration*.5))
      return e
     fs.append(weakened)
    sk.effects=fs
  return sk._perform(u,t)

def wolf_target(ms,i,f):return 80+i*100+12*math.sin(ms/(700*f)+i),105+25*math.sin(ms/(950*f)+i)

MAZES=[[0,1,5,6,10,11,15],[0,4,5,6,7,11,15],[0,4,8,9,10,14,15],[0,1,2,6,10,14,15]]
def stone_variants():
 # Enumerate exact covers of a 3x4 board with connected tetrominoes, then
 # select five different shape sets. Every generated puzzle has a proof.
 from itertools import combinations
 board=set(range(12));shapes=[]
 for cells in combinations(range(12),4):
  reach={cells[0]}
  while True:
   nxt=reach|{b for a in reach for b in cells if abs(a%3-b%3)+abs(a//3-b//3)==1}
   if nxt==reach:break
   reach=nxt
  if len(reach)==4:shapes.append(set(cells))
 out=[];seen=set()
 for a in shapes:
  if 0 not in a:continue
  for b in shapes:
   if a&b:continue
   c=board-a-b
   if c not in shapes:continue
   pieces=[];slots=[]
   for p in (a,b,c):
    x=min(v%3 for v in p);y=min(v//3 for v in p)
    pieces.append(sorted([[v%3-x,v//3-y] for v in p]));slots.append([x,y])
   sig=str(sorted(str(s) for s in pieces))
   if sig not in seen:seen.add(sig);out.append((pieces,slots))
   if len(out)==5:return out
 return out
STONE_VARIANTS=stone_variants()

def fair_rings(f):
 # A constructive control trace proves every ring sequence is physically reachable.
 end=round(8500*f);taps=[];last=round(650*f)
 while last<end:
  taps.append(last);last+=round(random.choice((650,950,1300,1500))*f)
 dummy={'prepare_ms':round(600*f),'factor':f,'rings':[]}
 _,_,_,path=flight(dummy,taps,end);lookup={t:y for t,y in path}
 rings=[]
 for i in range(5):
  ms=round((1850+i*1500)*f/20)*20
  ms=max(dummy['prepare_ms'],ms);sample=dummy['prepare_ms']+round((ms-dummy['prepare_ms'])/20)*20
  y=min(path,key=lambda p:abs(p[0]-sample))[1];rings.append(dict(ms=ms,y=round(y,2)))
 return rings,taps

def install(classes):
 from . import minigames_58 as m58,minigames_59 as m59,games_600 as m600
 from . import rituals_55
 m59.SPECS['aarakocra','talon'].update(limit=9000,hint='Пять колец: взмах поднимает птицу, пауза позволяет снизиться. Все переходы проверены по той же физике; следующая высота видна заранее.',reward='Пять колец: ×1.55 и кровотечение; четыре: ×1.35; 1–3: ×0.9.')
 m58.SPECS['aarakocra','dive'].update(limit=10000,hint='Семь проходов с постепенно сужающимся просветом. Ведите птицу указателем или пальцем; следующие проходы видны заранее.',reward='7 проходов: ×2.15, пробой 40% брони и кровотечение; 5–6: ×1.5; 1–4: ×0.65.')
 m58.SPECS['bluetroll','machete_cross'].update(limit=4800,hint='Два перехвата: ловите левый и правый клинок по центральной точке рукояти. Зелёное — хорошо, золотое — идеально; оценка фиксируется при нажатии.')
 old59=m59.PersonalGame.game_params;old58=m58.ModernGame.game_params;grade59=m59.PersonalGame.tier_from;grade58=m58.ModernGame.tier_from
 def params59(self,u,t):
  o=old59(self,u,t)
  if o['mode']=='updraft':o['rings']=fair_rings(o['factor'])[0]
  if o['mode']=='labyrinth':
   i=random.randrange(4);route=MAZES[i];o.update(variant=i,route=route,walls=[v for v in range(16) if v not in route])
  if o['mode']=='stone_fit':
   i=random.randrange(5);shapes,slots=STONE_VARIANTS[i];order=random.sample(range(3),3);o.update(variant=i,shapes=[shapes[j] for j in order])
  return o
 def params58(self,u,t):
  o=old58(self,u,t);f=o['factor']
  if (u.type_key,self.key)==('aarakocra','dive'):
   xs=random.choice(([85,155,240,285,210,130,75],[260,180,100,65,140,220,285],[140,225,280,210,120,65,145],[220,135,70,150,235,285,200]));o['gates']=[dict(x=x,ms=round((1550+i*1180)*f),radius=round(45-i*4)) for i,x in enumerate(xs)]
  if o['mode']=='machete':o.update(returns=[dict(hand=0,ms=round(2050*f)),dict(hand=1,ms=round(3500*f))],perfect_ms=round(110*f),good_ms=round(230*f))
  return o
 def tier59(self,c,o):
  if o['mode']=='updraft':
   elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']) if isinstance(c,dict) else -1
   taps=[a['ms'] for a in events(c,'clicks',o,60)];n=sum(flight(o,taps,max(0,elapsed))[2]);return (0 if n==5 else 1 if n>=4 else 2 if n else 3) if taps and elapsed>=o['prepare_ms'] else 3
  return grade59(self,c,o)
 def tier58(self,c,o):
  if o['mode']=='steer' and len(o['gates'])==7:
   pts=trace(c,o);elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);n=sum(g['ms']<=elapsed and abs(at(pts,g['ms'])[0]-g['x'])<=g['radius'] for g in o['gates']) if pts else 0
   return 0 if n==7 else 1 if n>=5 else 2 if n else 3
  return grade58(self,c,o)
 m59.PersonalGame.game_params=params59;m59.PersonalGame.tier_from=tier59;m58.ModernGame.game_params=params58;m58.ModernGame.tier_from=tier58
 def machete_metrics(c,o):
  actions=events(c,'actions',o,2);perfect=good=0
  for e in o['returns']:
   err=min([abs(a['ms']-e['ms']) for a in actions if integer(a.get('hand'),hi=1)==e['hand']],default=1e9)
   perfect+=err<=o.get('perfect_ms',100*o['factor']);good+=err<=o.get('good_ms',210*o['factor'])
  return (0 if perfect==2 else 1 if good==2 else 2 if good else 3),2-good
 m58.machete_metrics=machete_metrics
 # Existing aimed-shot rewards stay unchanged, but all three attempts matter.
 original_sight=m600.ReviewGame.game_params;original_sight_tier=m600.ReviewGame.tier_from
 def sight_params(self,u,t):
  o=original_sight(self,u,t)
  if o['mode']=='sight':o.update(shots=3,centers=[30,23,16],radius=48)
  return o
 def sight_tier(self,c,o):return sight_grade(c,o) if o['mode']=='sight' else original_sight_tier(self,c,o)
 old_sight_apply=m600.ReviewGame.apply
 def sight_apply(self,u,t,tier,data):
  if self.mode600=='sight' and tier==2:
   sk=copy.copy(self.original600);sk.multiplier*=.5;return sk._perform(u,t)
  return old_sight_apply(self,u,t,tier,data)
 m600.ReviewGame.apply=sight_apply
 m600.ReviewGame.game_params=sight_params;m600.ReviewGame.tier_from=sight_tier
 for key in (('archer','aimed_shot'),('ogre','ogre_spear')):m600.NEW[key]=('sight',6500,'Три последовательные мишени. Внутренний круг уменьшается: 30 → 23 → 16. Три попадания дают исходный эффект.',3)
 # Direct skill factories are adapted last, after all earlier hero fixes.
 for kind,C in classes.items():
  factory=C._create_skills
  def create(self,_factory=factory,_kind=kind):
   out=[]
   for old in _factory(self):
    if _kind=='beastlord' and old.key=='twin_axes':continue
    if _kind=='beastlord' and old.key=='call_beast':old.cost=28
    if _kind=='getou' and old.key=='raise_bones':old.TIME_LIMIT_MS+=1000
    config=CONFIG.get((_kind,old.key))
    if not config:out.append(old);continue
    mode,limit,hint=config;new=HeroGame(old.key,old.name,hint,cost=old.cost,cooldown=old.cooldown,icon=old.icon)
    for attr in ('group','min_turn','once_per_battle'):
     setattr(new,attr,getattr(old,attr,None))
    new.deals_damage=getattr(old,'deals_damage',hasattr(old,'multiplier'))
    new.original730=old
    for attr in ('effects','accuracy','multiplier','effect_chance','armor_pierce','lifesteal'):
     if hasattr(old,attr):setattr(new,attr,getattr(old,attr))
    new.mode730=mode;new.TIME_LIMIT_MS=limit;new.prompt=hint;new.description=hint
    if mode=='forms':new.AI_WEIGHTS=(22,45,25,8)
    out.append(new)
   return out
  C._create_skills=create
 for key in CONFIG:m600.STARS[key]=3 if key==('ghoul','lunge') else 1 if key!=('pagan','werewolf') else 2
 for key in (('aarakocra','talon'),('aarakocra','dive')):m600.STARS[key]=3
