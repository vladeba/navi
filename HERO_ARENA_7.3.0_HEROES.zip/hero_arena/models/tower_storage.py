"""Persist column progress without saving unrelated pending arena/story changes."""
import copy,json,os,shutil,tempfile

def save_columns(service,player):
 path=service.save_path
 if not os.path.exists(path):
  # First account save establishes a complete, loadable profile.
  return service.save()
 with open(path,encoding='utf-8') as f:data=json.load(f)
 if not isinstance(data,dict) or any(not isinstance(data.get(k),list) for k in ('players','heroes','items')):
  raise ValueError('Не удалось сохранить столбы: файл аккаунтов повреждён.')
 saved=next((p for p in data['players'] if p['id']==player.id),None)
 if saved is not None and saved['username']!=player.username:
  raise ValueError('Сначала загрузите сохранённые аккаунты: этот номер уже занят другим профилем.')
 if saved is None:
  saved=player.to_save_dict();saved['heroes']=[i for i in saved['heroes'] if any(h['id']==i for h in data['heroes'])];data['players'].append(saved)
 saved['columns']=copy.deepcopy(player.columns)
 run=saved['columns'].get('run')
 if run and run['status']=='active':run['status']='ready';run['battle_id']=None
 folder=os.path.dirname(path) or '.';os.makedirs(folder,exist_ok=True)
 fd,tmp=tempfile.mkstemp(prefix='.columns-',suffix='.json',dir=folder)
 try:
  with os.fdopen(fd,'w',encoding='utf-8') as f:
   json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
  shutil.copy2(path,tmp+'.bak');os.replace(tmp+'.bak',path+'.bak');os.replace(tmp,path)
 finally:
  for name in (tmp,tmp+'.bak'):
   if os.path.exists(name):os.unlink(name)
