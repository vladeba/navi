"""Isolated column encounters, using the existing hero combat engine."""
import random,copy,math
from .boss_action720 import ActionGame
from .boss_encounters720 import EPISODES,episode
from .battle import Battle
from .character import Character
from .skills import Skill,DamageSkill,HealSkill
from .effects import Effect,Shield,DamageReduction,Announcement,Weakened,Stun,StunWard
from .tower_data import BOSSES,GARRISONS,SCENES,background,portrait,game
from .tower_games import TowerGame,KnightGame,CounterGame,offensive,pure_damage

class BossResolve(StunWard):name='Стойкость босса';icon='⛓'

class GuardShield(Shield):name='Щит пехоты';icon='🛡'
class ThroneShield(Shield):name='Щит Стража Разлома';icon='🛡'
class GuardCover(DamageReduction):
 name='Прикрытие щитоносцев';icon='🛡'
 def armor_bonus(self):return .5
class InfantryBreak(Effect):
 name='Натиск пехоты';icon='⚔'
 def armor_bonus(self):return -.5
class GuardHeal(Effect):
 name='Эльфийское восстановление';icon='🌿';positive=True
 def on_turn_start(self,owner):
  amount=owner.heal(round(owner.max_hp*.03));return [f'🌿 Эльфы-целители: восстановлено {amount} HP герою {owner.name}.']+owner.pop_events()
class ArcherBleed(Effect):
 name='Кровотечение гарнизона';icon='🩸'
 def __init__(self,battle,target):self.battle=battle;self.target=target;super().__init__(3,round(target.max_hp*.005))
 def tick(self):pass
 def is_expired(self):return self.battle.hero2 is not self.target or self.battle.garrison_bleed<=0
 def to_dict(self):
  d=super().to_dict();d['duration']=self.battle.garrison_bleed;d['help']='Кровотечение после залпа лучников: по 0,5% максимального HP в конце раунда.';return d
class KnightHeal(Skill):
 def _perform(self,u,t):return [f'🩸 Проклятая стойкость: {u.name} восстанавливает {u.heal(18)} HP.']+u.pop_events()

class TowerEnemy(Character):
 hero_class='Демон';role='warrior';creatable=False
 def __init__(self,key):
  self.boss_key=key;self.type_key=key;self.spec=BOSSES[key];d=self.spec
  if key=='deyron_knight':self.hero_class='Воин'
  elif key=='succubus':self.hero_class='Суккуб'
  super().__init__(d['name'],max_hp=d['hp'],base_damage=d['damage'],armor=d['armor'],speed=d['speed'],dodge=.03,crit_chance=.07,max_energy=100,start_energy=100,energy_regen=18)
 def add_effect(self,effect):
  if isinstance(effect,Stun) and not self.spec.get('minor') and not self.spec.get('servant'):
   effect=copy.copy(effect);effect.duration=1;accepted=super().add_effect(effect)
   if accepted:super().add_effect(BossResolve(4,0))
   return accepted
  return super().add_effect(effect)
 def configure_arena(self):self._arena=False;self.story=False
 def take_damage(self,amount,ignore_armor=False,attacker=None):
  if getattr(getattr(self,'_battle',None),'waiting_boss',None) is self:
   self._events.append('Тассирион вне сцены: урон не проходит.');return 0
  return super().take_damage(amount,ignore_armor,attacker)
 @property
 def image(self):
  if self.boss_key=='gorr_gall' and getattr(getattr(self,'_battle',None),'phase',1)==3:return portrait('gorr_true')
  if self.boss_key=='gnuss':return '/static/images/story/gnuss.jpg'
  return portrait(self.boss_key)
 def _create_skills(self):
  key=self.boss_key;d=self.spec
  if key in ('deyron_knight','deyron_demon'):
   skills=[DamageSkill('attack','Удар проклятого меча','Обычная атака',accuracy=.97,icon='⚔'),DamageSkill('knight_lunge','Рыцарский выпад','Удар ×1,3, пробитие 20% брони',multiplier=1.3,armor_pierce=.2,cost=12,cooldown=2,icon='🗡'),DamageSkill('knight_cleave','Проклятое рассечение','Тяжёлый удар ×1,6',multiplier=1.6,cost=18,cooldown=3,icon='⚔'),KnightHeal('knight_heal','Проклятая стойкость','Восстановить 18 HP',cost=22,cooldown=5,icon='🩸'),DamageSkill('knight_pommel','Удар навершием','Удар ×0,9 и ослабление на один ход',multiplier=.9,effect=lambda:Weakened(2,10),cost=10,cooldown=3,icon='✊')]
   for k,spec in zip(('knight_runes','knight_assault','knight_ward'),EPISODES['deyron_knight']):skills.append(ActionGame(k,spec['name'],spec,key))
   if key=='deyron_demon':skills.append(ActionGame('demon_hand','Рука демона',EPISODES['deyron_demon'][0],key))
   if key=='deyron_demon':
    for s in skills:
     if s.key in {'attack','knight_lunge','knight_cleave','knight_pommel'}:s.name={'attack':'Удар демонической рукой','knight_lunge':'Проклятый выпад','knight_cleave':'Раздирающий взмах','knight_pommel':'Удар когтями'}[s.key]
   return skills
  skills=[DamageSkill('attack',d.get('attacks',['Удар'])[0],'Обычная атака босса',accuracy=.97,icon='⚔')]
  for i,name in enumerate(d.get('attacks',[])[1:]):skills.append(DamageSkill('hit_'+str(i),name,'Тяжёлый приём босса',multiplier=(1.25,1.4,1.6)[i%3],armor_pierce=.25 if i==0 else 0,accuracy=.92,cost=8,cooldown=0,icon='🪓'))
  for i,spec in enumerate(d.get('games',[])):skills.append(ActionGame('trial_'+str(i),spec['name'],spec,key))
  return skills
 def choose_action(self,target):
  key=self._planned_action(target)
  valid=key in self.skills and self.can_use(self.skills[key])
  if valid and self.boss_key=='gorr_gall' and key=='trial_5':self._battle.final_trial_used=True
  return key if valid else 'attack'
 def _planned_action(self,target):
  b=self._battle;n=b.boss_actions
  if self.boss_key=='deyron_demon' and (n+1)%6==0:return 'demon_hand'
  if self.boss_key in ('deyron_knight','deyron_demon'):
   keys=['attack','knight_runes','knight_lunge','knight_ward','knight_cleave','knight_assault','knight_heal','knight_pommel']
   key=keys[n%len(keys)];return key if self.can_use(self.skills[key]) else 'attack'
  trials=[s for s in self.skills.values() if isinstance(s,TowerGame)]
  if self.boss_key=='succubus':return trials[0].key if (n+1)%4==0 else ['attack','hit_0','hit_1'][n%3]
  cadence=3 if self.boss_key in ('gnuss','gnuss_true','gorr_gall') else 2
  if trials and n%cadence:
   if self.boss_key=='gorr_gall':
    allowed=trials[:2] if b.phase==1 else trials[:4] if b.phase==2 else trials
    if b.phase==3 and not b.final_trial_used:return trials[-1].key
    allowed=[s for s in allowed if s is not trials[-1]]
   else:allowed=trials
   return allowed[((n-n//3-1) if cadence==3 else n//2)%len(allowed)].key
  ordinary=[s for s in self.skills.values() if not isinstance(s,TowerGame)]
  return ordinary[(n//cadence)%len(ordinary)].key
 def to_dict(self):
  d=super().to_dict()
  if hasattr(self,'minions'):
   d['summons']=[dict(id=g.id,name=g.name,hp=g.hp,max_hp=g.max_hp,alive=g.is_alive(),image=portrait('servant'),icon='👹',damage=5 if g.kind=='executioner' else 0,about='Дополнительный удар каждые 3 раунда' if g.kind=='executioner' else 'Создал щит владыке',slot=i,kind='demon',quality=0,lifetime=999) for i,g in enumerate(self.minions)]
  return d

class TowerBattle(Battle):
 MAX_ROUNDS=1000
 def __init__(self,hero,foe,run,step,garrison=None,checkpoint=0):
  super().__init__(hero,foe,mode='manual',ai_ids=[foe.id],items={})
  self.run_id=run['id'];self.player_id=run['player_id'];self.column=run['column'];self.step=step
  self.boss_key=getattr(foe,'boss_key',None);self.is_boss=bool(self.boss_key and not BOSSES[self.boss_key].get('minor') and not BOSSES[self.boss_key].get('servant'))
  self.FATIGUE_STEP=0 if self.is_boss else .025 if self.boss_key in ('deyron_knight','succubus') else .05
  self.FATIGUE_FROM=10**8 if self.is_boss else 22
  self.arena_rules='normal';self.garrison=garrison if self.is_boss else None;self.boss_actions=0;self.player_actions=0;self.phase=1;self.final_trial_used=False
  self.mark=0;self.mark_kind=None;self.seal=0;self.mark_at=-1;self.scene=None;self.scene_serial=0;self.dialogue=[];self.dialogue_serial=0
  self.boss_rounds=0;self.called=set();self.waiting_boss=None;self.summon_return=False;self.pending_summon=False
  self.garrison_bleed=0;self.last_potion_round=0;self.guards=[];self.phase_checkpoint=checkpoint;self.result_applied=False
  self._started=False;self._round_processed=0;self.attack_selected=False;self._support_pending=False;self.zaferon_shards=0;self.zaferon_found=set();self.zaferon_ready=False;self.midpoint_seen=False;self.pressure_from=0
  self.tower_pressure720=self.is_boss
 @property
 def boss_heal_factor(self):return max(.50,.85-max(0,self.round-self.pressure_from-10)*.015)
 @property
 def arena_key(self):
  if self.boss_key=='gorr_gall':return 'gorr_'+str(self.phase)
  if self.boss_key=='gnuss' and self.phase==2:return 'gnuss_true'
  return BOSSES[self.boss_key]['arena'] if self.boss_key else ('euron','zaferon','deyron_knight','garrarat','gorr_1')[self.column-1]
 @staticmethod
 def _guess_kind(text):
  if any(x in str(text) for x in ('гарнизона','Пехотинцы:','Щитоносцы прикрывают','Эльфы-целители:')):return 'support'
  return Battle._guess_kind(text)
 def say(self,text):
  if sum(x['text']==text for x in self.dialogue)>=2:return
  if self.dialogue and self.dialogue[-1]['text']==text and self.round-self.dialogue[-1]['round']<4:return
  self.dialogue_serial+=1;self.dialogue.append(dict(id=self.dialogue_serial,text=text,round=self.round));self.dialogue=self.dialogue[-8:]
  self._add_log(text,'speech',actor=self.hero2)
  self.log[-1]['speaker']=self.hero2.name
 def set_scene(self,title,text,quote='',kind='intro'):
  self._scene_current=self.current if kind=='intro' else None
  self.scene_serial+=1;self.scene=dict(id=self.scene_serial,title=title,text=text,quote=quote,kind=kind,background=background(self.arena_key),image=self.hero2.image)
  self.current=None
 def start(self):
  # Freeze at the introduction, before any combat action can run.
  super().start();self.hero1.restore_energy(self.hero1.max_energy);self._started=True
  if self.phase_checkpoint and self.boss_key=='gnuss':self._gnuss_transform(checkpoint=True);self._restart_checkpoint_clock()
  elif self.phase_checkpoint and self.boss_key=='gorr_gall':self._gorr_transform(2,checkpoint=True);self._restart_checkpoint_clock()
  elif self.boss_key:
   d=BOSSES[self.boss_key]
   if self.boss_key=='deyron_demon':
    title,text,quote=SCENES['deyron_demon'];self.set_scene(title,text,quote)
    self.scene['frames']=[dict(title='Проклятие пробуждается',text='Дейрон опускает меч. Тёмная сила разрывает рыцарскую броню.',quote='Клинок мне больше не нужен.',image=portrait('deyron_knight'),background=background('deyron_knight')),dict(self.scene)]
   else:self.set_scene(d['name'],'Ступень '+str(self.step)+' · '+('Босс' if self.is_boss else 'Особый противник'),d['intro'])
  return self
 def _restart_checkpoint_clock(self):
  self.round=0;self._round_processed=0;self._support_pending=False;self.log=[];self._add_log('Контрольная точка: вторая стадия.','info')
 def resume_scene(self,serial):
  if not self.scene or serial!=self.scene['id']:raise ValueError('Эта сцена уже завершена')
  actor=getattr(self,'_scene_current',None);self.scene=None;self._scene_current=None
  if self.finished:return
  if self._support_pending:
   self._support_pending=False;self._round_support()
   if self._check_end():return
  if actor:self.current=actor
  else:self._order=[];self._index=0;self.current=None;self._advance()
  self.run_ai()
 def _new_round(self):
  if self.round and self._round_processed<self.round:
   self._round_processed=self.round;self._round_support()
   if self._check_end() or self.scene:return
   if self.waiting_boss is None and self.boss_key=='tassirion':
    self.boss_rounds+=1
    if self.boss_rounds in (7,14,20) and self.boss_rounds not in self.called:
     self.called.add(self.boss_rounds);self._call_servant();return
  super()._new_round()
  if self.is_boss:self.hero2._base_damage=BOSSES[self.hero2.boss_key]['damage']*min(1.65,1+max(0,self.round-self.pressure_from-10)*.025)
 def _advance(self):
  if self.scene or self.pending or self.finished:return
  if self._check_end():return
  if self.mark_kind=='gnuss' and self.mark:self.current=None;return
  while not self.finished and not self.scene:
   if self._index>=len(self._order):
    if self.round>=self.MAX_ROUNDS:
     self._add_log('Предел безопасности встречи: бой завершён поражением игрока.','info');self._finish(self.hero2);return
    self._new_round()
    if self.finished or self.scene:return
   actor=self._order[self._index];logs,can_act=actor.start_turn();self._log_many(logs,actor=actor)
   if self._check_end():return
   if can_act:self.current=actor;return
   if hasattr(actor,'on_skip'):actor.on_skip()
   if hasattr(actor,'minions'):self._log_many(actor.summon_act(self.opponent(actor)),actor,self.opponent(actor))
   self._finish_bombs(actor)
   if self._check_end():return
   self._index+=1
 def run_ai(self):
  count=0
  while not self.finished and not self.pending and not self.scene and self.current and self.current.id in self.ai_ids:
   self.play_turn();count+=1
   if count>100:raise RuntimeError('Цикл ходов босса прерван')
 def play_turn(self,skill_key=None,target_id=None):
  if self.scene:raise ValueError('Сначала завершите сцену')
  if self.current is self.hero1:
   if skill_key is None:raise ValueError('В столбах действие выбирает игрок')
   if str(skill_key).startswith('item:'):raise ValueError('В столбах предметы запрещены')
   if target_id not in (None,'hero'):self._selected_target(self.hero1,target_id,False)
   s=self.hero1.get_skill(skill_key) if not str(skill_key).startswith('dismiss:') else None
   self.attack_selected=bool(s and offensive(s))
   if self.mark and self.mark_kind!='gnuss' and self.waiting_boss is None:
    value=self.mark;self.mark=0
    if self.attack_selected:
     amount=pure_damage(self.hero2,self.hero2.max_hp*value,self.hero1);self._add_log(f'🎯 Метка пробита: {amount} урона по {self.hero2.name}.','attack',self.hero1,self.hero2)
     self.say('Я РАЗОРВУ ТЕБЯ НА КУСКИ, СМЕРТНЫЙ!' if self.boss_key=='garrarat' else 'Моя печать… СМЕРТНЫЙ!')
     if self._check_end():return
   self.player_actions+=1
  super().play_turn(skill_key,target_id)
 def _after_action(self,actor,target):
  self._guard_rewards()
  if actor is self.hero2:
   self.boss_actions+=1
   lines=BOSSES.get(self.boss_key,{}).get('lines',[])
   if lines and self.boss_actions in (4,10,18,28):self.say(lines[(self.boss_actions//6)%len(lines)])
  if self.boss_key and not self.midpoint_seen and self.hero2.hp<self.hero2.max_hp*.55 and not self.scene and self.boss_key not in ('gnuss','gorr_gall'):
   self.midpoint_seen=True;self.set_scene(self.hero2.name+' · ЯРОСТЬ','Противник меняет стойку. Площадка содрогается.',BOSSES[self.boss_key].get('lines',['Теперь попробуй выжить!'])[-1],'midpoint')
  super()._after_action(actor,target)
 def _guard_rewards(self):
  for g in self.guards:
   if not g.is_alive() and not getattr(g,'rewarded',False):
    g.rewarded=True;lines=[];self._add_seal(2,lines)
    if g.kind=='guard':self.hero2._effects=[e for e in self.hero2._effects if not isinstance(e,ThroneShield)];lines.append('Щит Стража Разлома исчез.')
    self._log_many([f'⚔ {g.name} повержен.']+lines,self.hero1,self.hero2)
 def tower_post_games(self,actor,target):
  if actor is not self.hero1 or self.waiting_boss is not None:return []
  if self.boss_key=='euron' and self.player_actions%5==0:
   self.say('Попробуй достать чемпиона!');s=ActionGame('boss_opening','Пробить доспех чемпиона',episode('Пробить доспех','core_strike',8,3,0),'euron','euron');return [(s,self.hero1,self.hero2)]
  if self.boss_key=='zaferon' and self.zaferon_ready:
   self.zaferon_ready=False;self.zaferon_shards=0;self.zaferon_found.clear();self.say('Ты собрал осколки… Но сумеешь ли замкнуть печать?')
   s=ActionGame('boss_opening','Соединить и разбить печать',episode('Печать опустошения','seal_forge',15,0,0),'zaferon','zaferon');return [(s,self.hero1,self.hero2)]
  return []
 def defense_result(self,skill,tier,hits,total):
  lines=[]
  if self.boss_key=='zaferon' and tier<2:
   if skill.key not in self.zaferon_found:self.zaferon_found.add(skill.key);self.zaferon_shards=len(self.zaferon_found)
   self.zaferon_ready=self.zaferon_shards>=6;lines.append(f'✦ Собрано печатей: {self.zaferon_shards}/6. Каждая добывается в отдельном испытании.')
  if self.boss_key=='deyron_demon' and skill.key=='demon_hand':
   value=pure_damage(self.hero2,self.hero2.max_hp*.01*hits,self.hero1);lines.append(f'✊ Перегрузка руки демона: {value} урона Дейрону за {hits} уклонений.')
  if self.boss_key in ('garrarat','tassirion') and tier<3:
   self.mark=max(self.mark,(.08,.05,.02,0)[tier]);self.mark_kind='death';lines.append(f'🎯 Метка Смерти: следующее атакующее действие нанесёт ещё {round(self.mark*100)}% HP босса.')
  if self.boss_key=='gnuss' and self.phase==2 and tier<3:self.mark=1;self.mark_kind='gnuss';lines.append('🎯 Открыта метка пробития. Выберите свою атакующую мини-игру.')
  if self.boss_key=='gorr_gall' and tier<3:
   self._add_seal((3,2,1,0)[tier],lines)
   if skill.key=='trial_5' and tier==0:
    value=pure_damage(self.hero2,self.hero2.max_hp*.15,self.hero1);lines.append(f'💥 Ядро Последнего Разлома разбито: {value} урона Горр-Галлу!');self.say('НЕТ! ТЫ НЕ ЗАКРОЕШЬ МОИ ВРАТА!')
  return lines

 def _add_seal(self,amount,lines):
  self.seal=min(6,self.seal+amount)
  if self.seal>=6:
   self.seal=0;self.mark=max(self.mark,.10);self.mark_kind='death';lines.append('🎯 Власть Горр-Галла сломлена — атакуй! Дополнительный урон 10% HP босса.')
 def _round_support(self):
  h=self.hero1;t=self.hero2
  if self.is_boss and self.round%10==0 and self.last_potion_round!=self.round:
   self.last_potion_round=self.round;amount=h.heal(round(h.max_hp*.12))
   detail=f'🧪 {h.name}: +{amount} HP.' if amount else f'🧪 {h.name}: '+('здоровье уже полное.' if h.hp==h.max_hp else 'лечение заблокировано.')
   self._log_many([Announcement('🧪 Получено зелье арены — автоматически использовано.'),detail]+h.pop_events(),h,h)
  if self.garrison_bleed:
   amount=pure_damage(t,t.max_hp*.005,h);self.garrison_bleed-=1;self._add_log(f'🏹 Кровотечение от залпа гарнизона: {amount} урона по {t.name}.','dot',h,t)
  if self.garrison and self.round%GARRISONS[self.garrison]['period']==0:
   k=self.garrison
   if k=='archers':
    basis=self.waiting_boss.max_hp if self.waiting_boss else t.max_hp;amount=pure_damage(t,min(basis*.02,t.max_hp*.10),h);self.garrison_bleed=2;t.add_effect(ArcherBleed(self,t))
    self._add_log(f'🏹 Залп стрел гарнизона лучников: {amount} урона по {t.name}, кровотечение.','support',h,t)
   elif k=='infantry':
    h.add_effect(GuardShield(3,round(h.max_hp*.10)));t.add_effect(InfantryBreak(3));amount=t.take_damage(max(4,round(h.get_damage()*.5)),attacker=h)
    self._log_many([f'⚔ Пехотинцы: щит +{round(h.max_hp*.10)}, {amount} урона по {t.name}, броня врага −0,5.']+t.pop_events(),h,t)
   elif k=='shields':h.add_effect(GuardCover(3,20));self._add_log('🛡 Щитоносцы прикрывают героя: −20% урона, +0,5 брони на 2 хода.','support',h,h)
   else:h.add_effect(GuardHeal(3));self._add_log('🌿 Эльфы-целители: лечение по 3% HP в начале трёх следующих ходов.','support',h,h)
  for g in self.guards:
   can_act=False
   if g.is_alive():
    lines,can_act=g.start_turn();self._log_many(lines,g,self.hero1)
   if g.is_alive() and can_act and g.kind=='executioner' and self.round%3==0:
    amount=h.take_damage(7,attacker=t);self._log_many([f'⚔ Палач Преисподней: {amount} урона по {h.name}.']+h.pop_events(),t,h)
  self._guard_rewards()
 def _bind_enemy(self,enemy):
  self.garrison_bleed=0
  self.hero2=enemy;enemy._battle=self;enemy.opponent=self.hero1;self.hero1.opponent=enemy;self.ai_ids={enemy.id};self._hp_seen[str(enemy.id)]=enemy.hp
  self._order=[];self._index=0;self.pending=None;self._post_action609=None;self._transition_clock()
 def _transition_clock(self):
  if self.round and self._round_processed<self.round:self._round_processed=self.round;self._support_pending=True
 def _call_servant(self):
  self.say('Слуга! Покажи ему, как умирают враги Преисподней!')
  self.waiting_boss=self.hero2;enemy=TowerEnemy('servant');enemy.reset();self._bind_enemy(enemy)
  self.set_scene('Призыв слуги','Тассирион отступает. Здоровье и ресурс игрока сохраняются.','По воле военачальника!','summon')
 def _gnuss_transform(self,checkpoint=False):
  old_image=self.hero2.image
  self.phase=2;self.phase_checkpoint=2;self.pressure_from=self.round;self.hero1.reset();self.hero1.restore_energy(self.hero1.max_energy)
  enemy=TowerEnemy('gnuss_true');enemy.reset();self._bind_enemy(enemy);self.mark=0;self.mark_kind=None
  title,text,quote=SCENES['gnuss_true'];self.set_scene(title,text,quote,'phase')
  if not checkpoint:self.scene['frames']=[dict(title='Оболочка Гнусса повержена',text='Огонь затихает. Из-под разрушенного святилища доносится смех.',quote='Ты погасил лишь оболочку…',image=old_image,background=background('gnuss')),dict(self.scene)]
 def _gorr_transform(self,phase,checkpoint=False):
  old_image=self.hero2.image;old_background=background(self.arena_key)
  self.phase=phase;self.phase_checkpoint=2
  if checkpoint:self.hero2.hp=round(self.hero2.max_hp*.70);self.hero1.reset();self.hero1.restore_energy(self.hero1.max_energy)
  else:
   self.hero1._effects=[e for e in self.hero1.get_effects() if e.positive]
   healed=self.hero1.heal(round(self.hero1.max_hp*.20));self.hero1.restore_energy(20);self._add_log(f'🩸 Передышка между фазами: {self.hero1.name} +{healed} HP, +20 ресурса.','heal',self.hero1,self.hero1)
  if phase==2:
   self.guards=[]
   for i,(name,kind) in enumerate([('Страж Разлома','guard'),('Палач Преисподней','executioner')]):
    g=Character(name,max_hp=36,base_damage=5,armor=1,speed=3);g.is_minion=True;g.kind=kind;g.id=f's{self.hero2.id}_{i}';g.expires_round=9999;g.lifetime=999;g._battle=self;g.opponent=self.hero1;self.guards.append(g)
   self.hero2.minions=self.guards;self.hero2.add_effect(ThroneShield(999,60))
  if phase==3:
   self.hero2._base_damage*=1.1;self.hero2.armor=max(0,self.hero2.armor-.6)
  self.pending=None;self._post_action609=None;self._order=[];self._index=0;self._transition_clock()
  title,text,quote=SCENES['gorr_'+str(phase)];self.set_scene(title,text,quote,'phase')
  if not checkpoint:self.scene['frames']=[dict(title='Врата раскрываются' if phase==2 else 'Последняя ярость',text='Горр-Галл вонзает оружие в площадку.' if phase==2 else 'Горр-Галл срывает повреждённую броню. Камень под ногами раскалывается.',quote='Легионы! Ваш владыка требует крови!' if phase==2 else 'ХВАТИТ! Я САМ ОБРАЩУ ТЕБЯ В ПЕПЕЛ!',image=old_image,background=old_background),dict(self.scene)]
 def _check_end(self):
  if self.finished:return True
  if not self.hero1.is_alive():self._finish(self.hero2);return True
  if not self.hero2.is_alive():
   if self.waiting_boss is not None:
    boss=self.waiting_boss;self.waiting_boss=None;self._bind_enemy(boss);self.mark=max(self.mark,.08);self.mark_kind='death'
    self.set_scene('Слуга повержен','Тассирион возвращается. Открыта максимальная метка: 8% HP босса.','Ты ещё не победил военачальника.','return');return True
   if self.boss_key=='gnuss' and self.phase==1:self._gnuss_transform();return True
   self._finish(self.hero1);return True
  if self.boss_key=='gorr_gall':
   percent=self.hero2.hp/self.hero2.max_hp
   if self.phase==1 and percent<=.70:self._gorr_transform(2);return True
   if self.phase==2 and percent<=.35:self._gorr_transform(3);return True
  return False
 def _finish(self,winner):
  self.finished=True;self.current=None;self.pending=None;self.scene=None;self.winner=winner;self.draw=winner is None
  if self.boss_key and winner is self.hero1:self.say(BOSSES[self.boss_key]['defeat'])
  elif self.boss_key:self.say('Твой путь завершён, смертный.')
  self._add_log('🏆 Победа!' if winner is self.hero1 else 'Вы проиграли','win',winner)
  if self.boss_key:
   text='Противник повержен. Восхождение продолжается.' if winner is self.hero1 else 'Жизнь потеряна. Противник ждёт следующей попытки.'
   if self.boss_key=='gorr_gall' and winner is self.hero1:text='Раскол престолов рассыпается. Врата схлопываются, и Горр-Галл исчезает в бездне. Последний столб покорён.'
   self.set_scene('Победа' if winner is self.hero1 else 'Поражение',text,BOSSES[self.boss_key]['defeat'] if winner is self.hero1 else 'Твой путь завершён, смертный.','defeat')
   if self.boss_key=='gorr_gall' and winner is self.hero1:self.scene['frames']=[dict(self.scene),dict(title='Последний Разлом закрыт',text='Клинок рассыпается. Врата схлопываются, и владыка исчезает в бездне. На арене наступает тишина.',quote='',image='',background=background('gorr_3'))]
  self._capture_arena_result()
 def counter_choices(self):
  result=[dict(key=s.key,name=s.name,icon=s.icon,description=s.description) for s in self.hero1.skills.values() if s.reaction=='minigame' and offensive(s)]
  return result or [dict(key='fallback',name='Контрудар',icon='⚔',description='Универсальная бесплатная мини-игра пробития.')]
 def counter(self,key):
  if not self.mark or self.mark_kind!='gnuss' or self.pending or self.scene:raise ValueError('Сейчас нет метки пробития')
  if key not in [s['key'] for s in self.counter_choices()]:raise ValueError('Выберите атакующую мини-игру героя')
  if key=='fallback':s=ActionGame('tower_counter','Контрудар',episode('Контрудар','core_strike',8,3,0),'gnuss_true','fallback')
  else:s=CounterGame(self.hero1.skills[key])
  self.mark=0;self.mark_kind=None;o=s.public_options(self.hero1,self.hero2)
  self.pending=dict(skill=s,actor=self.hero1,target=self.hero2,reactor=self.hero1,options=o,secret=s.secret_pick(o),tower_bonus=True)
 def react(self,choice):
  if self.pending and self.pending.get('tower_bonus'):
   p=self.pending;s=p['skill'];c=s.check_choice(choice);self.pending=None
   self._log_many(s.resolve(self.hero1,self.hero2,c,p['secret']),self.hero1,self.hero2)
   if not self._check_end():self._advance()
   return
  super().react(choice)
 def to_dict(self):
  d=super().to_dict();d['kind']='tower';d['arena_rules']='normal';d['available_items']=[]
  d['tower']=dict(run_id=self.run_id,column=self.column,step=self.step,boss=self.is_boss,boss_key=self.boss_key,phase=self.phase,background=background(self.arena_key),scene=self.scene,
   garrison=self.garrison,garrison_in=GARRISONS[self.garrison]['period']-self._round_processed%GARRISONS[self.garrison]['period'] if self.garrison else None,
   potion_in=10-self._round_processed%10 if self.is_boss else None,mark=self.mark,mark_kind=self.mark_kind,seal=self.seal,dialogue=self.dialogue,
   counter_choices=self.counter_choices() if self.mark_kind=='gnuss' and self.mark else [],checkpoint=self.phase_checkpoint,waiting_boss=bool(self.waiting_boss),shards=self.zaferon_shards,healing_factor=max(.50,.85-max(0,self.round-self.pressure_from-10)*.015) if self.is_boss else 1,rage=min(1.65,1+max(0,self.round-self.pressure_from-10)*.025) if self.is_boss else 1)
  return d
