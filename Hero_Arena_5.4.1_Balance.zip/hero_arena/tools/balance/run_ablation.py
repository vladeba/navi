"""Paired-seed ablation: each ability disabled for one fighter on both sides."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import json
from pathlib import Path
import math
import sys
import time

import run_matrix as r

SKILLS={
 'orc':['war_cry','chop'],
 'darkknight':['fear_aura','cursed_slash','plague','blood_harvest'],
 'minotaur':['stomp','unbreakable'],
 'mage':['snowfall'],
 'samurai':['iai_flash','iaijutsu','shunpo','blade_dance'],
 'shade':['void_whisper','dark_touch','dissolve'],
 'ranger':['mark'],
 'pandaren':['spin','keg_smash','douse'],
 'paladin':['bless','shield_bash','smite'],
 'croc':['mud_shell'],
}


def job(args):
    cls,key,n,seed,baseline=args
    outcomes=[];full=[]
    for enemy in r.HERO_CLASSES:
        if enemy==cls:continue
        for a,b,side in ((cls,enemy,0),(enemy,cls,1)):
            start=r.pair_seed(a,b,seed)
            for i in range(n):
                score,_=r.duel(a,b,start+i,(side,key))
                normal=baseline[(a,b)][i]
                outcomes.append(score if side==0 else 1-score)
                full.append(normal if side==0 else 1-normal)
    changes=[a-b for a,b in zip(full,outcomes)]
    mean=sum(changes)/len(changes)
    variance=sum((x-mean)**2 for x in changes)/(len(changes)-1)
    return {'class':cls,'skill':key,'fights':len(full),'full_wr':100*sum(full)/len(full),
            'disabled_wr':100*sum(outcomes)/len(outcomes),'contribution_pp':100*mean,
            'paired_95_half_width_pp':196*math.sqrt(variance/len(full))}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--project',required=True)
    p.add_argument('--matrix',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--n',type=int,default=100)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--classes',nargs='*')
    args=p.parse_args()
    matrix=json.loads(Path(args.matrix).read_text())
    baseline={(x['a'],x['b']):x['outcomes'] for x in matrix['rows']}
    assert args.n<=matrix['config']['n']
    seed=matrix['config']['seed'];rows=[];start=time.monotonic()
    with ProcessPoolExecutor(args.workers,initializer=r.init,initargs=(args.project,True)) as pool:
        tasks=[pool.submit(job,(cls,key,args.n,seed,baseline)) for cls,keys in SKILLS.items()
               if not args.classes or cls in args.classes for key in keys]
        for f in as_completed(tasks):
            row=f.result();rows.append(row)
            print(f"{len(rows)}/{len(tasks)} {row['class']}.{row['skill']}: {row['contribution_pp']:+.2f} pp elapsed={time.monotonic()-start:.1f}s",flush=True)
            Path(args.out).write_text(json.dumps({'config':vars(args),'rows':rows,'seconds':time.monotonic()-start},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
