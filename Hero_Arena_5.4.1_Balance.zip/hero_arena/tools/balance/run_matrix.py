"""Reproducible ordered 37x37 matrix using the actual Battle engine.

Only log rendering and HP animation recording are suppressed in fast mode.
No combat rules, randomness, action selection or winners are replaced.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import hashlib
import json
from pathlib import Path
import random
import sys
import time


def init(project, fast, profile=None):
    sys.path.insert(0, project)
    global HERO_CLASSES, Battle, Character
    from models import HERO_CLASSES, Battle
    from models.character import Character
    if profile:
        from models import tuning
        values=json.loads(Path(profile).read_text())
        for name,changes in values.items():
            if name not in ('HP_TUNING','DMG_TUNING','AI_SKILL','KIT_TUNING'):
                raise ValueError('Unsupported tuning table: '+name)
            getattr(tuning,name).update(changes)
    if fast:
        from models import hp_journal
        hp_journal.record = lambda *args: None
        Battle._add_log = lambda *args, **kw: None
        Battle._log_many = lambda *args, **kw: None


def duel(a, b, seed, disabled=None):
    random.seed(seed)
    Character._next_id = Battle._next_id = 1
    h1, h2 = HERO_CLASSES[a]('A'), HERO_CLASSES[b]('B')
    if disabled:
        hero = h1 if disabled[0] == 0 else h2
        # Availability wrapper preserves the actual kit, including skills
        # referenced by passives or subclass choosers (e.g. Archer).
        old = hero.can_use
        hero.can_use = lambda s: s.key != disabled[1] and old(s)
        unlocked = hero.skill_unlocked
        hero.skill_unlocked = lambda s: s.key != disabled[1] and unlocked(s)
    battle = Battle(h1, h2)
    winner = battle.fight()
    return (1 if winner is h1 else 0 if winner is h2 else 0.5), battle.round


def pair_seed(a, b, seed):
    return int.from_bytes(hashlib.sha256(f'{seed}:{a}:{b}'.encode()).digest()[:8], 'big')


def row_job(args):
    a, types, n, seed, disabled_key = args
    result = []
    for b in types:
        first = second = rounds = 0
        outcomes = []
        start = pair_seed(a, b, seed)
        for i in range(n):
            score, r = duel(a, b, start+i, (0, disabled_key) if disabled_key else None)
            first += score
            rounds += r
            outcomes.append(score)
        result.append({'a': a, 'b': b, 'n': n, 'score': first, 'wr': 100*first/n,
                       'rounds': rounds, 'outcomes': outcomes})
    return result


def report(rows, types):
    by_pair = {(r['a'], r['b']): r for r in rows}
    averages = {}
    extreme = []
    for a in types:
        scores = [((by_pair[a,b]['wr']+100-by_pair[b,a]['wr'])/2)
                  for b in types if a != b and (a,b) in by_pair and (b,a) in by_pair]
        if scores:
            averages[a] = sum(scores)/len(scores)
    for i,a in enumerate(types):
        for b in types[i+1:]:
            if (a,b) not in by_pair or (b,a) not in by_pair:
                continue
            wr=(by_pair[a,b]['wr']+100-by_pair[b,a]['wr'])/2
            if wr<30 or wr>70:
                extreme.append({'a':a,'b':b,'wr':wr})
    return {'averages': averages, 'outside_46_54': {k:v for k,v in averages.items() if v<46 or v>54},
            'extreme_pairs': extreme, 'extreme_count':len(extreme),
            'fights':sum(r['n'] for r in rows),
            'mean_rounds':sum(r['rounds'] for r in rows)/sum(r['n'] for r in rows)}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--project',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--n',type=int,default=100)
    p.add_argument('--seed',type=int,default=541)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--classes',nargs='*')
    p.add_argument('--disable')
    p.add_argument('--full-logs',action='store_true')
    p.add_argument('--profile')
    p.add_argument('--pairs-with')
    args=p.parse_args()
    init(args.project,not args.full_logs,args.profile)
    types=list(HERO_CLASSES)
    selected=args.classes or types
    tasks=[(a,types if not args.pairs_with or a==args.pairs_with else [args.pairs_with],args.n,args.seed,args.disable) for a in selected]
    start=time.monotonic(); rows=[]
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
    with ProcessPoolExecutor(args.workers,initializer=init,initargs=(args.project,not args.full_logs,args.profile)) as pool:
        futures={pool.submit(row_job,t):t[0] for t in tasks}
        completed=0
        for f in as_completed(futures):
            rows.extend(f.result())
            completed+=1
            print(f'{completed}/{len(tasks)} {futures[f]} elapsed={time.monotonic()-start:.1f}s',flush=True)
            data={'config':vars(args),'types':types,'rows':rows,'seconds':time.monotonic()-start}
            out.write_text(json.dumps(data,ensure_ascii=False))
    data['summary']=report(rows,types)
    out.write_text(json.dumps(data,ensure_ascii=False))
    with out.with_suffix('.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['class']+types+['average'])
        pairs={(r['a'],r['b']):r['wr'] for r in rows}
        for a in selected:w.writerow([a]+[pairs.get((a,b),'') for b in types]+[data['summary']['averages'].get(a,'')])
    print(json.dumps(data['summary'],ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':main()
