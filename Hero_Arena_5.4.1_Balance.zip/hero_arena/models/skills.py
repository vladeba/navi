"""Умения (атаки) героев: базовый Skill и наследники.

Формула урона (DamageSkill):
  1) цель: удар может «перехватить» призванный зверь (pick_defender)
  2) попадание: шанс = точность умения − уклонение цели (не меньше 10%)
     (самурай с особой катаной меняет эту формулу — hit_chance переопределён)
  3) урон = урон героя × множитель умения × разброс 0.9–1.1 × (1 + бонусы эффектов)
  4) крит: шанс = крит героя + бонус умения → урон × множитель крита
  5) броня цели вычитается (если умение не «сквозь броню»), минимум 1
  6) эффект умения накладывается ТОЛЬКО если хотя бы один удар попал по цели
"""
import copy
import time
import random
import re

from .effects import Announcement, Contract, DamageOverTime, Shield


def scale_effect(eff, user):
    """4.0: яды, кровотечения и щиты растут с уровнем героя."""
    scale = user.power_scale() if hasattr(user, "power_scale") else 1.0
    if scale != 1.0 and isinstance(eff, (DamageOverTime, Shield)):
        eff.power = max(1, int(round(eff.power * scale)))
    return eff



def ai_weights(user, weights):
    """4.2: «мастерство ИИ» класса (models/tuning.py AI_SKILL): >1 — ИИ чаще попадает в лучшие ступени
    мини-игр. Так сокращается разрыв «идеальный игрок ↔ ИИ», а общая сила выравнивается уроном."""
    from .tuning import AI_SKILL
    s = AI_SKILL.get(getattr(user, "type_key", ""), 1.0)
    return [w * s ** (-i) for i, w in enumerate(weights)] if s != 1.0 else weights


class Skill:
    """Базовое умение: название, стоимость, перезарядка, ограничения."""

    reaction = None   # нужен ли ответ соперника (уклон, выбор квадрата)
    copyable = True   # может ли монах скопировать это умение
    reactor = "target"  # кто отвечает на реакцию: соперник ("target") или сам герой ("user")

    def public_options(self):
        """Что показать отвечающему (варианты уклона, квадраты…)."""
        return getattr(self, "options", None)

    def __init__(self, key, name, description, cost=0, cooldown=0, icon="⚔",
                 once_per_battle=False, min_turn=0, group=None):
        self.key = key                  # id умения в API, например "heavy_strike"
        self.name = name
        self.description = description
        self.cost = cost                # стоимость в энергии/мане/ярости
        self.cooldown = cooldown        # сколько ходов ждать после применения
        self.icon = icon
        self.once_per_battle = once_per_battle
        self.min_turn = min_turn        # доступно только начиная с этого хода
        self.group = group              # группа (например, умения «каменной формы» огра)

    def is_available(self, user):
        """Особые условия умения (раз за бой, с N-го хода). Наследники дополняют."""
        if self.once_per_battle and user.was_used(self.key):
            return False
        return user.turn_number >= self.min_turn

    def pay(self, user):
        """Списать ресурс, поставить перезарядку, отметить «раз за бой»."""
        user.spend_energy(self.cost)
        user.set_cooldown(self.key, self.cooldown)
        if self.once_per_battle:
            user.mark_used(self.key)

    def execute(self, user, target):
        """Шаблонный метод: заплатить, затем выполнить действие."""
        self.pay(user)
        return self._perform(user, target)

    def _perform(self, user, target):
        """Само действие — переопределяют наследники."""
        return [f"{user.name} применяет «{self.name}», но ничего не происходит."]

    def ai_score(self, user, target):
        """Насколько ИИ хочет это умение (больше — лучше)."""
        return 1.0

    def copy_for(self, new_owner_name):
        """Копия умения (монах копирует умения врага)."""
        clone = copy.copy(self)
        clone.key = "copy_" + self.key
        clone.name = self.name + " (копия)"
        clone.once_per_battle = True
        clone.min_turn = 0
        clone.group = None
        return clone

    def describe_for(self, user):
        """5.4.1: человекочитаемое описание для кнопки боя (с числами, если есть user)."""
        return self.description

    def to_dict(self, user=None):
        desc = self.describe_for(user) if user is not None else self.description
        data = {"key": self.key, "name": self.name, "description": desc,
                "cost": self.cost, "cooldown": self.cooldown, "icon": self.icon,
                "once_per_battle": self.once_per_battle, "reaction": self.reaction}
        if user is not None:
            data["cooldown_left"] = user.cooldown_left(self.key)
            data["blocked_left"] = user.blocked_left(self.key)
            data["available"] = user.can_use(self)
            data["visible"] = user.skill_visible(self)
            if self.cooldown:
                data["description"] = desc + ("" if "перезаряд" in desc.lower() else f" · перезарядка {self.cooldown} х.")
        return data


class DamageSkill(Skill):
    """Атакующее умение с шансом наложить эффект на цель."""

    ROLL = 0.1   # разброс урона ±10%

    def __init__(self, key, name, description, multiplier=1.0, accuracy=0.95,
                 ignore_armor=False, crit_bonus=0.0, hits=1,
                 effect=None, effect_chance=1.0, fixed_hit=None, low_hp_bonus=0.0, armor_pierce=0.0,
                 lifesteal=0.0, **kwargs):
        super().__init__(key, name, description, **kwargs)
        self.armor_pierce = armor_pierce    # 4.0: доля брони цели, которую удар игнорирует
        self.lifesteal = lifesteal          # 4.0: доля нанесённого урона, которая лечит героя
        self.multiplier = multiplier
        self.accuracy = accuracy
        self.ignore_armor = ignore_armor
        self.crit_bonus = crit_bonus
        self.hits = hits
        self.effect = effect                # функция, создающая Effect
        self.effect_chance = effect_chance
        self.fixed_hit = fixed_hit          # шанс попадания, не зависящий от уклонения
        self.low_hp_bonus = low_hp_bonus    # доп. множитель по цели с HP < 35%

    def describe_for(self, user):
        base = max(1, int(user.get_damage()))
        per = max(1, int(round(base * self.multiplier)))
        pct = int(round(self.multiplier * 100))
        if self.hits > 1:
            dmg = f"Урон ~{per * self.hits} ({self.hits}×{pct}% силы)"
        else:
            dmg = f"Урон ~{per} ({pct}% силы)"
        bits = [dmg]
        if self.ignore_armor:
            bits.append("сквозь броню")
        if self.armor_pierce:
            bits.append(f"пробивает {int(self.armor_pierce * 100)}% брони")
        if self.crit_bonus:
            bits.append(f"+{int(self.crit_bonus * 100)}% крит")
        if self.lifesteal:
            bits.append(f"вампиризм {int(self.lifesteal * 100)}%")
        if self.effect:
            try:
                eff = self.effect()
                chance = "" if self.effect_chance >= 0.999 else f"{int(self.effect_chance * 100)}% "
                bits.append(f"{chance}{eff.icon} {eff.name} на {eff.duration} х.")
            except Exception:
                bits.append("с эффектом")
        # сохранить уникальный флейвор из исходного описания, если он не чистая формула
        flavor = (self.description or "").strip()
        if flavor and not re.fullmatch(r"[×xX\d\s\.\,\+\-/%]+", flavor):
            # убрать чисто мультипликаторный префикс, оставить смысл
            low = flavor.lower()
            if "урон ~" not in low:
                bits.append(flavor)
        return " · ".join(bits)

    def _perform(self, user, target):  # переопределение
        logs, landed = [], 0
        for _ in range(self.hits):
            if not target.is_alive():
                break
            line, dmg = self._single_hit(user, target)
            logs.append(line)
            landed += dmg
            logs.extend(target.pop_events() + user.pop_events())
        if landed > 0 and target.is_alive():   # ИСПРАВЛЕНО: эффект только при попадании
            logs.extend(self._after_hit(user, target, landed))
        return logs

    def _after_hit(self, user, target, damage):
        """Что происходит, если хотя бы один удар попал: эффект умения + особенность героя."""
        logs = []
        if self.effect and random.random() < self.effect_chance:
            eff = scale_effect(self.effect(), user)
            if target.add_effect(eff):
                logs.append(f"{eff.icon} На {target.name} наложено: {eff.name} ({eff.duration} х.).")
        if self.lifesteal:
            healed = user.heal(int(damage * self.lifesteal))
            if healed:
                logs.append(f"🩸 {user.name} восстанавливает +{healed} HP.")
        logs.extend(user.on_hit_landed(target, self))
        return logs

    def _single_hit(self, user, target, force_hit=False):
        """Один удар. Возвращает (строка лога, урон по основной цели; 0 — промах)."""
        victim = target.pick_defender(user)   # зверь может принять удар на себя
        chance = self.fixed_hit if self.fixed_hit is not None else user.hit_chance(self, victim)
        if getattr(user, "miss_streak", 0) >= getattr(user, "MAX_MISS_STREAK", 99):
            # 4.3/5.0: инстинкт Совуха — третьего промаха подряд не бывает (даже «Ускользание» тени)
            chance = 1.0
        trick = self._cups_trick(victim) if not force_hit and chance < 1.0 else None    # 4.2: «Напёрстки» Газ-Лоу
        if trick:
            user.note_attack(False)
            return f"🥤 {user.name} — «{self.name}»: удар уходит в пустой стакан! {victim.name} смеётся. Промах.", 0
        if not force_hit and random.random() > chance:
            user.note_attack(False)
            if hasattr(victim, "note_dodged"):
                victim.note_dodged()   # 4.2: Нефруит запоминает уклонение («Удар из тени»)   # хук: Совух запоминает промахи («Охотничий инстинкт»)
            glance = getattr(user, "GLANCING", 0.0)   # 4.4: «Тяжёлая рука» огра — увёртка всё равно задета
            miss = max(1e-6, 1 - chance)
            dodged = min(miss, victim.get_dodge()) / miss if hasattr(victim, "get_dodge") else 0
            if glance and victim.is_alive() and random.random() < dodged:
                raw = user.get_damage() * self.multiplier * glance * user.damage_multiplier()
                real = victim.take_damage(int(raw), ignore_armor=True, attacker=user)
                line = f"{self.icon} {user.name} — «{self.name}»: {victim.name} уклоняется, но удар задевает вскользь: {real} урона."
                if victim is not target:
                    return line + victim.death_note(), 0
                return line, real
            return f"{self.icon} {user.name} — «{self.name}»: {victim.name} уклоняется! Промах.", 0
        user.note_attack(True)
        mult = self.multiplier
        if self.low_hp_bonus and victim.hp < victim.max_hp * 0.35:
            mult *= 1 + self.low_hp_bonus
        damage = user.get_damage() * mult * random.uniform(1 - self.ROLL, 1 + self.ROLL) * user.damage_multiplier()
        damage *= 1 + getattr(user, "fatigue", 0.0)          # 4.0: усталость с 30-го раунда
        damage *= user.damage_vs(victim) if hasattr(user, "damage_vs") else 1.0
        crit = random.random() < (user.get_crit() if hasattr(user, "get_crit") else user.crit_chance) + self.crit_bonus
        if crit:
            damage *= user.crit_multiplier
        pierce = self.armor_pierce + float(getattr(user, "armor_pierce", 0) or 0)
        if pierce and not self.ignore_armor:
            arm = victim.armor_total() if hasattr(victim, "armor_total") else victim.armor
            damage += arm * min(1.0, pierce)
        flat = getattr(user, "ARMOR_PIERCE_FLAT", 0)        # 4.3: пассивка «Прорезь брони» (ассасин)
        if flat and not self.ignore_armor:
            arm = victim.armor_total() if hasattr(victim, "armor_total") else victim.armor
            damage += min(flat, max(0, arm))
        real = victim.take_damage(int(damage), ignore_armor=self.ignore_armor, attacker=user)
        note = " КРИТ!" if crit else ""
        armor = " (сквозь броню)" if self.ignore_armor else ""
        line = f"{self.icon} {user.name} — «{self.name}»: {real} урона по {victim.name}{armor}.{note}"
        if victim is not target:
            line += victim.death_note()
            return line, 0
        return line, real

    def _cups_trick(self, victim):
        """4.2: «Напёрстки» — следующая ОБЫЧНАЯ атака по Газ-Лоу гарантированно мимо (один раз)."""
        if self.key != "attack" or not hasattr(victim, "get_effects"):
            return False
        from .effects_42 import CupsTrick
        mark = next((e for e in victim.get_effects() if isinstance(e, CupsTrick)), None)
        if mark is None:
            return False
        victim._effects = [e for e in victim.get_effects() if e is not mark]
        return True

    def ai_score(self, user, target):  # переопределение: ожидаемый урон
        from .ai import damage_score
        return damage_score(self, user, target)


class HealSkill(Skill):
    """Лечение: восстанавливает процент HP (и может дать регенерацию)."""

    def __init__(self, key, name, description, percent=0.3, effect=None, **kwargs):
        super().__init__(key, name, description, **kwargs)
        self.percent = percent
        self.effect = effect

    def describe_for(self, user):
        amt = max(1, int(user.max_hp * self.percent))
        bits = [f"Лечение ~{amt} HP ({int(self.percent * 100)}% макс. HP)"]
        if self.effect:
            try:
                eff = self.effect()
                bits.append(f"{eff.icon} {eff.name} на {eff.duration} х.")
            except Exception:
                pass
        flavor = (self.description or "").strip()
        if flavor and flavor not in bits[0]:
            bits.append(flavor)
        return " · ".join(bits)

    def _perform(self, user, target):  # переопределение
        healed = user.heal(int(user.max_hp * self.percent))
        logs = [f"{self.icon} {user.name} — «{self.name}»: +{healed} HP."]
        if self.effect:
            eff = self.effect()
            user.add_effect(eff)
            logs.append(f"{eff.icon} {user.name}: {eff.name} на {eff.duration} х.")
        return logs

    def ai_score(self, user, target):
        from .ai import healing
        return healing(user, user.max_hp * self.percent)


class SelfBuffSkill(Skill):
    """Умение, которое накладывает полезные эффекты на самого героя."""

    def __init__(self, key, name, description, effects, score=12, announce=False, **kwargs):
        super().__init__(key, name, description, **kwargs)
        self.effects = effects   # список функций, создающих эффекты
        self.score = score
        self.announce = announce

    def describe_for(self, user):
        bits = []
        flavor = (self.description or "").strip()
        if flavor:
            bits.append(flavor)
        try:
            for make in self.effects:
                eff = make()
                line = f"{eff.icon} {eff.name} на {eff.duration} х."
                if line not in flavor:
                    bits.append(line)
        except Exception:
            pass
        return " · ".join(bits) if bits else (flavor or self.name)

    def _perform(self, user, target):  # переопределение
        names = []
        for make in self.effects:
            eff = scale_effect(make(), user)
            user.add_effect(eff)
            names.append(f"{eff.icon} {eff.name} ({eff.duration} х.)")
        text = f"{self.icon} {user.name} — «{self.name}»: " + ", ".join(names) + "."
        return [Announcement(text) if self.announce else text]

    def ai_score(self, user, target):
        from .ai import buff_score
        return buff_score(self, user, target)


class BackstabSkill(DamageSkill):
    """Удар в спину: если на цели есть дебафф (яд, оглушение...), шанс крита +50%."""

    def _single_hit(self, user, target, force_hit=False):  # переопределение
        bonus = 0.5 if target.has_debuff() else 0.0
        self.crit_bonus += bonus
        try:
            return super()._single_hit(user, target, force_hit)
        finally:
            self.crit_bonus -= bonus

    def ai_score(self, user, target):
        return super().ai_score(user, target) * (1.5 if target.has_debuff() else 1.0)


class LifestealSkill(DamageSkill):
    """Похищение жизни: лечит атакующего на часть нанесённого урона."""

    def __init__(self, key, name, description, steal=0.7, **kwargs):
        super().__init__(key, name, description, **kwargs)
        self.steal = steal

    def _after_hit(self, user, target, damage):  # переопределение
        logs = super()._after_hit(user, target, damage)
        healed = user.heal(int(damage * self.steal))
        logs.append(f"🩸 {user.name} похищает жизнь: +{healed} HP.")
        return logs


class SummonSkill(Skill):
    """Призыв существа, которое сражается рядом с героем."""

    def __init__(self, key, name, description, summon_factory, **kwargs):
        super().__init__(key, name, description, **kwargs)
        self.summon_factory = summon_factory   # функция: owner → объект Summon

    def is_available(self, user):  # переопределение: только если зверя нет или он погиб
        return super().is_available(user) and (user.summon is None or not user.summon.is_alive())

    def _perform(self, user, target):
        user.summon = self.summon_factory(user)
        s = user.summon
        s.scale_to(user)                       # 4.0: звери растут с уровнем хозяина

        return [Announcement(f"{s.icon} {user.name} призывает: {s.name}! "
                             f"(HP {s.hp}, урон {s.damage}) — {s.about}")]

    def ai_score(self, user, target):
        from .ai import summon_score
        return summon_score(self,user,target)


# ---------- Умения с ответом соперника ----------
class ReactionSkill(DamageSkill):
    """Удар, от которого соперник уклоняется сам: «влево» или «вправо».

    Атакующий тайно выбирает сторону. Совпало с выбором защитника — попадание,
    не совпало — уклонение. Против ИИ выбор защитника случайный (50/50).
    """

    reaction = "dodge"
    options = ["left", "right"]
    prompt = "⬅️ Уклон влево / Уклон вправо ➡️"

    def secret_pick(self):
        return random.choice(self.options)

    def check_choice(self, choice):
        if choice not in self.options:
            raise ValueError("choice должен быть: " + ", ".join(map(str, self.options)))
        return choice

    def _perform(self, user, target):  # путь против ИИ: выбор защитника случайный
        return self.resolve(user, target, random.choice(self.options), self.secret_pick())

    def resolve(self, user, target, choice, secret):
        side = {"left": "влево", "right": "вправо", "down": "вниз"}
        if choice != secret:
            return [f"{self.icon} {user.name} — «{self.name}» бьёт {side[secret]}, "
                    f"а {target.name} уклоняется {side[choice]}! Промах."]
        logs = [f"{self.icon} {user.name} угадал: {target.name} уклонился {side[choice]} — прямо под удар!"]
        line, dmg = self._single_hit(user, target, force_hit=True)
        logs.append(line)
        logs.extend(target.pop_events() + user.pop_events())
        if dmg > 0 and target.is_alive():
            logs.extend(self._after_hit(user, target, dmg))
        return logs

    def ai_score(self, user, target):
        return super().ai_score(user, target) / len(self.options) / max(0.1, self.accuracy - target.get_dodge())



class ContractSkill(Skill):
    """Контракт на убийство: соперник выбирает 1 из 6 чёрных квадратов, 2 из них отравлены.

    Если соперник выбрал отравленный — контракт заключён: ассасин получает
    +крит, усиленные яд и кровотечение, −24% получаемого урона и «Прыжок за спину».
    """

    reaction = "squares"
    copyable = False
    options = [0, 1, 2, 3, 4, 5]
    prompt = "Выберите один из 6 чёрных квадратов…"

    MAX_USES = 5   # 4.3: снова до 5 раз за бой (в 4.0 было ограничено 2)

    def is_available(self, user):
        return (super().is_available(user) and not user.has_effect(Contract)
                and getattr(user, "contract_tries", 0) < self.MAX_USES)

    def pay(self, user):  # переопределение: считаем попытки
        super().pay(user)
        user.contract_tries = getattr(user, "contract_tries", 0) + 1

    def secret_pick(self):
        return sorted(random.sample(self.options, 2))

    def check_choice(self, choice):
        try:
            choice = int(choice)
        except (TypeError, ValueError):
            raise ValueError("choice должен быть номером квадрата 0–5")
        if choice not in self.options:
            raise ValueError("choice должен быть номером квадрата 0–5")
        return choice

    def _perform(self, user, target):
        return self.resolve(user, target, random.choice(self.options), self.secret_pick())

    def resolve(self, user, target, choice, secret):
        if choice in secret:
            return [Announcement(f"📜 {target.name} открыл отравленный квадрат №{choice + 1}! "
                                 f"КОНТРАКТ НА УБИЙСТВО ЗАКЛЮЧЁН — {user.name} становится смертоноснее!")] \
                + user.grant_contract()
        return [Announcement(f"📜 {target.name} выбрал чистый квадрат №{choice + 1} — контракт сорван! "
                             f"(яд был в №{secret[0] + 1} и №{secret[1] + 1})")]

    def ai_score(self, user, target):
        return 22


class WeaknessSkill(DamageSkill):
    """«Поиск слабостей» монаха: игрок за монаха за ~3.5 с нажимает квадраты 1→2→3→4→5→6,
    разбросанные по сетке 3×3. 4.0 — результат по шагам: все 6 — ×2.7, 4–5 по порядку — ×1.5,
    меньше — слабый удар ×0.9 (монах всё равно бьёт). Решает сервер: проверяет порядок и время.
    ИИ-монах: 45% полный успех, 30% частичный, 25% провал.
    """
    FULL, PARTIAL, MISS = 2.7, 1.5, 0.9
    AI_WEIGHTS = (45, 30, 25)

    reaction = "sequence"
    reactor = "user"            # отвечает сам применяющий (а не соперник)
    copyable = False
    prompt = "Нажмите квадраты 1 → 2 → 3 → 4 → 5 → 6 по порядку, пока не вышло время!"
    SQUARES = 6
    TIME_LIMIT_MS = 3500
    GRACE_S = 1.5               # запас на сеть и анимацию
    AI_SUCCESS = 0.45

    def public_options(self):
        """Случайная раскладка: номер квадрата → клетка 0–8 сетки 3×3."""
        return {"cells": random.sample(range(9), self.SQUARES), "time_limit_ms": self.TIME_LIMIT_MS}

    def secret_pick(self):
        return time.time() + self.TIME_LIMIT_MS / 1000 + self.GRACE_S   # крайний срок ответа

    def check_choice(self, choice):
        if choice in ("timeout", None):
            return "timeout"
        if not isinstance(choice, list) or not all(isinstance(x, int) for x in choice):
            raise ValueError("choice — список нажатых номеров, например [1, 2, 3, 4, 5, 6], или \"timeout\"")
        return choice

    def _perform(self, user, target):  # ИИ-монах: случайный результат по весам
        if getattr(user, "perfect", False):
            return self._result(user, target, self.SQUARES, "")
        tier = random.choices([self.SQUARES, 4, 0], weights=ai_weights(user, self.AI_WEIGHTS))[0]
        return self._result(user, target, tier, "")

    def resolve(self, user, target, choice, secret):
        if choice == "timeout" or time.time() > secret:
            done = 0 if choice == "timeout" else self._prefix(choice)
            return self._result(user, target, min(done, self.SQUARES - 1), " (не успел)")
        return self._result(user, target, self._prefix(choice), "")

    def _prefix(self, choice):
        """Сколько квадратов нажато верно подряд с начала (1, 2, 3…)."""
        n = 0
        for i, x in enumerate(choice if isinstance(choice, list) else []):
            if x != i + 1:
                break
            n += 1
        return n

    def _result(self, user, target, done, why):
        if done >= self.SQUARES:
            mult, text = self.FULL, f"{self.icon} {user.name} нашёл слабое место {target.name}!"
        elif done >= 4:
            mult, text = self.PARTIAL, f"{self.icon} {user.name} нашёл часть слабостей ({done}/{self.SQUARES}){why}."
        else:
            mult, text = self.MISS, f"{self.icon} {user.name} не нашёл слабостей ({done}/{self.SQUARES}){why} — обычный удар."
        logs = [Announcement(text) if done >= self.SQUARES else text]
        saved, self.multiplier = self.multiplier, mult
        try:
            line, dmg = self._single_hit(user, target, force_hit=done >= 4)
        finally:
            self.multiplier = saved
        logs.append(line)
        logs.extend(target.pop_events() + user.pop_events())
        if dmg > 0 and target.is_alive():
            logs.extend(self._after_hit(user, target, dmg))
        return logs

    def ai_score(self, user, target):
        base = super().ai_score(user, target) / max(0.1, self.multiplier)
        w = self.AI_WEIGHTS
        return base * (w[0] * self.FULL + w[1] * self.PARTIAL + w[2] * 0.8) / sum(w)



class DebuffSkill(Skill):
    """Умение, которое всегда накладывает эффект на соперника (например, Рёв совуха)."""

    def __init__(self, key, name, description, effect, score=14, **kwargs):
        super().__init__(key, name, description, **kwargs)
        self.effect = effect
        self.score = score

    def _perform(self, user, target):  # переопределение
        eff = self.effect()
        target.add_effect(eff)
        return [f"{self.icon} {user.name} — «{self.name}»: на {target.name} наложено {eff.name} ({eff.duration} х.)."]

    def ai_score(self, user, target):
        from .ai import effect_value
        return effect_value(user, target, self.effect())


# ================= 4.0: мини-игры по шагам =================
class MiniGameSkill(DamageSkill):
    """Базовая мини-игра 4.0. Играет САМ применяющий (reactor="user").

    Сервер отдаёт параметры игры (public_options), игрок присылает результат (choice),
    сервер проверяет время и превращает результат в ступень (tier): 0 — лучший исход, дальше хуже.
    Частичный успех даёт частичный эффект. ИИ выбирает ступень по весам AI_WEIGHTS,
    «идеальный игрок» (user.perfect, для balance.py) — всегда ступень 0.
    Наследники задают game, TIERS, AI_WEIGHTS, tier_from(choice, options) и apply(user, target, tier, data).
    """

    reaction = "minigame"
    reactor = "user"
    copyable = False
    game = "minigame"
    prompt = "Мини-игра!"
    TIME_LIMIT_MS = 4000
    GRACE_S = 1.5
    TIERS = ("успех", "провал")
    AI_WEIGHTS = (50, 50)
    TIER_VALUE = (1.0, 0.0)      # условная «сила» ступени — для ai_score
    # 5.4.1: визуальная тема мини-игры (UI); щит+золото — только у Спартанца
    MG_ICON = None
    MG_TARGET_COLOR = None
    MG_RING_COLOR = None
    MG_HINT = None
    MG_ACCENT = None

    def game_params(self, user, target):
        """Параметры игры для интерфейса (раскладка, ритм…). Наследники дополняют."""
        return {}

    def public_options(self, user=None, target=None):
        data = {"game": self.game, "time_limit_ms": self.TIME_LIMIT_MS, "tiers": list(self.TIERS)}
        data.update(self.game_params(user, target))
        if self.MG_ICON: data.setdefault("icon", self.MG_ICON)
        if self.MG_TARGET_COLOR: data.setdefault("target_color", self.MG_TARGET_COLOR)
        if self.MG_RING_COLOR: data.setdefault("ring_color", self.MG_RING_COLOR)
        if self.MG_HINT: data.setdefault("hint", self.MG_HINT)
        if self.MG_ACCENT: data.setdefault("accent", self.MG_ACCENT)
        return data

    def secret_pick(self, options=None):
        limit = (options or {}).get("time_limit_ms", self.TIME_LIMIT_MS)
        deadline = time.time() + limit / 1000 + self.GRACE_S if limit else None
        return {"deadline": deadline, "options": options or {}}

    def check_choice(self, choice):
        if choice in ("timeout", None):
            return "timeout"
        if not isinstance(choice, (dict, int, float, str, list)):
            raise ValueError("choice — результат мини-игры (объект или число)")
        return choice

    def tier_from(self, choice, options):
        """Превратить ответ игрока в номер ступени. Наследники переопределяют."""
        return 0 if choice else len(self.TIERS) - 1

    def ai_tier(self, user, target):
        if getattr(user, "perfect", False):
            return 0
        return random.choices(range(len(self.TIERS)), weights=ai_weights(user, self.AI_WEIGHTS))[0]

    def ai_choice(self, user, target, tier):
        """Что «выбрал» ИИ (для игр с выбором: бог, форма). По умолчанию ничего."""
        return None

    def _perform(self, user, target):  # путь ИИ
        tier = self.ai_tier(user, target)
        return self.apply(user, target, tier, self.ai_choice(user, target, tier))

    def resolve(self, user, target, choice, secret):
        options = secret.get("options", {}) if isinstance(secret, dict) else {}
        late = isinstance(secret, dict) and secret.get("deadline") and time.time() > secret["deadline"]
        if choice == "timeout" or late:
            tier = len(self.TIERS) - 1
            data = choice if isinstance(choice, dict) else None
        else:
            tier = max(0, min(len(self.TIERS) - 1, int(self.tier_from(choice, options))))
            data = choice
        return self.apply(user, target, tier, data)

    def apply(self, user, target, tier, data):
        return [f"{self.icon} {user.name} — «{self.name}»: {self.TIERS[tier]}."]

    def strike(self, user, target, mult, ignore_armor=None, force=True, pierce=None):
        """Удар с заданным множителем (для мини-игр). Возвращает (логи, урон)."""
        saved = (self.multiplier, self.ignore_armor, self.armor_pierce)
        self.multiplier = mult
        if ignore_armor is not None:
            self.ignore_armor = ignore_armor
        if pierce is not None:
            self.armor_pierce = pierce
        # 4.4: «ускользание» — по герою с FORCED_EVADE даже точный приём мини-игры может пройти мимо
        # (шанс = его уклонение × FORCED_EVADE); иначе мини-игры полностью отменяли защиту тени
        evade = getattr(target, "FORCED_EVADE", 0.0)
        if force and evade and target.is_alive() and random.random() < target.get_dodge() * evade:
            self.multiplier, self.ignore_armor, self.armor_pierce = saved
            if hasattr(target, "note_dodged"):
                target.note_dodged()
            return [f"{self.icon} {user.name} — «{self.name}»: {target.name} ускользает во мрак! Промах."], 0
        try:
            line, dmg = self._single_hit(user, target, force_hit=force)
        finally:
            self.multiplier, self.ignore_armor, self.armor_pierce = saved
        logs = [line] + target.pop_events() + user.pop_events()
        if dmg > 0 and target.is_alive():
            logs.extend(self._after_hit(user, target, dmg))
        return logs, dmg

    def expected_value(self):
        w = self.AI_WEIGHTS
        return sum(a * b for a, b in zip(w, self.TIER_VALUE)) / sum(w)

    def ai_score(self, user, target):
        per_hit = max(1, user.get_damage() - (0 if self.ignore_armor else target.armor_total()))
        return per_hit * self.expected_value() * 1.0 + 2


class ChoiceSkill(MiniGameSkill):
    """Мини-«игра» выбора без таймера (Молитва: выбрать одного из двух богов)."""

    TIME_LIMIT_MS = 0
    TIERS = ("выбор",)
    AI_WEIGHTS = (1,)
