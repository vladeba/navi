"""5.4: двенадцать новых героев арены."""
import random

from .character import Character, HERO_CLASSES
from .effects import (Announcement, Shield, Stun, Bleed, Burn, Poison, Slow, Blinded,
                      DodgeBuff, Berserk, DamageReduction, Regeneration, Antiheal)
from .summons import BeastCompanion
from .skills import SummonSkill, DamageSkill, SelfBuffSkill, DebuffSkill, HealSkill, Skill, scale_effect
from .minigames_54 import (
    FlightDiveSkill, TrapSetSkill, MarkShotSkill, BoneDiceSkill, HyenaLaughSkill,
    TotemPulseSkill, HarpCurseSkill, MacheteCatchSkill, TwinSpinSkill, HammerJudgmentSkill,
    PounceSkill, KodoChargeSkill, AxeStormSkill, WebTrapSkill, SpiderlingSkill, QueenBiteSkill,
    BleedVolleySkill, SpearThrowSkillMG, DouseSkillMG, BreathIgniteSkill, CardDrawSkill,
)


class WindBarrier(Skill):
    copyable = False

    def _perform(self, user, target):
        user.add_effect(DodgeBuff(3, 25))
        user.add_effect(DamageReduction(2, 15, title="Ветряной барьер"))
        return [f"🌬 {user.name} поднимает ветряной барьер: +25% уклонения, −15% урона."]

    def ai_score(self, user, target):
        return 0 if user.has_effect(DodgeBuff) else 14


class Aarakocra(Character):
    """Скайр — ааракокра с горных пиков. Летает, пикирует когтями и повелевает ветром."""

    hero_class, type_key, resource_name = "Ааракокра", "aarakocra", "ветер"
    signature_skill = "dive"
    role = "light"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=192, base_damage=14.2, armor=1, level=level,
                         speed=8, dodge=0.18, crit_chance=0.15,
                         max_energy=100, energy_regen=13, start_energy=40)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Взмах крыла", "×0.9 урона, точность 90% — лёгкий удар перьями с высоты", multiplier=0.9, accuracy=0.9, icon="🪶"),
            DamageSkill("talon", "Хватка небес", "×1.35 урона + кровотечение 3 ур. на 3 хода", multiplier=1.35,
                        effect=lambda: Bleed(3, 3), cost=18, cooldown=2, icon="🦅"),
            DamageSkill("gust", "Шквал пика", "×1.1 урона, 35% замедлить на 2 хода", multiplier=1.1,
                        effect=lambda: Slow(2, 2), effect_chance=0.35, cost=15, cooldown=3, icon="💨"),
            WindBarrier("wind_barrier", "Стена ветров", "+25% уклонения на 3 хода и −15% входящего урона на 2 хода",
                        cost=25, cooldown=5, icon="🌬"),
            DamageSkill("sky_lance", "Копьё грозового пика", "×1.7 урона, игнор 40% брони", multiplier=1.7,
                        armor_pierce=0.4, cost=28, cooldown=3, icon="🔱"),
            DamageSkill("cyclone", "Вихрь перьев", "3 удара крыльями по ×0.55 каждый (итого ×1.65)", multiplier=0.55, hits=3,
                        cost=30, cooldown=4, icon="🌪"),
            FlightDiveSkill("dive", "Смертельный пике", "Мини-игра пикирования: идеал — ×2.35 + кровотечение 4 ур.",
                            cost=30, cooldown=5, icon="↘️"),
        ]


class Hunter(Character):
    """Дэрил — крупный охотник в шкуре фэнтезийного зверя. Сила в разнообразии атак."""

    hero_class, type_key, resource_name = "Охотник", "hunter", "добыча"
    signature_skill = "mark_shot"
    role = "warrior"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=225, base_damage=15.8, armor=2, level=level,
                         speed=5, dodge=0.09, crit_chance=0.15,
                         max_energy=100, energy_regen=11, start_energy=35)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Тесак зверолова", "×1.0 урона, точность 90% — тяжёлый рубящий замах", accuracy=0.9, icon="🗡"),
            DamageSkill("cleave", "Рассекатель шкур", "×1.45 урона — широкий рубящий удар тесаком", multiplier=1.45, cost=18, cooldown=2, icon="⚔"),
            DamageSkill("net", "Ловецкая сеть", "×0.8 урона + сильное замедление на 2 хода", multiplier=0.8,
                        effect=lambda: Slow(2, 3), cost=20, cooldown=4, icon="🕸"),
            DamageSkill("beast_strike", "Ярость зверя", "×1.6 урона и +15% шанс крита на этот удар", multiplier=1.6,
                        crit_bonus=0.15, cost=25, cooldown=3, icon="🦴"),
            DamageSkill("flurry", "Град тесаков", "3 быстрых удара по ×0.55 (итого ×1.65)", multiplier=0.55, hits=3,
                        cost=28, cooldown=4, icon="💥"),
            TrapSetSkill("traps", "Стальные капканы", "Мини-игра: 4 капкана — замедление/оглушение по числу удач",
                         cost=25, cooldown=5, icon="🪤"),
            MarkShotSkill("mark_shot", "Выстрел в глаз", "Мини-игра метки: идеал — огромный урон в уязвимое место",
                          cost=30, cooldown=5, icon="🎯"),
        ]


class ScavengeSkill(DamageSkill):
    def _perform(self, user, target):
        saved = self.multiplier
        missing = 1 - (target.hp / max(1, target.max_hp))
        self.multiplier = saved * (1 + 0.55 * missing)
        try:
            return super()._perform(user, target) + [f"🦴 Падальщик: бонус {int(55 * missing)}% к урону."]
        finally:
            self.multiplier = saved


class Gnoll(Character):
    """Рексор — гнолл с небольшим мечом. Суть: «Кости удачи» и падальщик — чем слабее враг, тем страшнее Рексор."""

    hero_class, type_key, resource_name = "Гнолл", "gnoll", "голод"
    signature_skill = "bone_dice"
    role = "trickster"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=205, base_damage=14.6, armor=1, level=level,
                         speed=7, dodge=0.16, crit_chance=0.18,
                         max_energy=100, energy_regen=13, start_energy=40)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Клык стали", "×1.0 урона коротким мечом, точность 90%", accuracy=0.9, icon="⚔"),
            ScavengeSkill("scavenge", "Чутьё падальщика", "×1.2, до +55% урона по раненым (чем меньше HP врага — тем больнее)",
                          multiplier=1.2, cost=20, cooldown=4, icon="🦴"),
            DamageSkill("rip", "Рваные клыки", "×1.05 урона + кровотечение 4 ур. на 3 хода", multiplier=1.05,
                        effect=lambda: Bleed(3, 4), cost=22, cooldown=3, icon="🩸"),
            SelfBuffSkill("cackle", "Зловещий хохот", "+20% уклонения на 2 хода — гиений смех сбивает прицел",
                          effects=[lambda: DodgeBuff(2, 20)], cost=18, cooldown=4, icon="😈"),
            BoneDiceSkill("bone_dice", "Кости судьбы", "Мини-игра: бросок 1…6 — бафф растёт с числом, без штрафа за единицу",
                          cost=25, cooldown=5, icon="🎲"),
            HyenaLaughSkill("hyena_laugh", "Ржание стаи", "Мини-игра ритма: крадёт удачу/энергию врага и бьёт",
                            cost=28, cooldown=5, icon="🤣"),
        ]


class TotemHealSkill(Skill):
    copyable = False

    def _perform(self, user, target):
        healed = user.heal(int(user.max_hp * 0.12))
        user.add_effect(Regeneration(3, max(1, int(user.max_hp * 0.03))))
        return [f"🛕 {user.name} ставит тотем лечения: +{healed} HP и регенерация."]

    def ai_score(self, user, target):
        return 20 if user.hp < user.max_hp * 0.55 else 6


class Centaur(Character):
    """Талар — кентавр-шаман с луком и арфой. Лечит тотемами и насылает проклятия."""

    hero_class, type_key, resource_name = "Кентавр-шаман", "centaur", "дух"
    signature_skill = "totem_pulse"
    role = "light"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=205, base_damage=12.8, armor=2, level=level,
                         speed=6, dodge=0.08, crit_chance=0.11,
                         max_energy=110, energy_regen=12, start_energy=45)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Стрела рощи", "×1.0 урона из лука, точность 88%", accuracy=0.88, icon="🏹"),
            DamageSkill("spirit_arrow", "Стрела духов", "×1.4 урона + яд 3 ур. на 3 хода", multiplier=1.4,
                        effect=lambda: Poison(3, 3), cost=20, cooldown=3, icon="💚"),
            TotemHealSkill("totem_heal", "Тотем живой рощи", "+12% макс. HP сразу и регенерация ~3%/ход на 3 хода",
                           cost=30, cooldown=5, icon="🛕"),
            DebuffSkill("hex", "Проклятие чащобы", "Точность врага −20% на 3 хода",
                        effect=lambda: Blinded(3, 20), cost=18, cooldown=4, icon="🔮"),
            DamageSkill("harp_shot", "Струна грома", "Магический выстрел арфы ×1.55 урона", multiplier=1.55, cost=25, cooldown=3, icon="🎵"),
            TotemPulseSkill("totem_pulse", "Пульс предков", "Мини-игра тотемов: лечение себе + проклятие врагу",
                            cost=28, cooldown=5, icon="✨"),
            HarpCurseSkill("harp_curse", "Диссонанс рока", "Мини-игра двух нот: замедление и слепота (−точность)",
                           cost=30, cooldown=6, icon="🎼"),
        ]


class ThrowMacheteSkill(Skill):
    copyable = False

    def is_available(self, user):
        thrown = getattr(user, "thrown_machetes", [])
        return super().is_available(user) and len(thrown) < 2

    def _perform(self, user, target):
        delay = random.randint(2, 3)
        effect = random.choice(["damage", "bleed", "slow"])
        user.thrown_machetes.append({"turns": delay, "effect": effect, "target_id": target.id})
        return [Announcement(f"🪓 {user.name} бросает мачете! Вернётся через {delay} х. ({effect}).")]

    def ai_score(self, user, target):
        thrown = getattr(user, "thrown_machetes", [])
        return 0 if len(thrown) >= 2 else 12


class BlueTroll(Character):
    """Рокх-анн — синий тролль с клыками и стальными мачете-бумерангами."""

    hero_class, type_key, resource_name = "Синий тролль", "bluetroll", "ярость"
    signature_skill = "throw_machete"
    role = "trickster"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=230, base_damage=15.5, armor=2, level=level,
                         speed=5, dodge=0.09, crit_chance=0.13,
                         max_energy=100, energy_regen=11, start_energy=35)
        self.thrown_machetes = []

    def _create_skills(self):
        return [
            DamageSkill("attack", "Рез архипелага", "×1.0 урона мачете, точность 88%", accuracy=0.88, icon="🪓"),
            DamageSkill("slash", "Крест клинков", "Два удара мачете по ×0.60 (итого ×1.20)", multiplier=0.60, hits=2, cost=18, cooldown=2, icon="⚔"),
            ThrowMacheteSkill("throw_machete", "Бумеранг прилива", "Тратит ход: мачете летит и бьёт через 2–3 хода (×1.6 + эффект)",
                              cost=20, cooldown=2, icon="🪃"),
            DamageSkill("tusk", "Клыки шторма", "×1.25 урона + кровотечение 3 ур. на 3 хода", multiplier=1.25,
                        effect=lambda: Bleed(3, 3), cost=22, cooldown=4, icon="🦷"),
            TwinSpinSkill("twin_spin", "Вихрь двух клинков", "Мини-игра: остановите оба мачете в зелёной зоне",
                          cost=28, cooldown=5, icon="🌀"),
            MacheteCatchSkill("catch_return", "Хватка возврата", "Мини-игра: поймайте оба бумеранга (промах — самоудар)",
                              cost=20, cooldown=4, icon="✋"),
        ]

    def start_turn(self):
        logs, can_act = super().start_turn()
        remaining = []
        battle = getattr(self, "_battle", None)
        foe = None
        if battle:
            foe = battle.hero2 if battle.hero1 is self else battle.hero1
        for m in list(self.thrown_machetes):
            m["turns"] -= 1
            if m["turns"] <= 0:
                if foe and foe.is_alive():
                    dmg = max(1, int(self.get_damage() * 1.6))
                    dealt = foe.take_damage(dmg, attacker=self)
                    logs.append(Announcement(f"🪃 Мачете возвращается в {foe.name}: −{dealt} HP!"))
                    if m["effect"] == "bleed":
                        foe.add_effect(scale_effect(Bleed(3, 4), self))
                        logs.append("🩸 Возврат накладывает кровотечение.")
                    elif m["effect"] == "slow":
                        foe.add_effect(Slow(2, 2))
                        logs.append(f"⛓ Возврат замедляет {foe.name}.")
                else:
                    logs.append(f"🪃 Мачете {self.name} возвращается в руку.")
            else:
                remaining.append(m)
        self.thrown_machetes = remaining
        return logs, can_act

    def _on_reset(self):
        self.thrown_machetes = []

    @property
    def machete_in_flight(self):
        return len(getattr(self, "thrown_machetes", []) or [])

    def to_dict(self):
        data = super().to_dict()
        data["thrown_machetes"] = list(self.thrown_machetes)
        data["machete_in_flight"] = self.machete_in_flight
        return data

    def describe(self):
        n = len(self.thrown_machetes)
        extra = f", 🪃 в полёте: {n}" if n else ""
        return super().describe() + extra


class DivineShieldSkill(Skill):
    copyable = False

    def _perform(self, user, target):
        user.add_effect(Shield(3, max(1, int(user.max_hp * 0.18))))
        user.add_effect(DamageReduction(2, 20, title="Божественная защита"))
        return [f"🛡 {user.name} — божественный щит: 18% HP и −20% урона."]

    def ai_score(self, user, target):
        from .ai import threat,horizon
        if user.has_effect(Shield):
            return 0
        turns=horizon(user,target)
        incoming=threat(target,user)
        return min(user.max_hp*0.18,incoming*turns)+incoming*0.20*min(2,turns)


class Paladin(Character):
    """Серена — паладинша-танк. Баффы на себя и оглушение молотом."""

    hero_class, type_key, resource_name = "Паладинша", "paladin", "вера"
    signature_skill = "judgment"
    role = "tank"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=255, base_damage=14.0, armor=5, level=level,
                         speed=4, dodge=0.04, crit_chance=0.10,
                         max_energy=100, energy_regen=10, start_energy=30)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар рассвета", "×1.0 урона молотом, точность 88%", accuracy=0.88, icon="🔨"),
            DamageSkill("shield_bash", "Щит клятвы", "×1.15 урона, 45% оглушить на 1 ход", multiplier=1.15,
                        effect=lambda: Stun(1), effect_chance=0.45, cost=22, cooldown=3, icon="🛡"),
            SelfBuffSkill("bless", "Благодать рассвета", "+20% урона на 3 хода",
                          effects=[lambda: Berserk(3, 20)], cost=20, cooldown=5, icon="✨"),
            DivineShieldSkill("divine_shield", "Эгида света", "Щит 18% макс. HP на 3 хода и −20% входящего урона на 2 хода",
                              cost=30, cooldown=5, icon="😇"),
            DamageSkill("smite", "Святая кара", "Святой удар ×1.7 урона", multiplier=1.7, cost=28, cooldown=3, icon="⚔"),
            HealSkill("lay_hands", "Длань исцеления", "Лечит 14% максимального HP", percent=0.14, cost=35, cooldown=6, icon="🙏"),
            HammerJudgmentSkill("judgment", "Молот правосудия", "Мини-игра весов: высокий урон + шанс оглушения",
                                cost=30, cooldown=5, icon="⚖"),
        ]


class TransformSkill(Skill):
    """Смена формы: бонус к первому удару после смены; сброс штрафа за застой."""
    copyable = False

    def _perform(self, user, target):
        user.cat_form = not getattr(user, "cat_form", False)
        user.form_turns = 0
        user.switch_empower = 1.35  # первый удар после смены ×1.35
        form = "кошки" if user.cat_form else "человека"
        role = "Воин" if user.cat_form else "Ловкач"
        return [Announcement(
            f"🐱 {user.name} принимает облик {form} ({role})! Следующий удар усилен.")]

    def ai_score(self, user, target):
        stuck = getattr(user, "form_turns", 0)
        # после 3 ходов в одной форме сильно хочется сменить (штраф застоя)
        base = 5 + min(18, max(0, stuck - 2) * 5)
        if user.cat_form and user.hp < user.max_hp * 0.45:
            return base + 7
        if (not user.cat_form) and target.hp < target.max_hp * 0.55:
            return base + 5
        return base


class Catfolk(Character):
    """Анниса — полукровка. Человек = sustain/уклонение (слабый урон);
    кошка = высокий урон, но хрупкость и расход HP. Нужно чередовать формы:
    бонус к первому удару после смены; штраф за застой в одной форме."""

    hero_class, type_key, resource_name = "Полукровка", "catfolk", "грация"
    signature_skill = "pounce"
    _role = "trickster"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=205, base_damage=14.8, armor=1, level=level,
                         speed=8, dodge=0.20, crit_chance=0.18,
                         max_energy=100, energy_regen=14, start_energy=40)
        self.cat_form = False
        self.form_turns = 0
        self.switch_empower = 0.0

    @property
    def role(self):
        return "warrior" if getattr(self, "cat_form", False) else "trickster"

    @role.setter
    def role(self, value):
        self._role = value

    @property
    def image(self):
        # Вне боя всегда человек; кошка — только во время активного боя после transform
        in_battle = bool(getattr(self, "_battle", None))
        if in_battle and getattr(self, "cat_form", False):
            from pathlib import Path as _P
            root = _P(__file__).resolve().parents[1] / "static" / "images"
            skin = getattr(self, "skin", None)
            if skin:
                cand = root / "skins" / f"{self.type_key}_{skin}_cat.jpg"
                if cand.exists():
                    return f"/static/images/skins/{self.type_key}_{skin}_cat.jpg"
            return f"/static/images/{self.type_key}_cat.jpg"
        return Character.image.fget(self)

    def _form_stale_mult(self):
        """Штраф за застой: с 5-го хода в одной форме −3% за ход, до −12%."""
        stuck = max(0, getattr(self, "form_turns", 0) - 5)
        return max(0.88, 1.0 - 0.03 * stuck)

    def get_damage(self):
        d = super().get_damage()
        if self.cat_form:
            d = int(d * 1.28)  # кошка — высокий урон
        else:
            d = int(d * 0.95)  # человек — чуть слабее
        d = int(d * self._form_stale_mult())
        emp = getattr(self, "switch_empower", 0) or 0
        if emp:
            d = int(d * emp)
        return max(1, d)


    def get_dodge(self):
        d = super().get_dodge()
        if not self.cat_form:
            d = min(0.75, d + 0.12)  # человек — уклонение
        else:
            d = max(0.0, d - 0.03)
        return max(0.0, d)


    def take_damage(self, amount, ignore_armor=False, attacker=None):
        # кошка хрупче: +18% входящего
        if self.cat_form and amount > 0 and not ignore_armor:
            amount = int(amount * 1.05)
        return super().take_damage(amount, ignore_armor, attacker)

    def start_turn(self):
        logs, can_act = super().start_turn()
        self.form_turns = getattr(self, "form_turns", 0) + 1
        # без периодического burn — штраф застоя только в уроне (_form_stale_mult)
        if False and self.cat_form:
            pass
        return logs, can_act

    def note_attack(self, hit):
        super().note_attack(hit)
        if getattr(self, "switch_empower", 0):
            self.switch_empower = 0.0

    def skill_unlocked(self, skill):
        # Ловкость — только человек; серия ударов лучше из кошки, но доступна всегда
        if skill.key == "agility" and self.cat_form:
            return False
        return True

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар полукровки", "×1.0 база; кошка ×1.28, человек ×0.95; точность 90%", accuracy=0.9, icon="🐾"),
            DamageSkill("scratch", "Кровавая царапина", "×1.15 + кровотечение 3 ур. на 3 хода (сильнее из кошки)", multiplier=1.15,
                        effect=lambda: Bleed(3, 3), cost=15, cooldown=2, icon="🩸"),
            SelfBuffSkill("agility", "Танец теней", "+28% уклонения на 2 хода (только в облике человека)",
                          effects=[lambda: DodgeBuff(2, 28)], cost=18, cooldown=4, icon="💨"),
            DamageSkill("rake", "Кошачья серия", "3 удара по ×0.55 (итого ×1.65, масштабируется формой)", multiplier=0.55, hits=3,
                        cost=26, cooldown=3, icon="🌀"),
            TransformSkill("transform", "Смена облика",
                           "Человек↔кошка: портрет и роль; первый удар после смены ×1.35; сброс штрафа застоя",
                           cost=8, cooldown=2, icon="🐱"),
            PounceSkill("pounce", "Прыжок хищницы", "Мини-игра прыжков: сильнее из формы кошки",
                        cost=28, cooldown=5, icon="➡️"),
        ]

    def _on_reset(self):
        self.cat_form = False
        self.form_turns = 0
        self.switch_empower = 0.0

    def to_dict(self):
        data = super().to_dict()
        in_battle = bool(getattr(self, "_battle", None))
        show_cat = in_battle and bool(self.cat_form)
        data["cat_form"] = show_cat
        # вне боя роль всегда ловкач (человек)
        role = "warrior" if show_cat else "trickster"
        data["role"] = role
        data["role_name"] = self.ROLE_NAMES.get(role, role)
        data["image"] = self.image  # property already gates cat on _battle
        data["form_turns"] = getattr(self, "form_turns", 0) if in_battle else 0
        return data

    def describe(self):
        return super().describe() + (", 🐱 кошка" if self.cat_form else ", 👤 человек")



class CallBeastSkill(SummonSkill):
    """Трейфус: призвать волка/кабана/ястреба. Пешком (кодой пал) — зверь сильнее."""
    copyable = False

    def __init__(self, key, name, description, **kwargs):
        super().__init__(key, name, description, summon_factory=self._factory, **kwargs)

    def _factory(self, owner):
        empowered = not getattr(owner, "kodo_alive", True)
        return BeastCompanion(owner, empowered=empowered)

    def describe_for(self, user):
        if getattr(user, "kodo_alive", True):
            return ("Зов стаи: волк/кабан/ястреб на 3–4 хода — бьёт и перехватывает удары. "
                    "Пешком после гибели кодоя — усиленный призыв (+25% HP/урона, +1 ход).")
        return ("Яростный зов стаи: усиленный волк/кабан/ястреб (+25% HP и урона, дольше живёт). "
                "Доступно пешком после гибели кодоя.")

    def _perform(self, user, target):
        logs = super()._perform(user, target)
        s = user.summon
        if getattr(s, "empowered", False):
            logs.append(f"🔥 Без кодоя зверь {s.name} явился в ярости!")
        return logs

    def ai_score(self, user, target):
        if user.summon and user.summon.is_alive():
            return 0
        # пешком — чаще звать подмогу
        if not getattr(user, "kodo_alive", True):
            return 18
        if user.hp < user.max_hp * 0.45:
            return 12
        return 8


class BeastLord(Character):
    """Трейфус — повелитель зверей верхом на кодое. HP разделено: сначала бьют кодоя, потом наездника."""

    hero_class, type_key, resource_name = "Повелитель зверей", "beastlord", "связь"
    signature_skill = "kodo_charge"
    role = "tank"
    KODO_HP = 200
    RIDER_HP = 100
    KODO_SKILLS = {"kodo_charge", "kodo_stomp", "kodo_guard"}

    def __init__(self, name, level=1):
        total = self.KODO_HP + self.RIDER_HP
        super().__init__(name, max_hp=total, base_damage=12.0, armor=2, level=level,
                         speed=4, dodge=0.03, crit_chance=0.09,
                         max_energy=100, energy_regen=10, start_energy=30)
        self._init_split()

    def _init_split(self):
        # 5.4.1: ровно 200/100 на 1 ур.; дальше оба пула растут одинаково с уровнем
        scale = 1 + self.HP_PER_LEVEL * (self.level - 1)
        self.kodo_max = max(1, int(round(self.KODO_HP * scale)))
        self.rider_max = max(1, int(round(self.RIDER_HP * scale)))
        self.max_hp = self.kodo_max + self.rider_max
        self._raw_hp = self.KODO_HP + self.RIDER_HP
        self.kodo_hp = self.kodo_max
        self.rider_hp = self.rider_max
        self.kodo_alive = True
        # Два отдельно округлённых пула могут отличаться на 1 HP от суммы,
        # округлённой Character при создании (например, на 2-м уровне).
        Character.hp.fset(self, self.kodo_hp + self.rider_hp)

    def set_level(self, level):
        super().set_level(level)
        self._init_split()

    def _create_skills(self):
        return [
            DamageSkill("attack", "Топор степей", "×1.0 урона, точность 88%; пешком после гибели кодоя +15% урона", accuracy=0.88, icon="🪓"),
            DamageSkill("kodo_stomp", "Топот грома", "×1.4 урона, 30% оглушить на 1 ход (нужен живой кодой)",
                        multiplier=1.4, effect=lambda: Stun(1), effect_chance=0.3,
                        cost=22, cooldown=3, icon="🦶"),
            SelfBuffSkill("kodo_guard", "Панцирь кодоя", "Щит 12% суммарного HP на 3 хода (нужен живой кодой)",
                          effects=[lambda: Shield(3, max(1, int(self.max_hp * 0.12)))],
                          cost=25, cooldown=5, icon="🛡"),
            DamageSkill("twin_axes", "Парные топоры", "Два удара по ×0.75 (итого ×1.5)", multiplier=0.75, hits=2,
                        cost=20, cooldown=2, icon="⚔"),
            DamageSkill("war_cry", "Рёв степного хана", "Боевой рёв: удар ×1.5 урона", multiplier=1.5, cost=22, cooldown=3, icon="📣"),
            KodoChargeSkill("kodo_charge", "Таран кодоя", "Мини-игра тарана: огромный урон (нужен живой кодой)",
                            cost=30, cooldown=5, icon="🐃"),
            AxeStormSkill("axe_storm", "Буря топоров", "Мини-игра вихря топоров: сильнее пешком после гибели кодоя",
                          cost=28, cooldown=5, icon="🌪"),
            CallBeastSkill("call_beast", "Зов стаи",
                           "Призыв волка/кабана/ястреба на 3–4 хода (бьёт и перехватывает); пешком — +25% HP/урона и +1 ход",
                           cost=32, cooldown=7, min_turn=2, icon="🐺"),
        ]

    def skill_unlocked(self, skill):
        if skill.key in self.KODO_SKILLS and not self.kodo_alive:
            return False
        return True

    def get_damage(self):
        d = super().get_damage()
        return int(d * 1.15) if not self.kodo_alive else d

    @property
    def hp(self):
        return Character.hp.fget(self)

    @hp.setter
    def hp(self, value):
        # Все изменения HP, включая отражение и прямой урон эффектов, должны
        # одновременно менять оба пула. В журнал попадает только итог, без
        # временного восстановления здоровья между ударами.
        if not isinstance(value, (int, float)) or not hasattr(self, "kodo_hp"):
            Character.hp.fset(self, value)
            return
        total = max(0, min(int(value), self.max_hp))
        change = total - (self.kodo_hp + self.rider_hp)
        if change < 0:
            left = -change
            if self.kodo_alive:
                take = min(self.kodo_hp, left)
                self.kodo_hp -= take
                left -= take
                if self.kodo_hp == 0:
                    self.kodo_alive = False
                    self._events.append(Announcement(
                        f"💀 Кодой {self.name} пал! Наездник в ярости (+15% урона), умения кодоя недоступны."))
            self.rider_hp = max(0, self.rider_hp - left)
        elif change > 0:
            left = change
            if self.kodo_alive:
                add = min(self.kodo_max - self.kodo_hp, left)
                self.kodo_hp += add
                left -= add
            self.rider_hp += min(self.rider_max - self.rider_hp, left)
        # Стандартные take_damage/heal сохраняют броню, щиты, запрет лечения
        # и усталость; погибший кодой не воскрешается обычным лечением.
        Character.hp.fset(self, self.kodo_hp + self.rider_hp)

    def _on_reset(self):
        self._init_split()

    @property
    def image(self):
        # Скины Треифуса — только верхом на кодо; после гибели кодо портрет не меняется
        return Character.image.fget(self)
    def to_dict(self):
        data = super().to_dict()
        data["kodo_hp"] = self.kodo_hp
        data["kodo_max"] = self.kodo_max
        data["rider_hp"] = self.rider_hp
        data["rider_max"] = self.rider_max
        data["kodo_alive"] = self.kodo_alive
        data["hp_bars"] = [
            {"id": "kodo", "label": "Кодой", "hp": self.kodo_hp, "max": self.kodo_max, "icon": "🐂",
             "color": "#c9a227"},
            {"id": "rider", "label": "Наездник", "hp": self.rider_hp, "max": self.rider_max, "icon": "🧔",
             "color": "#4cd07d"},
        ]
        data["hp_split"] = True
        data["image"] = self.image
        return data

    def describe(self):
        if self.kodo_alive:
            return super().describe() + f", 🐃 {self.kodo_hp}/{self.kodo_max} + 🪓 {self.rider_hp}/{self.rider_max}"
        return super().describe() + f", пешком 🪓 {self.rider_hp}/{self.rider_max}"


class SpiderQueen(Character):
    """Нимерия — Королева пауков. Яды, паутина и паучки."""

    hero_class, type_key, resource_name = "Королева пауков", "spiderqueen", "яд"
    signature_skill = "queen_bite"
    role = "trickster"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=195, base_damage=14.0, armor=1, level=level,
                         speed=7, dodge=0.14, crit_chance=0.16,
                         max_energy=100, energy_regen=13, start_energy=40)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Укус паучихи", "×1.0 урона, точность 90% — быстрый укус клыками", accuracy=0.9, icon="🕷"),
            DamageSkill("venom", "Яд чёрной вдовы", "×1.25 урона + сильный яд 4 ур. на 3 хода", multiplier=1.25,
                        effect=lambda: Poison(3, 4), cost=18, cooldown=2, icon="☠️"),
            DebuffSkill("web", "Шёлковые путы", "Сильное замедление на 2 хода — липкая паутина",
                        effect=lambda: Slow(2, 3), cost=15, cooldown=3, icon="🕸"),
            DamageSkill("fang", "Клык королевы", "Пронзающий укус ×1.55 урона", multiplier=1.55, cost=24, cooldown=3, icon="🦷"),
            WebTrapSkill("web_trap", "Ткацкий капкан", "Мини-игра плетения: ловит врага в паутину (замедление/урон)",
                         cost=25, cooldown=5, icon="🪤"),
            SpiderlingSkill("spiderlings", "Выводок гнезда", "Мини-игра: выпустить выводок паучков (множественные укусы)",
                            cost=28, cooldown=5, icon="🕷"),
            QueenBiteSkill("queen_bite", "Поцелуй вдовы", "Мини-игра: смертельный укус — огромный яд при идеале",
                           cost=30, cooldown=5, icon="👑"),
        ]


class Ranger(Character):
    """Элайра — полуэльфийка-следопытка. Копьё и лук, суть — кровотечение."""

    hero_class, type_key, resource_name = "Следопытка", "ranger", "меткость"
    signature_skill = "bleed_volley"
    role = "light"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=195, base_damage=14.8, armor=1, level=level,
                         speed=7, dodge=0.13, crit_chance=0.17,
                         max_energy=100, energy_regen=13, start_energy=40)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Выстрел следопыта", "×1.0 урона, точность 90%; углубляет уже висящее кровотечение", accuracy=0.9, icon="🏹"),
            DamageSkill("bleed_arrow", "Стрела кровоточия", "×1.0 урона + кровотечение 4 ур. на 3 хода; углубляет раны", multiplier=1.0,
                        effect=lambda: Bleed(3, 4), cost=18, cooldown=3, icon="🩸"),
            DamageSkill("spear_jab", "Укол рогатины", "×1.4 урона + кровотечение 3 ур. на 2 хода; углубляет раны", multiplier=1.4,
                        effect=lambda: Bleed(2, 3), cost=20, cooldown=3, icon="🔱"),
            DamageSkill("quick_shots", "Тройной выстрел", "3 быстрых выстрела по ×0.5 (итого ×1.5)", multiplier=0.5, hits=3,
                        cost=25, cooldown=3, icon="💥"),
            DebuffSkill("mark", "Метка добычи", "Точность врага −10% на 3 хода — помеченная цель слепнет",
                        effect=lambda: Blinded(3, 10), cost=15, cooldown=4, icon="🎯"),
            BleedVolleySkill("bleed_volley", "Кровавый залп", "Мини-игра веера стрел: много кровотечения",
                             cost=28, cooldown=5, icon="🏹"),
            SpearThrowSkillMG("spear_throw", "Метательная рогатина", "Мини-игра броска: мощное копьё + кровотечение",
                              cost=30, cooldown=5, icon="↗️"),
        ]

    def on_hit_landed(self, target, skill):
        bleeds = [e for e in target.get_effects() if isinstance(e, Bleed)]
        if bleeds and skill.key in ("bleed_arrow", "spear_jab", "attack"):
            bleeds[0].power += 1
            return [f"🩸 Раны {target.name} углубляются ({bleeds[0].power}/ход)."]
        return []


class Pandaren(Character):
    """Кейвин — пандарен-воин. Обливает врага выпивкой, затем поджигает дыханием."""

    hero_class, type_key, resource_name = "Пандарен", "pandaren", "брага"
    signature_skill = "ignite"
    role = "warrior"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=228, base_damage=14.5, armor=3, level=level,
                         speed=4, dodge=0.05, crit_chance=0.12,
                         max_energy=100, energy_regen=11, start_energy=35)

    def _create_skills(self):
        return [
            DamageSkill("attack", "Лапа хмелевара", "×1.0 урона, точность 88% — тяжёлая лапа", accuracy=0.88, icon="👊"),
            DamageSkill("belly", "Удар бочонком живота", "×1.35 урона, 25% оглушить на 1 ход", multiplier=1.35,
                        effect=lambda: Stun(1), effect_chance=0.25, cost=20, cooldown=3, icon="🍺"),
            DamageSkill("keg_smash", "Крушитель бочонков", "Мощный удар бочонком ×1.55 урона", multiplier=1.55, cost=25, cooldown=3, icon="🛢"),
            SelfBuffSkill("fortify", "Стойкость монастыря", "Щит 12% макс. HP на 3 хода",
                          effects=[lambda: Shield(3, max(1, int(self.max_hp * 0.12)))],
                          cost=22, cooldown=5, icon="🛡"),
            DamageSkill("spin", "Круговой хмель", "Два круговых удара по ×0.8 (итого ×1.6)", multiplier=0.8, hits=2,
                        cost=22, cooldown=3, icon="🌀"),
            DouseSkillMG("douse", "Окатить брагой", "Мини-игра: пропитывает врага — усиливает огненное дыхание",
                         cost=20, cooldown=4, icon="🍺"),
            BreathIgniteSkill("ignite", "Дыхание печи", "Мини-игра: поджигает; по пропитанному брагой — огромный урон",
                              cost=28, cooldown=4, icon="🔥"),
        ]


class ColorCardSkill(Skill):
    """Цветные карты Вейла: нельзя один цвет подряд. Синяя копит комбо для красной/жёлтой."""
    copyable = False
    COLOR = "blue"

    def is_available(self, user):
        last = getattr(user, "last_card_color", None)
        return super().is_available(user) and last != self.COLOR

    def _perform(self, user, target):
        user.last_card_color = self.COLOR
        return self._card(user, target)

    def _card(self, user, target):
        raise NotImplementedError

    def ai_score(self, user, target):
        if getattr(user, "last_card_color", None) == self.COLOR:
            return 0
        return 14


def _veil_combo(user):
    return int(getattr(user, "veil_combo", 0) or 0)


def _veil_set_combo(user, n):
    user.veil_combo = max(0, min(2, int(n)))


class BlueCard(ColorCardSkill):
    """Синяя — двигатель колоды: удача + заряд комбо для красной/жёлтой."""
    COLOR = "blue"

    def describe_for(self, user):
        c = _veil_combo(user)
        return (f"Комбо-заряд (+1, макс 2) и +38 удачи · нельзя подряд. "
                f"Без синей красная/жёлтая слабы. Сейчас комбо: {c}")

    def _card(self, user, target):
        before = _veil_combo(user)
        _veil_set_combo(user, before + 1)
        user.restore_energy(38)
        return [f"🟦 Синяя карта: {user.name} +38 удачи, комбо {before}→{_veil_combo(user)} "
                f"(следующая красная/жёлтая усилена)."]

    def ai_score(self, user, target):
        if getattr(user, "last_card_color", None) == self.COLOR:
            return 0
        combo = _veil_combo(user)
        # синяя обязательна в ротации: нет комбо или мало удачи — высокий приоритет
        if combo <= 0:
            return 22
        if user.energy < 40:
            return 20
        if combo < 2 and user.energy < 70:
            return 16
        return 12


class RedCard(ColorCardSkill):
    COLOR = "red"

    def describe_for(self, user):
        combo = _veil_combo(user)
        if combo > 0:
            dmg = max(1, int(round(user.get_damage() * 2.45)))
            return f"КОМБО: урон ~{dmg} (245% силы) · тратит 1 комбо · нельзя подряд"
        dmg = max(1, int(round(user.get_damage() * 0.95)))
        return f"Без комбо слабо: урон ~{dmg} (95%) · нужна синяя · нельзя подряд"

    def _card(self, user, target):
        combo = _veil_combo(user)
        if combo > 0:
            _veil_set_combo(user, combo - 1)
            sk = DamageSkill("_red", "Красная", "", multiplier=2.45, accuracy=0.92)
            return [f"🟥 Красная карта (КОМБО)! Осталось комбо: {_veil_combo(user)}"] + sk._perform(user, target)
        # без синей — дорого и слабо
        sk = DamageSkill("_red", "Красная", "", multiplier=0.95, accuracy=0.85)
        return [f"🟥 Красная без комбо: слабо. Сыграйте синюю!"] + sk._perform(user, target)

    def ai_score(self, user, target):
        if getattr(user, "last_card_color", None) == self.COLOR:
            return 0
        if _veil_combo(user) <= 0:
            return 3  # почти не брать без комбо
        return 19


class YellowCard(ColorCardSkill):
    COLOR = "yellow"

    def describe_for(self, user):
        combo = _veil_combo(user)
        if combo > 0:
            dmg = max(1, int(round(user.get_damage() * 0.95)))
            return f"КОМБО: оглушение 1 ход + урон ~{dmg} · тратит 1 комбо · нельзя подряд"
        dmg = max(1, int(round(user.get_damage() * 0.45)))
        return f"Без комбо: урон ~{dmg}, без оглушения · нужна синяя · нельзя подряд"

    def _card(self, user, target):
        combo = _veil_combo(user)
        if combo > 0:
            _veil_set_combo(user, combo - 1)
            target.add_effect(Stun(1))
            sk = DamageSkill("_yel", "Жёлтая", "", multiplier=0.9, accuracy=0.9)
            return [f"🟨 Жёлтая (КОМБО): оглушение! Комбо→{_veil_combo(user)}"] + sk._perform(user, target)
        sk = DamageSkill("_yel", "Жёлтая", "", multiplier=0.45, accuracy=0.85)
        return [f"🟨 Жёлтая без комбо: нет оглушения. Сыграйте синюю!"] + sk._perform(user, target)

    def ai_score(self, user, target):
        if getattr(user, "last_card_color", None) == self.COLOR:
            return 0
        if _veil_combo(user) <= 0:
            return 2
        if target.has_effect(Stun):
            return 8
        return 18


class GreenCard(ColorCardSkill):
    """Зелёная — лечение; не тратит комбо, но без синей ротации удачи не хватит на дорогие карты."""
    COLOR = "green"

    def describe_for(self, user):
        amt = max(1, int(user.max_hp * 0.10))
        return f"Лечение ~{amt} HP (10% макс.) и +8 удачи · нельзя подряд · комбо не тратит"

    def _card(self, user, target):
        amount = max(1, int(user.max_hp * 0.10))
        healed = user.heal(amount)
        user.restore_energy(8)
        return [f"🟩 Зелёная карта: {user.name} +{healed} HP и 8 удачи."]

    def ai_score(self, user, target):
        if getattr(user, "last_card_color", None) == self.COLOR:
            return 0
        if user.hp < user.max_hp * 0.5:
            return 15
        if user.hp < user.max_hp * 0.75:
            return 9
        return 5


class BluffCard(Skill):
    """Карта блефа — вторая защита: высокий уклон и снижение урона."""
    copyable = False

    def describe_for(self, user):
        return "+22% уклонения и −12% входящего урона на 2 хода (дорого — копите синей)"

    def _perform(self, user, target):
        user.add_effect(DodgeBuff(2, 22))
        user.add_effect(DamageReduction(2, 12, title="Блеф"))
        return [f"🂡 {user.name} блефует картой: +22% уклонения и −12% входящего урона на 2 хода."]

    def ai_score(self, user, target):
        if user.has_effect(DodgeBuff) and user.has_effect(DamageReduction):
            return 0
        if user.hp < user.max_hp * 0.4 and user.energy >= self.cost:
            return 15
        return 7


class GuardCard(Skill):
    copyable = False

    def describe_for(self, user):
        sh = max(1, int(user.max_hp * 0.14))
        return f"Щит ~{sh} HP (14%) и +15% уклонения на 2 хода (дорого — копите синей)"

    def _perform(self, user, target):
        user.add_effect(Shield(2, max(1, int(user.max_hp * 0.14))))
        user.add_effect(DodgeBuff(2, 15))
        return [f"🛡 {user.name} закрывается картой: щит 14% и +15% уклонения."]

    def ai_score(self, user, target):
        if user.has_effect(Shield):
            return 0
        if user.hp < user.max_hp * 0.55 and user.energy >= self.cost:
            return 13
        return 6


class Gambler(Character):
    """Вейл — Картежник. Синяя копит комбо; красная/жёлтая сильны только с комбо; дорогая колода без синей не тянет."""

    hero_class, type_key, resource_name = "Картежник", "gambler", "удача"
    signature_skill = "card_draw"
    role = "trickster"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=212, base_damage=16.0, armor=1, level=level,
                         speed=7, dodge=0.15, crit_chance=0.21,
                         max_energy=100, energy_regen=10, start_energy=44)
        self.last_card_color = None
        self.veil_combo = 0

    def _create_skills(self):
        return [
            DamageSkill("attack", "Удар колодой", "×1.0 урона ребром колоды, точность 90%", accuracy=0.9, icon="🃏"),
            BlueCard("blue_card", "Синий туз хода",
                     "+1 комбо (макс 2) и +38 удачи; двигатель колоды; нельзя подряд",
                     cost=0, cooldown=1, icon="🟦"),
            RedCard("red_card", "Красный валет удара",
                    "С комбо: ×2.45 урона; без комбо ×0.95; нельзя подряд",
                    cost=30, cooldown=1, icon="🟥"),
            YellowCard("yellow_card", "Жёлтая дама оглушения",
                       "С комбо: оглушение 1 ход + ×0.9; без комбо ×0.45 без стана; нельзя подряд",
                       cost=32, cooldown=2, icon="🟨"),
            GuardCard("guard_card", "Карта баррикады", "Щит 14% макс. HP и +15% уклонения на 2 хода",
                      cost=36, cooldown=4, icon="🛡"),
            GreenCard("green_card", "Зелёный король удачи", "Лечит 10% макс. HP и +8 удачи; нельзя подряд",
                      cost=24, cooldown=2, icon="🟩"),
            BluffCard("bluff_card", "Блеф крупняка", "+22% уклонения и −12% входящего урона на 2 хода",
                      cost=28, cooldown=5, icon="🂡"),
            CardDrawSkill("card_draw", "Слепой розыгрыш",
                          "Мини-игра: 4 карты (валет/дама/король/туз) с уникальными эффектами",
                          cost=44, cooldown=5, icon="🂠"),
        ]

    def _on_reset(self):
        self.last_card_color = None
        self.veil_combo = 0

    def to_dict(self):
        data = super().to_dict()
        data["last_card_color"] = self.last_card_color
        data["card_lock"] = self.last_card_color
        data["veil_combo"] = _veil_combo(self)
        return data

    def describe(self):
        lock = f", 🔒 {self.last_card_color}" if self.last_card_color else ""
        combo = f", 🎴 комбо {_veil_combo(self)}" if _veil_combo(self) else ""
        return super().describe() + lock + combo


NEW_HEROES_54 = {
    "aarakocra": Aarakocra,
    "hunter": Hunter,
    "gnoll": Gnoll,
    "centaur": Centaur,
    "bluetroll": BlueTroll,
    "paladin": Paladin,
    "catfolk": Catfolk,
    "beastlord": BeastLord,
    "spiderqueen": SpiderQueen,
    "ranger": Ranger,
    "pandaren": Pandaren,
    "gambler": Gambler,
}
HERO_CLASSES.update(NEW_HEROES_54)

DEFAULT_NAMES_54 = {
    "aarakocra": "Скайр",
    "hunter": "Дэрил",
    "gnoll": "Рексор",
    "centaur": "Талар",
    "bluetroll": "Рокх-анн",
    "paladin": "Серена",
    "catfolk": "Анниса",
    "beastlord": "Трейфус",
    "spiderqueen": "Нимерия",
    "ranger": "Элайра",
    "pandaren": "Кейвин",
    "gambler": "Вейл",
}
