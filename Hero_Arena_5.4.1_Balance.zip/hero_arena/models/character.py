"""Персонажи: родитель Character и 25 классов героев (плюс мобы сюжета).

Здесь: Warrior (Воин), Mage (Маг), Archer (Лучник), Ogre (Огр), Spartan (Спартанец), Assassin (Ассасин),
Samurai (Самурай), Druid (Друид), Monk (Монах, открывается за победы), DarkElf (Тёмный эльф),
Owlbeast (Совух, секретный).
heroes_new.py: Musketeer, Pagan, Minotaur, Croc, DarkKnight (+ мобы «Тёмного леса»).
heroes_42.py: GazLow (Гоблин), Satyr, Ghoul, Rhino, Durrila (Богатырь), Orc, Dwarf, LightElf, Nefruit (Тень).
"""
import random
from .ai import evaluating

from models import hp_journal

from .inventory import Inventory
from .item import Katana, KATANAS
from .effects import (Announcement, Bleed, DeepBleed, Burn, Poison, Acid, DarkCurse, Stun,
                      Shield, StoneSkin, StoneShield, Berserk, Evasion, Invisibility,
                      CounterStance, Regeneration, Contract, Antiheal, Intimidated, MastBuff,
                      DodgeBuff, Slow, Blinded, Weakened, DamageReduction, Chill, CalmShield, MeleeMode,
                      DamageOverTime)

from .skills import (DamageSkill, HealSkill, SelfBuffSkill, BackstabSkill, LifestealSkill,
                     SummonSkill, ReactionSkill, ContractSkill, WeaknessSkill, DebuffSkill)
from .summons import WaterSpirit, Clone, random_beast
from .minigames_42 import ForestCallSkill, RuneSealSkill, ParrySkill, NephewsSkill, NightHuntSkill, GustSkill
from .effects_42 import Guard, ParryStance, Rooted
from .minigames_54 import IaiFlashSkill
from .minigames import (ArmorCrossesSkill, DeerHuntSkill, FeastSkill, ShieldWallSkill, ReadEnemySkill, ReadEnemy,
                        ShunpoSkill, KnifeThrowSkill, MastSkill, ShadowRitualSkill, BloodShieldSkill)


class Character:
    """Базовый класс персонажа арены."""

    _next_id = 1
    hero_class = "Персонаж"
    type_key = "character"        # ключ для API и картинки
    resource_name = "энергия"     # как называется ресурс (мана, ярость...)
    signature_skill = "attack"    # главное умение для use_skill()
    required_wins = 0             # сколько побед игрока нужно, чтобы открыть класс
    secret = False                # секретный класс (Совух) скрыт, пока не найден секрет
    creatable = True              # можно ли создать героя этого класса через форму/API
    role = "warrior"              # роль — light (лёгкие), warrior (воины), tank (танки; до 4.2 — «монстры»), trickster (ловкач)
    mob = False                   # 4.0: моб сюжета (не герой арены)
    MAX_LEVEL = 25                # 5.0: максимум 25 (к Карр-Галлу)
    STORY_BAG_SLOTS = 8        # 5.2: слоты сюжетной сумки (стек одного ключа = 1 слот)
    HP_PER_LEVEL = 0.025           # 4.0: +2.5% HP за уровень (было +15 HP — разница в 2 уровня давала ~90% побед)
    DMG_PER_LEVEL = 0.025         # 4.0: +2.5% урона за уровень (было +2 урона)
    POWER_PER_LEVEL = 0.025        # 4.0: яды, звери, лечение и щиты растут на 2.5% за уровень
    HP_SCALE = 1.0                # 4.0: общий множитель HP (длина боёв)
    FATIGUE_HEAL_CUT = 1.0   # 4.4: лечение слабее на столько же процентов, на сколько усталость усилила удары
    MIN_HIT = 0.4        # 4.4: шанс попасть никогда не ниже 40% (было 10%: слои уклонения давали «жёсткие контры»)
    ACC_BONUS = 0.0      # 4.4: прибавка к точности всех атак героя
    DODGE_PIERCE = 0.0   # 4.4: доля уклонения цели, которую игнорируют атаки героя
    GLANCING = 0.0       # 4.4: промах всё равно задевает на эту долю урона (огр)
    MAGIC_GUARD = 0.0    # 4.4: насколько слабее по герою удары «сквозь броню» (магия и т.п.)
    DOT_RESIST = 0.0     # 4.4: насколько слабее по герою бьют яд, горение и кровотечение (богатырь)
    ROLE_NAMES = {"light": "Лёгкий", "warrior": "Воин", "tank": "Танк", "trickster": "Ловкач",
                  "monster": "Танк"}   # 4.2: роль «Монстр» переименована в «Танк» (ключ monster — для старых данных)

    def __init__(self, name, max_hp=200, base_damage=10, armor=0, level=1,
                 speed=5, dodge=0.05, crit_chance=0.1, crit_multiplier=1.5,
                 max_energy=100, energy_regen=10, start_energy=50):
        if not name or not str(name).strip():
            raise ValueError("Имя героя не может быть пустым")
        self.id = Character._next_id
        Character._next_id += 1
        self.name = str(name).strip()
        level = max(1, min(int(level), self.MAX_LEVEL))
        self.level = level
        from .tuning import HP_TUNING
        self._raw_hp = int(max_hp * self.HP_SCALE * HP_TUNING.get(self.type_key, 1.0))

        self.max_hp = self._hp_for_level(level)
        self.__hp = self.max_hp           # приватный: только через свойство hp
        self._raw_damage = base_damage
        self._base_damage = base_damage   # защищённый

        from .tuning import KIT_TUNING
        kit = KIT_TUNING.get(self.type_key, {})   # 4.4: подстройка набора (броня/уклонение/точность)
        self._armor = armor + kit.get("armor", 0)  # защищённый
        self._default_armor = self._armor  # class baseline for persistent balance migrations
        self.speed = speed                # инициатива: кто ходит первым
        self.dodge = round(max(0.0, dodge + kit.get("dodge", 0.0)), 3)   # шанс уклонения 0..1
        self.acc_bonus = self.ACC_BONUS + kit.get("acc", 0.0)          # 4.4: бонус точности героя
        self.crit_chance = crit_chance
        self.crit_multiplier = crit_multiplier
        self.max_energy = max_energy
        self.energy_regen = energy_regen
        self._start_energy = start_energy
        self.__energy = start_energy      # приватный ресурс (мана/ярость/энергия)
        self.experience = 0
        self.wins = 0
        self.losses = 0
        self.weapon = None
        self.inventory = Inventory()
        self.opponent = None              # соперник в текущем бою (ставит Battle)
        self.summon = None                # призванное существо (Summon) или None
        self.turn_number = 0              # номер собственного хода в бою
        self._effects = []                # активные эффекты (яд, щит...)
        self._cooldowns = {}              # ключ умения → сколько ходов ждать
        self._blocked = {}                # умения, заблокированные врагом (Вальхалла)
        self._used_once = set()           # умения «раз за бой», которые уже применены
        self._events = []                 # события при получении урона (щит, блок)
        self.owner_id = None              # id игрока-владельца (свой герой может ходить в магазин)
        self.custom = False               # True — герой создан самим игроком (не стартовый/ИИ)
        self.protected = False            # True — героя нельзя удалить (Грозокрыл)
        self.skin = None
        self.random_skin = False   # 5.2: каждый бой — случайный облик из купленных
        self.last_random_skin = None  # чтобы не повторять подряд
        # skin: надетый облик "gold"/"blood"/"frost" или None
        self.skins = []                   # купленные облики (принадлежат только этому герою)
        # ----- 4.0 -----
        self.fatigue = 0.0                # усталость с 30-го раунда: +4% урона за раунд
        self.battle_item = None           # ключ предмета, взятого в этот бой (один предмет на бой)
        self.item_used = False
        self.perfect = False              # «идеальный игрок» в мини-играх (для balance.py)
        self.story = False                # сюжетный герой (только для вкладки «Сюжет»)
        self.story_progress = {}          # {"forest": пройдено этапов}
        self.story_flags = {}
        self.story_bag = {}          # 5.0: сюжетные расходники {key: count}
        self.story_pending_loot = []  # 5.2: награды, ждущие свободный слот
        self.npc = False                  # основной герой-противник (Конан, Мерлин…)
        self.skills = {}

        for skill in self._create_skills():
            self.skills[skill.key] = skill

    def _create_skills(self):
        """Список умений героя. Наследники переопределяют и дополняют."""
        return [DamageSkill("attack", "Удар", "Обычная атака", icon="👊")]

    # ---------- Инкапсуляция: HP ----------
    @property
    def hp(self):
        """Текущее здоровье (только чтение напрямую)."""
        return self.__hp

    @hp.setter
    def hp(self, value):
        """Сеттер с валидацией: HP всегда в диапазоне 0..max_hp."""
        if not isinstance(value, (int, float)):
            raise ValueError("HP должно быть числом")
        self.__hp = max(0, min(int(value), self.max_hp))
        hp_journal.record(str(self.id), self.__hp)   # для пошаговой анимации полосок

    # ---------- Инкапсуляция: ресурс ----------
    @property
    def energy(self):
        return self.__energy

    def spend_energy(self, amount):
        if amount > self.__energy:
            raise ValueError(f"Не хватает ресурса «{self.resource_name}»")
        self.__energy -= amount

    def restore_energy(self, amount):
        self.__energy = max(0, min(self.max_energy, self.__energy + amount))

    @property
    def armor(self):
        return self._armor

    def armor_total(self):
        """Броня с учётом эффектов (Оберег, дар Мокоши, форма медведя, Панцирь)."""
        return max(0, self._armor + sum(e.armor_bonus() for e in self._effects))

    # ---------- 4.0: уровень ----------
    def _hp_for_level(self, level):
        return int(round(self._raw_hp * (1 + self.HP_PER_LEVEL * (level - 1))))

    def power_scale(self):
        """Множитель силы ядов, зверей, лечения и щитов от уровня."""
        return 1 + self.POWER_PER_LEVEL * (self.level - 1)

    def set_level(self, level):
        """Поставить уровень (ИИ-противник подстраивается под уровень игрока)."""
        level = max(1, min(int(level), self.MAX_LEVEL))
        self.level = level
        self.max_hp = self._hp_for_level(level)
        self.hp = self.max_hp

    def level_group(self):
        """Группа уровней для подбора соперника: 1–3, 4–6, 7–9…"""
        return (self.level - 1) // 3

    def get_crit(self):
        return self.crit_chance + sum(e.crit_bonus() for e in self._effects)

    def get_speed(self):
        return self.speed + sum(e.speed_bonus() for e in self._effects)


    @armor.setter
    def armor(self, value):
        if not isinstance(value, (int, float)) or value < 0 or value > 50:
            raise ValueError("Броня должна быть от 0 до 50")
        self._armor = value

    # ---------- Состояние ----------
    def is_alive(self):
        return self.__hp > 0

    def take_damage(self, amount, ignore_armor=False, attacker=None):
        """Получить урон: броня → эффекты (щит, контратака) → HP. Возвращает урон."""
        if ignore_armor and attacker is not None and self.MAGIC_GUARD:
            amount = amount * (1 - self.MAGIC_GUARD)   # 4.4: защита от ударов сквозь броню (спартанец, крок)
        damage = amount if ignore_armor else amount - self.armor_total()

        damage = max(1, int(damage))
        for eff in list(self._effects):
            damage, logs = eff.modify_incoming(self, damage, attacker)
            self._events.extend(logs)
        self.hp = self.__hp - damage
        return damage

    def pop_events(self):
        """Забрать накопленные события (для журнала боя)."""
        events, self._events = self._events, []
        return events

    def heal(self, amount):
        """Восстановить HP. Под «Запретом исцеления» лечение не работает (вернёт 0)."""
        if amount > 0 and self.has_effect(Antiheal):
            self._events.append(f"🚫 {self.name} не может лечиться — запрет исцеления!")
            return 0
        if amount > 0 and self.fatigue > 0 and self.FATIGUE_HEAL_CUT:
            # 4.4: усталость режет и лечение — затяжные бои «на отхиле» не тянутся бесконечно
            amount = int(amount * max(0.0, 1 - self.fatigue * self.FATIGUE_HEAL_CUT))
        before = self.__hp
        self.hp = self.__hp + amount
        return self.__hp - before

    def equip(self, weapon):
        self.weapon = weapon

    def get_damage(self):
        bonus = self.weapon.damage_bonus if self.weapon else 0
        from .tuning import DMG_TUNING
        k = DMG_TUNING.get(self.type_key, 1.0)
        return round(self._base_damage * k * (1 + self.DMG_PER_LEVEL * (self.level - 1)), 1) + bonus



    def damage_multiplier(self):
        return max(0.1, 1 + sum(e.damage_bonus() for e in self._effects))

    def get_dodge(self):
        bonus = 0.0
        summon = getattr(self, "summon", None)
        if summon is not None and summon is not self and summon.is_alive():
            bonus = getattr(summon, "OWNER_DODGE", 0.0)   # 4.4: хомяк прикрывает друида
        # 4.4: не ниже 0 — «Оковы корней» (−100%) давали отрицательное уклонение = +80% к точности врага
        return max(0.0, min(0.75, self.dodge + bonus + sum(e.dodge_bonus() for e in self._effects)))

    # ---------- Хуки боя (переопределяют наследники) ----------
    def hit_chance(self, skill, victim):
        """Шанс попасть умением по цели."""
        acc = skill.accuracy + getattr(self, "acc_bonus", 0.0) + sum(e.accuracy_bonus() for e in self._effects)
        # 4.4: DODGE_PIERCE — доля уклонения цели, которую игнорирует герой (самонаводящаяся магия мага)
        return max(self.MIN_HIT, acc - victim.get_dodge() * (1 - self.DODGE_PIERCE))


    def on_hit_landed(self, target, skill):
        """Вызывается, когда атака героя попала. Возвращает список строк лога."""
        return []

    def pick_defender(self, attacker):
        """Кто примет удар: сам герой или его призванное существо."""
        chance = self.summon.intercept_chance if self.summon and self.summon.is_alive() else 0
        chance *= 1 - getattr(attacker, "INTERCEPT_IGNORE", 0)   # 4.3: ассасин целится в хозяина, а не в зверя
        if chance and random.random() < chance:
            return self.summon
        return self

    def death_note(self):
        return ""

    def battle_intro(self):
        """Что герой объявляет в начале боя (самурай — свою катану)."""
        return []

    def note_attack(self, hit):
        """Хук: атака попала (True) или промахнулась (False). Совух копит инстинкт."""

    # ---------- Облики и расходники ----------
    @property
    def image(self):
        if self.skin:
            return f"/static/images/skins/{self.type_key}_{self.skin}.jpg"
        return f"/images/{self.type_key}"

    def add_skin(self, skin):
        if skin in self.skins:
            raise ValueError("Этот облик уже куплен")
        self.skins.append(skin)

    def equip_skin(self, skin):
        """Надеть купленный облик (None — вернуть обычный портрет)."""
        if skin is not None and skin not in self.skins:
            raise ValueError("Сначала купите этот облик")
        self.skin = skin
        if skin is not None:
            self.random_skin = False  # ручной выбор выключает рандом

    def skin_options(self, account_skins=None):
        """Варианты облика: обычный (None) + купленные (герой + аккаунт)."""
        owned = set(self.skins or [])
        if account_skins:
            owned |= set(account_skins)
        return [None] + sorted(owned)

    def set_random_skin(self, enabled, account_skins=None):
        """5.2: включить/выключить случайный облик. Нужно ≥2 варианта (обычный + хотя бы 1 скин)."""
        opts = self.skin_options(account_skins)
        if enabled and len([s for s in opts if s]) < 1:
            raise ValueError("Случайный скин нужен, когда есть хотя бы один купленный облик")
        self.random_skin = bool(enabled)
        return self.random_skin

    def pick_random_battle_skin(self, account_skins=None, rng=None):
        """5.3: случайный облик ТОЛЬКО из купленных (без обычного/None). Не повторять предыдущий."""
        import random as _rnd
        rng = rng or _rnd
        opts = [s for s in self.skin_options(account_skins) if s]  # без default
        if not opts:
            return self.skin
        pool = list(opts)
        last = getattr(self, "last_random_skin", None)
        if last in pool and len(pool) > 1:
            pool = [s for s in pool if s != last]
        choice = rng.choice(pool)
        self.last_random_skin = choice
        self._had_random_pick = True
        return choice

    def story_bag_slots_used(self):
        """5.3: слоты = предметы в инвентаре (единая сумка 5 кг)."""
        return len(self.inventory.get_items())

    def story_bag_capacity(self):
        return self.inventory.max_slots

    def story_bag_can_add(self, key):
        """5.3: проверка по инвентарю (вес 5 кг / 10 слотов), story_bag — зеркало."""
        from .item import CONSUMABLES
        cls = CONSUMABLES.get(key)
        if not cls:
            return False
        proto = cls()
        inv = self.inventory
        if len(inv.get_items()) >= inv.max_slots:
            return False
        if inv.total_weight + proto.weight > inv.max_weight + 1e-9:
            return False
        return True

    def discard_story_item(self, key, count=1):
        """5.3: выбросить из инвентаря (+ зеркало story_bag)."""
        n = max(1, int(count))
        removed = 0
        items = list(self.inventory.get_items())
        for it in items:
            if removed >= n:
                break
            if getattr(it, "key", None) == key:
                self.inventory.remove_item(it.id)
                removed += 1
        bag = getattr(self, "story_bag", None)
        if bag is None:
            self.story_bag = {}
            bag = self.story_bag
        if removed:
            bag[key] = max(0, bag.get(key, 0) - removed)
            if bag.get(key, 0) <= 0:
                bag.pop(key, None)
        elif key not in bag or bag[key] <= 0:
            raise ValueError(f"В сумке нет предмета «{key}»")
        else:
            bag[key] = bag.get(key, 0) - n
            if bag[key] <= 0:
                bag.pop(key, None)
        return dict(bag)

    def consumable_counts(self):
        """Сколько расходников каждого вида лежит в сумке героя."""
        counts = {}
        for item in self.inventory.get_items():
            key = getattr(item, "key", None)
            if key and getattr(item, "battle_usable", False):
                counts[key] = counts.get(key, 0) + 1
        return counts

    def use_consumable(self, key, target):
        """Достать предмет из СВОЕЙ сумки и применить в бою (тратит ход).
        4.0: в бой берётся ОДИН предмет (battle_item), применить его можно один раз."""
        from .item import CONSUMABLES, consumable_prototype
        if self.has_effect(Stun):
            raise ValueError(f"{self.name} оглушён — предмет использовать нельзя")
        if self.battle_item is not None:
            if key != self.battle_item or self.item_used:
                raise ValueError(f"В этот бой {self.name} взял другой предмет или уже использовал его")
            self.item_used = True
            if getattr(self, "_free_item", False):       # ИИ или сюжетная сумка
                # 5.3: списать из инвентаря (+ зеркало story_bag)
                for it in list(self.inventory.get_items()):
                    if getattr(it, "key", None) == key:
                        self.inventory.remove_item(it.id)
                        break
                bag = getattr(self, "story_bag", None)
                if bag is not None and key in bag:
                    bag[key] = max(0, bag.get(key, 0) - 1)
                    if bag[key] <= 0:
                        bag.pop(key, None)
                return consumable_prototype(key).battle_use(self, target)
        for item in self.inventory.get_items():
            if getattr(item, "key", None) == key and getattr(item, "battle_usable", False):
                self.inventory.remove_item(item.id)
                return item.battle_use(self, target)
        raise ValueError(f"У {self.name} нет предмета «{key}»")

    def usable_item(self):
        """Ключ предмета, который можно применить сейчас (или None)."""
        if self.battle_item is None or self.item_used:
            return None
        if getattr(self, "_free_item", False) or self.consumable_counts().get(self.battle_item):
            return self.battle_item
        return None


    def summon_act(self, target):
        """Ход призванного существа после хода героя. 4.0: у некоторых существ ограничен срок жизни."""
        logs = []
        if self.summon and self.summon.is_alive() and target.is_alive():
            logs = self.summon.attack(target)
            if hasattr(self.summon, "tick_boost"):
                self.summon.tick_boost()      # 4.3: «Зов леса» — 3 хода, а не 3 удара
            if self.summon.tick_life():
                logs.append(Announcement(f"{self.summon.icon} {self.summon.name} исчезает — время вышло."))
        return logs

    # ---------- 4.0: «Читай врага» и сила против ролей ----------
    def damage_vs(self, victim):
        """Множитель урона против конкретной цели (переопределяют наследники, например Крок)."""
        return 1.0

    @staticmethod
    def action_category(actor, key):
        """Тип действия для «Читай врага»: attack / skill / defense."""
        if key == "attack":
            return "attack"
        if str(key).startswith("item:"):
            return "defense"
        skill = actor.skills.get(key)
        return "skill" if skill is not None and hasattr(skill, "multiplier") else "defense"

    def on_enemy_action(self, enemy, key):
        """Враг собирается сделать действие key. Спартанец с «Читай врага» может его предугадать."""
        mark = next((e for e in self._effects if isinstance(e, ReadEnemy)), None)
        if mark is None or not self.is_alive():
            return []
        self._effects.remove(mark)
        if self.action_category(enemy, key) != mark.guess:
            return [f"👁 {self.name} не угадал замысел {enemy.name}."]
        self.add_effect(DamageReduction(1, 70, title="Предугадал"))
        logs = [Announcement(f"👁 {self.name} предугадал действие {enemy.name} и бьёт первым!")]
        logs.extend(self.skills["attack"].execute(self, enemy))
        return logs

    # ---------- Эффекты, перезарядки, блокировки ----------
    def add_effect(self, effect):
        """Наложить эффект. Оглушение не складывается; «stacks»-эффекты суммируются."""
        if isinstance(effect, Stun) and (self.has_effect(Stun) or any(e.blocks_stun() for e in self._effects)):
            return False

        for old in self._effects:
            if type(old) is type(effect) and effect.stacks:
                old.power += effect.power
                old.duration = max(old.duration, effect.duration)
                return True
        self._effects = [e for e in self._effects if type(e) is not type(effect)]
        self._effects.append(effect)
        return True

    def has_effect(self, effect_type):
        return any(isinstance(e, effect_type) for e in self._effects)

    def has_debuff(self):
        return any(not e.positive for e in self._effects)

    def get_effects(self):
        return list(self._effects)

    def set_cooldown(self, key, turns):
        if turns > 0:
            self._cooldowns[key] = turns + 1   # +1: в начале следующего хода уменьшится

    def cooldown_left(self, key):
        return self._cooldowns.get(key, 0)

    def block_skills(self, keys, turns):
        """Заблокировать умения на turns собственных ходов (Вальхалла)."""
        for key in keys:
            self._blocked[key] = turns + 1

    def blocked_left(self, key):
        return self._blocked.get(key, 0)

    def was_used(self, key):
        return key in self._used_once

    def mark_used(self, key):
        self._used_once.add(key)

    def skill_unlocked(self, skill):
        """Открыто ли умение в текущем состоянии героя. Наследники переопределяют."""
        return True

    def skill_visible(self, skill):
        """Показывать ли умение в интерфейсе."""
        return self.skill_unlocked(skill)

    def _can_use_strict(self, skill):
        return (self.cooldown_left(skill.key) == 0 and self.blocked_left(skill.key) == 0
                and self.__energy >= skill.cost and skill.is_available(self)
                and self.skill_unlocked(skill))

    def can_use(self, skill):
        if self._can_use_strict(skill):
            return True
        # 4.0: страховка — если ничего другого нельзя, обычная атака доступна всегда
        return (skill.key == "attack" and self.blocked_left("attack") == 0
                and not any(self._can_use_strict(s) for s in self.skills.values()))


    def start_turn(self):
        """Начало хода: реген, перезарядки, эффекты. Возвращает (лог, может_ходить)."""
        if getattr(self, "doused_turns", 0):
            self.doused_turns = max(0, int(self.doused_turns) - 1)
        logs, can_act = [], True
        self.turn_number += 1
        self.restore_energy(self.energy_regen)
        self._cooldowns = {k: v - 1 for k, v in self._cooldowns.items() if v > 1}
        self._blocked = {k: v - 1 for k, v in self._blocked.items() if v > 1}
        for eff in list(self._effects):
            logs.extend(eff.on_turn_start(self))
            if eff.prevents_action():
                can_act = False
            eff.tick()
        for eff in [e for e in self._effects if e.is_expired()]:
            logs.extend(eff.on_expire(self))
        self._effects = [e for e in self._effects if not e.is_expired()]
        return logs, can_act and self.is_alive()

    def roll_initiative(self):
        """Инициатива = скорость + бросок кубика d6."""
        return self.get_speed() + random.randint(1, 6)

    # ---------- Опыт ----------
    def xp_needed(self):
        """5.0: сколько опыта нужно до следующего уровня. Растёт с уровнем (~2+ ур. на локацию → 25 к Карр-Галлу)."""
        # ур.1→2: 70, 2→3: 85, … формула 55 + 15*level
        return 55 + 15 * self.level

    def gain_experience(self, amount):
        """Опыт; порог растёт с уровнем (максимум 25)."""
        if self.level >= self.MAX_LEVEL:
            self.experience = 0
            return
        self.experience += int(amount)
        while self.level < self.MAX_LEVEL and self.experience >= self.xp_needed():
            self.experience -= self.xp_needed()
            self.level_up()
        if self.level >= self.MAX_LEVEL:
            self.experience = 0

    def level_up(self):
        self.set_level(self.level + 1)


    def reset(self):
        """Подготовить к бою: полное HP, стартовый ресурс, без эффектов и зверей."""
        self.hp = self.max_hp
        self.__energy = self._start_energy
        self._effects = []
        self._cooldowns = {}
        self._blocked = {}
        self._used_once = set()
        self._events = []
        self.summon = None
        self.turn_number = 0
        self.fatigue = 0.0
        self.item_used = False
        self.skills = {k: s for k, s in self.skills.items() if not k.startswith("foe_")}   # 4.2: «Поймать тень»
        self._on_reset()


    def _on_reset(self):
        """Защищённый хук для наследников."""

    # ---------- Действия ----------
    def attack(self, target):
        """Обычная атака (без затрат). Наследники переопределяют."""
        return " ".join(self.skills["attack"].execute(self, target))

    def use_skill(self, target):
        """Главное умение класса; если оно не готово — обычная атака."""
        skill = self.skills[self.signature_skill]
        if skill.key == "attack" or not self.can_use(skill):
            return self.attack(target)
        return " ".join(skill.execute(self, target))

    def get_skill(self, key):
        skill = self.skills.get(key)
        if skill is None:
            raise ValueError(f"У {self.name} нет умения «{key}»")
        if key != "attack" and not self.can_use(skill):
            raise ValueError(f"Умение «{skill.name}» сейчас недоступно "
                             f"(перезарядка, блокировка или не хватает ресурса)")
        return skill

    def perform(self, key, target):
        """Выполнить действие по ключу умения. Возвращает список строк лога."""
        if key == "attack":
            return [self.attack(target)]
        return self.get_skill(key).execute(self, target)

    AI_RANDOM = 0.08   # окно неопределённости оценки среди близких по ценности ходов

    def ai_mood(self, target):
        """4.0: настроение ИИ против «Масти»: ассасин с мастью — агрессивен, его соперник — осторожен."""
        if self.has_effect(MastBuff):
            return "aggressive"
        if target is not None and target.has_effect(MastBuff):
            return "cautious"
        return None

    @evaluating
    def choose_action(self, target):
        """ИИ: выбрать лучшее доступное умение (с небольшой случайностью) или предмет."""
        from .ai import action_score
        options = [s for s in self.skills.values() if self.can_use(s)]
        mood = self.ai_mood(target)
        forecasts = {s.key:s.ai_score(self,target) for s in self.skills.values()
                     if s in options or (self.cooldown_left(s.key)<=2 and self.blocked_left(s.key)<=2
                                         and s.is_available(self) and self.skill_unlocked(s))}

        def score(s):
            value = action_score(s, self, target, forecasts)
            if mood == "aggressive" and hasattr(s, "multiplier"):
                value *= 1.25
            elif mood == "cautious" and not hasattr(s, "multiplier"):
                value *= 1.15
            return value
        # Score once: neither random exploration nor item comparison may
        # re-evaluate a different random value for the same action.
        scored = [(s, score(s)) for s in options]
        best, best_value = max(scored, key=lambda row: row[1])
        # A smooth preference avoids a tiny HP/damage adjustment flipping
        # the entire rotation between two almost equally useful actions.
        # Paid moves at or below the free attack still have zero weight.
        margin=max(0.5,abs(best_value)*self.AI_RANDOM)
        free_value=next((value for s,value in scored if s.key=='attack'),best_value-margin)
        choices=[]
        weights=[]
        for s,value in scored:
            closeness=max(0,1-(best_value-value)/margin)
            advantage=1 if s.key=='attack' else max(0,(value-free_value)/margin)
            weight=closeness*advantage
            if weight>0:
                choices.append(s)
                weights.append(weight)
        if len(choices)>1:
            best=random.choices(choices,weights=weights)[0]
        item = self.usable_item()
        if item:
            from .item import consumable_prototype
            if consumable_prototype(item).ai_score(self, target) > best_value:

                return "item:" + item
        return best.key


    def describe(self):
        return f"{self.hero_class} {self.name} (ур. {self.level}), HP {self.hp}/{self.max_hp}"

    def to_dict(self):
        return {"id": self.id, "name": self.name, "class": self.__class__.__name__,
                "type": self.type_key, "hero_class": self.hero_class, "level": self.level,
                "display_level": getattr(self, "display_level", None),
                **({"display_level": self.display_level} if getattr(self, "display_level", None) is not None else {}),
                "hp": self.hp, "max_hp": self.max_hp, "damage": self.get_damage(),
                "armor": self._armor, "speed": self.speed, "dodge": round(self.get_dodge(), 2),
                "crit_chance": round(self.get_crit(), 2), "crit_multiplier": self.crit_multiplier,
                "role": self.role, "role_name": self.ROLE_NAMES[self.role], "level_group": self.level_group(),
                "armor_total": self.armor_total(), "fatigue": round(self.fatigue, 2),
                "battle_item": self.battle_item, "item_used": self.item_used, "story": self.story,
                "story_progress": dict(self.story_progress), "story_flags": dict(self.story_flags), "npc": self.npc, "mob": self.mob, "dev_mob": bool(getattr(self, "dev_mob", False)),

                "energy": self.__energy, "max_energy": self.max_energy,
                "resource_name": self.resource_name, "turn_number": self.turn_number,
                "experience": self.experience, "xp_needed": self.xp_needed() if self.level < self.MAX_LEVEL else 0,
                "wins": self.wins, "losses": self.losses,
                "image": self.image, "skin": self.skin, "skins": list(self.skins),
                "random_skin": bool(getattr(self, "random_skin", False)),
                "last_random_skin": getattr(self, "last_random_skin", None),
                "owner_id": self.owner_id, "custom": self.custom, "protected": self.protected,
                "consumables": self.consumable_counts(),
                "effects": [e.to_dict() for e in self._effects],
                "skills": [s.to_dict(self) for s in self.skills.values()],
                "summon": self.summon.to_dict() if self.summon else None,
                "weapon": self.weapon.to_dict() if self.weapon else None,
                "inventory": self.inventory.to_dict(), "description": self.describe(),
                "story_bag": dict(getattr(self, "story_bag", {}) or {}),
                "story_pending_loot": list(getattr(self, "story_pending_loot", []) or [])}

    @classmethod
    def about_text(cls, sample=None):
        """4.4: описание класса из докстринга; {поля} подставляются из кода (цифры не устаревают)."""
        text = " ".join((cls.__doc__ or cls.hero_class or "").split())
        if "{" not in text:
            return text
        sample = sample or cls("Образец")
        strike = getattr(sample.skills.get("bogatyr_strike"), "MULT", 0)
        return text.format(c=cls, h=sample, hp=sample.max_hp, dodge=f"{round(sample.dodge * 100)}%",
                           dot=f"{round(cls.DOT_RESIST * 100)}%", strike=strike,
                           incorporeal=f"{round(getattr(cls, 'INCORPOREAL', 0) * 100)}%",
                           shadow=getattr(sample.skills.get("shadow_strike"), "DODGED_MULT", ""),
                           pct_step=f"{round(getattr(cls, 'INSTINCT_STEP', 0) * 100)}%",
                           evade=f"{round(sample.dodge * getattr(cls, 'FORCED_EVADE', 0) * 100)}%")

    @classmethod
    def class_info(cls):
        """Описание класса для API (создаём временный образец, id не тратим)."""
        saved = Character._next_id
        sample = cls("Образец")
        Character._next_id = saved
        data = sample.to_dict()
        for key in ("id", "name", "experience", "wins", "losses", "weapon", "inventory",
                    "effects", "description", "level", "summon", "turn_number", "katana", "notice",
                    "skin", "skins", "owner_id", "custom", "protected", "consumables", "fatigue",
                    "story_bag", "story_pending_loot", "story_flags", "story_progress",
                    "battle_item", "item_used", "story", "story_progress", "npc", "level_group"):

            data.pop(key, None)
        data["about"] = cls.about_text(sample)
        from .lore import hero_card, skill_facts
        for sd, sk in zip(data["skills"], sample.skills.values()):
            sd["facts"] = skill_facts(sk, sample)        # 4.4: цифры умения из объекта, не из текста
        hero_card(cls, data)
        data["required_wins"] = cls.required_wins
        data["story_free"] = bool(getattr(cls, "story_free", False) or cls.type_key == "monk")
        data["secret"] = cls.secret
        data["creatable"] = cls.creatable
        return data

    def __str__(self):
        return self.describe()


class Warrior(Character):
    """Воин: крепкий и бронированный, копит ярость. При HP < 30% может воззвать к Вальхалле."""

    hero_class, type_key, resource_name = "Воин", "warrior", "ярость"
    signature_skill = "heavy_strike"
    role = "warrior"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=198, base_damage=12.2, armor=4, level=level,
                         speed=5, dodge=0.05, crit_chance=0.1,
                         max_energy=100, energy_regen=10, start_energy=10)
        self._valhalla_rolled = False

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Удар мечом", "Обычная атака, +15 ярости", icon="⚔"),
            DamageSkill("heavy_strike", "Сильный удар", "×2 урона, но точность 75%",
                        multiplier=2.0, accuracy=0.75, cost=30, cooldown=2, icon="🔨"),
            DamageSkill("rend", "Рассечение", "Удар + кровотечение 3 хода",
                        effect=lambda: Bleed(3, 6), cost=20, cooldown=3, icon="🩸"),
            SelfBuffSkill("berserk", "Берсерк", "+40% к урону на 3 хода",
                          effects=[lambda: Berserk(3, 40)], cost=40, cooldown=5, icon="😡"),
            ArmorCrossesSkill("armor_fix", "Доспех", "Мини-игра: стащите мышкой крестики с брони. "
                              "6/6 — щит 13% HP, +1 броня и иммунитет к оглушению; 3–5 — щит 11.5%; 0–2 — щит 8%",
                              cost=30, cooldown=6, icon="🛡"),
            # ----- 4.2: Конан — больше разнообразия (не силы) -----
            SelfBuffSkill("deep_guard", "Глухая оборона", "Закрывается щитом: −35% получаемого урона на 2 хода",
                          effects=[lambda: Guard(2, 35)], cost=20, cooldown=4, score=11, icon="🛡"),
            SelfBuffSkill("counter", "Контрудар", "Стойка до следующего хода: 50% парировать атаку и ударить ×0.8",
                          effects=[lambda: ParryStance(1, 0)], cost=15, cooldown=4, score=9, icon="↩"),
            DamageSkill("cleave", "Рассекающий удар", "×1.3 + кровотечение 3/ход на 3 хода", multiplier=1.3,
                        effect=lambda: Bleed(3, 3), cost=20, cooldown=3, icon="🗡"),
            ParrySkill("parry", "Парирование", "Мини-игра: повторите 4 стрелки замахов. 4/4 — ×2.2 и оглушение; "
                       "3 — ×1.6; 2 — ×1.0; 0–1 — ×0.5 и −5% HP себе", cost=35, cooldown=6, icon="⚔"),
        ]

    @property
    def rage(self):
        return self.energy

    def attack(self, target):  # переопределение: удар копит ярость
        result = super().attack(target)
        self.restore_energy(15)
        return result + f" (ярость {self.energy})"

    def start_turn(self):  # переопределение: «Вальхалла»
        logs, can_act = super().start_turn()
        enemy = self.opponent
        if (self.is_alive() and enemy and not self._valhalla_rolled
                and self.hp < self.max_hp * 0.3):
            self._valhalla_rolled = True   # шанс выпадает один раз за бой
            if random.random() < 0.67:
                keys = [k for k, s in enemy.skills.items() if k != "attack" and enemy.skill_visible(s)]
                chosen = random.sample(keys, min(len(keys), random.randint(1, 2)))
                enemy.block_skills(chosen, 2)
                names = ", ".join(f"«{enemy.skills[k].name}»" for k in chosen) or "ничего"
                logs.append(Announcement(f"⚡ ВАЛЬХАЛЛА! {self.name} взывает к предкам — у {enemy.name} "
                                         f"заблокировано на 2 хода: {names}!"))
            else:
                logs.append(f"⚡ {self.name} взывает к Вальхалле, но боги молчат…")
        return logs, can_act

    def _on_reset(self):
        self._valhalla_rolled = False

    def describe(self):  # переопределение
        return super().describe() + f", броня {self.armor}, ярость {self.energy}"


class Mage(Character):
    """Маг: хрупкий, магия бьёт сквозь броню. Лечение, щит и призыв Водяного духа."""

    hero_class, type_key, resource_name = "Маг", "mage", "мана"
    signature_skill = "fireball"
    role = "light"
    DODGE_PIERCE = 0.5   # 4.4: «Самонаводящаяся магия» — уклонение цели против мага вдвое слабее

    def __init__(self, name, level=1):  # 4.0: HP 135 → 150
        super().__init__(name, max_hp=154, base_damage=9.1, armor=1, level=level,
                         speed=6, dodge=0.08, crit_chance=0.1,
                         max_energy=100, energy_regen=12, start_energy=100)

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Магическая стрела", "Обычная атака сквозь броню, почти не промахивается, +5 маны",
                        ignore_armor=True, accuracy=1.05, icon="✨"),
            DamageSkill("fireball", "Огненный шар", "×2.2 урона, 60% поджечь",
                        multiplier=2.2, effect=lambda: Burn(2, 5), effect_chance=0.6,
                        cost=35, cooldown=2, icon="☄"),
            DamageSkill("dark_power", "Сила тьмы", "×1.5 сквозь броню + проклятие (урон и −20% к атаке врага)",
                        multiplier=1.5, ignore_armor=True, effect=lambda: DarkCurse(3, 5),
                        cost=30, cooldown=3, icon="🌑"),
            HealSkill("heal", "Исцеление", "Восстановить 20% HP", percent=0.2,
                      cost=30, cooldown=5, icon="💚"),
            SelfBuffSkill("ice_shield", "Ледяной щит", "Щит на 30 урона",
                          effects=[lambda: Shield(3, 30)], cost=25, cooldown=5, icon="🛡"),
            SummonSkill("water_spirit", "Водяной дух", "Призвать духа на 5 ходов: бьёт сквозь броню",
                        summon_factory=WaterSpirit, cost=45, cooldown=10, icon="💧"),
            DamageSkill("snowfall", "Снегопад", "3 льдинки по ×0.5 сквозь броню + замедление (−2 скорости, 2 хода)",
                        multiplier=0.5, hits=3, ignore_armor=True, effect=lambda: Slow(2, 2),
                        cost=35, cooldown=4, icon="🌨"),
            # ----- 4.2 -----
            RuneSealSkill("rune_seal", "Руническая печать", "Мини-игра: запомните и повторите 4 руны. 4/4 — ×2.4, "
                          "игнор 30% брони, +15 маны; 3 — ×1.7; 2 — ×1.1; 1 — ×0.6 и «Рассеянность»; "
                          "0 — «Откат магии»: −8% HP себе и «Рассеянность» 3 хода", cost=40, cooldown=5, icon="ᚱ"),
        ]

    @property
    def mana(self):
        return self.energy

    def attack(self, target):  # переопределение: стрела восстанавливает ману
        result = super().attack(target)
        self.restore_energy(5)
        return result

    def describe(self):  # переопределение
        return super().describe() + f", мана {self.energy}/{self.max_energy}"


class Archer(Character):
    """Лучник: быстрый и меткий, частые криты. Рваные раны складываются, есть Невидимость."""

    hero_class, type_key = "Лучник", "archer"
    signature_skill = "double_shot"
    role = "light"
    BOW = ("double_shot", "bleeding_arrow", "aimed_shot", "invisibility", "hunt")


    def __init__(self, name, level=1, arrows=40):
        super().__init__(name, max_hp=184, base_damage=11.9, armor=2, level=level,
                         speed=7, dodge=0.15, crit_chance=0.3,
                         max_energy=100, energy_regen=15, start_energy=40)
        self.arrows = arrows

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Выстрел", "Обычный выстрел (тратит стрелу)", icon="🏹"),
            DamageSkill("double_shot", "Двойной выстрел", "Два выстрела по ×0.75",
                        multiplier=0.75, hits=2, cost=25, cooldown=2, icon="🎯"),
            DamageSkill("bleeding_arrow", "Рваная стрела", "Выстрел + рваная рана (раны СКЛАДЫВАЮТСЯ)",
                        multiplier=0.9, effect=lambda: DeepBleed(3, 5), cost=20, cooldown=2, icon="🩸"),
            DamageSkill("aimed_shot", "Прицельный выстрел", "×1.7, не промахивается, +30% к криту",
                        multiplier=1.7, accuracy=1.2, crit_bonus=0.3, cost=35, cooldown=3, icon="👁"),
            SelfBuffSkill("invisibility", "Невидимость", "Раз за бой: 1 ход прячется (не атакует), "
                          "затем +50% уклонения на 3 хода", effects=[lambda: Invisibility(4, 50)],
                          once_per_battle=True, announce=True, cost=20, icon="👻"),
            DeerHuntSkill("hunt", "Охота", "Мини-игра: кликайте по головам оленей за 5 с — каждое попадание стрела ×0.45",
                          cost=30, cooldown=4, icon="🦌"),
            SelfBuffSkill("craft_swap", "Смена ремесла", "С 8-го хода, раз за бой: 5 ходов меч и кинжал — "
                          "4 умения ближнего боя вместо лука", effects=[lambda: MeleeMode(5)],
                          once_per_battle=True, min_turn=8, announce=True, score=15, cost=10, icon="⚔"),
            # ----- 4.0: умения ближнего боя (только в «Смене ремесла») -----
            DamageSkill("sword_slash", "Удар мечом", "×1.3 урона", multiplier=1.3, group="melee", icon="🗡"),
            DamageSkill("dagger_flurry", "Кинжальный вихрь", "3 удара по ×0.55", multiplier=0.55, hits=3,
                        cost=25, cooldown=2, group="melee", icon="🌀"),
            DamageSkill("leg_sweep", "Подсечка", "×0.9, 35% оглушить", multiplier=0.9, effect=lambda: Stun(1),
                        effect_chance=0.35, cost=25, cooldown=3, group="melee", icon="🦵"),
            DamageSkill("lunge_stab", "Выпад с кинжалом", "×1.5 + кровотечение", multiplier=1.5,
                        effect=lambda: Bleed(3, 5), cost=30, cooldown=3, group="melee", icon="🔪"),
        ]

    def skill_unlocked(self, skill):  # 4.0: «Смена ремесла» меняет набор умений
        melee = self.has_effect(MeleeMode)
        if skill.group == "melee":
            return melee
        if melee and (skill.key in self.BOW or skill.key == "attack"):
            return False      # в ближнем бою лук убран
        return True


    def attack(self, target):  # переопределение: без стрел — слабый кинжал
        if self.arrows <= 0:
            dmg = target.take_damage(self._base_damage // 2, attacker=self)
            return f"🗡 Лучник {self.name} без стрел бьёт кинжалом {target.name}: {dmg} урона."
        self.arrows -= 1
        return super().attack(target)

    def choose_action(self, target):
        # Invisibility pays for setup and the extra hiding turn in the same
        # evaluator as other actions; low HP alone is not a reason to hide.
        return super().choose_action(target)

    def _on_reset(self):
        self.arrows = max(self.arrows, 40)

    def describe(self):  # переопределение
        return super().describe() + f", стрел {self.arrows}, крит {int(self.crit_chance * 100)}%"

    def to_dict(self):
        data = super().to_dict()
        data["arrows"] = self.arrows
        return data


class Ogre(Character):
    """Огр: огромный запас HP, регенерация и Каменный щит; медленный и неточный."""

    hero_class, type_key, resource_name = "Огр", "ogre", "ярость"
    signature_skill = "club_smash"
    role = "tank"
    GLANCING = 0.35      # 4.4: «Тяжёлая рука» — промах всё равно задевает на 35% (сквозь броню)

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=208, base_damage=12.2, armor=2, level=level,
                         speed=2, dodge=0.0, crit_chance=0.05, crit_multiplier=1.5,
                         max_energy=100, energy_regen=12, start_energy=20)
        self.regeneration = 0.015  # доля max HP, которую огр лечит каждый ход

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Удар кулаком", "Медленный тяжёлый удар (точность 85%), +10 ярости",
                        accuracy=0.85, icon="👊"),
            DamageSkill("club_smash", "Удар дубиной", "×1.5 урона, 50% оглушить на 1 ход",
                        multiplier=1.5, accuracy=0.8, effect=lambda: Stun(1), effect_chance=0.5,
                        cost=40, cooldown=3, icon="🪵"),
            DamageSkill("heavy_strike", "Сильный удар", "×2.2 урона, точность 70%",
                        multiplier=2.2, accuracy=0.7, cost=30, cooldown=2, icon="🔨"),
            SelfBuffSkill("roar", "Рёв", "Берсерк: +25% к урону на 3 хода",
                          effects=[lambda: Berserk(3, 25)], cost=35, cooldown=5, icon="😡"),
            SelfBuffSkill("stone_shield", "Каменный щит",
                          "3–4 хода: −50% ЛЮБОГО урона (даже магии), сильные удары укорачивают; "
                          "нет регенерации; открывает каменные умения",
                          effects=[lambda: StoneShield(random.choice([3, 4]))], announce=True,
                          score=16, cost=30, cooldown=8, icon="🗿"),
            # ----- умения только под Каменным щитом -----
            DamageSkill("ogre_spear", "Бросок копья", "×1.4 урона, 30% оглушить", multiplier=1.4,
                        accuracy=0.85, effect=lambda: Stun(1), effect_chance=0.3,
                        cost=25, cooldown=3, group="stone", icon="🔱"),
            DamageSkill("stone_rain", "Каменный дождь", "3 камня по ×0.75 (4.0: сильнее)", multiplier=0.75, hits=3,
                        accuracy=0.82, cost=30, cooldown=2, group="stone", icon="🌧"),
            DamageSkill("rock_throw", "Бросок камней", "×1.6 урона", multiplier=1.6, accuracy=0.85,
                        cost=20, cooldown=1, group="stone", icon="🪨"),
            DamageSkill("acid_spit", "Плевок кислоты", "×0.7 сквозь броню + кислота",
                        multiplier=0.7, ignore_armor=True, effect=lambda: Acid(3, 6),
                        cost=20, cooldown=3, group="stone", icon="🧪"),
            FeastSkill("feast", "Пир людоеда", "Мини-игра на память: повторите 4 ингредиента. 4/4 — +13% HP и "
                       "+12% урона; 2–3 — +10% HP; 0–1 — +5%. Перец 🌶 — огненная отрыжка (горение врагу, −4% HP себе)",
                       cost=25, cooldown=6, icon="🍖"),
        ]

    def shielded(self):
        return self.has_effect(StoneShield)

    def skill_unlocked(self, skill):  # переопределение: две «формы» огра
        if skill.key in ("attack", "feast"):
            return True
        return (skill.group == "stone") == self.shielded()

    def attack(self, target):  # переопределение
        result = super().attack(target)
        self.restore_energy(10)
        return result

    def start_turn(self):  # переопределение: регенерация, если нет Каменного щита
        logs, can_act = super().start_turn()
        if self.is_alive() and not self.shielded():
            healed = self.heal(int(self.max_hp * self.regeneration))
            if healed:
                logs.append(f"💚 Огр {self.name} регенерирует {healed} HP.")
        return logs, can_act

    def perform(self, key, target):  # переопределение: объявление о щите
        logs = super().perform(key, target)
        if key == "stone_shield":
            logs.append(Announcement(f"🗿 {self.name} покрывается камнем! Доступны каменные умения."))
        return logs

    def describe(self):  # переопределение
        state = ", 🗿 под Каменным щитом" if self.shielded() else ""
        return super().describe() + f", регенерация {self.regeneration * 100:g}%/ход, медленный{state}"


class Spartan(Character):
    """Спартанец: щит блокирует удары, фаланга, «Меткий глаз»; может потерять копьё."""

    hero_class, type_key, resource_name = "Спартанец", "spartan", "дисциплина"
    signature_skill = "phalanx"
    role = "warrior"

    def __init__(self, name, level=1, block_chance=0.25):
        super().__init__(name, max_hp=184, base_damage=13.1, armor=5, level=level,
                         speed=4, dodge=0.05, crit_chance=0.1,
                         max_energy=100, energy_regen=12, start_energy=30)
        self.block_chance = block_chance   # шанс заблокировать половину урона
        self.spear_lost = False

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Удар копьём", "Обычная атака", icon="🔱"),
            DamageSkill("spear_throw", "Бросок копья", "×1.9 урона, точность 85%; 35% потерять копьё",
                        multiplier=1.9, accuracy=0.85, cost=30, cooldown=2, icon="🎯"),
            DamageSkill("shield_bash", "Удар щитом", "×1.1 урона, 40% оглушить",
                        multiplier=1.1, effect=lambda: Stun(1), effect_chance=0.4,
                        cost=30, cooldown=3, icon="🛡"),
            SelfBuffSkill("phalanx", "Фаланга", "Щит на 20 + контратака 50% урона на 1 ход",
                          effects=[lambda: Shield(2, 20), lambda: CounterStance(1, 50)],
                          cost=30, cooldown=4, score=14, icon="🏛"),
            DamageSkill("eagle_eye", "Меткий глаз", "Раз за БОЙ: выстрел из лука ×2.8, не промахивается",
                        multiplier=2.8, accuracy=1.2, crit_bonus=0.2, once_per_battle=True,
                        cost=40, icon="🏹"),
            ShieldWallSkill("shield_wall", "Стена щитов", "Мини-игра на тайминг: нажмите, когда кольцо совпадёт со щитом. "
                            "Точно — −50% урона 2 хода; рядом — −35%; мимо — −15% 1 ход",
                            cost=25, cooldown=5, icon="🧱"),
            ReadEnemySkill("read_enemy", "Читай врага", "Угадайте следующее действие врага (атака / умение / защита). "
                           "Угадал — бьёте первым и гасите 70% урона", cost=20, cooldown=4, icon="👁"),
        ]

    def skill_unlocked(self, skill):  # переопределение: без копья бросать нечего
        return not (skill.key == "spear_throw" and self.spear_lost)

    def perform(self, key, target):  # переопределение: копьё можно потерять
        logs = super().perform(key, target)
        if key == "spear_throw" and random.random() < 0.35:
            self.spear_lost = True
            self.crit_chance += 0.15
            self.skills["attack"].name = "Удар мечом"
            self.skills["attack"].icon = "🗡"
            logs.append(Announcement(f"🔱 {self.name} теряет копьё! Он берётся за меч — шанс крита +15%."))
        return logs

    MAGIC_GUARD = 0.25   # 4.4: «Бронзовый щит» — урон сквозь броню (магия, яды не в счёт) −25%

    def take_damage(self, amount, ignore_armor=False, attacker=None):  # переопределение
        if random.random() < self.block_chance:
            amount = amount // 2
            self._events.append(f"🛡 Спартанец {self.name} блокирует щитом половину удара!")
        return super().take_damage(amount, ignore_armor, attacker)

    def attack(self, target):  # переопределение: дисциплина за удар
        result = super().attack(target)
        self.restore_energy(5)
        return result

    def _on_reset(self):
        if self.spear_lost:
            self.spear_lost = False
            self.crit_chance -= 0.15
            self.skills["attack"].name, self.skills["attack"].icon = "Удар копьём", "🔱"

    def describe(self):  # переопределение
        weapon = "меч" if self.spear_lost else "копьё"
        return super().describe() + f", броня {self.armor}, блок {int(self.block_chance * 100)}%, {weapon}"

    def to_dict(self):
        data = super().to_dict()
        data.update(block_chance=self.block_chance, spear_lost=self.spear_lost)
        return data


class Assassin(Character):
    """Ассасин: самый быстрый, уклоняется и критует ×2; с 5-го хода — Контракт на убийство (до 5 попыток).
    Пассивка «Прорезь брони» — каждый удар игнорирует {c.ARMOR_PIERCE_FLAT} брони; HP {hp}."""

    hero_class, type_key = "Ассасин", "assassin"
    signature_skill = "backstab"
    role = "trickster"
    ARMOR_PIERCE_FLAT = 1   # 4.3: «Прорезь брони» — каждый удар игнорирует 1 брони
    INTERCEPT_IGNORE = 0.5  # 4.3: «Цель — хозяин»: звери и клоны перехватывают его удары вдвое реже

    def __init__(self, name, level=1):  # 4.0: HP 135 → 150, броня 1 → 2; 4.3: HP 150 → 160
        super().__init__(name, max_hp=174, base_damage=6.3, armor=2, level=level,
                         speed=9, dodge=0.2, crit_chance=0.18, crit_multiplier=2.0,
                         max_energy=100, energy_regen=15, start_energy=50)
        self.contract = False
        self.contract_tries = 0

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Быстрые удары", "Два удара по ×0.55", multiplier=0.55,
                        hits=2, icon="🗡"),
            DamageSkill("poison_blade", "Отравленный клинок", "Удар + яд (растёт; сильнее с контрактом)",
                        multiplier=0.9, effect=lambda: Poison(4, 6 if self.contract else 4),
                        cost=20, cooldown=3, icon="☠"),
            BackstabSkill("backstab", "Удар в спину", "×1.8, +25% крит; +50% крит, если на цели дебафф",
                          multiplier=1.8, crit_bonus=0.25, cost=35, cooldown=2, icon="🔪"),
            SelfBuffSkill("smoke", "Дымовая завеса", "+35% уклонения на 2 хода",
                          effects=[lambda: Evasion(2)], cost=30, cooldown=5, icon="🌫"),
            ContractSkill("contract", "Контракт на убийство",
                          "С 5-го хода: соперник выбирает 1 из 6 квадратов, 2 отравлены", cost=20,
                          cooldown=3, min_turn=5, icon="📜"),
            DamageSkill("leap", "Прыжок за спину", "Только по контракту: 65% успеха, всегда крит",
                        multiplier=1.5, fixed_hit=0.65, crit_bonus=1.0, cost=30, cooldown=2, icon="🦘"),
            SummonSkill("clone", "Клон", "Двойник на 4 хода: принимает удары на себя (35%) и бьёт сам",
                        summon_factory=Clone, cost=30, cooldown=8, icon="👥"),
            KnifeThrowSkill("knives", "Бросок ножей", "Мини-игра: попадите по 5 крестикам за 3 с — нож ×0.4, "
                            "20% кровотечения", cost=25, cooldown=3, icon="🔪"),
            MastSkill("mast", "Какой ты масти?", "4 хода: +35% урона по лёгким, +17% по воинам, +5% по танкам, "
                      "+10% по ловкачам", cost=25, cooldown=8, icon="🃏"),
        ]

    def skill_unlocked(self, skill):  # переопределение
        return skill.key != "leap" or self.contract

    def grant_contract(self):
        """Контракт заключён: усиления до конца боя."""
        self.contract = True
        self.crit_chance += 0.15
        self.add_effect(Contract())
        return ["📜 +15% крита, яд и кровотечение сильнее, −24% получаемого урона, открыт «Прыжок за спину»!"]

    def on_hit_landed(self, target, skill):  # переопределение: по контракту — кровотечение
        if self.contract and skill.key in ("attack", "backstab", "leap"):
            target.add_effect(Bleed(3, 7))
            return [f"🩸 Клинок контракта рвёт {target.name}: кровотечение 7/ход."]
        return []

    def attack(self, target):  # переопределение: яд в ране усиливается
        result = super().attack(target)
        for eff in target.get_effects():
            if isinstance(eff, Poison):
                eff.power += 1
                result += f" Яд в ране усиливается ({eff.power}/ход)."
        return result

    def _on_reset(self):
        self.contract_tries = 0
        if self.contract:
            self.contract = False
            self.crit_chance -= 0.15

    def describe(self):  # переопределение
        extra = ", 📜 контракт" if self.contract else ""
        return super().describe() + f", уклонение {int(self.dodge * 100)}%, крит ×{self.crit_multiplier}{extra}"


class Samurai(Character):
    """Самурай: в начале КАЖДОГО боя вытягивает случайную катану (10% — легендарная Масамунэ: +3 урона и 25% пробивания брони)."""

    hero_class, type_key, resource_name = "Самурай", "samurai", "ки"
    signature_skill = "iaijutsu"
    role = "warrior"

    def __init__(self, name, level=1, katana=None):
        super().__init__(name, max_hp=144, base_damage=7.2, armor=3, level=level,
                         speed=6, dodge=0.1, crit_chance=0.15,
                         max_energy=100, energy_regen=14, start_energy=40)
        self.katana = katana or Katana.roll()   # объект-оружие (композиция)

    @property
    def notice(self):
        """Объявление о катане (для API и интерфейса)."""
        if self.katana.legendary:
            return f"⚔️ ЛЕГЕНДАРНЫЙ КЛИНОК! {self.name} обнажает {self.katana.name}!"
        return f"🗡 {self.name} получает катану «{self.katana.name}»."

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Удар катаной", "Обычная атака", icon="🗡"),
            DamageSkill("iaijutsu", "Иайдзюцу", "Молниеносный удар ×1.7, +15% крит",
                        multiplier=1.7, crit_bonus=0.15, cost=30, cooldown=2, icon="⚡"),
            DamageSkill("blade_dance", "Танец клинка", "3 удара по ×0.6", multiplier=0.6, hits=3,
                        cost=35, cooldown=3, icon="🌀"),
            HealSkill("meditation", "Медитация", "Восстановить 15% HP", percent=0.15,
                      cost=30, cooldown=6, icon="🧘"),
            ShunpoSkill("shunpo", "Шунпо", "Мини-игра: жмите на вспыхнувшие зоны манекена (3/3 — 3 рывка ×0.58, 2/3 — 2 × 0.72, "
                        "1/3 — 1 × 0.9; пробивают 50% брони)", cost=30, cooldown=4, icon="💨"),
            SelfBuffSkill("calm", "Спокойствие", "Щит 14% HP на 3 хода; когда ломается — волна ки бьёт врага на 10",
                          effects=[lambda: CalmShield(3, int(self.max_hp * 0.14), int(round(10 * self.power_scale())))],
                          cost=25, cooldown=6, icon="🍃"),
            DamageSkill("rising_slash", "Восходящий разрез", "×1.55, +10% крит", multiplier=1.55,
                        crit_bonus=0.10, cost=22, cooldown=3, icon="🗡"),
            IaiFlashSkill("iai_flash", "Вспышка иай", "Мини-игра: узкое окно тайминга — идеально ×2.2 сквозь броню",
                          cost=28, cooldown=5, icon="⚡"),
        ]

    def get_damage(self):  # переопределение: + бонус катаны
        return super().get_damage() + self.katana.damage_bonus

    @property
    def armor_pierce(self):
        """5.2: пробивание брони текущего клинка (Масамунэ — заметный бонус)."""
        return float(getattr(self.katana, "armor_pierce", 0) or 0)

    def get_dodge(self):  # переопределение
        return min(0.75, super().get_dodge() + self.katana.dodge_bonus)

    def hit_chance(self, skill, victim):  # переопределение: особые катаны
        if self.katana.never_miss:
            return 1.0
        if self.katana.enemy_dodge is not None:
            return 1 - self.katana.enemy_dodge
        return super().hit_chance(skill, victim)

    def on_hit_landed(self, target, skill):  # переопределение: кровотечение и Удар судьбы
        logs = []
        if random.random() < self.katana.bleed_chance:
            target.add_effect(Bleed(3, 5))
            logs.append(f"🩸 {self.katana.name} оставляет рану: кровотечение у {target.name}.")
        if self.katana.fate_chance and random.random() < self.katana.fate_chance:
            target.hp = target.hp - 100
            logs.append(Announcement(f"☄ УДАР СУДЬБЫ! Масамунэ рассекает {target.name}: −100 HP!"))
        return logs

    def take_damage(self, amount, ignore_armor=False, attacker=None):  # переопределение: контратака
        dmg = super().take_damage(amount, ignore_armor, attacker)
        if attacker is not None and self.is_alive() and random.random() < self.katana.counter_chance:
            back = attacker.take_damage(int(self.get_damage() * 0.5), attacker=None)
            self._events.append(f"⚔ {self.name} контратакует катаной: {attacker.name} получает {back} урона.")
        return dmg

    def roll_katana(self):
        """Новая катана на этот бой: 45% / 22.5% / 22.5% / 10%."""
        self.katana = Katana.roll()
        return self.katana

    def battle_intro(self):  # переопределение: катана выпадает заново в начале каждого боя
        self.roll_katana()
        text = self.notice
        return [Announcement(text) if self.katana.legendary else text]

    def describe(self):  # переопределение
        return super().describe() + f", {self.katana.describe()}"

    def to_dict(self):
        data = super().to_dict()
        data["katana"] = self.katana.to_dict()
        data["katana"]["per_battle"] = True   # катана перевыпадает каждый бой
        data["notice"] = self.notice
        return data


class Druid(Character):
    """Друид: лечится и призывает зверей (медведь, сокол, змея, хомяк) — мастер долгого боя."""

    hero_class, type_key, resource_name = "Друид", "druid", "сила природы"
    signature_skill = "summon_beast"
    role = "light"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=159, base_damage=9.5, armor=2, level=level,
                         speed=5, dodge=0.08, crit_chance=0.1,
                         max_energy=100, energy_regen=12, start_energy=50)

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Удар посохом", "Обычная атака", icon="🪄"),
            SummonSkill("summon_beast", "Призыв зверя",
                        "Случайный зверь: Хомяк 25%, Сокол 22%, Змея 20%, Олень 18%, Медведь 15%",
                        summon_factory=random_beast, cost=40, cooldown=7, icon="🐾"),
            HealSkill("nature_heal", "Дар природы", "+12% HP и регенерация 6 HP на 3 хода",
                      percent=0.12, effect=lambda: Regeneration(3, 6), cost=30, cooldown=5, icon="🌿"),
            DamageSkill("entangle", "Опутывающие корни", "×1.0 урона, 30% оглушить",
                        effect=lambda: Stun(1), effect_chance=0.3, cost=30, cooldown=4, icon="🌱"),
            DamageSkill("thorns", "Шипы", "×1.4 урона + кровотечение", multiplier=1.4,
                        effect=lambda: Bleed(3, 4), cost=25, cooldown=2, icon="🌵"),
            # ----- 4.2 -----
            DamageSkill("root_chains", "Оковы корней", "×1.0, не промахивается; враг не может уклоняться и −2 скорости "
                        "на 2 хода", fixed_hit=0.95, effect=lambda: Rooted(2), cost=20, cooldown=4, icon="⛓"),
            ForestCallSkill("forest_call", "Зов леса", "Мини-игра: ловите светящихся духов 5 с. 8+ — +20% HP и зверь "
                            "+30% урона на 3 хода; 5–7 — +12% и +15%; 2–4 — +6%; 0–1 — +2%", cost=35, cooldown=6,
                            icon="🌲"),
        ]

    def attack(self, target):  # переопределение: зверь рычит вместе с друидом
        result = super().attack(target)
        if self.summon and self.summon.is_alive():
            result += f" {self.summon.icon} {self.summon.name} рядом."
        return result

    def describe(self):  # переопределение
        beast = f", зверь: {self.summon.describe()}" if self.summon and self.summon.is_alive() else ""
        return super().describe() + beast


class Monk(Character):
    """Монах: много HP, мало урона, отражает удары, копирует умения врага. Открывается за 7 побед."""

    hero_class, type_key, resource_name = "Монах", "monk", "ци"
    signature_skill = "palm_strike"
    required_wins = 7
    role = "warrior"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=166, base_damage=10.7, armor=3, level=level,
                         speed=5, dodge=0.1, crit_chance=0.1,
                         max_energy=100, energy_regen=14, start_energy=40)
        self.reflect = 0.1   # доля полученного урона, которая возвращается врагу

    COPY_POWER = 0.8         # скопированное умение бьёт на 80% от оригинала

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Удар кулаком", "Обычная атака", icon="👊"),
            DamageSkill("palm_strike", "Удар ладонью",
                        "×1.5 урона, 20% оглушить + «Запрет исцеления» на 2 хода (нет лечения, щиты слабее)",
                        multiplier=1.5, effect=lambda: Antiheal(2),   # 4.4: было 2–3 хода при перезарядке 2 — вечный запрет
                        cost=25, cooldown=3, icon="🖐"),
            WeaknessSkill("weakness", "Поиск слабостей",
                          "Мини-игра: нажмите 1→6 за ~3.5 с: все 6 — ×2.7, 4–5 — ×1.5, меньше — слабый удар ×0.9",
                          multiplier=2.7, cost=20, cooldown=5, icon="🎯"),
            SelfBuffSkill("stone_skin", "Каменная кожа", "Щит на 45 урона на 3 хода",
                          effects=[lambda: StoneSkin(3, 45)], cost=30, cooldown=5, icon="🪨"),
        ]

    def on_hit_landed(self, target, skill):  # переопределение: ладонь оглушает и объявляет запрет
        logs = []
        if skill.key == "palm_strike" and target.is_alive():
            logs.append(Announcement(f"🚫 {target.name} под «Запретом исцеления»: лечение и регенерация "
                                     f"заблокированы, щиты ослаблены!"))
            if random.random() < 0.2 and target.add_effect(Stun(1)):
                logs.append(f"💫 {target.name} оглушён ударом ладони!")
        return logs

    def take_damage(self, amount, ignore_armor=False, attacker=None):  # переопределение: отражение
        dmg = super().take_damage(amount, ignore_armor, attacker)
        if attacker is not None and dmg > 1:
            back = max(1, int(dmg * self.reflect))
            attacker.hp = attacker.hp - back
            self._events.append(f"🪷 {self.name} отражает {back} урона в {attacker.name}.")
        return dmg

    def start_turn(self):  # переопределение: каждый 3-й ход копирует умение врага
        logs, can_act = super().start_turn()
        enemy = self.opponent
        if self.is_alive() and enemy and self.turn_number % 3 == 0:
            options = [s for s in enemy.skills.values()
                       if s.key != "attack" and s.copyable and not s.key.startswith("copy_")
                       and "copy_" + s.key not in self.skills]
            # 4.4: копирует только боевые приёмы (с уроном): копии чужих оборон делали бои с «черепахами» бесконечными
            options = [s for s in options if hasattr(s, "multiplier")]
            if options:
                clone = random.choice(options).copy_for(self.name)
                if hasattr(clone, "multiplier"):
                    clone.multiplier = round(clone.multiplier * self.COPY_POWER, 2)   # копия слабее оригинала
                self.skills[clone.key] = clone
                logs.append(Announcement(f"🪷 {self.name} изучает стиль врага и копирует умение "
                                         f"«{clone.name}» (можно применить один раз в этом бою)!"))
        return logs, can_act

    def _on_reset(self):  # скопированные умения живут только один бой
        self.skills = {k: s for k, s in self.skills.items() if not k.startswith("copy_")}

    def describe(self):  # переопределение
        return super().describe() + f", отражение {int(self.reflect * 100)}%"


class DarkElf(Character):
    """Тёмный эльф: «Тёмный столб огня» и «Казнь» (соперник уклоняется сам); при HP < 30% — вампиризм."""

    hero_class, type_key, resource_name = "Тёмный эльф", "darkelf", "тьма"
    signature_skill = "dark_pillar"
    role = "light"

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=172, base_damage=13.8, armor=2, level=level,
                         speed=6, dodge=0.1, crit_chance=0.15,
                         max_energy=100, energy_regen=14, start_energy=50)
        self._weak_announced = False
        self.shield_pierce = 0.35  # 35% урона эльфа проходит сквозь поглощающие щиты
        self.skills["execution"].options = ["left", "right", "down"]   # 4.0: третья кнопка «вниз»


    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Теневой клинок", "Обычная атака", icon="🗡"),
            ReactionSkill("dark_pillar", "Тёмный столб огня",
                          "×3.0 сквозь броню + горение. Соперник выбирает уклон влево/вправо (50/50)",
                          multiplier=3.0, ignore_armor=True, effect=lambda: Burn(2, 6),
                          cost=35, cooldown=3, icon="🔥"),
            ReactionSkill("execution", "Казнь", "×2.2, по цели с HP < 35% ещё +50%. Уклон влево / вправо / вниз",
                          multiplier=2.2, low_hp_bonus=0.5, cost=40, cooldown=4, icon="🪓"),
            DamageSkill("dark_curse", "Тёмное проклятие", "×1.0 + проклятие тьмы",
                        effect=lambda: DarkCurse(3, 5), cost=20, cooldown=3, icon="🌑"),
            LifestealSkill("life_drain", "Похищение жизни", "Только при HP < 30%: ×1.5, лечит 70% урона",
                           multiplier=1.5, steal=0.7, cost=25, cooldown=1, icon="🩸"),
            ShadowRitualSkill("ritual", "Ритуал теней", "Мини-игра с риском: открывайте руны (каждая +0.45 к удару "
                              "сквозь броню), одна проклята — −8% HP и ничего", cost=30, cooldown=4, icon="🔮"),
            DebuffSkill("you_weak", "Ты слаб", "3 хода: враг бьёт на 20% слабее и получает на 10% больше урона",
                        effect=lambda: Weakened(3), cost=25, cooldown=6, icon="🥀"),
            BloodShieldSkill("blood_shield", "Кровавый щит", "Плата 10% HP → щит на 22% HP на 3 хода",
                             cost=15, cooldown=6, icon="🩸"),
        ]

    def weakened(self):
        return self.hp < self.max_hp * 0.3

    def skill_unlocked(self, skill):  # переопределение
        if skill.key in ("dark_pillar", "execution"):
            return not self.weakened()
        if skill.key == "life_drain":
            return self.weakened()
        return True

    def start_turn(self):  # переопределение: объявление о слабости
        logs, can_act = super().start_turn()
        if self.is_alive() and self.weakened() and not self._weak_announced:
            self._weak_announced = True
            logs.append(Announcement(f"🩸 {self.name} слабеет: «Тёмный столб огня» и «Казнь» "
                                     f"недоступны — открыто «Похищение жизни»!"))
        return logs, can_act

    def _on_reset(self):
        self._weak_announced = False

    def describe(self):  # переопределение
        state = ", 🩸 ослаблен (вампиризм)" if self.weakened() else ""
        return super().describe() + state


class Owlbeast(Character):
    """Совух — секретный герой-зверь: огромное HP и сила. Пассивно: «Толстая шкура» −5% урона, «Охотничий инстинкт» — каждый промах даёт +{pct_step} к точности следующей атаки, третьего промаха подряд не бывает."""

    hero_class, type_key, resource_name = "Совух", "owlbeast", "ярость"
    signature_skill = "ram"
    role = "tank"

    secret = True      # скрыт, пока игрок не нашёл секрет (клик по «VS» в бою)
    creatable = False  # создать нельзя: после находки появляется готовый герой «Грозокрыл»
    INSTINCT_STEP = 0.10     # 4.4: было 0.15 — уклоняющиеся герои против Совуха были почти беззащитны
    MAX_MISS_STREAK = 2

    def __init__(self, name, level=1):
        super().__init__(name, max_hp=224, base_damage=10.7, armor=2, level=level,   # 4.0: HP 300 → 280; 4.4: HP 263→224, урон 9.1→10.7 (реже упирается в броню)
                         speed=3, dodge=0.0, crit_chance=0.1,
                         max_energy=100, energy_regen=15, start_energy=20)
        self.hide = 0.05       # «Толстая шкура»: −5% любого урона
        self.miss_streak = 0   # «Охотничий инстинкт»: промахов подряд

    def _create_skills(self):  # переопределение
        return [
            DamageSkill("attack", "Удар лапой", "Обычная атака", accuracy=0.82, icon="🐾"),
            DamageSkill("rend", "Разрывающие когти", "×1.3 + кровотечение", multiplier=1.3, accuracy=0.8,
                        effect=lambda: Bleed(3, 6), cost=20, cooldown=2, icon="🦅"),
            DamageSkill("ram", "Сокрушительный таран", "×1.8, 50% оглушить", multiplier=1.8, accuracy=0.76,
                        effect=lambda: Stun(1), effect_chance=0.5, cost=35, cooldown=4, icon="🐗"),
            DebuffSkill("roar", "Рёв совуха", "Соперник напуган: −25% урона на 3 хода",
                        effect=lambda: Intimidated(3, 25), cost=25, cooldown=5, icon="📢"),
            SelfBuffSkill("fury", "Ярость зверя", "Только при HP < 50%, раз за бой: +40% урона на 3 хода",
                          effects=[lambda: Berserk(3, 40)], score=30, announce=True,
                          cost=0, once_per_battle=True, icon="😡"),
            # ----- 4.2 -----
            GustSkill("gust", "Ураганный взмах", "×1.2, срывает с врага бафф или щит, −2 скорости на 2 хода",
                      multiplier=1.2, accuracy=0.85, effect=lambda: Slow(2, 2), cost=20, cooldown=4, icon="🌪"),
            NightHuntSkill("night_hunt", "Ночная охота", "Мини-игра: во тьме 3 раза мелькают глаза врага. Каждое "
                           "попадание ×0.9; 3/3 — последний удар крит + кровотечение", accuracy=0.8, cost=30, cooldown=5,
                           icon="🌙"),
            NephewsSkill("nephews", "Племянники Совуха", "Мини-игра: ловите 6 совят. 5–6 — 2 мини-совуха (40 HP, урон 6) "
                         "на 4 хода; 3–4 — 1; 1–2 — слабый совёнок; 0 — −10% точности. С 3-го хода",
                         accuracy=0.8, cost=50, cooldown=8, min_turn=3, icon="🦉"),
        ]

    def hit_chance(self, skill, victim):  # переопределение: «Охотничий инстинкт»
        if self.miss_streak >= self.MAX_MISS_STREAK:
            return 1.0   # третьего промаха подряд не бывает
        return min(1.0, super().hit_chance(skill, victim) + self.INSTINCT_STEP * self.miss_streak)

    def note_attack(self, hit):  # переопределение
        if hit:
            self.miss_streak = 0
        else:
            self.miss_streak = min(self.miss_streak + 1, self.MAX_MISS_STREAK)
            self._events.append(f"🦉 Охотничий инстинкт: {self.name} злится — следующая атака точнее "
                                f"(+{int(self.INSTINCT_STEP * 100 * self.miss_streak)}%).")

    def _on_reset(self):
        self.miss_streak = 0

    def skill_unlocked(self, skill):  # переопределение: ярость — только раненым
        if skill.key == "fury":
            return self.hp < self.max_hp * 0.5
        return True

    def take_damage(self, amount, ignore_armor=False, attacker=None):  # переопределение: толстая шкура
        return super().take_damage(max(1, int(amount * (1 - self.hide))), ignore_armor, attacker)

    def attack(self, target):  # переопределение: удар лапой копит ярость
        result = super().attack(target)
        self.restore_energy(10)
        return result

    def describe(self):  # переопределение
        return super().describe() + (f", толстая шкура −{int(self.hide * 100)}% урона, "
                                     f"охотничий инстинкт (промахов подряд: {self.miss_streak})")


# Словарь для создания героя по названию класса (используется в API)
HERO_CLASSES = {"warrior": Warrior, "mage": Mage, "archer": Archer,
                "ogre": Ogre, "spartan": Spartan, "assassin": Assassin,
                "samurai": Samurai, "druid": Druid, "monk": Monk, "darkelf": DarkElf,
                "owlbeast": Owlbeast}
