"""GameService — хранилище в памяти и бизнес-логика арены."""
import json
import os
import random

from models import (Announcement, HERO_CLASSES, KATANAS, CONSUMABLES, SKINS, Character, Weapon, Potion,
                    Item, Player, Battle, Owlbeast, RARITIES, SKIN_THEMES, STORY, StoryBattle)

IMAGES_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static", "images")
DEV_GOLD = 99999          # 4.0: чит разработчика — тройной клик по логотипу «Хиро арена»
RARITY_NAMES = {"common": "⚪ Обычный", "rare": "🔵 Редкий", "epic": "🟣 Эпический", "legendary": "🟡 Легендарный",
                "mythic": "🔴 Мифический"}   # 4.2: новая редкость
# 4.2: старые 16 героев — только у них остаются обычные облики «Золотой / Кровавый / Ледяной»
OLD_HERO_TYPES = ("warrior", "mage", "archer", "ogre", "spartan", "assassin", "samurai", "druid", "monk", "darkelf",
                  "owlbeast", "musketeer", "pagan", "minotaur", "croc", "darkknight")


class NotFoundError(Exception):
    """Объект не найден (в API превращается в 404)."""


class BusyError(Exception):
    """4.1: уже идёт другой бой (арена или сюжет) — новый начать нельзя (409)."""


class LockedError(Exception):
    """Действие запрещено: класс не открыт, героя нельзя создать/удалить, чужой герой в магазине (403)."""


class GameService:
    """Хранит героев, предметы, игроков и бои (in-memory репозиторий)."""

    def __init__(self, save_path="data/save.json"):
        self._heroes = {}
        self._items = {}
        self._players = {}
        self._battles = {}
        self._unlocked = set()   # кто открыл секретного героя: id игроков или "all" (без игрока)
        self.save_path = save_path

    # ---------- Классы героев ----------
    def is_unlocked(self, player=None):
        return "all" in self._unlocked or (player is not None and player.id in self._unlocked)

    def list_classes(self, player_id=None):
        """Список классов; секретный (Совух) показывается, только если он открыт.
        5.3.3: сюжетные мобы НЕ в меню создания — только готовые бойцы в настройке боя."""
        player = self.get_player(int(player_id)) if player_id not in (None, "") else None
        out = []
        for cls in HERO_CLASSES.values():
            if cls.secret and not self.is_unlocked(player):
                continue
            out.append(cls.class_info())
        return out

    def class_card(self, hero_type):
        """4.4: полная карточка одного класса (для окна героя). Секретный класс тоже — его видно у соперников."""
        from models.heroes_new import MOBS, DEV_ARENA_MOB_KEYS
        cls = HERO_CLASSES.get(hero_type) or MOBS.get(hero_type)
        if cls is None:
            raise NotFoundError(f"Класс «{hero_type}» не найден")
        info = cls.class_info()
        if hero_type in DEV_ARENA_MOB_KEYS:
            info["dev_mob"] = True
        return info

    # ---------- Секрет: клик по «VS» ----------
    def find_secret(self, battle_id, data):
        """Игрок нажал «VS» в бою. Совух откроется, когда этот бой закончится."""
        battle = self.get_battle(battle_id)
        if not battle.secret_found:
            battle.secret_found = True
            player = None
            if data.get("player_id") is not None:
                player = self.get_player(int(data["player_id"]))
            else:
                humans = [h for h in (battle.hero1, battle.hero2) if battle.is_human(h)] or [battle.hero1, battle.hero2]
                for h in humans:
                    player = player or self._owner_of(h)
            battle.secret_owner = player.id if player else "all"
            battle._add_log(Announcement("🦉 Вы нашли секрет! Таинственный зверь откроется, когда закончится этот бой…"))
        self._check_secret(battle)
        return battle

    def _owner_of(self, hero):
        for p in self._players.values():
            if hero in p.heroes:
                return p
        return None

    def _check_secret(self, battle):
        if battle.finished and battle.secret_found and not battle.secret_unlocked:
            battle.secret_unlocked = True
            self._unlocked.add(battle.secret_owner)
            owl = self._spawn_owl(battle.secret_owner)
            battle._add_log(Announcement(f"🦉 Совух разблокирован! Готовый герой «{owl.name}» ждёт вас на вкладке «Герои»."))

    OWL_NAME = "Грозокрыл"

    def _spawn_owl(self, owner_key):
        """После находки секрета появляется РОВНО ОДИН готовый Совух «Грозокрыл» (на игрока или общий)."""
        owner_id = owner_key if owner_key != "all" else None
        for h in self._heroes.values():
            if isinstance(h, Owlbeast) and h.protected and h.owner_id == owner_id:
                return h
        owl = Owlbeast(self.OWL_NAME)
        owl.protected, owl.owner_id = True, owner_id
        owl.custom = owner_id is not None   # 4.2: открытый Совух — СВОЙ герой игрока (облики, магазин, сумка)
        self._heroes[owl.id] = owl
        if owner_id is not None and owner_id in self._players:
            self._players[owner_id].add_hero(owl)
        return owl

    # ---------- Герои ----------
    def create_hero(self, data):
        hero_type = str(data.get("type", "")).lower()
        from models.heroes_new import MOBS, DEV_ARENA_MOB_KEYS
        cls = HERO_CLASSES.get(hero_type)
        # 5.3.3: мобы — только готовые NPC в арене, создать через меню нельзя
        if cls is None and hero_type in DEV_ARENA_MOB_KEYS:
            raise LockedError(f"«{MOBS[hero_type].hero_class}» — готовый боец режима разработчика, его нельзя создать")
        if cls is None:
            raise ValueError("type должен быть: " + ", ".join(HERO_CLASSES))
        try:
            level = int(data.get("level", 1))
        except (TypeError, ValueError):
            raise ValueError("level должен быть числом")
        if level < 1 or level > Character.MAX_LEVEL:
            raise ValueError(f"Уровень должен быть от 1 до {Character.MAX_LEVEL}")
        player = self.get_player(int(data["player_id"])) if data.get("player_id") is not None else None
        story = bool(data.get("story"))
        if not data.get("npc") and str(data.get("name", "")).strip().lower() in self.reserved_names():
            raise ValueError(f"Имя «{str(data.get('name')).strip()}» занято героем арены — выберите другое")
        if player and not data.get("npc"):
            if story and len(player.story_heroes()) >= Player.MAX_STORY_HEROES:
                raise LockedError(f"Сюжетных героев может быть не больше {Player.MAX_STORY_HEROES}")
            # 5.0: в режиме разработчика лимита героев арены нет; у обычных игроков — максимум 5
            if not story and len(player.arena_heroes()) >= Player.MAX_HEROES and not player.dev_mode:
                raise LockedError(f"У игрока уже {Player.MAX_HEROES} героев — это максимум "
                                  f"(Совух не считается). Удалите героя, чтобы создать нового")
        if story and level != 1:
            raise ValueError("Сюжетный герой начинает с 1 уровня")
        if not cls.creatable and not data.get("npc"):
            raise LockedError(f"{cls.hero_class} — особый герой, его нельзя создать. Найдите секрет в бою: "
                              f"готовый герой «{self.OWL_NAME}» появится сам.")
        if cls.secret and not self.is_unlocked(player):
            raise LockedError(f"{cls.hero_class} — секретный герой. Найдите секрет в бою, чтобы открыть его.")
        if cls.required_wins and not data.get("npc"):
            # 5.1: сюжетный Монах доступен сразу; арена по-прежнему ждёт required_wins
            if story and hero_type == "monk":
                pass
            else:
                wins = player.wins if player else 0
                if wins < cls.required_wins:
                    raise LockedError(f"{cls.hero_class} откроется после {cls.required_wins} побед игрока "
                                      f"(сейчас: {wins}/{cls.required_wins}). Укажите player_id игрока с победами.")
        hero = cls(data.get("name"), level=level)
        hero.story, hero.npc = story, bool(data.get("npc"))
        self._heroes[hero.id] = hero
        if player:
            player.add_hero(hero)
            hero.owner_id = player.id
            hero.custom = not data.get("starter")   # свой герой игрока: может ходить в магазин
            if player.active_hero_id is None and not story:
                player.active_hero_id = hero.id
        return hero

    def reserved_names(self):
        """4.0: имена героев арены (Конан, Мерлин, …) заняты — так назвать своего героя нельзя."""
        return {h.name.lower() for h in self._heroes.values() if getattr(h, "npc", False)}

    def select_hero(self, player_id, hero_id):
        """4.0: клик по своей карточке — герой становится активным игровым персонажем."""
        player, hero = self.get_player(player_id), self.get_hero(hero_id)
        if hero not in player.heroes:
            raise LockedError(f"{hero.name} — не ваш герой")
        player.active_hero_id = hero.id
        return {"player": player.to_dict(), "hero": hero.to_dict(), "message": "Игровой персонаж сменён"}

    def dev_gold(self, player_id):
        """4.0: чит разработчика (3 клика по логотипу): +99999 золота."""
        player = self.get_player(player_id)
        player.add_gold(DEV_GOLD)
        player.dev_mode = True        # 4.1: заодно включается режим разработчика — играть можно любым героем
        self._ensure_dev_arena_mobs()
        return {"player": player.to_dict(), "message": f"🛠 Режим разработчика: +{DEV_GOLD} золота"}

    def set_dev_mode(self, player_id, on=True):
        """4.1: режим разработчика: в бою можно играть ЛЮБЫМ героем (и героями арены), без ограничения групп.
        5.3.3: при включении — 15 готовых мобов в настройке боя (как Конан); при выключении скрыты."""
        player = self.get_player(player_id)
        player.dev_mode = bool(on)
        if on:
            self._ensure_dev_arena_mobs()
        elif not any(getattr(p, "dev_mode", False) for p in self._players.values()):
            self._remove_dev_arena_mobs()
        msg = ("🛠 Режим разработчика: можно играть любым героем; сюжетные мобы — готовые бойцы арены"
               if on else "Режим разработчика выключен (мобы скрыты из арены)")
        return {"player": player.to_dict(), "message": msg}

    def opponents_for(self, hero_id):
        """4.0: соперники героя — только из его группы уровней (1–3, 4–6, …); NPC подстраиваются под уровень.
        5.3.3: готовые мобы-бойцы видны как соперники только в режиме разработчика."""
        hero = self.get_hero(hero_id)
        owner = self._owner_of(hero)
        in_dev = bool(owner and owner.dev_mode)
        if not in_dev and (getattr(hero, "dev_mob", False) or getattr(hero, "npc", False)):
            # в UI режима разработчика можно выбрать NPC/моба своим бойцом — owner=None
            in_dev = any(getattr(p, "dev_mode", False) for p in self._players.values())
        result = []
        for h in self._heroes.values():
            if h is hero or getattr(h, "story", False):
                continue
            if getattr(h, "test_ephemeral", False):
                continue
            if (getattr(h, "mob", False) or getattr(h, "dev_mob", False)) and not in_dev:
                continue
            if hero.owner_id is not None and h.owner_id == hero.owner_id:
                continue
            if getattr(h, "npc", False) or h.level_group() == hero.level_group() or in_dev:
                result.append(h)
        return result


    def list_heroes(self, hero_type=None):
        heroes = [h for h in self._heroes.values() if not getattr(h, "test_ephemeral", False)]
        if hero_type:
            cls = HERO_CLASSES.get(hero_type.lower())
            heroes = [h for h in heroes if cls and isinstance(h, cls)]
        return heroes

    def get_hero(self, hero_id):
        if hero_id not in self._heroes:
            raise NotFoundError(f"Герой {hero_id} не найден")
        return self._heroes[hero_id]

    def update_hero(self, hero_id, data, full=True):
        """PUT (full=True) требует name; PATCH меняет только переданные поля."""
        hero = self.get_hero(hero_id)
        if full and "name" not in data:
            raise ValueError("Для PUT нужно поле name")
        # сначала проверяем все значения, чтобы при ошибке ничего не изменилось
        if "armor" in data and (not isinstance(data["armor"], (int, float)) or not 0 <= data["armor"] <= 50):
            raise ValueError("Броня должна быть от 0 до 50")
        if "level" in data and not 1 <= int(data["level"]) <= Character.MAX_LEVEL:
            raise ValueError(f"Уровень должен быть от 1 до {Character.MAX_LEVEL}")
        if ("name" in data and str(data["name"]).strip().lower() in self.reserved_names()
                and str(data["name"]).strip().lower() != hero.name.lower()):
            raise ValueError(f"Имя «{str(data['name']).strip()}» занято героем арены")
        if "name" in data and not str(data["name"]).strip():
            raise ValueError("Имя не может быть пустым")
        if "name" in data:
            hero.name = str(data["name"]).strip()
        if "hp" in data:
            hero.hp = data["hp"]          # валидация в сеттере
        if "armor" in data:
            hero.armor = data["armor"]    # валидация в сеттере
        if "level" in data:
            hero.set_level(int(data["level"]))
        return hero

    def delete_hero(self, hero_id):
        """Удалить героя. Его незаконченный бой отменяется автоматически."""
        hero = self.get_hero(hero_id)
        if hero.protected:
            raise LockedError(f"{hero.name} — особый герой, его нельзя удалить")
        battle = self._active_battle_of(hero)
        if battle:
            battle.cancel(f"Бой отменён: герой {hero.name} удалён")
            self._check_secret(battle)
        del self._heroes[hero_id]
        for p in self._players.values():
            if hero in p.heroes:
                p.heroes.remove(hero)
            if p.active_hero_id == hero.id:
                rest = p.arena_heroes()
                p.active_hero_id = rest[0].id if rest else None
        return hero

    def hero_action(self, hero_id, target_id, action):
        """Одиночное действие вне боя: attack, skill или ключ умения."""
        hero, target = self.get_hero(hero_id), self.get_hero(target_id)
        if hero is target:
            raise ValueError("Нельзя атаковать самого себя")
        if not hero.is_alive():
            raise ValueError(f"{hero.name} без сознания — вылечите его (POST /heal)")
        for h in (hero, target):
            if self._active_battle_of(h):
                raise ValueError(f"{h.name} сейчас в бою — действуйте через /api/battles")
        logs, _ = hero.start_turn()   # проходит один ход: реген, перезарядки, эффекты
        if action == "skill":
            logs.append(hero.use_skill(target))
        else:
            logs.extend(hero.perform(action or "attack", target))
        logs.extend(hero.pop_events() + target.pop_events())
        return " ".join(logs)

    def use_item(self, hero_id, item_id):
        hero = self.get_hero(hero_id)
        try:
            item = hero.inventory.remove_item(item_id)
        except KeyError as e:
            raise NotFoundError(str(e.args[0]))
        return item.use(hero)

    # ---------- Предметы ----------
    def create_item(self, data):
        kind = str(data.get("type", "")).lower()
        name, price = data.get("name"), data.get("price", 10)
        if not name:
            raise ValueError("Нужно поле name")
        if not isinstance(price, int) or price < 0:
            raise ValueError("price должен быть целым >= 0")
        if kind == "weapon":
            item = Weapon(name, price, int(data.get("damage_bonus", 5)))
        elif kind == "potion":
            item = Potion(name, price, int(data.get("heal_amount", 30)))
        elif kind == "item":
            item = Item(name, price)
        else:
            raise ValueError("type должен быть: weapon, potion или item")
        if "id" in data:          # используется при загрузке сохранения
            item.id = data["id"]
        self._items[item.id] = item
        return item

    def list_items(self):
        return list(self._items.values())

    def get_item(self, item_id):
        if item_id not in self._items:
            raise NotFoundError(f"Предмет {item_id} не найден")
        return self._items[item_id]

    def update_item(self, item_id, data):
        item = self.get_item(item_id)
        if "price" in data and (not isinstance(data["price"], int) or data["price"] < 0):
            raise ValueError("price должен быть целым >= 0")
        if "name" in data:
            item.name = data["name"]
        if "price" in data:
            item.price = data["price"]
        if "damage_bonus" in data and isinstance(item, Weapon):
            item.damage_bonus = int(data["damage_bonus"])
        if "heal_amount" in data and isinstance(item, Potion):
            item.heal_amount = int(data["heal_amount"])
        return item

    def delete_item(self, item_id):
        return self._items.pop(self.get_item(item_id).id)

    def give_item(self, hero_id, item_id):
        """Положить предмет из магазина в инвентарь героя (бесплатно)."""
        hero, item = self.get_hero(hero_id), self.get_item(item_id)
        hero.inventory.add_item(item)
        del self._items[item_id]
        return hero

    # ---------- Игроки ----------
    def create_player(self, data):
        if any(p.username == data.get("username") for p in self._players.values()):
            raise ValueError("Такой логин уже занят")
        player = Player(data.get("username"), data.get("password"), data.get("gold", 100))
        self._players[player.id] = player
        return player

    def list_players(self):
        return list(self._players.values())

    def get_player(self, player_id):
        if player_id not in self._players:
            raise NotFoundError(f"Игрок {player_id} не найден")
        return self._players[player_id]

    def update_player(self, player_id, data):
        player = self.get_player(player_id)
        if "gold" in data:
            player.gold = data["gold"]
        if data.get("active_hero_id") is not None:
            self.select_hero(player_id, int(data["active_hero_id"]))

        if "new_password" in data:
            player.change_password(data.get("old_password"), data["new_password"])
        return player

    def delete_player(self, player_id):
        return self._players.pop(self.get_player(player_id).id)

    def login(self, username, password):
        for p in self._players.values():
            if p.username == username and p.check_password(password):
                return p
        raise ValueError("Неверный логин или пароль")

    def buy_item(self, player_id, hero_id, item_id):
        player = self.get_player(player_id)
        hero, item = self.get_hero(hero_id), self.get_item(item_id)
        player.buy_item(item, hero)
        del self._items[item_id]
        return player

    # ---------- Магазин 3.3: расходники и облики ----------
    @staticmethod
    def skin_catalog(hero_type):
        """4.0: облики класса по редкости. Старые 3 — ⚪ обычные; 4 новых (2 редких, эпический, легендарный)
        доступны, когда готова картинка, иначе — «скоро»."""
        result = [{"skin": k, "name": n, "price": p, "rarity": "common", "rarity_name": RARITY_NAMES["common"],
                   "available": os.path.exists(os.path.join(IMAGES_DIR, "skins", f"{hero_type}_{k}.jpg")),
                   "image": f"/static/images/skins/{hero_type}_{k}.jpg", "description": ""}
                  for k, (n, p) in SKINS.items() if hero_type in OLD_HERO_TYPES]
        for rarity, key, name, desc in SKIN_THEMES.get(hero_type, []):
            result.append({"skin": key, "name": name, "price": RARITIES[rarity][1], "rarity": rarity,
                           "rarity_name": RARITY_NAMES[rarity], "description": desc,
                           "coming_soon": not os.path.exists(os.path.join(IMAGES_DIR, "skins", f"{hero_type}_{key}.jpg")),
                           "available": os.path.exists(os.path.join(IMAGES_DIR, "skins", f"{hero_type}_{key}.jpg")),
                           "image": f"/static/images/skins/{hero_type}_{key}.jpg"})
        # 5.0: сортировка common→rare→epic→legendary→mythic, затем по цене
        order = {r: i for i, r in enumerate(("common", "rare", "epic", "legendary", "mythic"))}
        result.sort(key=lambda s: (order.get(s["rarity"], 99), s["price"], s["name"]))
        return result

    @staticmethod
    def shop_catalog():
        """Что продаётся: расходники для боя (с весом) и облики по редкости для каждого класса."""
        consumables = [cls().to_dict() for cls in CONSUMABLES.values()]
        Item._next_id -= len(consumables)   # образцы для витрины не тратят id
        skins = {t: GameService.skin_catalog(t) for t, cls in HERO_CLASSES.items()
                 if cls.creatable or SKIN_THEMES.get(t)}
        rarities = [{"key": k, "name": RARITY_NAMES[k], "price": p} for k, (_, p) in RARITIES.items()]
        return {"consumables": consumables, "skins": skins, "rarities": rarities}

    def _shop_owner(self, hero, data):
        """Покупать может только СВОЙ созданный герой игрока (не стартовый, не ИИ, не чужой)."""
        if data.get("player_id") is None:
            raise ValueError("Нужно поле player_id")
        player = self.get_player(int(data["player_id"]))
        if self._own_owl(hero, player):      # 4.2: открытый Совух игрока считается его созданным героем
            hero.custom = True
        if not hero.custom or hero.owner_id != player.id or hero not in player.heroes:
            raise LockedError(f"{hero.name} — не ваш созданный герой: в магазин могут ходить только свои герои")
        if self._active_battle_of(hero):
            raise ValueError(f"{hero.name} сейчас в бою — покупки после боя")
        return player

    @staticmethod
    def _own_owl(hero, player):
        """4.2: Совух «Грозокрыл», открытый этим игроком (лежит у него в героях)."""
        return isinstance(hero, Owlbeast) and hero.protected and hero.owner_id == player.id and hero in player.heroes

    def shop_buy(self, hero_id, data):
        """Купить расходник (item=kunai/heal_potion/energy_potion/bomb) или облик (item=skin:gold)."""
        hero = self.get_hero(hero_id)
        player = self._shop_owner(hero, data)
        key = str(data.get("item", ""))
        if key.startswith("skin:"):
            skin = key[5:]
            entry = next((s for s in self.skin_catalog(hero.type_key) if s["skin"] == skin), None)
            if entry is None:
                raise ValueError("Облик должен быть: " + ", ".join(s["skin"] for s in self.skin_catalog(hero.type_key)))
            if not entry["available"] and skin not in SKINS:
                raise LockedError(f"Облик «{entry['name']}» скоро появится — картинка ещё рисуется")
            name, price = entry["name"], entry["price"]
            if player.owns_skin(hero.type_key, skin):      # 4.1: уже куплен аккаунтом — просто выдаём герою
                hero.add_skin(skin)
                return {"hero": hero.to_dict(), "player": player.to_dict(),
                        "message": f"Облик «{name}» уже ваш — {hero.name} может его надеть"}
            if price > player.gold:
                raise ValueError(f"Недостаточно золота: нужно {price}, есть {player.gold}")
            hero.add_skin(skin)
            player.add_skin(hero.type_key, skin)
            player.gold = player.gold - price
            return {"hero": hero.to_dict(), "player": player.to_dict(),
                    "message": f"Облик «{name}» куплен для аккаунта: его можно надеть на любого героя класса «{hero.hero_class}» (−{price} зол.)"}
        cls = CONSUMABLES.get(key)
        if cls is None:
            raise ValueError("item должен быть: " + ", ".join(list(CONSUMABLES) + ["skin:<облик>"]))
        if hero.consumable_counts().get(key, 0) >= cls.stack_max:
            raise ValueError(f"В сумке уже максимум: {cls.stack_max} шт.")
        item = cls()
        if item.price > player.gold:
            Item._next_id -= 1
            raise ValueError(f"Недостаточно золота: нужно {item.price}, есть {player.gold}")
        hero.inventory.add_item(item)          # проверка веса (5 кг) и слотов (10) — в Inventory

        player.gold = player.gold - item.price
        return {"hero": hero.to_dict(), "player": player.to_dict(),
                "message": f"{hero.name} кладёт в сумку «{item.name}» (−{item.price} зол.)"}

    def equip_skin(self, hero_id, data):
        """Надеть купленный облик (skin=null — обычный портрет). random_skin=true — режим случайного."""
        hero = self.get_hero(hero_id)
        player = self._shop_owner(hero, data)
        if "random_skin" in data and data.get("skin") is None and data.get("random_skin") is not None                 and "skin" not in data:
            pass  # handled below
        if "random_skin" in data and data.get("toggle_random"):
            return self.set_random_skin(hero_id, data)
        skin = data.get("skin")
        if "random_skin" in data and skin is None and data.get("random_skin"):
            # включить рандом без смены текущего skin
            return self.set_random_skin(hero_id, {**data, "random_skin": True})
        if skin and skin not in hero.skins and player.owns_skin(hero.type_key, skin):
            hero.add_skin(skin)            # 4.1: облик аккаунта подходит любому герою этого класса
        if "skin" in data:
            hero.equip_skin(skin)
        if "random_skin" in data:
            hero.set_random_skin(bool(data.get("random_skin")),
                                 account_skins=self._account_skins_for(hero))
        return hero

    def buy_skin(self, player_id, data):
        """4.1: единый магазин обликов — покупка облика для аккаунта (type + skin), без выбора героя."""
        player = self.get_player(player_id)
        hero_type, skin = str(data.get("type", "")), str(data.get("skin", ""))
        if hero_type not in HERO_CLASSES:
            raise ValueError("type должен быть: " + ", ".join(HERO_CLASSES))
        entry = next((s for s in self.skin_catalog(hero_type) if s["skin"] == skin), None)
        if entry is None:
            raise ValueError("Облик должен быть: " + ", ".join(s["skin"] for s in self.skin_catalog(hero_type)))
        if player.owns_skin(hero_type, skin):
            raise ValueError(f"Облик «{entry['name']}» уже куплен")
        if not entry["available"]:
            raise LockedError(f"Облик «{entry['name']}» скоро появится — картинка ещё рисуется")
        if entry["price"] > player.gold:
            raise ValueError(f"Недостаточно золота: нужно {entry['price']}, есть {player.gold}")
        player.gold = player.gold - entry["price"]
        player.add_skin(hero_type, skin)
        for h in player.heroes:
            if h.type_key == hero_type:
                h.add_skin(skin)
        return {"player": player.to_dict(), "skin": entry,
                "message": f"Облик «{entry['name']}» куплен (−{entry['price']} зол.) — наденьте его на любого героя класса"}

    # ---------- Бои ----------
    def _busy_battle(self, *heroes):
        """4.1: незаконченный бой, в котором уже участвует любой из героев или любой герой того же игрока."""
        owners = {h.owner_id for h in heroes if h.owner_id is not None and not getattr(h, "npc", False)}
        for b in self._battles.values():
            if b.finished:
                continue
            for h in (b.hero1, b.hero2):
                if h in heroes or (h.owner_id is not None and h.owner_id in owners):
                    return b
        return None

    def _busy_error(self, battle):
        kind = "сюжетный бой" if getattr(battle, "story", None) else "бой на арене"
        return BusyError(f"Уже идёт {kind} №{battle.id}: {battle.hero1.name} VS {battle.hero2.name}. "
                         f"Новый бой начать нельзя — доиграйте его, нажмите «Отменить бой» или «Сдаться»")

    def active_battles_of_player(self, player_id):
        """4.1: незаконченные бои героев игрока (арена и сюжет отдельно)."""
        player = self.get_player(player_id)
        result = {"arena": None, "story": None}
        for b in self._battles.values():
            if not b.finished and (b.hero1 in player.heroes or b.hero2 in player.heroes):
                result["story" if getattr(b, "story", None) else "arena"] = b.to_dict()
        return result

    SIMULATE_MAX = 200   # 4.3: было 1000 (≈5 с CPU на запрос)

    def can_simulate(self, player_id):
        if self.ALLOW_SEED:
            return True
        try:
            return self._is_dev({"player_id": int(player_id)}) if player_id is not None else False
        except (TypeError, ValueError):
            return False

    ALLOW_SEED = bool(os.environ.get("HERO_ARENA_TESTS"))   # 4.3: тесты разрешают seed без режима разработчика

    def _seed_rng(self, data):
        """4.3: seed от клиента — только в режиме разработчика или в тестах. Возвращает отдельный
        random.Random боя (глобальный ГСЧ не трогается); без seed — None (обычная случайность)."""
        if data.get("seed") is None:
            return None
        if not (self.ALLOW_SEED or self._is_dev(data)):
            raise PermissionError("seed доступен только в режиме разработчика")
        return random.Random(data["seed"])

    def _is_dev(self, data):
        pid = data.get("player_id")
        return bool(pid is not None and int(pid) in self._players and self._players[int(pid)].dev_mode)

    def _active_battle_of(self, hero):
        for b in self._battles.values():
            if not b.finished and hero in (b.hero1, b.hero2):
                return b
        return None


    def _account_skins_for(self, hero):
        """Ключи обликов аккаунта для класса героя."""
        player = self._players.get(hero.owner_id) if hero.owner_id else None
        if not player:
            return []
        prefix = hero.type_key + ":"
        return [s[len(prefix):] for s in player.owned_skins if s.startswith(prefix)]

    def _apply_random_skins(self, battle, *heroes):
        """5.2: если у героя включён случайный скин — выбрать облик на этот бой."""
        for hero in heroes:
            if not hero or not getattr(hero, "random_skin", False):
                continue
            acct = self._account_skins_for(hero)
            # подтянуть облики аккаунта на героя
            for s in acct:
                if s not in hero.skins:
                    try:
                        hero.add_skin(s)
                    except ValueError:
                        pass
            choice = hero.pick_random_battle_skin(account_skins=acct, rng=getattr(battle, "rng", None))
            battle.skin_override[hero.id] = choice

    def set_random_skin(self, hero_id, data):
        """Включить/выключить «🎲 Случайный скин»."""
        hero = self.get_hero(hero_id)
        player = self._shop_owner(hero, data) if data.get("player_id") is not None else self._players.get(hero.owner_id)
        acct = self._account_skins_for(hero)
        for s in acct:
            if s not in hero.skins:
                try:
                    hero.add_skin(s)
                except ValueError:
                    pass
        enabled = bool(data.get("random_skin") if "random_skin" in data else data.get("enabled"))
        hero.set_random_skin(enabled, account_skins=acct)
        return hero

    def story_is_complete(self, hero):
        """Сюжет пройден = последняя доступная локация (сейчас — все в STORY_ORDER) очищена."""
        from models.story import STORY_ORDER
        if not hero or not getattr(hero, "story", False):
            return False
        return all(loc.to_dict(hero).get("cleared") for loc in STORY_ORDER)

    def new_story_game(self, player_id, data=None):
        """5.2: «Новая игра» — архивировать пройденного героя, слот сюжета свободен."""
        data = data or {}
        player = self.get_player(player_id)
        heroes = player.story_heroes()
        if not heroes:
            raise ValueError("Нет активного сюжетного героя")
        hero = heroes[0]
        if data.get("hero_id") and int(data["hero_id"]) != hero.id:
            raise ValueError("Укажите текущего сюжетного героя")
        if not self.story_is_complete(hero) and not data.get("force"):
            raise LockedError("«Новая игра» доступна после прохождения сюжета")
        # отменить активный бой героя
        oldb = self._active_battle_of(hero)
        if oldb:
            oldb.cancel("Бой закрыт: новая игра")
        entry = player.archive_story_hero(hero)
        # убрать из активных героев сервиса (снимок в архиве)
        if hero.id in self._heroes:
            del self._heroes[hero.id]
        return {
            "archived": entry,
            "story_archive": list(player.story_archive),
            "player": player.to_dict(),
            "message": f"«{entry['name']}» отправлен в «Пройденные герои». Создайте нового героя — сюжет начнётся сначала.",
        }

    def abandon_story_hero(self, player_id, data=None):
        """5.2: «Сменить персонажа» — удалить текущего сюжетного героя БЕЗ архива."""
        data = data or {}
        player = self.get_player(player_id)
        heroes = player.story_heroes()
        if not heroes:
            raise ValueError("Нет активного сюжетного героя")
        hero = heroes[0]
        if data.get("hero_id") and int(data["hero_id"]) != hero.id:
            raise ValueError("Укажите текущего сюжетного героя")
        confirm = (data.get("confirm_name") or data.get("confirm") or "").strip()
        if confirm != hero.name:
            raise ValueError(f"Для подтверждения введите имя героя точно: «{hero.name}»")
        oldb = self._active_battle_of(hero)
        if oldb:
            oldb.cancel("Бой закрыт: смена персонажа")
        name = hero.name
        if hero in player.heroes:
            player.heroes.remove(hero)
        if player.active_hero_id == hero.id:
            player.active_hero_id = None
        if hero.id in self._heroes:
            del self._heroes[hero.id]
        return {
            "deleted": {"id": hero.id, "name": name},
            "player": player.to_dict(),
            "message": f"Герой «{name}» удалён. Прогресс сюжета потерян — создайте нового героя.",
        }

    def _require_dev(self, data):
        if data.get("player_id") is None:
            raise PermissionError("Секретная арена доступна только в режиме разработчика")
        player = self.get_player(int(data["player_id"]))
        if not player.dev_mode:
            raise PermissionError("Секретная арена доступна только в режиме разработчика")
        return player

    def test_arena_roster(self, player_id):
        """5.2: полный список бойцов секретной арены (классы + NPC + сюжетные мобы)."""
        player = self.get_player(player_id)
        if not player.dev_mode:
            raise PermissionError("Секретная арена доступна только в режиме разработчика")
        from models.story import STORY_ORDER
        roster = []
        for key, cls in HERO_CLASSES.items():
            roster.append({
                "key": f"class:{key}", "group": "class", "name": cls.hero_class,
                "label": cls.hero_class, "type": key, "image": f"/images/{key}",
                "level": 1, "display_level": 1, "kind": "class",
            })
        for key, name in self.NPC_HEROES:
            if key not in HERO_CLASSES:
                continue
            roster.append({
                "key": f"npc:{key}", "group": "npc", "name": name,
                "label": f"🤖 {name} ({HERO_CLASSES[key].hero_class})",
                "type": key, "image": f"/images/{key}",
                "level": None, "display_level": None, "kind": "npc",
            })
        for loc in STORY_ORDER:
            for stage in loc.stages:
                try:
                    mob = stage.make_mob()
                    img = mob.image
                except Exception:
                    img = f"/images/{stage.mob_key}"
                tag = "👑 " if stage.boss else ("⭐ " if stage.elite else ("🎁 " if stage.secret else ""))
                roster.append({
                    "key": f"stage:{loc.key}:{stage.key}", "group": "story",
                    "location": loc.key, "location_title": loc.title, "stage": stage.key,
                    "name": stage.name or stage.title,
                    "label": f"{tag}{stage.name or stage.title} · {loc.title}",
                    "type": stage.mob_key, "image": img,
                    "level": stage.level, "display_level": stage.display_level,
                    "boss": stage.boss, "elite": stage.elite, "secret": stage.secret,
                    "kind": "stage",
                })
        return {"fighters": roster, "count": len(roster),
                "note": "Тестовая арена: без наград, опыта и влияния на сюжет/сохранения"}

    def _spawn_test_fighter(self, key, level=None):
        """Эфемерный боец: class:/npc:/stage:/hero:."""
        from models.story import STORY
        key = str(key)
        if key.startswith("hero:"):
            src = self.get_hero(int(key.split(":", 1)[1]))
            hero = HERO_CLASSES[src.type_key](src.name, level=level or src.level)
            if src.skin:
                hero.skin = src.skin
        elif key.startswith("class:"):
            typ = key.split(":", 1)[1]
            if typ not in HERO_CLASSES:
                raise ValueError(f"Неизвестный класс «{typ}»")
            cls = HERO_CLASSES[typ]
            hero = cls(cls.hero_class, level=int(level or 1))
        elif key.startswith("npc:"):
            typ = key.split(":", 1)[1]
            name = next((n for k, n in self.NPC_HEROES if k == typ), None)
            if typ not in HERO_CLASSES or name is None:
                raise ValueError(f"Неизвестный NPC «{typ}»")
            hero = HERO_CLASSES[typ](name, level=int(level or 1))
            hero.npc = True
        elif key.startswith("stage:"):
            parts = key.split(":")
            if len(parts) != 3:
                raise ValueError("stage-ключ: stage:<локация>:<этап>")
            _, loc_key, stage_key = parts
            loc = STORY.get(loc_key)
            if not loc:
                raise ValueError(f"Локация «{loc_key}» не найдена")
            stage = next((s for s in loc.stages if s.key == stage_key), None)
            if not stage:
                raise ValueError(f"Этап «{stage_key}» не найден")
            hero = stage.make_mob()
            if level is not None:
                hero.set_level(int(level))
            hero.display_level = stage.display_level
        else:
            raise ValueError("fighter key: class:|npc:|stage:|hero:")
        hero.test_ephemeral = True
        hero.custom = False
        hero.story = False
        self._heroes[hero.id] = hero
        return hero

    def create_test_arena_battle(self, data):
        """5.2: секретная арена — любой vs любой, без наград и прогресса."""
        self._require_dev(data)
        f1, f2 = data.get("fighter1") or data.get("a"), data.get("fighter2") or data.get("b")
        if not f1 or not f2:
            raise ValueError("Нужны fighter1 и fighter2")
        hero1 = self._spawn_test_fighter(f1, data.get("level1"))
        hero2 = self._spawn_test_fighter(f2, data.get("level2"))
        mode = data.get("mode", "manual")
        if mode not in ("auto", "manual"):
            raise ValueError("mode должен быть auto или manual")
        if data.get("level1") is None and data.get("level2") is not None and not str(f1).startswith("stage:"):
            hero1.set_level(int(data["level2"]))
        if data.get("level2") is None and data.get("level1") is not None and not str(f2).startswith("stage:"):
            hero2.set_level(int(data["level1"]))
        ai_ids = [hero2.id]
        if mode == "auto" or data.get("ai_both"):
            ai_ids = [hero1.id, hero2.id]
        battle = Battle(hero1, hero2, mode=mode, ai_ids=ai_ids)
        battle.rng = self._seed_rng(data)
        battle.test_arena = True
        battle.notices.append({"type": "test_arena",
                               "text": "🧪 Секретная арена — без наград и влияния на сюжет"})
        self._battles[battle.id] = battle
        if mode == "auto":
            battle.fight()
        else:
            battle.start()
            battle.run_ai()
        self._reward(battle)
        return battle

    def _pick_bot_arena_skin(self, hero, rng=None):
        """5.3: ~90% обычный облик, ~10% случайный скин из магазина класса."""
        rng = rng or random
        catalog = [s for s in self.skin_catalog(hero.type_key) if s.get("available")]
        if not catalog:
            return None
        if rng.random() < 0.90:
            return None  # 5.3: ~10% случайный скин магазина
        return rng.choice(catalog)["skin"]

    def _apply_bot_arena_skin(self, battle, hero):
        """Косметический облик бота на бой (skin_override, сохранённый skin не трогаем)."""
        if not hero or not getattr(hero, "npc", False):
            return None
        # только если ещё нет override
        if hero.id in getattr(battle, "skin_override", {}):
            return battle.skin_override[hero.id]
        skin = self._pick_bot_arena_skin(hero, getattr(battle, "rng", None) or random)
        battle.skin_override[hero.id] = skin  # None = обычный
        return skin


    def create_battle(self, data):
        """mode=auto — бой целиком сразу; mode=manual — по ходам через play_turn."""
        if "hero1_id" not in data or "hero2_id" not in data:
            raise ValueError("Нужны поля hero1_id и hero2_id")
        hero1, hero2 = self.get_hero(int(data["hero1_id"])), self.get_hero(int(data["hero2_id"]))
        if hero1 is hero2:
            raise ValueError("Герой не может сражаться сам с собой")
        mode = data.get("mode", "auto")
        if mode not in ("auto", "manual"):
            raise ValueError("mode должен быть auto или manual")
        for h in (hero1, hero2):
            if getattr(h, "story", False):
                raise LockedError(f"{h.name} — сюжетный герой: он сражается только в сюжете")
        # 4.0: герой арены (NPC) подстраивается под уровень игрока; два героя игроков — только из одной группы
        # 5.3: уровни в UI арены скрыты. Выбор справедливости: NPC по-прежнему set_level(игрока);
        # PvP — только группа уровней (1–3), постоянные level/XP не трогаем (выравнивание к среднему
        # сломало бы прогресс). Сюжетные уровни остаются видимыми.
        npc1, npc2 = getattr(hero1, "npc", False), getattr(hero2, "npc", False)
        if npc2 and not npc1:
            hero2.set_level(hero1.level)
        elif npc1 and not npc2:
            hero1.set_level(hero2.level)
        elif not npc1 and not npc2 and hero1.level_group() != hero2.level_group() and not data.get("any_level") \
                and not self._is_dev(data):
            g = lambda h: f"{h.level_group() * 3 + 1}–{h.level_group() * 3 + 3}"
            raise ValueError(f"Соперники из разных групп уровней: {hero1.name} ({g(hero1)}) и {hero2.name} ({g(hero2)})")
        # 4.0: один предмет на бой — выбирается заранее из сумки
        items, free = {}, set()
        if data.get("item"):
            key = str(data["item"]).replace("item:", "")
            if key not in CONSUMABLES:
                raise ValueError("item должен быть: " + ", ".join(CONSUMABLES))
            if not hero1.consumable_counts().get(key):
                raise ValueError(f"У {hero1.name} нет предмета «{CONSUMABLES[key].title}» в сумке")
            items[hero1.id] = key
        # 4.1: пока идёт другой бой (арена или сюжет) — новый не начать. force=true — старое поведение:
        # брошенные незаконченные бои этих героев закрываются автоматически
        busy = self._busy_battle(hero1, hero2)
        if busy and not data.get("force"):
            raise self._busy_error(busy)
        closed = []
        for hero in (hero1, hero2):
            old = self._active_battle_of(hero)
            if old:
                old.cancel(f"Бой закрыт: {hero.name} начал новый бой")
                self._check_secret(old)
                closed.append(old.id)
        ai_ids = data.get("ai_ids", [])
        if data.get("vs_ai"):                # удобный флаг: второй герой под ИИ
            ai_ids = [hero2.id]
        seed_rng = self._seed_rng(data)      # 4.3: seed — только режим разработчика / тесты, свой ГСЧ боя
        if data.get("item2"):
            items[hero2.id] = str(data["item2"]).replace("item:", "")
        # 4.1: честный предмет ИИ — герой арены берёт случайный предмет, ТОЛЬКО если игрок взял свой
        # (раньше ИИ получал бесплатный предмет всегда, и бой без предметов был нечестным)
        for h in (hero1, hero2):
            if h.id not in items and items and (h.id in ai_ids or mode == "auto") and getattr(h, "npc", False) \
                    and not data.get("no_ai_items"):
                items[h.id] = random.choice(list(CONSUMABLES))
                free.add(h.id)
        battle = Battle(hero1, hero2, mode=mode, ai_ids=ai_ids, items=items)
        battle.rng = seed_rng
        battle.free_items = free
        self._apply_random_skins(battle, hero1, hero2)
        self._apply_bot_arena_skin(battle, hero1)
        self._apply_bot_arena_skin(battle, hero2)
        self._battles[battle.id] = battle
        battle.closed_battles = closed
        if mode == "auto":
            battle.fight()
        else:
            battle.start()
            battle.run_ai()
        self._reward(battle)
        return battle

    def play_turn(self, battle_id, data):
        battle = self.get_battle(battle_id)
        if battle.finished:
            raise ValueError("Бой уже закончен")
        skill = data.get("skill") or None
        if skill == "auto":
            skill = None
        battle.play_turn(skill)
        battle.run_ai()
        self._reward(battle)
        return battle

    def react(self, battle_id, data):
        """Ответ соперника-человека: уклон (left/right) или номер квадрата (0–5)."""
        battle = self.get_battle(battle_id)
        if "choice" not in data:
            raise ValueError("Нужно поле choice")
        battle.react(data["choice"])
        battle.run_ai()
        self._reward(battle)
        return battle

    def surrender(self, battle_id, data):
        battle = self.get_battle(battle_id)
        hero = None
        if data.get("hero_id") is not None:
            hero = self.get_hero(int(data["hero_id"]))
        battle.surrender(hero)
        self._reward(battle)
        return battle

    def cancel_battle(self, battle_id):
        battle = self.get_battle(battle_id)
        battle.cancel()
        self._check_secret(battle)
        return battle

    def kill_opponent(self, battle_id, data):
        """5.0: режим разработчика — мгновенно убить соперника, победа как обычная."""
        if not self._is_dev(data):
            raise PermissionError("«Убить» доступно только в режиме разработчика")
        battle = self.get_battle(battle_id)
        if battle.finished:
            raise ValueError("Бой уже закончен")
        hero = None
        if data.get("hero_id") is not None:
            hero = self.get_hero(int(data["hero_id"]))
        else:
            humans = [h for h in (battle.hero1, battle.hero2) if battle.is_human(h)]
            hero = humans[0] if humans else battle.hero1
        foe = battle.opponent(hero)
        battle.pending = None
        foe.hp = 0
        battle._add_log(Announcement(f"💀 {hero.name} убивает {foe.name} одним ударом (режим разработчика)!"),
                        actor=hero, target=foe)
        battle._finish(hero)
        self._reward(battle)
        return battle

    def open_story_secret(self, hero_id, data):
        """5.0: пасхалка — клик по портрету Рыбака открывает секретный бой со Шреком."""
        hero = self.get_hero(hero_id)
        if not getattr(hero, "story", False):
            raise ValueError("Не сюжетный герой")
        key = data.get("secret", "shrek_secret")
        hero.story_flags[f"secret_{key}"] = True
        return {"hero_id": hero.id, "flags": dict(hero.story_flags),
                "message": "🎣 Вы открыли секретный бой!"}

    def _reward(self, battle):
        """После окончания боя: +25 золота и победа владельцу героя-победителя."""
        self._check_secret(battle)
        if not battle.finished or getattr(battle, "rewarded", False) or battle.winner is None:
            return
        if getattr(battle, "test_arena", False):
            battle.rewarded = True  # 5.2: без золота/аудита
            return
        battle.rewarded = True
        if isinstance(battle, StoryBattle):
            self._story_reward(battle)
            return
        for p in self._players.values():
            if battle.winner in p.heroes:
                p.wins += 1
                p.add_gold(25)
                self._check_class_unlocks(p, battle)

    def _check_class_unlocks(self, player, battle=None):
        """4.0: класс за победы (Монах) открылся — один раз показываем «Вы открыли новый класс»."""
        notices = []
        for key, cls in HERO_CLASSES.items():
            if cls.required_wins and player.wins >= cls.required_wins and key not in player.unlocked_classes:
                player.unlocked_classes.append(key)
                notice = {"type": "class_unlocked", "class": key, "hero_class": cls.hero_class,
                          "text": f"Вы открыли новый класс: {cls.hero_class}", "image": f"/images/{key}"}
                notices.append(notice)
                if battle is not None:
                    battle.notices.append(notice)
                    battle._add_log(Announcement(f"🔓 Вы открыли новый класс: {cls.hero_class}!"))
        return notices

    # ---------- 4.0: Сюжет ----------
    def story_overview(self, hero_id=None):
        hero = self.get_hero(hero_id) if hero_id is not None else None
        if hero is not None and not getattr(hero, "story", False):
            raise ValueError(f"{hero.name} — не сюжетный герой")
        from models.story import INTRO_SCENES, STORY_ORDER
        locs = []
        prev_cleared = True
        for loc in STORY_ORDER:
            d = loc.to_dict(hero)
            # локация открыта, если предыдущая пройдена (или это первая)
            d["unlocked"] = prev_cleared
            if not prev_cleared:
                for s in d["stages"]:
                    s["status"] = "locked"
            prev_cleared = d["cleared"]
            locs.append(d)
        bag = dict(getattr(hero, "story_bag", {})) if hero else {}
        pending = list(getattr(hero, "story_pending_loot", []) or []) if hero else []
        bag_info = None
        if hero:
            bag_info = {
                "slots_used": hero.story_bag_slots_used(),
                "slots_max": hero.story_bag_capacity(),
                "pending_loot": pending,
            }
        player = self._players.get(hero.owner_id) if hero else None
        return {"locations": locs, "hero": hero.to_dict() if hero else None, "intro": INTRO_SCENES,
                "flags": dict(getattr(hero, "story_flags", {})) if hero else {},
                "story_bag": bag, "story_bag_info": bag_info, "version": 5.2,
                "story_complete": bool(hero and self.story_is_complete(hero)),
                "story_archive": list(getattr(player, "story_archive", []) or []) if player else [],
                "world_map": "/static/images/story/world_map.jpg"}

    STORY_FLAGS = ("intro_seen", "forest_boss_before_seen", "forest_boss_after_seen",
                   "slums_boss_before_seen", "slums_boss_after_seen",
                   "grove_boss_before_seen", "grove_boss_after_seen",
                   "swamp_boss_before_seen", "swamp_boss_after_seen",
                   "swamp_path", "secret_fisherman", "chain_wolves", "chain_hydra",
                   "pulled_leg")

    def set_story_flag(self, hero_id, data):
        """4.3: отметить, что вступительный ролик / диалог уже показан (value=false — показать снова)."""
        hero = self.get_hero(hero_id)
        if not getattr(hero, "story", False):
            raise ValueError(f"{hero.name} — не сюжетный герой")
        flag = data.get("flag")
        allowed = flag in self.STORY_FLAGS or (isinstance(flag, str) and (
            flag.startswith("secret_") or flag.startswith("chain_") or flag.startswith("seen_")
            or flag.endswith("_boss_before_seen") or flag.endswith("_boss_after_seen")
            or flag.startswith("secret_done_")))
        if not allowed:
            raise ValueError("flag должен быть: " + ", ".join(self.STORY_FLAGS))
        val = data.get("value", True)
        # 5.0/5.1: флаг развилки хранит строку ("light"/"dark"), остальные — bool
        if flag == "swamp_path":
            hero.story_flags[flag] = str(val)
            # после выбора — перепрыгнуть чужую ветку, чтобы открылся верный этап
            swamp = STORY.get("swamp")
            if swamp:
                swamp.snap_progress(hero)
        else:
            hero.story_flags[flag] = bool(val)
        return {"hero_id": hero.id, "flags": dict(hero.story_flags),
                "progress": dict(hero.story_progress)}

    def create_story_hero(self, player_id, data):
        data = dict(data, player_id=player_id, story=True, level=1)
        return self.create_hero(data)

    def story_battle(self, hero_id, data):
        hero = self.get_hero(hero_id)
        if not getattr(hero, "story", False):
            raise LockedError(f"{hero.name} — не сюжетный герой: создайте героя на вкладке «Сюжет»")
        from models.story import STORY_ORDER
        location = STORY.get(data.get("location", "slums"))
        if location is None:
            raise ValueError("location должен быть: " + ", ".join(STORY))
        # локация должна быть открыта (учитываем развилку через to_dict/cleared)
        for loc in STORY_ORDER:
            if loc.key == location.key:
                break
            if not loc.to_dict(hero).get("cleared"):
                raise LockedError(f"Локация «{location.title}» ещё закрыта — сначала пройдите предыдущую")
        # секретный этап
        stage_key = data.get("stage")
        if stage_key:
            stage = next((s for s in location.stages if s.key == stage_key), None)
            if stage is None:
                raise ValueError(f"Этап «{stage_key}» не найден")
            index = location.stage_index(stage_key)
        else:
            index = hero.story_progress.get(location.key, 0)
            main = [s for s in location.stages if not s.secret]
            if index >= len(main):
                raise ValueError("Локация уже пройдена — переиграйте любой этап, указав stage")
            stage = main[index]
        done = hero.story_progress.get(location.key, 0)
        main = [s for s in location.stages if not s.secret]
        main_keys = [s.key for s in main]
        if not stage.secret:
            try:
                mi = main_keys.index(stage.key)
            except ValueError:
                mi = index
            open_i = location.next_open_index(hero)
            loc_cleared = open_i >= len(main)
            # 5.1: в полностью пройденной локации бои закрыты (только кат-сцены при возврате с карты мира)
            if loc_cleared:
                raise LockedError("Локация уже пройдена — бои закрыты, можно пересмотреть кат-сцены")
            if open_i < 0:
                raise LockedError("Сначала выберите дорогу на развилке")
            # реванш на уже пройденном узле текущей локации разрешён (антифарм через farm_factor)
            if mi > open_i:
                raise LockedError("Этот этап ещё закрыт — сначала победите предыдущего противника")
        if stage.secret and not hero.story_flags.get(f"secret_{stage.key}"):
            raise LockedError("Секретный бой ещё не открыт")
        if stage.secret and hero.story_flags.get(f"secret_done_{stage.key}"):
            raise LockedError("Секретный бой уже пройден")
        # развилка
        if stage.choice and stage.choice.get("requires"):
            req = stage.choice["requires"]
            if hero.story_flags.get(req[0]) != req[1]:
                raise LockedError("Этот путь не выбран")
        busy = self._busy_battle(hero)
        if busy and not data.get("force"):
            raise self._busy_error(busy)
        oldb = self._active_battle_of(hero)
        if oldb:
            oldb.cancel(f"Бой закрыт: {hero.name} начал новый бой")
        # цепочка (волки/гидра): продолжаем с текущим HP
        chain_hp = None
        if stage.chain:
            ch = hero.story_flags.get(f"chain_{stage.chain}", 0)
            if ch > 0 and hasattr(hero, "_chain_hp"):
                chain_hp = hero._chain_hp
        mob = stage.make_mob()
        # 5.0: сюжетные расходники — только из story_bag (магазин не работает)
        items = {}
        if data.get("item"):
            key = str(data["item"]).replace("item:", "")
            bag = getattr(hero, "story_bag", {})
            if not bag.get(key):
                raise ValueError(f"У {hero.name} нет предмета «{key}» в сюжетной сумке")
            items[hero.id] = key
        mode = data.get("mode", "manual")
        battle = StoryBattle(hero, mob, location, stage, mode=mode, items=items)
        battle.rng = self._seed_rng(data)
        self._mirror_skin(battle, hero, mob)
        self._apply_random_skins(battle, hero)  # 5.2: случайный скин перекрывает зеркало при необходимости
        self._battles[battle.id] = battle
        battle._add_log(Announcement(f"💬 {hero.name}: «{stage.line}»"))
        # 5.1: мини-игра «Вытащи ногу» — при провале герой начинает бой раненым
        pull_ratio = data.get("pull_leg_ratio")
        if stage.key == "giant_croc" and pull_ratio is not None:
            try:
                pull_ratio = max(0.0, min(1.0, float(pull_ratio)))
            except (TypeError, ValueError):
                pull_ratio = 0.0
            hero.story_flags["pulled_leg"] = pull_ratio >= 1.0
            battle.story["pull_leg_ratio"] = pull_ratio
        if mode == "auto":
            battle.fight()
        else:
            battle.start()
            if chain_hp is not None:
                hero.hp = min(hero.max_hp, max(1, int(chain_hp)))
                battle._hp_seen[str(hero.id)] = hero.hp
            if stage.key == "giant_croc" and pull_ratio is not None and pull_ratio < 1.0:
                # не успел вытащить — теряет 25–40% HP пропорционально провалу
                wound = 0.25 + 0.15 * (1.0 - pull_ratio)
                new_hp = max(1, int(hero.max_hp * (1.0 - wound)))
                hero.hp = min(hero.hp, new_hp)
                battle._hp_seen[str(hero.id)] = hero.hp
                battle._add_log(Announcement(
                    f"🐊 Челюсти сомкнулись! {hero.name} теряет {int(wound*100)}% здоровья перед боем."))
                battle.story["pull_leg_failed"] = True
            battle.run_ai()
        self._reward(battle)
        return battle

    def _mirror_skin(self, battle, hero, mob):
        """4.4: в сюжете герой того же класса, что и противник (друид против Радогаста), без облика получает
        на этот бой случайный обычный облик своего класса — чтобы не выглядеть как враг. Сохранённый облик
        героя не меняется (облик хранится только в бою: battle.skin_override)."""
        if hero.type_key != mob.type_key or hero.skin:
            return None
        commons = [s["skin"] for s in self.skin_catalog(hero.type_key)
                   if s["rarity"] == "common" and s.get("available")]
        if not commons:
            return None
        skin = random.choice(commons)
        battle.skin_override[hero.id] = skin
        battle.story["mirror_skin"] = skin
        return skin

    def _story_reward(self, battle):
        hero = battle.hero1
        player = self._players.get(hero.owner_id)
        stage = battle.stage
        battle.story["gold"] = 0
        battle.story["items_gained"] = []
        battle.story["xp_gained"] = battle.xp[0] if battle.winner is hero else (battle.xp[1] if battle.xp else 0)
        battle.story["level_before"] = hero.level
        battle.story["xp_before"] = hero.experience
        if battle.winner is hero:
            gold = battle.gold_reward()
            if player:
                player.add_gold(gold)
                player.wins += 1
                self._check_class_unlocks(player, battle)
            battle.story["gold"] = gold
            # награда-предмет
            if stage.reward_item:
                battle.story["items_pending"] = []
                for part in str(stage.reward_item).split("+"):
                    key = part.strip()
                    res = self._grant_story_item(hero, key)
                    if res.get("status") == "ok":
                        battle.story["items_gained"].append(key)
                    elif res.get("status") == "pending":
                        battle.story["items_pending"].append(key)
                if battle.story.get("items_pending"):
                    battle.story["bag_full"] = True
                    battle.notices.append({
                        "type": "bag_full",
                        "text": "Сюжетная сумка заполнена — освободите слот, чтобы забрать награду",
                        "pending": list(battle.story["items_pending"]),
                    })
            # цепочка
            if stage.chain:
                ch = hero.story_flags.get(f"chain_{stage.chain}", 0) + 1
                hero.story_flags[f"chain_{stage.chain}"] = ch
                hero._chain_hp = hero.hp
                battle.story["chain_progress"] = ch
                if ch < stage.chain_size:
                    battle.story["chain_continue"] = True
                    battle._add_log(Announcement(f"⭐ Цепочка {ch}/{stage.chain_size} — бой продолжается без лечения!"))
                    battle.story["progress"] = hero.story_progress.get(battle.location.key, 0)
                    battle.story["level_after"] = hero.level
                    battle.story["xp_after"] = hero.experience
                    return
                hero.story_flags[f"chain_{stage.chain}"] = 0
                hero._chain_hp = None
            # прогресс по основным этапам (с учётом развилки)
            main = [s for s in battle.location.stages if not s.secret]
            main_keys = [s.key for s in main]
            if stage.key in main_keys:
                index = main_keys.index(stage.key)
                open_i = battle.location.next_open_index(hero)
                # засчитываем, если это текущий открытый этап (даже если raw progress меньше из-за пропуска ветки)
                if open_i == index or hero.story_progress.get(battle.location.key, 0) == index:
                    hero.story_progress[battle.location.key] = index + 1
                    battle.location.snap_progress(hero)
                    nxt = battle.location.next_open_index(hero)
                    battle.story["new_stage_opened"] = 0 <= nxt < len(main)
                    battle.story["background"] = stage.background or battle.location.cutscene_bg
                    battle.story["cutscene_bg"] = stage.background or battle.location.cutscene_bg
                    if stage.after:
                        after = stage.to_dict()["after"]
                        # 5.1: без ремарок рассказчика-режиссёра
                        battle.story["after"] = after
                        # 5.1g: после боя — нейтральный заголовок (локация), не «Имя — босс»
                        battle.story["after_title"] = battle.location.title or ""
                        battle.story["after_background"] = (
                            getattr(stage, "after_background", None)
                            or stage.background
                            or battle.location.cutscene_bg
                        )
                        # 5.3.2: фигура врага после боя — только если у врага есть реплики
                        _ally = {"dayla", "hero", "narrator", "tavern"}
                        enemy_speaks = any(
                            (line.get("speaker") if isinstance(line, dict) else None) not in _ally
                            and (line.get("speaker") if isinstance(line, dict) else None)
                            for line in after
                        )
                        battle.story["after_figure"] = stage.figure if enemy_speaks else None
                        if not enemy_speaks:
                            # чтобы старый фронт (figure fallback) тоже не показал врага
                            battle.story["figure"] = None
                    if stage.choice and stage.choice.get("options"):
                        battle.story["choice"] = stage.choice
                    if nxt >= len(main) or hero.story_progress.get(battle.location.key, 0) >= len(main):
                        battle.notices.append({"type": "story_cleared",
                                               "text": f"Локация «{battle.location.title}» пройдена!"})
            if stage.secret:
                hero.story_flags[f"secret_done_{stage.key}"] = True
                battle._add_log(Announcement(f"🎁 Секретная награда: +{gold} золота"))
            else:
                battle._add_log(Announcement(f"🎁 Награда: +{battle.xp[0]} опыта, +{gold} золота"))
                if battle.story["items_gained"]:
                    battle._add_log(Announcement(f"🎒 Получено: {', '.join(battle.story['items_gained'])}"))
        else:
            # поражение в цепочке — сброс
            if stage.chain:
                hero.story_flags[f"chain_{stage.chain}"] = 0
                hero._chain_hp = None
            battle._add_log(Announcement(f"📖 Поражение… +{battle.xp[1]} опыта. Попробуйте ещё раз!"))
        battle.story["progress"] = hero.story_progress.get(battle.location.key, 0)
        battle.story["level_after"] = hero.level
        battle.story["xp_after"] = hero.experience
        if player:
            battle.story["monk_progress"] = f"{player.wins}/7"

    def _grant_story_item(self, hero, key):
        """5.3: положить в инвентарь героя (5 кг / 10 слотов). story_bag — зеркало счётчиков."""
        if not key:
            return {"status": "rejected", "key": key, "reason": "empty"}
        from models.item import CONSUMABLES
        if key not in CONSUMABLES:
            return {"status": "rejected", "key": key, "reason": "unknown"}
        if not hasattr(hero, "story_bag") or hero.story_bag is None:
            hero.story_bag = {}
        if not hasattr(hero, "story_pending_loot") or hero.story_pending_loot is None:
            hero.story_pending_loot = []
        item = CONSUMABLES[key]()
        try:
            hero.inventory.add_item(item)
        except ValueError:
            hero.story_pending_loot.append(key)
            return {"status": "pending", "key": key,
                    "slots_used": len(hero.inventory.get_items()),
                    "slots_max": hero.inventory.max_slots,
                    "pending": list(hero.story_pending_loot),
                    "weight": hero.inventory.total_weight,
                    "max_weight": hero.inventory.max_weight}
        hero.story_bag[key] = hero.story_bag.get(key, 0) + 1
        return {"status": "ok", "key": key, "count": hero.story_bag[key],
                "slots_used": len(hero.inventory.get_items()),
                "slots_max": hero.inventory.max_slots,
                "weight": hero.inventory.total_weight,
                "max_weight": hero.inventory.max_weight}

    def discard_story_item(self, hero_id, data):
        """5.2: выбросить предмет из сюжетной сумки."""
        hero = self.get_hero(hero_id)
        if not getattr(hero, "story", False):
            raise ValueError(f"{hero.name} — не сюжетный герой")
        key = data.get("key") or data.get("item")
        if not key:
            raise ValueError("Укажите key предмета")
        count = int(data.get("count", 1) or 1)
        hero.discard_story_item(key, count)
        claimed = self._try_claim_pending_loot(hero)
        return self._story_bag_payload(hero, claimed=claimed)

    def claim_pending_story_loot(self, hero_id, data=None):
        hero = self.get_hero(hero_id)
        if not getattr(hero, "story", False):
            raise ValueError(f"{hero.name} — не сюжетный герой")
        claimed = self._try_claim_pending_loot(hero)
        return self._story_bag_payload(hero, claimed=claimed)

    def _try_claim_pending_loot(self, hero):
        if not hasattr(hero, "story_pending_loot") or hero.story_pending_loot is None:
            hero.story_pending_loot = []
        claimed, left = [], []
        for key in list(hero.story_pending_loot):
            if hero.story_bag_can_add(key):
                hero.story_bag[key] = hero.story_bag.get(key, 0) + 1
                claimed.append(key)
            else:
                left.append(key)
        hero.story_pending_loot = left
        return claimed

    def _story_bag_payload(self, hero, claimed=None):
        from models.item import CONSUMABLES
        bag = dict(getattr(hero, "story_bag", {}) or {})
        items = []
        for key, n in bag.items():
            if not n:
                continue
            cls = CONSUMABLES.get(key)
            proto = cls() if cls else None
            items.append({
                "key": key, "count": n,
                "name": getattr(cls, "title", None) or (proto.name if proto else key),
                "icon": getattr(cls, "icon", None) or (proto.icon if proto else "📦"),
                "rarity": getattr(proto, "rarity", None) or "обычный",
                "description": getattr(proto, "description", None) or "",
                "stack_max": getattr(cls, "stack_max", 99) if cls else 99,
            })
        return {
            "hero_id": hero.id, "items": items, "bag": bag,
            "slots_used": hero.story_bag_slots_used(),
            "slots_max": hero.story_bag_capacity(),
            "pending_loot": list(getattr(hero, "story_pending_loot", []) or []),
            "claimed": claimed or [], "hero": hero.to_dict(),
            "inventory": hero.inventory.to_dict(),
        }

    def story_bag_info(self, hero_id):
        hero = self.get_hero(hero_id)
        if not getattr(hero, "story", False):
            raise ValueError(f"{hero.name} — не сюжетный герой")
        return self._story_bag_payload(hero)


    def list_battles(self, status=None):
        battles = list(self._battles.values())
        if status:
            battles = [b for b in battles if b.status == status]
        return battles

    def get_battle(self, battle_id):
        if battle_id not in self._battles:
            raise NotFoundError(f"Бой {battle_id} не найден")
        return self._battles[battle_id]

    def delete_battle(self, battle_id):
        return self._battles.pop(self.get_battle(battle_id).id)

    # ---------- Свои идеи: рейтинг и симуляция ----------
    def leaderboard(self):
        def rate(h):
            total = h.wins + h.losses
            return round(100 * h.wins / total, 1) if total else 0.0
        def rated(h):
            # 5.3.2: мобы/тестовые/эфемерные не засоряют рейтинг
            if getattr(h, "test_ephemeral", False) or getattr(h, "dev_mob", False) or getattr(h, "mob", False):
                return False
            from models.heroes_new import DEV_ARENA_MOB_KEYS
            if h.type_key in DEV_ARENA_MOB_KEYS:
                return False
            return True
        heroes = sorted([h for h in self._heroes.values() if rated(h)],
                        key=lambda h: (h.wins, rate(h), h.level), reverse=True)
        return {
            "heroes": [{"place": i + 1, "id": h.id, "name": h.name, "hero_class": h.hero_class,
                        "type": h.type_key, "level": h.level, "wins": h.wins, "losses": h.losses,
                        "win_rate": rate(h), "image": h.image}
                       for i, h in enumerate(heroes)],
            "players": [{"place": i + 1, "username": p.username, "wins": p.wins, "gold": p.gold}
                        for i, p in enumerate(sorted(self._players.values(), key=lambda p: p.wins, reverse=True))],
        }

    @staticmethod
    def simulate(type1, type2, n=100):
        """Провести n боёв между новыми героями двух классов (проверка баланса)."""
        c1, c2 = HERO_CLASSES.get(type1), HERO_CLASSES.get(type2)
        if not c1 or not c2:
            raise ValueError("type1 и type2 должны быть: " + ", ".join(HERO_CLASSES))
        if not 1 <= n <= GameService.SIMULATE_MAX:
            raise ValueError(f"n должно быть от 1 до {GameService.SIMULATE_MAX}")
        saved = Character._next_id, Battle._next_id   # не тратим id настоящих героев
        wins1 = wins2 = draws = rounds = 0
        try:   # 4.3: счётчики id восстанавливаются даже при ошибке
            for _ in range(n):
                h1, h2 = c1("A"), c2("B")
                battle = Battle(h1, h2)
                winner = battle.fight()
                rounds += battle.round
                if winner is h1:
                    wins1 += 1
                elif winner is h2:
                    wins2 += 1
                else:
                    draws += 1
        finally:
            Character._next_id, Battle._next_id = saved
        return {"type1": type1, "type2": type2, "fights": n,
                "wins1": wins1, "wins2": wins2, "draws": draws,
                "win_rate1": round(100 * wins1 / n, 1), "avg_rounds": round(rounds / n, 1)}

    # ---------- Сохранение / загрузка ----------
    def save(self):
        """Сохранить героев, предметы и игроков в JSON-файл (бои не сохраняются)."""
        heroes = []
        for h in self._heroes.values():
            if getattr(h, "test_ephemeral", False):
                continue
            extra = {"katana": type(h.katana).__name__} if hasattr(h, "katana") else {}
            heroes.append({**extra, "id": h.id, "type": h.type_key, "name": h.name, "level": h.level,
                           "experience": h.experience, "wins": h.wins, "losses": h.losses,
                           "armor": h.armor, "armor_base": getattr(h, "_default_armor", h.armor),
                           "skin": h.skin, "skins": h.skins,
                           "random_skin": getattr(h, "random_skin", False),
                           "last_random_skin": getattr(h, "last_random_skin", None),
                           "owner_id": h.owner_id,
                           "custom": h.custom, "protected": h.protected,
                           "story": getattr(h, "story", False), "npc": getattr(h, "npc", False),
                           "mob": getattr(h, "mob", False), "dev_mob": getattr(h, "dev_mob", False),
                           "story_progress": getattr(h, "story_progress", {}),
                           "story_flags": getattr(h, "story_flags", {}), "story_bag": getattr(h, "story_bag", {}),
                           "story_pending_loot": getattr(h, "story_pending_loot", []),
                           "story_version": 50,
                           "weapon": h.weapon.to_dict() if h.weapon else None,
                           "inventory": [i.to_dict() for i in h.inventory.get_items()]})
        data = {"heroes": heroes, "items": [i.to_dict() for i in self._items.values()],
                "players": [p.to_save_dict() for p in self._players.values()],
                "unlocked_secrets": sorted(self._unlocked, key=str)}
        folder = os.path.dirname(self.save_path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        with open(self.save_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return {"path": self.save_path, "heroes": len(heroes), "items": len(self._items),
                "players": len(self._players)}

    @staticmethod
    def _item_from_dict(d):
        kind = d["type"]
        if kind == "Weapon":
            item = Weapon(d["name"], d["price"], d["damage_bonus"])
        elif kind == "Potion":
            item = Potion(d["name"], d["price"], d["heal_amount"])
        elif d.get("key") in CONSUMABLES:
            item = CONSUMABLES[d["key"]]()
        else:
            item = Item(d["name"], d["price"])
        item.id = d["id"]
        return item

    def load(self):
        """Загрузить состояние из JSON-файла (текущие данные заменяются)."""
        if not os.path.exists(self.save_path):
            raise NotFoundError("Файл сохранения не найден — сначала POST /api/save")
        with open(self.save_path, encoding="utf-8") as f:
            data = json.load(f)
        self._heroes, self._items, self._players, self._battles = {}, {}, {}, {}
        self._unlocked = set(data.get("unlocked_secrets", []))
        from models.heroes_new import MOBS, DEV_ARENA_MOB_KEYS
        for d in data["heroes"]:
            cls = HERO_CLASSES.get(d["type"]) or (MOBS.get(d["type"]) if d["type"] in DEV_ARENA_MOB_KEYS or d.get("mob") or d.get("dev_mob") else None)
            if cls is None:
                raise ValueError(f"Неизвестный тип героя в сохранении: {d.get('type')}")
            hero = cls(d["name"], level=d["level"])
            if d.get("katana") in KATANAS:
                hero.katana = KATANAS[d["katana"]]()
            hero.id, hero.experience = d["id"], d["experience"]
            hero.wins, hero.losses = d["wins"], d["losses"]
            # Saved armor used to overwrite the constructor's balance changes.
            # Preserve personal offsets while moving to the current class base.
            # Pre-balance 5.4.1 saves have no armor_base and used the constructor
            # armor before the current KIT_TUNING adjustment.
            from models.tuning import KIT_TUNING
            current_base = hero._default_armor
            legacy_base = current_base - KIT_TUNING.get(hero.type_key, {}).get("armor", 0)
            saved_base = d.get("armor_base", legacy_base)
            hero.armor = max(0, min(50, d["armor"] - saved_base + current_base))
            hero.skins, hero.skin = list(d.get("skins", [])), d.get("skin")
            hero.random_skin = bool(d.get("random_skin", False))
            hero.last_random_skin = d.get("last_random_skin")
            hero.owner_id, hero.custom = d.get("owner_id"), d.get("custom", False)
            hero.protected = d.get("protected", False)
            if isinstance(hero, Owlbeast) and hero.protected and hero.owner_id is not None:
                hero.custom = True   # 4.2: старые сохранения — открытый Совух становится своим героем
            hero.story, hero.npc = d.get("story", False), d.get("npc", False)
            hero.mob = bool(d.get("mob", getattr(hero, "mob", False)))
            hero.dev_mob = bool(d.get("dev_mob", False))
            hero.story_progress = dict(d.get("story_progress", {}))
            hero.story_flags = dict(d.get("story_flags", {}))
            hero.story_bag = dict(d.get("story_bag", {}))
            hero.story_pending_loot = list(d.get("story_pending_loot", []) or [])
            ver = d.get("story_version", 0)
            if hero.story and ver < 43:
                if hero.story_progress.get("forest", 0) >= 4:
                    hero.story_progress["forest"] = 5
            if hero.story and ver < 50:
                # 5.0: трущобы вставлены перед лесом — пройденный лес остаётся пройденным,
                # прогресс трущоб = пройден (чтобы лес оставался открыт)
                if hero.story_progress.get("forest", 0) > 0 and "slums" not in hero.story_progress:
                    hero.story_progress["slums"] = 5
            if d["weapon"]:
                hero.equip(self._item_from_dict(d["weapon"]))
            for item in d["inventory"]:
                hero.inventory.add_item(self._item_from_dict(item))
            self._heroes[hero.id] = hero
        for d in data["items"]:
            item = self._item_from_dict(d)
            self._items[item.id] = item
        for d in data["players"]:
            player = Player.from_save_dict(d)
            for hid in d["heroes"]:
                if hid in self._heroes:
                    player.add_hero(self._heroes[hid])
                    for s in self._heroes[hid].skins:      # 4.1: старые сохранения — облики героя → аккаунту
                        player.add_skin(self._heroes[hid].type_key, s)
            self._players[player.id] = player
        # следующие id должны быть больше загруженных
        Character._next_id = max([Character._next_id] + [i + 1 for i in self._heroes])
        Item._next_id = max([Item._next_id] + [i + 1 for i in self._items])
        Player._next_id = max([Player._next_id] + [i + 1 for i in self._players])
        # 5.0: у каждого игрока оставляем только первого сюжетного героя (старые сохранения)
        for player in self._players.values():
            stories = [h for h in player.heroes if getattr(h, "story", False)]
            for extra in stories[1:]:
                player.heroes.remove(extra)
                # герой остаётся в _heroes, но без владельца-сюжета не ломает; помечаем
                extra.owner_id = player.id  # остаётся, но не в списке героев игрока
                # фактически убираем из player — уже remove
        from models import NEW_HEROES_42
        have = {h.type_key for h in self._heroes.values() if getattr(h, "npc", False)}
                # 5.4 Даагаш_migration: язычник Даш → Даагаш
        for h in self._heroes.values():
            if getattr(h, "type_key", None) == "pagan" and h.name == "Даш":
                h.name = "Даагаш"
        for t, name in self.NPC_HEROES:          # 4.2: в сохранениях 4.1 нет новых соперников — добавляем
            if t in NEW_HEROES_42 and t not in have:
                self.create_hero({"type": t, "name": name, "npc": True})
        # 5.3.3: удалить созданных игроком мобов; готовые бойцы — только если кто-то в,dev
        self._purge_owned_dev_mobs()
        if any(getattr(p, "dev_mode", False) for p in self._players.values()):
            self._ensure_dev_arena_mobs()
        else:
            self._remove_dev_arena_mobs()
        return {"path": self.save_path, "heroes": len(self._heroes), "items": len(self._items),
                "players": len(self._players)}

    def _ensure_dev_arena_mobs(self):
        """5.3.3: 15 обычных сюжетных мобов — готовые NPC-бойцы арены (как Конан), без создания."""
        from models.heroes_new import MOBS, DEV_ARENA_MOB_KEYS
        have = {h.type_key for h in self._heroes.values()
                if getattr(h, "dev_mob", False) and getattr(h, "npc", False)
                and getattr(h, "owner_id", None) is None}
        for key in sorted(DEV_ARENA_MOB_KEYS):
            if key in have:
                continue
            cls = MOBS.get(key)
            if not cls:
                continue
            hero = cls(cls.hero_class, level=1)
            hero.npc = True
            hero.mob = True
            hero.dev_mob = True
            hero.custom = False
            hero.story = False
            self._heroes[hero.id] = hero

    def _purge_owned_dev_mobs(self):
        """5.3.3: убрать из сохранений/рейтинга героев-мобов, которых игрок создал раньше."""
        from models.heroes_new import DEV_ARENA_MOB_KEYS
        drop = []
        for hid, h in list(self._heroes.items()):
            is_mob = getattr(h, "dev_mob", False) or getattr(h, "mob", False) or h.type_key in DEV_ARENA_MOB_KEYS
            if not is_mob:
                continue
            # оставляем только готовых NPC без владельца
            if getattr(h, "npc", False) and getattr(h, "owner_id", None) is None and not getattr(h, "custom", False):
                h.dev_mob = True
                h.mob = True
                continue
            drop.append(hid)
        for hid in drop:
            h = self._heroes.pop(hid, None)
            if not h:
                continue
            for p in self._players.values():
                if h in getattr(p, "heroes", []):
                    p.heroes.remove(h)
                if getattr(p, "active_hero_id", None) == hid:
                    p.active_hero_id = None

    def _remove_dev_arena_mobs(self):
        """5.3.3: убрать готовых мобов-бойцов, когда режим разработчика выключен у всех."""
        drop = [hid for hid, h in self._heroes.items()
                if getattr(h, "dev_mob", False) and getattr(h, "npc", False)
                and getattr(h, "owner_id", None) is None]
        for hid in drop:
            self._heroes.pop(hid, None)

    def seed(self):
        """Стартовые данные, чтобы API не был пустым."""
        # предметы магазина создаём первыми, чтобы у них были id 1 и 2 (катана самурая — тоже Item)
        self.create_item({"type": "weapon", "name": "Стальной меч", "price": 50, "damage_bonus": 6})
        self.create_item({"type": "potion", "name": "Зелье здоровья", "price": 20, "heal_amount": 40})
        self.create_player({"username": "student", "password": "1234", "gold": 200})
        # 4.0: базовые герои — только соперники арены (NPC без владельца); их имена заняты
        for t, name in self.NPC_HEROES:
            self.create_hero({"type": t, "name": name, "npc": True})

    NPC_HEROES = [("warrior", "Конан"), ("mage", "Мерлин"), ("archer", "Леголас"), ("ogre", "Шрек"),
                  ("spartan", "Леонид"), ("assassin", "Альтаир"), ("samurai", "Мусаси"), ("druid", "Радогаст"),
                  ("darkelf", "Нер'зул"), ("monk", "Шаолинь"), ("musketeer", "Рейв"), ("pagan", "Даагаш"),
                  ("minotaur", "Кэрн"), ("croc", "Крок"), ("darkknight", "Мордред"),
                  # 4.2: девять новых героев арены
                  ("goblin", "Газ-Лоу"), ("satyr", "Шибэк"), ("ghoul", "Гуль"), ("rhino", "Риноу"),
                  ("bogatyr", "Дуррила"), ("orc", "Моргал"), ("dwarf", "Эриксон"), ("lightelf", "Каэль-туас"),
                  ("shade", "Нефруит"),
                  # 5.4
                  ("aarakocra", "Скайр"), ("hunter", "Дэрил"), ("gnoll", "Рексор"), ("centaur", "Талар"),
                  ("bluetroll", "Рокх-анн"), ("paladin", "Серена"), ("catfolk", "Анниса"),
                  ("beastlord", "Трейфус"), ("spiderqueen", "Нимерия"), ("ranger", "Элайра"),
                  ("pandaren", "Кейвин"), ("gambler", "Вейл")]

