"""Six new heroes: source-bound marks, deliberate combos and controlled undead."""
import math
import random
from .character import Character, HERO_CLASSES
from .skills import Skill, DamageSkill, SelfBuffSkill, DebuffSkill, scale_effect
from .effects import (Effect, Announcement, Shield, DodgeBuff, Slow, Stun, Blinded,
                      StunWard, DamageReduction, Berserk, Poison, Bleed, Antiheal, DamageOverTime)


class WeakPoint(Effect):
    name, icon = 'Слабое место', '🎯'
    def __init__(self, source_id, expiries):
        super().__init__(999, len(expiries))
        self.source_id, self.expiries = source_id, list(expiries)
    def on_turn_start(self, owner):
        self.expiries = [t for t in self.expiries if t > owner.turn_number]
        self.power = len(self.expiries)
        if not self.power: self.duration = 0
        return []
    def modify_incoming(self, owner, damage, attacker):
        return (round(damage*(1+.08*self.power)) if getattr(attacker,'id',None)==self.source_id else damage), []
    def to_dict(self):
        return {**super().to_dict(), 'source_id':self.source_id, 'stacks':self.power}


def marks(target, source):
    return next((e for e in target.get_effects() if isinstance(e,WeakPoint) and e.source_id==source.id and e.duration>0),None)


def add_marks(user, target, count):
    e=marks(target,user)
    old=list(e.expiries) if e else []
    for _ in range(count):
        if len(old)>=3: old.pop(0)
        old.append(target.turn_number+3)
    if e: e.expiries,e.power=old,len(old)
    else: target._effects.append(WeakPoint(user.id,old))
    return [f'🎯 {target.name}: Слабое место {len(old)}/3 от {user.name}.']


def spend_marks(user,target):
    e=marks(target,user)
    if e: target._effects.remove(e)


class Judgment(Effect):
    name,icon='Приговор','⌛'
    def __init__(self,source_id):
        super().__init__(999,3);self.source_id=source_id
    def on_turn_start(self,owner):
        if self.power>0:
            self.power-=1
            return [Announcement(f'⌛ Приговор {owner.name}: '+(f'{self.power} х.' if self.power else 'готов к исполнению!'))]
        return []
    def to_dict(self):
        return {**super().to_dict(),'source_id':self.source_id,'ready':self.power==0}


def verdict(user,target):
    return next((e for e in target.get_effects() if isinstance(e,Judgment) and e.source_id==user.id),None)


class Dread(Effect):
    name,icon='Парализующий страх','😨'
    def damage_bonus(self):return -self.power/100
    def accuracy_bonus(self):return -.1


class Drain(DamageOverTime):
    name,icon='Иссушение страха','🩸'
    def __init__(self,source,power):super().__init__(2,power);self.source=source
    def on_turn_start(self,owner):
        if not owner.is_alive():return []
        before=owner.hp
        damage=max(1,round(self.power*(1-getattr(owner,'DOT_RESIST',0))))
        if hasattr(owner,'take_dot_damage'):owner.take_dot_damage(damage)
        else:owner.hp-=damage
        lost=before-owner.hp
        healed=self.source.heal(lost) if self.source.is_alive() else 0
        return [f'🩸 Страх иссушает {owner.name}: {lost} урона; {self.source.name} +{healed} HP.']


class TwoHitShield(Effect):
    name,icon,positive='Каменная плоть','🪨',True
    def __init__(self,power):super().__init__(999,power);self.hits=2
    def modify_incoming(self,owner,damage,attacker):
        if attacker is None or damage<=0 or self.hits<=0:return damage,[]
        cut=min(damage,self.power);self.hits-=1
        if not self.hits:self.duration=0
        return damage-cut,[f'🪨 Каменная плоть поглощает {cut}; осталось ударов: {self.hits}.']
    def to_dict(self):return {**super().to_dict(),'hits_left':self.hits}


class Reckless(Berserk):
    name,icon='Чёрная месса','🕯'
    def dodge_bonus(self):return -.15


class NextCritical(Effect):
    name,icon,positive='Следующий удар — крит','👑',True


class ShortGame(Effect):
    name,icon='Дрожащие руки','⏳'


class NewHero(Character):
    HP,DAMAGE,ARMOR,SPEED,DODGE=190,13,1,6,.1
    def __init__(self,name,level=1):
        super().__init__(name,max_hp=self.HP,base_damage=self.DAMAGE,armor=self.ARMOR,
            speed=self.SPEED,dodge=self.DODGE,level=level,max_energy=100,start_energy=100,energy_regen=12)
        self._on_reset()
    def _on_reset(self):
        self._action_key=None;self._active_target=None;self._critical_action=False;self._execute_bonus=0
    def begin_action(self,skill,target):
        self._action_key=skill.key;self._active_target=target
        self._critical_action=False;self._execute_bonus=0
        mark=next((e for e in self.get_effects() if isinstance(e,NextCritical)),None)
        if mark and getattr(skill,'deals_damage',hasattr(skill,'multiplier')):
            self._critical_action=True;self._execute_bonus=mark.power/100;self._effects.remove(mark)
    def after_action(self,target):self._critical_action=False;self._execute_bonus=0;self._active_target=None
    def damage_vs(self,victim):return 1+self._execute_bonus if victim.hp<=victim.max_hp*.25 else 1
    def get_crit(self):return super().get_crit()+(1 if getattr(self,'_critical_action',False) else 0)
    def state_data(self):return {}
    def to_dict(self):return {**super().to_dict(),**self.state_data()}


class Special(Skill):
    copyable=False
    def __init__(self,*a,action=None,score=None,available=None,**kw):
        super().__init__(*a,**kw);self.action=action;self.score=score;self.condition=available
    def is_available(self,user):return super().is_available(user) and (not self.condition or self.condition(user))
    def _perform(self,user,target):return self.action(user,target)
    def ai_score(self,user,target):return max(0,self.score(user,target) if self.score else 1)


class BloodFeast(DamageSkill):
    copyable=False
    def is_available(self,user):return super().is_available(user) and user.hp>1
    def pay(self,user):
        if user.hp<=1:raise ValueError('Для Пира крови нужно больше 1 HP')
        super().pay(user)
        paid=min(user.hp-1,max(1,math.ceil(user.hp*.15)))
        user.hp-=paid;user._events.append(f'🩸 Пир крови: {user.name} платит {paid} текущего HP.')
    def ai_score(self,user,target):
        return max(0,super().ai_score(user,target)-math.ceil(user.hp*.15))


class MarkStrike(DamageSkill):
    copyable=False
    def ai_score(self,user,target):
        from .ai import horizon
        e=marks(target,user);n=e.power if e else 0
        gain=1 if n<3 else .3 if min(e.expiries)<=target.turn_number+1 else 0
        turns=horizon(user,target,3)
        future=user.get_damage()*(.08+.04*(user.crit_multiplier-1))*turns
        future+=min(3,turns)+user.get_damage()*.2
        return super().ai_score(user,target)+gain*future*min(1,target.hp/max(1,user.get_damage()*3))
    def _after_hit(self,user,target,damage):return super()._after_hit(user,target,damage)+add_marks(user,target,1)


class VenomStrike(DamageSkill):
    copyable=False
    def ai_score(self,user,target):
        from .ai import effect_value
        e=marks(target,user);power=3+(e.power if e else 0)
        return super().ai_score(user,target)+min(1,user.hit_chance(self,target))*effect_value(user,target,Poison(3,power))
    def _after_hit(self,user,target,damage):
        e=marks(target,user);power=3+(e.power if e else 0)
        target.add_effect(scale_effect(Poison(3,power),user))
        return super()._after_hit(user,target,damage)+[f'☠ Ядовитое жало: сила яда {power}.']


class FixedStrike(DamageSkill):
    copyable=False
    def ai_score(self,user,target):
        from .ai import strike_value
        focus=user.focus if user.focus_target==target.id else 0
        mult=1.8 if focus else 1.5
        minimum=max(1,user.get_damage()*mult*.9*user.damage_multiplier()*user.damage_vs(target)-target.armor_total())
        unreliable=user.hit_chance(user.skills['attack'],target)<.72
        if target.hp>minimum and not unreliable:
            return 0  # A focused/control rotation is worth more than paying for redundant accuracy.
        charge=user.get_damage()*(.5 if user.cooldown_left('fang_grip')<=2 else .12) if focus else 0
        return strike_value(user,target,mult,fixed_hit=1)-charge
    def _perform(self,user,target):
        focus=user.focus if user.focus_target==target.id else 0
        old=(self.multiplier,self.fixed_hit)
        self.multiplier=1.8 if focus else 1.5;self.fixed_hit=1
        try:logs=super()._perform(user,target)
        finally:self.multiplier,self.fixed_hit=old
        if focus:user.focus-=1;logs.append('👁 Прищур расходует 1 Фокус.')
        return logs


class Cleave(DamageSkill):
    copyable=False
    def _perform(self,user,target):
        old=self.multiplier;self.multiplier=old*(1.25 if verdict(user,target) else 1)
        try:return super()._perform(user,target)
        finally:self.multiplier=old


class LionStrike(DamageSkill):
    copyable=False
    def _perform(self,user,target):
        old=(self.multiplier,self.hits)
        combo=getattr(user,'_combo_before',0)
        if self.key=='beast_king':self.multiplier=1.5*(1 if combo else .6)
        if self.key=='royal_will':self.multiplier=1.6 if combo==2 else 1.1
        if self.key=='pride_call':self.multiplier=1.05*(1.35 if target.hp<target.max_hp*.5 else 1)
        try:logs=super()._perform(user,target)
        finally:self.multiplier,self.hits=old
        if self.key=='royal_will' and combo==2:
            user.add_effect(NextCritical(3));logs.append('👑 Королевская воля: следующий удар станет критическим.')
        return logs
    def ai_score(self,user,target):
        value=super().ai_score(user,target)
        combo=user.combo if user.combo_target==target.id else 0
        if self.key=='beast_king':value*=1.35 if combo else .6
        if self.key=='royal_will':value*=1.8 if combo==2 else .7
        if self.key=='predator_instinct' and not combo:value+=3
        return value


def game(*a,**kw):
    from .rituals_55 import Ritual
    return Ritual(*a,**kw)


class Keltazar(NewHero):
    """Кельтазар, Повелитель страха: хрупкая проклятая плоть и управление вампиризмом."""
    resource_name='кровавая сила'
    hero_class,type_key,role='Повелитель страха','keltazar','light'
    HP,DAMAGE,ARMOR,SPEED=182,13.5,1,6
    INCOMING_MULT=1.18
    signature_skill='draining_grasp'
    PASSIVE_NOTES=(lambda c:f'«Проклятая плоть»: весь получаемый урон ×{c.INCOMING_MULT:g}',)
    def take_damage(self,amount,ignore_armor=False,attacker=None):
        # Multiply after armor, preserving the armor value and every effect hook.
        armor=0 if ignore_armor else self.armor_total()
        incoming=max(1,amount-armor)*self.INCOMING_MULT+armor
        return super().take_damage(incoming,ignore_armor,attacker)
    def take_dot_damage(self,amount):
        before=self.hp;self.hp-=max(1,round(amount*self.INCOMING_MULT));return before-self.hp
    def _create_skills(self):return [
        DamageSkill('attack','Иссушающий коготь','Вампиризм 10%',lifesteal=.1,icon='🩸'),
        DamageSkill('draining_grasp','Иссушающий захват','Вампиризм 45%',multiplier=1.3,lifesteal=.45,cost=15,icon='✋'),
        SelfBuffSkill('night_wings','Крылья ночи','+25% уклонения на 2 хода',effects=[lambda:DodgeBuff(2,25)],cost=20,cooldown=4,icon='🦇'),
        BloodFeast('blood_feast','Пир крови','Цена: 15% текущего HP; ×2, вампиризм 110%',multiplier=2,lifesteal=1.1,cooldown=5,icon='🩸'),
        game('fear','Страх','Случайная вспышка: реакция накладывает страх и иссушение на 2 хода',game='dread_flinch',cost=20,cooldown=4,icon='😨'),
        game('blood_game','Игра крови','Распределите силу между атакой и лечением; риск отката при атакующем перекосе',game='blood_split',cost=25,cooldown=4,icon='⚖'),
        game('blood_tide','Кровавый прилив','Чем ниже HP, тем быстрее и уже окно, но выше урон и вампиризм',game='blood_tide',cost=35,cooldown=7,icon='🌊')]


class Feliss(NewHero):
    """Фелисс: точный хищник с копьём. Подготовка слабых мест облегчает добивание."""
    resource_name='охотничий азарт'
    hero_class,type_key,role='Людоящер','feliss','light'
    HP,DAMAGE,ARMOR,SPEED,DODGE=188,13.2,2,8,.15
    CRIT_PER_WEAKPOINT=.04
    signature_skill='venom_sting'
    PASSIVE_NOTES=(lambda c:f'«Хладная кровь»: +{round(c.CRIT_PER_WEAKPOINT*100)}% крита за своё Слабое место на цели (до 3)',)
    def get_crit(self):
        target=getattr(self,'_combat_target',None) or getattr(self,'_active_target',None) or self.opponent
        e=marks(target,self) if target else None
        return super().get_crit()+(e.power*self.CRIT_PER_WEAKPOINT if e else 0)
    def _create_skills(self):return [
        DamageSkill('attack','Удар копьём','Точный выпад',icon='🔱'),
        MarkStrike('ranging','Пристрелка','×0.7, ставит 1 Слабое место на 3 хода цели',multiplier=.7,cost=12,cooldown=1,icon='🎯'),
        VenomStrike('venom_sting','Ядовитое жало','×1.1; яд 3 хода, сила 3 + число своих меток',multiplier=1.1,cost=18,cooldown=3,icon='☠'),
        game('prey_pulse','Пульс добычи','Удерживайте прицел на рывках пульса: 40/75/95% дают 1/2/3 метки; идеал — крит',game='prey_track',cost=18,cooldown=2,icon='💜'),
        game('scale_breach','Взлом чешуи','Тапами преодолейте контртолчки; метки ослабляют сопротивление и расходуются на удар',game='scale_pressure',cost=25,cooldown=4,icon='🔱'),
        game('opening_sting','Жало вскрытия','Метки расширяют идеальное окно и расходуются после удара',game='weakpoint_bar',cost=30,cooldown=6,icon='⚡')]


class Cyclops(NewHero):
    """Тилемах: плоть горы, один глаз и Фокус на выбранной цели."""
    resource_name='сила исполина'
    hero_class,type_key,role='Циклоп','cyclops','tank'
    HP,DAMAGE,ARMOR,SPEED,DODGE=228,11.5,6,3,.03
    BLIND_VULN=.5
    signature_skill='stone_grip'
    PASSIVE_NOTES=(lambda c:f'«Недремлющий взгляд»: ослепление действует на {round(c.BLIND_VULN*100)}% сильнее; Фокус до 4: +4% урона и +3% точности за заряд',)
    def _on_reset(self):super()._on_reset();self.focus=0;self.focus_target=None
    def begin_action(self,skill,target):
        super().begin_action(skill,target)
        if self.focus_target!=target.id:self.focus=0;self.focus_target=target.id
    def hit_chance(self,skill,victim):
        chance=super().hit_chance(skill,victim)
        extra=sum(e.accuracy_bonus() for e in self._effects if isinstance(e,Blinded))*self.BLIND_VULN
        return max(self.MIN_HIT,chance+extra+(.03*self.focus if self.focus_target==getattr(victim,"id",None) else 0))
    def damage_vs(self,victim):return 1+.04*self.focus if self.focus_target==getattr(victim,"id",None) else 1
    def state_data(self):return {'focus':self.focus,'focus_target_id':self.focus_target}
    def _create_skills(self):return [
        DamageSkill('attack','Удар кулака','Тяжёлый прямой удар',icon='👊'),
        DamageSkill('stone_grip','Каменная хватка','×1.3; 15% замедлить на 2 хода',multiplier=1.3,effect=lambda:Slow(2,2),effect_chance=.15,cost=15,icon='✊'),
        DamageSkill('heavy_step','Тяжёлая поступь','×1.1, замедление −2 скорости на 2 хода',multiplier=1.1,effect=lambda:Slow(2,2),cost=18,cooldown=3,icon='🦶'),
        SelfBuffSkill('mountain_guard','Горный щит','−25% входящего урона на 2 хода',effects=[lambda:DamageReduction(2,25)],cost=25,cooldown=5,icon='🛡'),
        FixedStrike('squint','Прищур','Гарантированное попадание ×1.5; расход 1 Фокуса даёт ×1.8',multiplier=1.5,fixed_hit=1,cost=20,cooldown=3,icon='👁'),
        DebuffSkill('mountain_roar','Рёв горы','−20% урона и −10% точности на 2 хода',effect=lambda:Dread(2,20),cost=22,cooldown=4,icon='📣'),
        game('watchful_eye','Недремлющее око','Нажимайте только при истинной вспышке, игнорируйте обманки; +1–2 Фокуса',game='watchful_nogo',cost=18,cooldown=2,icon='👁'),
        game('ram_horn','Рог тарана','Ритм ускоряется, окно сжимается; длинный стрик усиливает удар и оглушение',game='horn_streak',cost=22,cooldown=3,icon='🦏'),
        game('stone_flesh','Каменная плоть','Балансируйте под толчками: поглощение на 2 следующих прямых удара',game='stone_balance',cost=20,cooldown=4,icon='🪨'),
        game('fang_grip','Хватка клыков','Удерживайте дрейфующую цель; весь Фокус усиливает укус, вампиризм 30%',game='fang_drift',cost=30,cooldown=6,icon='🦷')]


class Mersey(NewHero):
    """Мерсей: исполнение приговора. Ошибка тяжёлого замаха ранит самого палача."""
    resource_name='неотвратимость'
    hero_class,type_key,role='Палач','mersey','warrior'
    HP,DAMAGE,ARMOR,SPEED,DODGE=205,15,3,4,.06
    DODGE_PIERCE=.35
    signature_skill='cleave'
    PASSIVE_NOTES=(lambda c:f'«Приговор не обжалуется»: игнорирует {round(c.DODGE_PIERCE*100)}% уклонения; Приговор готов через 3 хода цели',)
    def _create_skills(self):return [
        DamageSkill('attack','Взмах топора','Обычный тяжёлый удар',icon='🪓'),
        DamageSkill('shoulder_strike','Удар с плеча','×1.2',multiplier=1.2,cost=12,icon='🪓'),
        Special('judgment','Приговор','Отсчёт 3 хода цели; готовый усиливает Свершение',cost=18,cooldown=3,icon='⌛',
            action=lambda u,t:place_verdict(u,t),available=lambda u:not (getattr(u,'_combat_target',None) or u.opponent) or not verdict(u,getattr(u,'_combat_target',None) or u.opponent),
            score=lambda u,t:0 if verdict(u,t) else 15),
        DamageSkill('block','Плаха','Замедляет на 2 хода; 15% оглушить',multiplier=.5,effect=lambda:Slow(2,2),cost=20,cooldown=4,icon='🪵'),
        SelfBuffSkill('black_mass','Чёрная месса','+30% урона, −15% уклонения на 2 хода',effects=[lambda:Reckless(2,30)],cost=22,cooldown=5,icon='🕯'),
        SelfBuffSkill('cold_eyes','Холодные глаза','Иммунитет к оглушению на 1 ход',effects=[lambda:StunWard(1)],cost=15,cooldown=4,icon='👀'),
        Cleave('cleave','Рассечение','×1.8; ещё +25% урона, пока на цели ваш Приговор',multiplier=1.8,cost=25,cooldown=3,icon='🪓'),
        game('execution_swing','Замах палача','Отпустите тяжёлый топор в узком окне; ошибка ранит и может лишить хода',game='execution_charge',cost=22,cooldown=3,icon='🪓'),
        game('sentence_end','Свершение приговора','Удерживайте цель: готовый Приговор даёт крит сквозь броню; срыв ранит вас и тратит Приговор',game='sentence_hold',cost=30,cooldown=6,icon='⚖'),
        game('slit_gaze','Взгляд сквозь прорезь','Сокращает таймер следующей мини-игры врага и ослепляет',game='slit_gaze',cost=20,cooldown=4,icon='👁')]
    def on_hit_landed(self,target,skill):
        if skill.key=='block' and random.random()<.15:target.add_effect(Stun(1))
        return []


def place_verdict(user,target):
    if verdict(user,target):raise ValueError('Этот Приговор ещё не исполнен')
    target._effects.append(Judgment(user.id))
    return [Announcement(f'⌛ {user.name} выносит Приговор {target.name}: 3 хода цели.')]


class Leon(NewHero):
    """Леон: королевская уверенность и последовательные связки двух мечей."""
    resource_name='царская воля'
    hero_class,type_key,role='Зверолюд-лев','leon','warrior'
    HP,DAMAGE,ARMOR,SPEED,DODGE=195,13,2,7,.12
    CONF_DAMAGE,CONF_ACCURACY,CONF_CRIT=.06,.04,.04
    signature_skill='predator_instinct'
    PASSIVE_NOTES=(lambda c:f'«Уверенность» −2…+3: {round(c.CONF_DAMAGE*100)}% урона, {round(c.CONF_ACCURACY*100)}% точности и крита за ступень; растёт на порогах 75/50/25% HP врага, падает при проигрыше инициативы',)
    def _on_reset(self):
        super()._on_reset();self.confidence=0;self.combo=0;self.combo_last=None;self.combo_target=None;self._combo_before=0;self._thresholds=set()
    def on_initiative(self,first):
        if not first:self.confidence=max(-2,self.confidence-1)
    def on_skip(self):self.combo=0;self.combo_last=None
    def begin_action(self,skill,target):
        super().begin_action(skill,target)
        if self.combo_target!=target.id:self.combo=0;self.combo_last=None
        self.combo_target=target.id;self._combo_before=self.combo
    def after_action(self,target):
        key=self._action_key
        if key in ('predator_instinct','predator_ambush'):
            self.combo=2 if self.combo==1 and self.combo_last!=key else 1
            self.combo_last=key
        elif key=='beast_king':self.combo=2 if self._combo_before>=1 else 0;self.combo_last=key
        elif key=='king_roar' and self._combo_before:self.combo=self._combo_before
        else:self.combo=0;self.combo_last=None
        super().after_action(target)
    def on_hit_landed(self,target,skill):
        if getattr(target,'is_minion',False):return []
        for threshold in (.75,.5,.25):
            key=(target.id,threshold)
            if target.hp<=target.max_hp*threshold and key not in self._thresholds:
                self._thresholds.add(key);self.confidence=min(3,self.confidence+1)
        return []
    def damage_multiplier(self):return super().damage_multiplier()*(1+self.confidence*self.CONF_DAMAGE)
    def get_crit(self):return max(0,super().get_crit()+self.confidence*self.CONF_CRIT)
    def hit_chance(self,skill,victim):return max(self.MIN_HIT,super().hit_chance(skill,victim)+self.confidence*self.CONF_ACCURACY)
    def state_data(self):return {'confidence':self.confidence,'combo':self.combo,'combo_target_id':self.combo_target}
    def _create_skills(self):return [
        DamageSkill('attack','Удар мечей','Точный обычный удар',icon='⚔'),
        LionStrike('predator_instinct','Инстинкт хищника','×1.3; открывает связку левым мечом',multiplier=1.3,cost=18,cooldown=3,icon='🗡'),
        LionStrike('beast_king','Царь зверей','×1.5, пробивает 20% брони; без Комбо −40%; продолжает связку до 2',multiplier=1.5,armor_pierce=.2,cost=20,cooldown=3,icon='👑'),
        LionStrike('royal_will','Королевская воля','При Комбо 2: ×1.6 и следующий удар крит; иначе ×1.1',multiplier=1.1,cost=22,cooldown=5,icon='👑'),
        LionStrike('pride_call','Зов прайда','2 удара по ×1.05; +35% по цели ниже 50% HP',multiplier=1.05,hits=2,cost=28,cooldown=6,icon='🦁'),
        game('blade_fusion','Слияние клинков','Совместите две орбиты: Комбо 2 расходуется на усиленный двойной удар',game='blade_orbits',cost=24,cooldown=4,icon='⚔'),
        game('king_roar','Рык короля','Удерживайте до выбранного риска: сорванный голос ослабляет удар; сохраняет окно Комбо ещё на ход',game='king_risk',cost=22,cooldown=3,icon='🦁'),
        game('predator_ambush','Засада хищника','Попадите по исчезнувшему послеобразу; альтернативное открытие Комбо',game='predator_afterimage',cost=20,cooldown=3,icon='🐾'),
        game('composure','Невозмутимость','Читайте стойку: выбирайте открытую из трёх зон. 4 верных ответа — крит следующего удара и +25% по цели ниже 25% HP; 3 — крит',game='royal_read',cost=20,cooldown=4,icon='👑')]


# Getou and the controllable undead live separately to keep the legacy summon
# protocol intact. Registration is performed after both modules are loaded.
NEW_HEROES_55={c.type_key:c for c in (Keltazar,Feliss,Cyclops,Mersey,Leon)}
HERO_CLASSES.update(NEW_HEROES_55)
