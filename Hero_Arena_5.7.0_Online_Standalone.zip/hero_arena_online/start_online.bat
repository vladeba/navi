@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
if not exist ".venv-online\Scripts\python.exe" (
  py -3 -m venv .venv-online
  if errorlevel 1 python -m venv .venv-online
)
if not exist ".venv-online\Scripts\python.exe" (
  echo Установите Python 3.10 или новее с python.org и повторите запуск.
  pause
  exit /b 1
)
".venv-online\Scripts\python.exe" -m pip install -r requirements-online.txt
if errorlevel 1 (
  pause
  exit /b 1
)
".venv-online\Scripts\python.exe" run_online.py
pause
