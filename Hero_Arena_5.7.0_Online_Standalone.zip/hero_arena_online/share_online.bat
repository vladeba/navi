@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
if not exist ".venv-online\Scripts\python.exe" (
  echo Сначала запустите start_online.bat и оставьте его окно открытым.
  pause
  exit /b 1
)
".venv-online\Scripts\python.exe" share_online.py
pause
