"""Flask REST API «Арена героев». Запуск: python app.py → http://127.0.0.1:5000"""
from flask import Flask, jsonify, request, render_template, send_from_directory

import os

from services import GameService, NotFoundError, LockedError, BusyError

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
from version import APP_VERSION
app = Flask(__name__)
app.json.ensure_ascii = False  # русские буквы в JSON без \uXXXX
service = GameService(save_path=os.path.join(BASE_DIR, "data", "save.json"))
service.seed()

from services.online_api import online_blueprint
app.register_blueprint(online_blueprint())


def body():
    """JSON тела запроса (или 400, если тело не JSON)."""
    data = request.get_json(silent=True)
    if data is None or not isinstance(data, dict):
        raise ValueError("Тело запроса должно быть JSON-объектом")
    return data


# ---------- Обработка ошибок ----------
@app.errorhandler(ValueError)
def bad_request(e):
    return jsonify(error=str(e)), 400


@app.errorhandler(NotFoundError)
def not_found(e):
    return jsonify(error=str(e)), 404


@app.errorhandler(LockedError)
def locked(e):
    return jsonify(error=str(e)), 403


@app.errorhandler(PermissionError)
def forbidden(e):   # 4.3: seed и /api/simulate — только режим разработчика
    return jsonify(error=str(e)), 403


@app.errorhandler(BusyError)
def busy(e):
    return jsonify(error=str(e)), 409


@app.errorhandler(404)
def route_not_found(e):
    return jsonify(error="Маршрут не найден"), 404


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify(error="Метод не разрешён"), 405


# ---------- Главная страница ----------
@app.get("/")
def index():
    return render_template("index.html", app_version=APP_VERSION)


@app.get("/images/<hero_type>")
def hero_image(hero_type):
    """Портрет класса из static/images: сначала <type>.jpg (или .png), если нет — story/mobs, затем svg."""
    folder = os.path.join(app.static_folder, "images")
    for sub in ("", "story", "mobs"):
        base = os.path.join(folder, sub) if sub else folder
        for ext in ("jpg", "png", "svg"):
            filename = f"{hero_type}.{ext}"
            if os.path.exists(os.path.join(base, filename)):
                return send_from_directory(base, filename)
    return jsonify(error="Картинка не найдена"), 404


@app.get("/api")
def api_info():
    return jsonify(name=f"Hero Arena {APP_VERSION}", version=APP_VERSION,
                   resources=["/api/classes", "/api/heroes", "/api/items", "/api/players",
                              "/api/battles", "/api/leaderboard", "/api/simulate", "/api/shop", "/api/story"])


@app.get("/api/classes")
def list_classes():
    return jsonify(service.list_classes(request.args.get("player_id")))


@app.get("/api/classes/<hero_type>")
def class_info(hero_type):
    """4.4: карточка класса для окна героя: имя, лор, характеристики, пассивка, умения с цифрами."""
    return jsonify(service.class_card(hero_type))


@app.get("/api/leaderboard")
def leaderboard():
    return jsonify(service.leaderboard())


@app.get("/api/simulate")
def simulate():
    try:
        n = int(request.args.get("n", 100))
    except ValueError:
        raise ValueError("n должно быть числом")
    # 4.3: только режим разработчика (player_id с включённым dev_mode) или тесты; не больше 200 боёв за запрос
    if not service.can_simulate(request.args.get("player_id")):
        raise PermissionError("Симуляция доступна только в режиме разработчика")
    return jsonify(service.simulate(request.args.get("type1", ""), request.args.get("type2", ""), n))


@app.post("/api/save")
def save_state():
    return jsonify(message="Сохранено", **service.save())


@app.post("/api/load")
def load_state():
    return jsonify(message="Загружено", **service.load())


# ---------- Герои ----------
@app.get("/api/heroes")
def list_heroes():
    return jsonify([service.hero_view(h) for h in service.list_heroes(request.args.get("type"))])


@app.post("/api/heroes")
def create_hero():
    data = body()
    data.pop("npc", None)          # NPC арены создаёт только сервер
    data.pop("story", None)        # сюжетные герои — через /api/players/<id>/story_heroes
    return jsonify(service.hero_view(service.create_hero(data))), 201


@app.get("/api/heroes/<int:hero_id>/opponents")
def hero_opponents(hero_id):
    """Соперники арены с базовыми характеристиками."""
    return jsonify([service.hero_view(h) for h in service.opponents_for(hero_id)])


# ---------- 4.0: активный герой, чит разработчика, сюжет ----------
@app.post("/api/players/<int:player_id>/select_hero")
def select_hero(player_id):
    return jsonify(service.select_hero(player_id, int(body().get("hero_id", 0))))


@app.post("/api/players/<int:player_id>/dev_gold")
def dev_gold(player_id):
    """Тройной клик по логотипу «Хиро арена»: +99999 золота (для разработчика)."""
    return jsonify(service.dev_gold(player_id))


# ---------- 4.1: режим разработчика, активный бой игрока, облики аккаунта ----------
@app.post("/api/players/<int:player_id>/dev_mode")
def dev_mode(player_id):
    return jsonify(service.set_dev_mode(player_id, bool(body().get("on", True))))


@app.get("/api/players/<int:player_id>/active_battle")
def active_battle(player_id):
    return jsonify(service.active_battles_of_player(player_id))


@app.post("/api/players/<int:player_id>/buy_skin")
def buy_skin(player_id):
    # {"type": "musketeer", "skin": "navigator"} — облик покупается для аккаунта
    return jsonify(service.buy_skin(player_id, body()))



@app.get("/api/test_arena/roster")
def test_arena_roster():
    """5.2: список бойцов секретной арены (только dev_mode)."""
    player_id = request.args.get("player_id")
    if not player_id:
        raise ValueError("Нужен player_id")
    return jsonify(service.test_arena_roster(int(player_id)))


@app.post("/api/test_arena/battle")
def test_arena_battle():
    """5.2: тестовый бой без наград."""
    return jsonify(service.create_test_arena_battle(body()).to_dict()), 201

@app.get("/api/story")
def story_overview():
    hero_id = request.args.get("hero_id")
    return jsonify(service.story_overview(int(hero_id) if hero_id else None))


@app.post("/api/players/<int:player_id>/story_heroes")
def create_story_hero(player_id):
    return jsonify(service.create_story_hero(player_id, body()).to_dict()), 201


@app.post("/api/heroes/<int:hero_id>/story_secret")
def story_secret(hero_id):
    """5.0: открыть секретный сюжетный бой (пасхалка Рыбака)."""
    data = request.get_json(silent=True) or {}
    return jsonify(service.open_story_secret(hero_id, data))


@app.post("/api/heroes/<int:hero_id>/story_flags")
def story_flags(hero_id):
    """4.3: {"flag": "intro_seen", "value": true} — ролик/диалог показан (false — показать снова)."""
    return jsonify(service.set_story_flag(hero_id, body()))



@app.get("/api/heroes/<int:hero_id>/story_bag")
def story_bag_get(hero_id):
    return jsonify(service.story_bag_info(hero_id))


@app.post("/api/heroes/<int:hero_id>/story_bag/discard")
def story_bag_discard(hero_id):
    return jsonify(service.discard_story_item(hero_id, body()))


@app.post("/api/heroes/<int:hero_id>/story_bag/claim")
def story_bag_claim(hero_id):
    return jsonify(service.claim_pending_story_loot(hero_id, body()))

@app.post("/api/heroes/<int:hero_id>/story_battle")
def story_battle(hero_id):
    return jsonify(service.story_battle(hero_id, body()).to_dict()), 201



@app.get("/api/heroes/<int:hero_id>")
def get_hero(hero_id):
    return jsonify(service.hero_view(service.get_hero(hero_id)))


@app.put("/api/heroes/<int:hero_id>")
def put_hero(hero_id):
    return jsonify(service.hero_view(service.update_hero(hero_id, body(), full=True)))


@app.patch("/api/heroes/<int:hero_id>")
def patch_hero(hero_id):
    return jsonify(service.hero_view(service.update_hero(hero_id, body(), full=False)))


@app.delete("/api/heroes/<int:hero_id>")
def delete_hero(hero_id):
    hero = service.delete_hero(hero_id)
    return jsonify(message=f"Герой {hero.name} удалён")


# ---------- Магазин 3.3: расходники и облики (только для СВОИХ героев игрока) ----------
@app.get("/api/shop")
def shop_catalog():
    data = service.shop_catalog()
    pid = request.args.get("player_id", type=int)
    if pid is not None:                       # 4.1: отметки «куплено» для аккаунта
        player = service.get_player(pid)
        for t, lst in data["skins"].items():
            for s in lst:
                s["owned"] = player.owns_skin(t, s["skin"])
    return jsonify(data)


@app.post("/api/heroes/<int:hero_id>/shop")
def shop_buy(hero_id):
    # {"player_id": 1, "item": "kunai" | "heal_potion" | "energy_potion" | "bomb" | "skin:gold"}
    return jsonify(service.shop_buy(hero_id, body()))



@app.post("/api/players/<int:player_id>/story/new_game")
def story_new_game(player_id):
    """5.2: архивировать пройденного героя и начать сюжет заново."""
    return jsonify(service.new_story_game(player_id, body()))


@app.post("/api/players/<int:player_id>/story/abandon")
def story_abandon(player_id):
    """5.2: сменить персонажа — удалить текущего сюжетного героя без архива."""
    return jsonify(service.abandon_story_hero(player_id, body()))


@app.put("/api/heroes/<int:hero_id>/random_skin")
def random_skin_toggle(hero_id):
    """5.2: вкл/выкл случайный скин. {"player_id":1,"random_skin":true}"""
    return jsonify(service.hero_view(service.set_random_skin(hero_id, body())))

@app.put("/api/heroes/<int:hero_id>/skin")
def equip_skin(hero_id):
    # {"player_id": 1, "skin": "gold" | "blood" | "frost" | null}
    return jsonify(service.hero_view(service.equip_skin(hero_id, body())))


@app.post("/api/heroes/<int:hero_id>/attack")
def hero_attack(hero_id):
    data = body()
    if "target_id" not in data:
        raise ValueError("Нужно поле target_id")
    # action: "attack", "skill" (главное умение) или ключ умения, например "heavy_strike"
    result = service.hero_action(hero_id, int(data["target_id"]), data.get("action", "attack"))
    return jsonify(result=result, target=service.hero_view(service.get_hero(int(data["target_id"]))))


@app.post("/api/heroes/<int:hero_id>/heal")
def hero_heal(hero_id):
    hero = service.get_hero(hero_id)
    hero.reset()
    return jsonify(service.hero_view(hero))


@app.post("/api/heroes/<int:hero_id>/items")
def give_item(hero_id):
    data = body()
    if "item_id" not in data:
        raise ValueError("Нужно поле item_id")
    return jsonify(service.hero_view(service.give_item(hero_id, int(data["item_id"]))))


@app.post("/api/heroes/<int:hero_id>/use/<int:item_id>")
def use_item(hero_id, item_id):
    result = service.use_item(hero_id, item_id)
    return jsonify(result=result, hero=service.hero_view(service.get_hero(hero_id)))


# ---------- Предметы ----------
@app.get("/api/items")
def list_items():
    return jsonify([i.to_dict() for i in service.list_items()])


@app.post("/api/items")
def create_item():
    return jsonify(service.create_item(body()).to_dict()), 201


@app.get("/api/items/<int:item_id>")
def get_item(item_id):
    return jsonify(service.get_item(item_id).to_dict())


@app.put("/api/items/<int:item_id>")
def put_item(item_id):
    return jsonify(service.update_item(item_id, body()).to_dict())


@app.delete("/api/items/<int:item_id>")
def delete_item(item_id):
    item = service.delete_item(item_id)
    return jsonify(message=f"Предмет {item.name} удалён")


# ---------- Игроки ----------
@app.get("/api/players")
def list_players():
    return jsonify([p.to_dict() for p in service.list_players()])


@app.post("/api/players")
def create_player():
    return jsonify(service.create_player(body()).to_dict()), 201


@app.get("/api/players/<int:player_id>")
def get_player(player_id):
    return jsonify(service.get_player(player_id).to_dict())


@app.put("/api/players/<int:player_id>")
def put_player(player_id):
    return jsonify(service.update_player(player_id, body()).to_dict())


@app.delete("/api/players/<int:player_id>")
def delete_player(player_id):
    p = service.delete_player(player_id)
    return jsonify(message=f"Игрок {p.username} удалён")


@app.post("/api/login")
def login():
    data = body()
    p = service.login(data.get("username"), data.get("password"))
    return jsonify(message="Вход выполнен", player=p.to_dict())


@app.post("/api/players/<int:player_id>/buy")
def buy(player_id):
    data = body()
    if "hero_id" not in data or "item_id" not in data:
        raise ValueError("Нужны поля hero_id и item_id")
    p = service.buy_item(player_id, int(data["hero_id"]), int(data["item_id"]))
    return jsonify(message="Покупка успешна", player=p.to_dict())


# ---------- Бои ----------
@app.get("/api/battles")
def list_battles():
    # ?status=active — незаконченные бои (интерфейс восстанавливает их после перезагрузки)
    return jsonify([b.to_dict() for b in service.list_battles(request.args.get("status"))])


@app.post("/api/battles")
def create_battle():
    battle = service.create_battle(body())
    return jsonify(closed_battles=battle.closed_battles, **battle.to_dict()), 201


@app.post("/api/battles/<int:battle_id>/turn")
def battle_turn(battle_id):
    data = request.get_json(silent=True) or {}
    return jsonify(service.play_turn(battle_id, data).to_dict())


@app.post("/api/battles/<int:battle_id>/react")
def battle_react(battle_id):
    """Ответ на реакцию (choice: left/right/down, 0–5) или результат мини-игры (choice: объект)."""
    return jsonify(service.react(battle_id, body()).to_dict())


@app.post("/api/battles/<int:battle_id>/surrender")
def battle_surrender(battle_id):
    data = request.get_json(silent=True) or {}
    return jsonify(service.surrender(battle_id, data).to_dict())


@app.post("/api/battles/<int:battle_id>/secret")
def battle_secret(battle_id):
    """Секрет: клик по «VS» в бою. После окончания боя открывается Совух."""
    return jsonify(service.find_secret(battle_id, request.get_json(silent=True) or {}).to_dict())


@app.post("/api/battles/<int:battle_id>/cancel")
def battle_cancel(battle_id):
    return jsonify(service.cancel_battle(battle_id).to_dict())


@app.post("/api/battles/<int:battle_id>/kill")
def battle_kill(battle_id):
    """5.0: режим разработчика — убить соперника."""
    data = request.get_json(silent=True) or {}
    return jsonify(service.kill_opponent(battle_id, data).to_dict())


@app.get("/api/battles/<int:battle_id>")
def get_battle(battle_id):
    return jsonify(service.get_battle(battle_id).to_dict())


@app.delete("/api/battles/<int:battle_id>")
def delete_battle(battle_id):
    service.delete_battle(battle_id)
    return jsonify(message=f"Бой {battle_id} удалён")


if __name__ == "__main__":
    print("Арена героев запущена: http://127.0.0.1:5000")
    app.run(debug=True)
