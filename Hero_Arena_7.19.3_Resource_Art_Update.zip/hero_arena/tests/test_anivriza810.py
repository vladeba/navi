import unittest
from models import HERO_CLASSES
from services.game_service import GameService
class AnivrizaTests(unittest.TestCase):
 def setUp(self):self.h=HERO_CLASSES['anivriza']('Анивриза');self.t=HERO_CLASSES['warrior']('Цель')
 def test_flight_refreshes_but_never_stacks(self):
  h=self.h;base=h.get_dodge();h.note_attack(True);h.note_attack(True);self.assertAlmostEqual(h.get_dodge(),base+.35)
  h.note_attack(False);self.assertAlmostEqual(h.get_dodge(),base+.35)
  h.on_opponent_action_finished(self.t);self.assertAlmostEqual(h.get_dodge(),base)
 def test_kit_and_skins(self):
  self.assertEqual(len(self.h.skills),7);self.assertEqual(sum(bool(s.reaction) for s in self.h.skills.values()),3)
  self.assertEqual(self.h.to_dict()['roles'],['trickster','light'])
  self.assertEqual(len(GameService.skin_catalog('anivriza')),15)
 def test_route_and_reject_illegal_jump(self):
  s=self.h.skills['route'];o=s.game_params(self.h,self.t);o.update(time_limit_ms=14000,blocked=[7,17])
  cells=[15,10,11,12,13,14,9,4]
  c=dict(elapsed_ms=3000,actions=[dict(ms=700+i*200,cell=v) for i,v in enumerate(cells)])
  self.assertEqual(s.tier_from(c,o),0)
  c['actions']=[dict(ms=700,cell=4)];self.assertEqual(s.tier_from(c,o),3)
 def test_wind_requires_compensation(self):
  from solutions920 import winning920
  s=self.h.skills['dive'];o=s.public_options(self.h,self.t)
  self.assertEqual(s.tier_from(winning920(s,o),o),0)
  self.assertNotEqual(s.tier_from({'elapsed_ms':o['time_limit_ms']-1},o),0)
 def test_feathers_follow_sample(self):
  s=self.h.skills['feathers'];o=s.game_params(self.h,self.t);o['time_limit_ms']=14000
  indexes=[o['feathers'].index(v) for v in o['wanted']]
  c=dict(elapsed_ms=2200,actions=[dict(ms=700+i*400,feather=v) for i,v in enumerate(indexes)])
  self.assertEqual(s.tier_from(c,o),0)
