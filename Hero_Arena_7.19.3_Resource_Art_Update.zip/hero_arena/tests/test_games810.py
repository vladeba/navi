import unittest,json,math,time
from models import HERO_CLASSES
from models.games810 import Puzzle
from solutions810 import winning810,winning_legacy

class Games810(unittest.TestCase):
 def kits(self):
  for key in ('atlargas','frida','plutarch','yaisha','dindau','connie'):
   h=HERO_CLASSES[key](key);yield h,list(h.skills.values())
   if key=='plutarch':h.side='black';h._rebuild();yield h,list(h.skills.values())
   if key=='connie':
    for kind in ('rabbit','bear'):
     h.plush=None;h.recall=0;h.summon_toy(kind);yield h,list(h.skills.values())
 def test_all_31_new_interactions_reachable_and_no_claimed_scores(self):
  t=HERO_CLASSES['warrior']('target');count=0
  for h,kit in self.kits():
   for s in kit:
    if not s.reaction:continue
    count+=1
    for _ in range(3):
     with self.subTest(hero=h.type_key,skill=s.key):
      o=s.public_options(h,t);json.dumps(o,allow_nan=False);self.assertEqual(s.tier_from(winning810(s,o),o),0)
      self.assertNotEqual(s.tier_from(dict(elapsed_ms=o['time_limit_ms']-1,score=999,hits=999),o),0)
  self.assertEqual(count,31)
 def test_remaining_legacy_replacements_have_reachable_solutions(self):
  t=HERO_CLASSES['warrior']('target');count=0
  for key in ('tauhand','vervelt','gormadont','jotunlok','gordonos','ksair','buattila','afill'):
   h=HERO_CLASSES[key](key)
   for s in h.skills.values():
    if getattr(s,'game',None)!='legacy810':continue
    count+=1
    for _ in range(3):
     with self.subTest(hero=key,skill=s.key):
      o=s.public_options(h,t);self.assertEqual(s.tier_from(winning_legacy(s,o),o),0)
      self.assertEqual(s.tier_from(dict(elapsed_ms=o['time_limit_ms']-1,score=999),o),3)
  self.assertEqual(count,9)
 def test_reflection_uses_physical_tangent_not_opposite_ray(self):
  h=HERO_CLASSES['afill']('a');s=h.skills['parry'];o=s.public_options(h,HERO_CLASSES['warrior']('t'));o['goal']=math.pi
  # A vertical shield reflects an incoming horizontal blade back to the left.
  c=dict(elapsed_ms=3000,actions=[dict(ms=1000,x=180,y=200)])
  self.assertEqual(s.tier_from(c,o),0)
 def test_future_input_does_not_gain_a_reward(self):
  h=HERO_CLASSES['frida']('f');t=HERO_CLASSES['warrior']('t');s=h.skills['spear'];o=s.public_options(h,t);c=winning810(s,o)
  c['elapsed_ms']=10;c['actions'][0]['ms']=5000
  before=t.hp;s.resolve(h,t,c,dict(options=o,started=time.time(),deadline=time.time()+20));self.assertEqual(t.hp,before)

 def test_copied_reworked_game_uses_its_own_timer(self):
  h=HERO_CLASSES['afill']('a');s=h.skills['parry'];clone=s.copy_for('Монах');clone._time_multiplier=.7
  monk=HERO_CLASSES['monk']('m');t=HERO_CLASSES['warrior']('t');o=clone.public_options(monk,t)
  self.assertEqual(o['time_limit_ms'],12600);self.assertAlmostEqual(o['factor'],.7);self.assertEqual(s.public_options(h,t)['time_limit_ms'],round(18000*.62))

 def test_pipe_layout_never_starts_already_solved(self):
  from types import SimpleNamespace
  from unittest.mock import patch
  seq=iter([0,2,1,3]);stub=SimpleNamespace(uniform=lambda *args:0,randrange=lambda *args:next(seq))
  h=HERO_CLASSES['atlargas']('a');t=HERO_CLASSES['warrior']('t');s=h.skills['current']
  with patch('models.games810.random',stub):o=s.public_options(h,t)
  self.assertNotEqual(o['turns'],o['solution']);self.assertEqual(s.tier_from(winning810(s,o),o),0)

 def test_spear_requires_a_real_pull_from_the_weapon(self):
  h=HERO_CLASSES['frida']('f');s=h.skills['spear'];o=s.public_options(h,HERO_CLASSES['warrior']('t'));c=winning810(s,o)
  self.assertEqual(s.tier_from(c,o),0);c['actions']=[];self.assertNotEqual(s.tier_from(c,o),0)
