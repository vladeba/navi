import unittest
from models import HERO_CLASSES
from services.game_service import GameService

class HybridRoles(unittest.TestCase):
 def test_class_and_character_roles_are_consistent(self):
  expected={'keltazar':['light','trickster'],'aarakocra':['light','trickster'],'beastlord':['tank','warrior'], 'feliss':['light','trickster'], 'catfolk':['trickster','warrior'], 'croc':['tank','warrior'], 'darkknight':['warrior','tank'], 'bluetroll':['trickster','light'], 'gambler':['trickster','light'], 'spiderqueen':['trickster','light'], 'shade':['light','trickster'], 'vervelt':['warrior','tank'], 'jotunlok':['tank','warrior'], 'tauhand':['tank'], 'gormadont':['tank'], 'paladin':['tank'], 'gnoll':['trickster']}
  service=GameService()
  for key,roles in expected.items():
   with self.subTest(hero=key):
    hero=HERO_CLASSES[key]('Проверка');original=hero.role
    self.assertEqual(hero.to_dict()['roles'],roles)
    self.assertEqual(hero.to_dict()['role'],roles[0])
    self.assertEqual(service.class_card(key)['roles'],roles)
    self.assertEqual(service.class_card(key)['role'],roles[0])
    self.assertEqual(hero.role,original)
  for key,cls in HERO_CLASSES.items():
   data=cls('Проверка').to_dict()
   self.assertIn(data['role'],data['roles'])

 def test_battle_shows_first_role_without_changing_character(self):
  from models import Battle
  for key in ('keltazar','aarakocra','beastlord','feliss','catfolk','croc','darkknight','bluetroll','gambler','spiderqueen','shade','vervelt','jotunlok','tauhand','gormadont','paladin','gnoll'):
   with self.subTest(hero=key):
    hero=HERO_CLASSES[key]('Проверка');enemy=HERO_CLASSES['warrior']('Враг')
    expected=hero.to_dict()['roles'];original_role=hero.role
    battle=Battle(hero,enemy,mode='manual');battle.start()
    view=battle.to_dict()['heroes'][0]
    self.assertEqual(view['role'],expected[0]);self.assertEqual(view['role_name'],hero.ROLE_NAMES[expected[0]])
    self.assertEqual(view['roles'],expected);self.assertEqual(hero.role,original_role)
    self.assertEqual(hero.lobby_dict()['roles'],expected)
