import unittest
from models import HERO_CLASSES
from models.gormadont780 import Shell,Exposed
class TurtleTest(unittest.TestCase):
 def setUp(self):self.h=HERO_CLASSES['gormadont']('Гормадонт');self.t=HERO_CLASSES['warrior']('Цель')
 def test_seven_skills(self):
  self.assertEqual(len(self.h.skills),7);self.assertEqual(sum(bool(s.reaction) for s in self.h.skills.values()),3)
 def test_shell_then_exposure(self):
  h=self.h;h.skills['shell']._perform(h,self.t);before=h.hp;h.take_damage(100,True,self.t);self.assertEqual(before-h.hp,10)
  h.start_turn();self.assertTrue(h.has_effect(Exposed));self.assertFalse(h.has_effect(Shell));self.assertFalse(h.skills['shell'].is_available(h));self.assertEqual(h.armor_total(),2)
  before=h.hp;h.take_damage(100,True,self.t);self.assertEqual(before-h.hp,135)
  h.start_turn();self.assertFalse(h.has_effect(Exposed))
 def test_shell_reduces_periodic_damage(self):
  from models.effects import Burn
  h=self.h;h.skills['shell']._perform(h,self.t);before=h.hp;Burn(2,100).on_turn_start(h);self.assertEqual(before-h.hp,10)
 def test_games_need_actual_input(self):
  for key in ('runes','tide','roll'):
   s=self.h.skills[key];o=s.public_options(self.h,self.t);self.assertNotEqual(s.tier_from({'elapsed_ms':o['time_limit_ms']-1},o),0)
 def test_maze_reachable(self):
  from collections import deque
  s=self.h.skills['roll'];o=s.public_options(self.h,self.t);q=deque([(0,[])]);seen=set()
  while q:
   cell,path=q.popleft()
   if cell in seen:continue
   seen.add(cell)
   if cell==15:break
   for d,(dx,dy) in {'up':(0,-1),'down':(0,1),'left':(-1,0),'right':(1,0)}.items():
    x,y=cell%4+dx,cell//4+dy
    if 0<=x<4 and 0<=y<4 and y*4+x not in o['walls']:q.append((y*4+x,path+[d]))
  self.assertEqual(cell,15);c={'elapsed_ms':o['time_limit_ms']-1,'actions':[{'ms':o['prepare_ms']+200+i*250,'dir':d} for i,d in enumerate(path)]};self.assertEqual(s.tier_from(c,o),0)
