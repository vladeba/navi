"""User decisions: effects, migration boundaries, pair isolation and physical input."""
import unittest,sys,math,random
from unittest.mock import patch
from models import HERO_CLASSES,Battle,Character
from models.effects import Shield,Stun,Antiheal
from models.review_600 import PAIR_RULES,ColdEyes

def hero(k):
 h=HERO_CLASSES[k](k);h.configure_arena();h.reset();return h

class SoloReview600(unittest.TestCase):
 def test_final_arena_hp_contract(self):
  values={'keltazar': 185, 'feliss': 183, 'cyclops': 289, 'mersey': 246, 'leon': 235, 'getou': 174, 'warrior': 245, 'mage': 181, 'archer': 212, 'ogre': 294, 'spartan': 255, 'assassin': 170, 'samurai': 225, 'druid': 198, 'monk': 240, 'darkelf': 185, 'owlbeast': 287, 'musketeer': 210, 'pagan': 238, 'minotaur': 276, 'croc': 298, 'darkknight': 255, 'goblin': 165, 'satyr': 162, 'ghoul': 179, 'rhino': 307, 'bogatyr': 284, 'orc': 256, 'dwarf': 255, 'lightelf': 197, 'shade': 190, 'aarakocra': 192, 'hunter': 240, 'gnoll': 186, 'centaur': 207, 'bluetroll': 180, 'paladin': 280, 'catfolk': 174, 'beastlord': 315, 'spiderqueen': 160, 'ranger': 199, 'pandaren': 262, 'gambler': 165}
  for k,v in values.items():self.assertEqual(hero(k).max_hp,v,k)
 def test_pairs_are_applied_once_and_cleanly_reset(self):
  for (a,b),rule in PAIR_RULES.items():
   h,t=hero(a),hero(b);base_hp=h.max_hp;base_armor=h.armor
   game=Battle(h,t,mode='manual');game.start()
   self.assertEqual(h.max_hp,base_hp+rule.get('hp',0),(a,b))
   self.assertAlmostEqual(h.armor,base_armor+rule.get('armor',0))
   for _ in range(3):h.configure_arena();h.reset()
   self.assertEqual(h.max_hp,base_hp);self.assertAlmostEqual(h.armor,base_armor)
 def test_pair_disabled_control(self):
  import models.review_600 as r
  with patch.object(r,'PAIR_RULES_ENABLED',False):
   h,t=hero('ogre'),hero('pagan');base=h.max_hp;game=Battle(h,t,mode='manual');game.start();self.assertEqual(h.max_hp,base)
 def test_fractional_armor_conserves_average_damage(self):
  a=Character('a',max_hp=1000,armor=2.7)
  for _ in range(10):a.take_damage(10)
  self.assertEqual(a.hp,927)
 def test_cold_eyes_heals_once_per_use(self):
  h=hero('mersey');h.hp=100;h.skills['cold_eyes']._perform(h,hero('warrior'))
  self.assertFalse(h.add_effect(Stun(1)));self.assertEqual(h.hp,117)
  self.assertFalse(h.add_effect(Stun(1)));self.assertEqual(h.hp,117)
 def test_cold_eyes_antihheal_is_respected(self):
  h=hero('mersey');h.hp=100;h.add_effect(Antiheal(2));h.add_effect(ColdEyes());h.add_effect(Stun(1));self.assertEqual(h.hp,100)
 def test_druid_can_resummon_any_dead_species(self):
  from models.summons import BEASTS
  for cls in BEASTS:
   h=hero('druid');h.summon=cls(h);h.hp=50;h.summon.hp=0
   self.assertTrue(h.skills['summon_beast'].is_available(h),cls.__name__)
 def test_druid_departure_is_fixed_and_once(self):
  from models.summons import BEASTS
  expected={'Hamster':8,'Snake':9,'Falcon':10,'Deer':13,'Bear':16}
  for cls in BEASTS:
   h=hero('druid');h.hp=50;s=cls(h);s.hp=0;self.assertEqual(h.hp,50+expected[cls.__name__]);h.on_summon_death(s);self.assertEqual(h.hp,50+expected[cls.__name__])
 def test_all_katana_chances_sum_to_100(self):
  from models.item import OrdinaryKatana,Yoshirin,Kyocherin,Masamune
  self.assertEqual([c.chance for c in (OrdinaryKatana,Yoshirin,Kyocherin,Masamune)],[35.5,27.5,27.5,9.5])
 def test_cat_forms_never_create_health(self):
  h=hero('catfolk');h.hp=80;before=h.hp/h.max_hp
  for _ in range(20):h.set_form(True);self.assertEqual(h.max_hp,214);h.set_form(False)
  self.assertLessEqual(h.hp/h.max_hp,before);self.assertEqual(h.max_hp,174)
 def test_rider_buff_does_not_change_kodo(self):
  h=hero('beastlord');self.assertEqual((h.kodo_hp,h.rider_hp,h.max_hp),(200,115,315))
 def test_cards_heal_twenty_and_have_new_prices(self):
  h=hero('gambler');h.hp=50;h.skills['green_card']._perform(h,hero('warrior'));self.assertEqual(h.hp,70);self.assertEqual(h.skills['guard_card'].cost,24);self.assertEqual(h.skills['bluff_card'].cost,18)
 def test_bluff_failure_still_rewards(self):
  h=hero('gambler');h.skills['bluff_card'].apply(h,hero('warrior'),3,None);self.assertGreater(h.get_dodge(),h.dodge)
 def test_spear_loss_blocks_both_skills(self):
  h=hero('spartan');h.spear_lost=True
  for k in ('spear_throw','spear_challenge'):self.assertFalse(h.skill_unlocked(h.skills[k]))
 def test_monk_sequence_is_marked_and_rated(self):
  h=hero('monk');s=next(s for s in h.to_dict()['skills'] if s['key']=='weakness');self.assertTrue(s['is_minigame']);self.assertIn('difficulty_label',s)
 def test_roots_replay_success_and_failure(self):
  h=hero('druid');s=h.skills['root_chains'];t=hero('warrior');o=s.public_options(h,t);c={'elapsed_ms':2500,'placements':[]}
  for i,(a,b) in enumerate(zip(o['sources'],o['targets'])):c['placements'].append(dict(part=i,down_ms=700+500*i,up_ms=1000+500*i,x0=a[0],y0=a[1],x1=b[0],y1=b[1]))
  self.assertEqual(s.tier_from(c,o),0);self.assertEqual(s.tier_from({'elapsed_ms':2500},o),3)
 def test_hp_target_and_prices(self):
  self.assertEqual(hero('centaur').skills['harp_shot'].cost,20)
  self.assertEqual(hero('ranger').skills['quick_shots'].multiplier,.6)
  self.assertEqual(hero('mersey').skills['cold_eyes'].effects[0]().duration,2)
  self.assertNotIn('shoulder_strike',hero('mersey').skills)
 def test_musket_coefficients(self):
  h=hero('musketeer');self.assertEqual(h.max_energy,70);self.assertEqual(h.skills['musket_shot'].cost,15);self.assertEqual(h.skills['musket_shot'].multiplier,2.0);self.assertEqual(h.skills['musket_shot'].armor_pierce,.4)
 def test_hunter_five_traps_and_per_hit_heal(self):
  h,t=hero('hunter'),hero('warrior');s=h.skills['traps'];o=s.public_options(h,t);self.assertEqual(len(o['waves']),5)
  c={'elapsed_ms':o['time_limit_ms'],'actions':[dict(ms=e['ms'],lane=e['lane']) for e in o['waves']]};self.assertEqual(s.tier_from(c,o),0)
  h.hp=100;s.apply(h,t,0,s.result_data(c,o));self.assertEqual(h.hp,115)
 def test_owl_is_a_regular_creatable_class(self):
  self.assertTrue(HERO_CLASSES['owlbeast'].creatable);self.assertFalse(HERO_CLASSES['owlbeast'].secret)
 def test_saving_a_pair_does_not_persist_bonus_armor(self):
  import tempfile
  from services import GameService
  from pathlib import Path
  with tempfile.TemporaryDirectory() as folder:
   g=GameService(save_path=str(Path(folder)/'save.json'));h,t=hero('minotaur'),hero('goblin');base=h.armor;g._heroes={h.id:h,t.id:t}
   Battle(h,t,mode='manual').start();self.assertAlmostEqual(h.armor,base+.7);g.save();g.load();self.assertAlmostEqual(g.get_hero(h.id).armor,base)
 def test_owl_is_available_in_creation_and_arena_from_start(self):
  from services import GameService
  g=GameService();g.seed(include_player=False)
  self.assertIn('owlbeast',{x['type'] for x in g.list_classes()})
  npc=next(x for x in g._heroes.values() if x.type_key=='owlbeast' and x.npc)
  self.assertTrue(npc.protected)
  p=g.create_player({'username':'owl-test','password':'testing'})
  own=g.create_hero({'type':'warrior','name':'Проверочный герой','player_id':p.id})
  self.assertIn(npc,g.opponents_for(own.id))
  created=g.create_hero({'type':'owlbeast','name':'Совух игрока','player_id':p.id})
  self.assertEqual(created.type_key,'owlbeast')
 def test_all_monk_full_damage_paths_agree(self):
  h=hero('monk');self.assertEqual(h.skills['weakness'].FULL,2.5)
 def test_rhino_actual_stun_field_is_updated(self):
  h=hero('rhino');self.assertEqual(h.skills['ram'].stun_chance,.38)
 def test_orc_new_games_use_the_same_lifesteal_as_regular_attacks(self):
  from models.heroes_42 import WarCry
  h,t=hero('orc'),hero('warrior');s=h.skills['axe_throw']
  for powered,expected in [(False,7),(True,16)]:
   h.hp=50;h._effects=[]
   if powered:h.add_effect(WarCry(3,20))
   with patch.object(s,'strike',return_value=([],100)):
    s.apply(h,t,0,None)
   self.assertEqual(h.hp,50+expected)
 def test_spirit_arrow_fixed_poison_is_scored_as_fixed(self):
  from models.ai import effect_value
  h,t=hero('centaur'),hero('warrior');effect=h.skills['spirit_arrow'].effect()
  self.assertFalse(effect.grows)
  before=t.hp
  for _ in range(4):effect.on_turn_start(t)
  self.assertEqual(before-t.hp,16)

 def test_annisa_extra_window_recovers_a_missed_window(self):
  h,t=hero('catfolk'),hero('warrior');s=h.skills['pounce'];o=s.public_options(h,t)
  self.assertEqual(o['time_limit_ms'],6400);self.assertEqual(len(o['safe']),4)
  holds=[dict(down_ms=a+15,up_ms=b-15) for a,b in o['safe'][1:]]
  self.assertEqual(s.tier_from(dict(elapsed_ms=o['safe'][-1][1]+30,holds=holds),o),0)
 def test_actual_extended_game_limits(self):
  for k,key,ms in [('catfolk','pounce',6400),('darkknight','plague',10200),('satyr','dance',6500)]:
   h=hero(k);self.assertEqual(h.skills[key].public_options(h,hero('warrior'))['time_limit_ms'],ms)
