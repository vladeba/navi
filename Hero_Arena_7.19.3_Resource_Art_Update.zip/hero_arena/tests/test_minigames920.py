import json,unittest
from models import HERO_CLASSES
from models.minigames920 import PACK
from solutions920 import winning920

class MiniGames920(unittest.TestCase):
    def test_all_twenty_are_registered_reachable_and_server_scored(self):
        target=HERO_CLASSES['warrior']('target')
        self.assertEqual(len(PACK),20)
        for (hero,key),(mode,_) in PACK.items():
            h=HERO_CLASSES[hero]('player')
            if hero=='plutarch' and key in ('dash','joke'):
                h.side='black';h._rebuild()
            if hero=='connie':h.summon_toy('bear')
            with self.subTest(hero=hero,skill=key):
                skill=h.skills[key];self.assertEqual(skill.game,'minigames920')
                o=skill.public_options(h,target);json.dumps(o,allow_nan=False)
                choice=winning920(skill,o)
                self.assertEqual(skill.tier_from(choice,o),0)
                forged=dict(elapsed_ms=o['time_limit_ms']-1,score=999,hits=999)
                self.assertNotEqual(skill.tier_from(forged,o),0)

    def test_pack_timers_are_shortened(self):
        target=HERO_CLASSES['warrior']('target')
        for hero,key in PACK:
            h=HERO_CLASSES[hero]('player')
            if hero=='plutarch' and key in ('dash','joke'):
                h.side='black';h._rebuild()
            if hero=='connie':h.summon_toy('bear')
            with self.subTest(hero=hero,key=key):
                skill=h.skills[key]
                self.assertLess(skill.public_options(h,target)['time_limit_ms'],skill.TIME_LIMIT_MS)
