"""Winning physical input sequences for the lore-specific minigames."""
import itertools

def winning920(skill, o):
    mode=o['mode']; p=o['prepare_ms']; a=[]
    c={'elapsed_ms':p+1800,'actions':a}
    def add(**v): a.append({'ms':p+100+len(a)*30,**v})
    if mode=='shell_valves':
        for i,t in enumerate(o['valves']):
            for _ in range(t or 4): add(valve=i,turn=1)
    elif mode=='ice_jigsaw':
        for i,t in enumerate(o['fit']): add(piece=i,slot=t)
    elif mode=='trident_thread':
        c['points']=[{'t':p+100+i*100,'x':x,'y':y} for i,(x,y) in enumerate([[40,40],*o['gates']])];c['elapsed_ms']=p+500
    elif mode=='valkyrie_spear':
        for k in ['right']*2+['up']*2+['right']+['right']*2+['down']*4+['right']+['up']*4+['right']*3: add(key=k,down=True)
    elif mode=='titan_brace':
        for x in o['loads']: add(plate=x)
    elif mode=='cloak_wind':
        for d in o['counter']: add(direction=d)
    elif mode=='blade_links':
        for seq in itertools.product(range(4),repeat=7):
            state=o['initial'][:]
            for i in seq:
                for j in o['links'][i]: state[j]^=1
            if state==[0,0,0]:
                for i in seq: add(switch=i)
                break
    elif mode=='sand_cut920':
        c['points']=[{'t':p+100,'x':70,'y':60},{'t':p+200,'x':290,'y':200}];c['elapsed_ms']=p+300
    elif mode=='war_footwork':
        for d in ('up','up','right','right'): add(dir=d)
    elif mode=='blood_scent':
        c['points']=[{'t':p+100+i*100,'x':x,'y':y} for i,(x,y) in enumerate(o['scent'])];c['elapsed_ms']=p+500
    elif mode=='harpy_glide':
        seq=['right','up','right','up','right','up','up']+sum((['right','up'] for _ in range(4)),[])+['up']*3+sum((['right','up'] for _ in range(2)),[])+['right']*2
        for k in seq: add(key=k,down=True)
    elif mode=='jester_shadows':
        for i,(x,y) in enumerate(o['shadows']): add(clone=i,x=x,y=y)
    elif mode=='black_parkour':
        for k in ('right','space','right','right','right'): add(key=k)
    elif mode=='jester_pour':
        for i,d in enumerate(o['dose']): add(cup=i,drops=d,x=(70,180,290)[i])
    elif mode=='jester_line': add(typed=o['line'])
    elif mode=='siren_string':
        for _ in range(abs(o['target'])): add(turn=1 if o['target']>0 else -1)
    elif mode=='goblin_probe':
        for i in range(4): add(node=i)
        add(fault=max(range(4),key=lambda j:abs(o['readings'][j]-o['normal'])))
    elif mode=='goblin_gears':
        for g in o['gears']: add(gear=g)
    elif mode=='bear_pose':
        for i,(x,y) in enumerate(o['paws']): add(paw=i,x=x,y=y)
    elif mode=='bear_lever': add(angle=o['angle'])
    else: raise AssertionError(mode)
    return c
