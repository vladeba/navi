"""Keggo the copycat chameleon and Grod the wounded yeti legend."""
import copy, random
from .character import Character
from .skills import DamageSkill, Skill
from .effects import Shield, Poison, Burn, Bleed, Stun, Regeneration
from .games810 import game

class Mimic(Skill):
    def _perform(self,u,t):
        original=getattr(u,'last_enemy_damage_skill',None)
        if original is None:return ['🦎 Кегго ещё не видел удачного приёма врага.']
        s=copy.copy(original);s.multiplier*=.65;s.hits=min(2,s.hits);s.effect_chance*=.65
        output=s._perform(u,t)
        logs=list(output[0]) if isinstance(output,tuple) and output and isinstance(output[0],(list,tuple)) else (list(output) if isinstance(output,(list,tuple)) else [str(output)])
        u.mimic_resist_type=getattr(u,'last_enemy_effect_type',None);u.mimic_resist_turns=1
        u.last_enemy_damage_skill=None
        return logs+['🦎 Кегго повторил ослабленную копию и приспособился к её эффекту на ход.']
    def is_available(self,u):return super().is_available(u) and getattr(u,'last_enemy_damage_skill',None) is not None
    def ai_score(self,u,t):return 45 if getattr(u,'last_enemy_damage_skill',None) and t.is_alive() else 1

class TongueLash(DamageSkill):
    def _perform(self,u,t):
        logs=super()._perform(u,t)
        hit=any(f'урона по {t.name}' in line for line in logs)
        if hit and t.energy:
            drained=min(10,t.energy);t.spend_energy(drained);u.restore_energy(drained)
            logs.append(f'👅 Липкий язык вытянул {drained} энергии.')
        return logs

class Keggo(Character):
    hero_class,type_key,resource_name,role='Хамелюд','keggo','отражение','trickster'
    PASSIVE_NOTES=('Цвет под стать: Кегго запоминает последнее попавшее урон-умение врага. «Подражание» выпускает его ослабленную копию и на один ход снижает силу совпавших яда, горения и кровотечения на 30%; против прочих эффектов есть 30% шанс сопротивления.',)
    def __init__(self,name,level=1):
        self.last_enemy_damage_skill=None;self.last_enemy_effect_type=None;self.mimic_resist_type=None;self.mimic_resist_turns=0
        super().__init__(name,max_hp=188,base_damage=14,armor=1,level=level,speed=8,dodge=.15,crit_chance=.14,max_energy=100,energy_regen=14,start_energy=75)
    def remember_damage_skill(self,skill,attacker=None):
        if attacker is self:return
        self.last_enemy_damage_skill=copy.copy(skill);self.last_enemy_effect_type=type(skill.effect()) if skill.effect else None
    def reset(self):
        result=super().reset()
        self.last_enemy_damage_skill=None;self.last_enemy_effect_type=None
        self.mimic_resist_type=None;self.mimic_resist_turns=0
        return result
    def add_effect(self,effect):
        if self.mimic_resist_turns and self.mimic_resist_type and isinstance(effect,self.mimic_resist_type):
            if isinstance(effect,(Poison,Burn,Bleed)):effect.power=max(1,round(effect.power*.7))
            elif isinstance(effect,Stun):
                if random.random() < .30:
                    self._events.append('🦎 «Цвет под стать» помог Кегго избежать эффекта.')
                    return False
            elif random.random() < .30:
                self._events.append('🦎 «Цвет под стать» помог Кегго избежать эффекта.')
                return False
        return super().add_effect(effect)
    def start_turn(self):
        out=super().start_turn();self.mimic_resist_turns=max(0,self.mimic_resist_turns-1);return out
    def _create_skills(self):
        return [DamageSkill('attack','Хлёсткий хвост','Удар хвостом.',multiplier=1,accuracy=.95,icon='🦎'),
        Mimic('mimic','Подражание','Копирует последнее успешное урон-умение противника ослабленной версией.',cost=22,cooldown=2,icon='🪞'),
        TongueLash('tongue','Липкий язык','Удар ×0.75 и вытягивает до 10 энергии.',multiplier=.75,cost=16,cooldown=2,icon='👅'),
        DamageSkill('spine','Ядовитый шип','Удар ×0.9, яд на два хода.',multiplier=.9,effect=lambda:Poison(2,4),effect_chance=.8,cost=20,cooldown=3,icon='☠'),
        game('camouflage','Сменить окраску','armor_deduce','keggo',20,3),game('ambush','Тень мангров','shadow_route','keggo',22,4),game('bait','Живая приманка','trap_place','keggo',24,4)]
    def puzzle_reward(self,key,target,tier):
        if tier==3:return ['🦎 Маскировка сорвалась.']
        if key=='camouflage':
            self.add_effect(Shield(2,(28,20,10)[tier]));return ['🦎 Кегго слился с окружением и укрылся щитом.']
        if key=='ambush':
            sk=DamageSkill('ambush_hit','Засада','',multiplier=(1.65,1.3,.7)[tier],accuracy=.98);return sk._perform(self,target)
        self.add_effect(Regeneration(2,(7,5,2)[tier]));return ['🦎 Приманка отвлекла врага; Кегго восстановится.']
    def to_dict(self):
        d=super().to_dict();d['copied_skill']=getattr(self.last_enemy_damage_skill,'name',None);return d

class Grod(Character):
    hero_class,type_key,resource_name,role='Йети','grod','натиск','tank'
    PASSIVE_NOTES=('Дыхание легенды: противник платит на 10% больше энергии за умения при полном HP Грода; надбавка линейно растёт до 35% при 25% HP и ниже.',)
    def __init__(self,name,level=1):super().__init__(name,max_hp=330,base_damage=15,armor=6,level=level,speed=3,dodge=.02,crit_chance=.06,max_energy=100,energy_regen=12,start_energy=65)
    def incoming_skill_cost_multiplier(self):
        ratio=self.hp/max(1,self.max_hp);return 1.35 if ratio<=.25 else 1.10+.25*(1-ratio)/.75
    def _create_skills(self):
        return [DamageSkill('attack','Удар легенды','Мощный удар тяжёлой лапой.',multiplier=1.1,accuracy=.92,icon='🐾'),
        DamageSkill('frost_breath','Морозное дыхание','Удар ×0.8, шанс оглушить на ход.',multiplier=.8,effect=lambda:Stun(1),effect_chance=.25,cost=18,cooldown=2,icon='❄'),
        DamageSkill('avalanche','Лавинный бросок','Тяжёлый удар ×1.55.',multiplier=1.55,cost=25,cooldown=3,icon='🏔'),
        GrodGuard('legend_hide','Шкура легенды','Получает щит 15% максимального HP.',cost=22,cooldown=4,icon='🛡'),
        game('whiteout','Белая мгла','water_balance','grod',20,3),game('ice_shelf','Край обрыва','shield_wrestle','grod',23,4),game('last_roar','Рёв раненой легенды','armor_deduce','grod',25,4)]
    def _perform_buff(self,u,t):
        n=round(self.max_hp*.15);self.add_effect(Shield(3,n));return [f'🐾 Шкура легенды: щит {n}.']
    def puzzle_reward(self,key,target,tier):
        if tier==3:return ['🏔 Грод не удержал снежный проход.']
        if key=='whiteout':
            n=round(self.max_hp*(.18,.13,.07)[tier]);self.add_effect(Shield(3,n));return [f'❄ Белая мгла укрыла Грода: щит {n}.']
        if key=='ice_shelf':return DamageSkill('shelf_hit','Сдвиг льда','',multiplier=(1.6,1.25,.65)[tier])._perform(self,target)
        self.add_effect(Regeneration(2,(10,7,3)[tier]));return ['🐾 Рёв легенды восстановит здоровье.']
    def to_dict(self):
        d=super().to_dict();d['breath_tax']=round((self.incoming_skill_cost_multiplier()-1)*100);return d

class GrodGuard(Skill):
    def _perform(self,u,t):
        n=round(u.max_hp*.15);u.add_effect(Shield(3,n));return [f'🐾 Шкура легенды: щит {n}.']
    def ai_score(self,u,t):return 25 if not any(isinstance(e,Shield) for e in u.get_effects()) else 5
