"""Jotunlok: spend frost on a shield or a decisive trident strike."""
import random,math
from .character import Character
from .effects import Burn,Shield
from .skills import Skill,DamageSkill,MiniGameSkill
from .minigames_56 import Replay,events,integer,number

class Gather(Skill):
 copyable=False
 def _perform(self,u,t):u.frost=min(3,u.frost+2);return [f'❄ Сила мороза: {u.frost}/3.']
 def ai_score(self,u,t):return 25 if u.frost<=1 else -10
class FrostThrust(DamageSkill):
 copyable=False
 def _perform(self,u,t):
  logs=super()._perform(u,t);u.frost=min(3,u.frost+1);return logs+[f'❄ Сила мороза: {u.frost}/3.']
class FrostShield(Skill):
 copyable=False
 def _perform(self,u,t):
  used=u.frost;u.frost=0;n=round(u.max_hp*(.06+.04*used));u.add_effect(Shield(3,n));return [f'🧊 Щит {n} на два хода; потрачено мороза: {used}.']
 def ai_score(self,u,t):return 22 if u.frost>=2 else 8
class FrostRupture(DamageSkill):
 copyable=False
 def _perform(self,u,t):
  used=u.frost;u.frost=0;old=self.multiplier;self.multiplier=.9+.32*used
  try:logs=super()._perform(u,t)
  finally:self.multiplier=old
  return logs+[f'❄ Потрачено мороза: {used}/3.']
 def ai_score(self,u,t):return 25 if u.frost>=2 else 7
class IceGame(Replay,MiniGameSkill):
 game='jotunlok780';reactor='user';hero_target=True;PREP=600;TIME_LIMIT_MS=10000
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,43,25,10);MODE='ice'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);o.update(mode=self.MODE,hero_type='jotunlok',instruction=self.prompt)
  if self.MODE=='ice':o.update(values=random.sample([1,2,3,4,6],5),target=10,max_moves=15)
  else:o.update(period=round(4500*o['factor']),radius=32,count=3)
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict) or integer(c.get('elapsed_ms'),hi=o['time_limit_ms'])<o['prepare_ms']:return 3
  a=events(c,'actions',o,12)
  if not a:return 3
  if self.MODE=='ice':
   chosen=set()
   for v in a:
    i=integer(v.get('shard'),hi=4)
    if i<0:return 3
    if i in chosen:chosen.remove(i)
    else:chosen.add(i)
   total=sum(o['values'][i] for i in chosen)
   return 0 if len(chosen)==3 and total==o['target'] else 1 if len(chosen)==3 and abs(total-o['target'])==1 else 2 if len(chosen)==3 else 3
  n=0;last=o['prepare_ms']-round(600*o['factor'])
  for i,v in enumerate(a):
   if i>=3:return 3
   if v['ms']-last<round(500*o['factor']):return 3
   last=v['ms'];q=(v['ms']-o['prepare_ms'])/o['period']*math.tau+i*1.3
   x,y=180+100*math.sin(q),125+45*math.cos(q)
   if math.hypot(number(v.get('x'))-x,number(v.get('y'))-y)<=o['radius']:n+=1
  return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3

 def apply(self,u,t,tier,data):
  if self.MODE=='ice':
   gain=(3,2,1,0)[tier];u.frost=min(3,u.frost+gain);return [f'❄ Сила мороза: {u.frost}/3.']
  mult=(1.7,1.3,.65,0)[tier]
  return self.strike(u,t,mult)[0] if mult else ['❄ Копьё не достигло цели.']
 def ai_score(self,u,t):return 25 if self.MODE=='ice' and u.frost<=1 else 14

def game(key,name,prompt,mode,cost,cd):
 s=IceGame(key,name,prompt,cost=cost,cooldown=cd,icon='❄');s.MODE=mode;s.prompt=prompt;return s
class Jotunlok(Character):
 hero_class,type_key,resource_name,role='Ледяной великан','jotunlok','мороз','warrior'
 PASSIVE_NOTES=('Холод северных земель: запас мороза до 3 зарядов. Рывок и сосредоточение накапливают его, щит и раскол расходуют. Горение наносит на 50% больше урона.',)
 def __init__(self,name,level=1):
  self.frost=0
  super().__init__(name,max_hp=240,base_damage=22,armor=3,level=level,speed=5,dodge=.05,crit_chance=.08,max_energy=100,energy_regen=12,start_energy=65)
 def dot_multiplier_for(self,e):return 1.5 if isinstance(e,Burn) else 1.
 def _on_reset(self):self.frost=0
 def to_dict(self):
  d=super().to_dict();d['frost']=self.frost;return d
 def _create_skills(self):return [
  DamageSkill('attack','Укол трезубцем','Обычная атака.',accuracy=.95,icon='🔱'),
  Gather('gather','Дыхание зимы','Накапливает два заряда мороза, максимум три.',cost=12,cooldown=2,icon='❄'),
  FrostThrust('thrust','Ледяной выпад','Удар ×1.1, после действия один заряд мороза.',multiplier=1.1,cost=14,cooldown=2,icon='🔱'),
  FrostShield('shield','Панцирь инея','Расходует мороз: щит 6% HP + 4% за заряд на два хода.',cost=20,cooldown=3,icon='🧊'),
  FrostRupture('rupture','Раскол ледника','Расходует мороз: удар ×0.9 + 0.32 за заряд.',multiplier=.9,cost=22,cooldown=3,icon='💥'),
  game('crystal','Сердце ледника','Выберите три кристалла, чтобы их числа в сумме дали десять.','ice',20,4),
  game('trident','Трезубец бурана','Трижды попадите трезубцем в движущуюся ледяную мишень.','trident',24,4)]
