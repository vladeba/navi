"""Gordonos gains pride per successful hit, risking a fall at its peak."""
import random,math
from .character import Character
from .effects import Shield
from .skills import Skill,DamageSkill,MiniGameSkill
from .minigames_56 import Replay,events,integer,number

class TitanGuard(Skill):
 def _perform(self,u,t):
  n=round(u.max_hp*.12);u.add_effect(Shield(3,n));return [f'🛡 Титан выставляет руки: щит {n} на два хода.']
 def ai_score(self,u,t):return 17
class TitanGame(Replay,MiniGameSkill):
 game='gordonos780';reactor='user';hero_target=True;PREP=600;TIME_LIMIT_MS=10500
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(20,40,25,15);MODE='fall'
 def pick_reactor(self,u,t,is_human):return u
 def is_available(self,u):return super().is_available(u) and (self.MODE!='fall' or u.pride==5)
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(mode=self.MODE,hero_type='gordonos',instruction=self.prompt)
  if self.MODE=='fall':o.update(beats=[round((2400+i*2800)*f) for i in range(2)],perfect=round(180*f),good=round(360*f),partial=round(600*f))
  elif self.MODE=='pillar':o.update(weights=random.sample([1,2,3,4,5],5),target=9)
  else:o.update(period=round(4400*f),radius=34)
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict) or integer(c.get('elapsed_ms'),hi=o['time_limit_ms'])<o['prepare_ms']:return 3
  a=events(c,'actions',o,12)
  if not a:return 3
  if self.MODE=='fall':
   if len(a)!=2:return 3
   ds=[abs(v['ms']-b) for v,b in zip(a,o['beats'])]
   return 0 if max(ds)<=o['perfect'] else 1 if max(ds)<=o['good'] else 2 if max(ds)<=o['partial'] else 3
  if self.MODE=='pillar':
   chosen=set()
   for v in a:
    i=integer(v.get('stone'),hi=4)
    if i<0:return 3
    if i in chosen:chosen.remove(i)
    else:chosen.add(i)
   total=sum(o['weights'][i] for i in chosen)
   return 0 if len(chosen)==3 and total==o['target'] else 1 if len(chosen)==3 and abs(total-o['target'])==1 else 2 if len(chosen)==3 else 3
  hits=0
  for i,v in enumerate(a):
   if i>=3:return 3
   if i and v['ms']-a[i-1]['ms']<round(500*o['factor']):return 3
   q=(v['ms']-o['prepare_ms'])/o['period']*math.tau+i*1.3;x=180+90*math.sin(q);y=130+45*math.cos(q)
   hits+=math.hypot(number(v.get('x'))-x,number(v.get('y'))-y)<=o['radius']
  return 0 if hits==3 else 1 if hits==2 else 2 if hits==1 else 3
 def apply(self,u,t,tier,data):
  if self.MODE=='fall':
   if tier==3:
    old=u.pride;u.pride=0;damage=round(u.max_hp*.05*old);before=u.hp;u.hp=u.hp-damage
    return [f'⚡ Боги карают за гордыню: потеряно {old} зарядов и {before-u.hp} HP.']
   mult=(2.8,2.1,1.25,0)[tier];return self.strike(u,t,mult)[0]
  if self.MODE=='pillar':
   amount=round(u.max_hp*(.16,.11,.06,0)[tier]);
   if amount:u.add_effect(Shield(3,amount))
   return [f'🏛 Каменный заслон: щит {amount}.']
  mult=(1.6,1.2,.6,0)[tier];return self.strike(u,t,mult)[0] if mult else ['👊 Удар не достиг цели.']
 def ai_score(self,u,t):return 35 if self.MODE=='fall' and u.pride==5 else 14

def game(k,n,p,m,cost,cd):
 s=TitanGame(k,n,p,cost=cost,cooldown=cd,icon='👊');s.MODE=m;s.prompt=p;return s
class Gordonos(Character):
 hero_class,type_key,resource_name,role='Титан','gordonos','гордыня','tank'
 PASSIVE_NOTES=('Гордыня титана: каждый успешный удар даёт один заряд, максимум пять; каждый заряд добавляет 8% урона. «Низвержение» доступно только на пяти зарядах; при срыве титану наносится 5% максимального HP за каждый потерянный заряд.',)
 def __init__(self,name,level=1):
  self.pride=0
  super().__init__(name,max_hp=295,base_damage=9,armor=3,level=level,speed=3,dodge=.03,crit_chance=.06,max_energy=100,energy_regen=12,start_energy=70)
 def note_attack(self,hit):
  super().note_attack(hit)
  if hit:self.pride=min(5,self.pride+1)
 def damage_multiplier(self):return super().damage_multiplier()+.08*self.pride
 def _on_reset(self):self.pride=0
 def to_dict(self):
  d=super().to_dict();d['pride']=self.pride;return d
 def _create_skills(self):return [
  DamageSkill('attack','Кулак титана','Обычный удар голым кулаком.',accuracy=.95,icon='👊'),
  DamageSkill('crush','Сокрушение','Один удар ×1.4.',multiplier=1.4,cost=18,cooldown=2,icon='💥'),
  DamageSkill('double','Двойной натиск','Два удара ×0.7; каждый успешный удар добавляет гордыню.',multiplier=.7,hits=2,cost=23,cooldown=3,icon='👊'),
  TitanGuard('guard','Стойка титана','Щит 12% HP на два хода.',cost=20,cooldown=3,icon='🛡'),
  DamageSkill('pierce','Камнелом','Удар ×1.15, пробивает 35% брони.',multiplier=1.15,armor_pierce=.35,cost=18,cooldown=2,icon='🪨'),
  game('fall','Низвержение','Только при 5 гордыни. Два точных удара; срыв уничтожит все заряды и отнимет 5% максимального HP за каждый.','fall',32,5),
  game('pillar','Опора Олимпа','Выберите три камня с суммой веса 9, чтобы возвести щит.','pillar',22,4),
  game('fist','Кулак небес','Трижды попадите кулаком по движущейся цели.','fist',24,4)]
