"""Lore-driven replacement interactions for the 7.8–8.1 hero kits."""
import math, random
from types import MethodType
from .minigames_56 import events, integer, number, records, trace, at

PACK={
 ('gormadont','tide'):('shell_valves','Поверните три клапана панциря колёсиком мыши: закройте каналы, куда ударит встречная волна.'),
 ('jotunlok','crystal'):('ice_jigsaw','Сдвигайте ледяные осколки в гнёзда по форме сколов. Сердце должно сомкнуться без наложений.'),
 ('jotunlok','trident'):('trident_thread','Проведите остриё трезубца сквозь три ледяных кольца одним непрерывным движением.'),
 ('gordonos','pillar'):('titan_brace','Переставляйте стопы титана по отмеченным плитам, чтобы принять вес небесного свода.'),
 ('ksair','avoid'):('cloak_wind','Короткими взмахами плаща гасите порывы песка: каждый жест должен идти поперёк показанного ветра.'),
 ('ksair','align'):('blade_links','Переключайте связанные зубчатые замки. Каждый замок сдвигает соседнее лезвие.'),
 ('ksair','timing'):('sand_cut920','Одним прямым взмахом рассеките три подвешенные ленты, не задевая стойки.'),
 ('buattila','rhythm'):('war_footwork','Пройдите по свободным следам тяжёлыми шагами. Красные плиты рушатся под ногой.'),
 ('buattila','hunt'):('blood_scent','Ведите факелом по карте: след проступает только внутри круга света, охотник должен найти его ответвления.'),
 ('anivriza','dive'):('harpy_glide','Управляйте крыльями клавишами A/D и W/S. Поток ветра подхватывает гарпию, но скала не прощает срыва.'),
 ('frida','spear'):('valkyrie_spear','Направляйте летящее копьё стрелками через три раскрывающихся кольца.'),
 ('plutarch','clones'):('jester_shadows','Передвигайте настоящего шута по сцене, пока его двойники повторяют движения наоборот. Доведите их тени до разных кулис.'),
 ('plutarch','poison'):('jester_pour','Перелейте яд из пипетки в три блюда, наклоняя её мышью. Не пролейте капли на стол.'),
 ('plutarch','dash'):('black_parkour','Проведите чёрного шута через сцену прыжками: бегите, прыгайте через яму и приземлитесь за спиной цели.'),
 ('plutarch','joke'):('jester_line','Наберите реплику с таблички без ошибок. Злая шутка должна попасть точно в слова.'),
 ('yaisha','finale'):('siren_string','Подтяните струну арфы вверх или вниз колёсиком, пока биение последней ноты не исчезнет.'),
 ('dindau','wires'):('goblin_probe','Проверьте контакты щупами мультиметра и найдите перегретый провод по скачку показаний.'),
 ('dindau','overdrive'):('goblin_gears','Переведите рычаг по H-схеме передач. Переключайтесь по оборотам, пока робот не заглох.'),
 ('connie','hug'):('bear_pose','Расставьте лапы Мишутки вокруг противника по очереди, затем сведите их для захвата.'),
 ('connie','hammer'):('bear_lever','Нажмите на рукоять плюшевого молота и проведите её по рычажной дуге; тяжёлый удар требует верного плеча.'),
}

def _tier(mode,c,o):
    if not isinstance(c,dict): return 3
    end=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']); prep=o['prepare_ms']
    if end<prep:return 3
    a=events(c,'actions',o,120); pts=trace(c,o)
    if mode=='shell_valves':
        state=[0,0,0]
        for v in a:
            i=integer(v.get('valve'),hi=2);turn=integer(v.get('turn'),lo=-1,hi=1)
            if i<0 or turn==0:return 3
            state[i]=(state[i]+turn)%4
        n=sum(x==y for x,y in zip(state,o['valves']))
        return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
    if mode=='ice_jigsaw':
        slots={}
        for v in a:
            i=integer(v.get('piece'),hi=3);j=integer(v.get('slot'),hi=3)
            if i<0 or j<0:return 3
            slots[i]=j
        n=sum(slots.get(i)==v for i,v in enumerate(o['fit']))
        return 0 if n==4 else 1 if n==3 else 2 if n>=1 else 3
    if mode=='trident_thread':
        if len(pts)<2:return 3
        gates=o['gates'];n=0
        for _,x,y in pts:
            if n<len(gates) and math.dist((x,y),gates[n])<o['radius']:n+=1
        return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
    if mode=='valkyrie_spear':
        x,y=40.,130.;n=0
        for v in a:
            if not v.get('down'):continue
            k=v.get('key')
            if k=='right':x+=32
            elif k=='left':x-=18
            elif k=='up':y-=20
            elif k=='down':y+=20
            else:continue
            while n<len(o['gates']) and x>=o['gates'][n][0]:
                if abs(y-o['gates'][n][1])<o['radius']:n+=1
                else:return 3 if n==0 else 2
        return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
    if mode=='titan_brace':
        n=0
        for v in a:
            p=integer(v.get('plate'),hi=3)
            if p<0:return 3
            if p==o['loads'][n] if n<len(o['loads']) else False:n+=1
        return 0 if n==4 else 1 if n==3 else 2 if n>=1 else 3
    if mode=='cloak_wind':
        n=0
        for i,v in enumerate(a[:4]):
            direction=v.get('direction')
            n+=direction==o['counter'][i]
        return 0 if n==4 else 1 if n==3 else 2 if n>=1 else 3
    if mode=='blade_links':
        state=o['initial'][:]
        for v in a:
            i=integer(v.get('switch'),hi=3)
            if i<0:return 3
            for k in o['links'][i]:state[k]^=1
        n=sum(x==0 for x in state)
        return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
    if mode=='sand_cut920':
        if len(pts)<2:return 3
        p0,p1=pts[0][1:],pts[-1][1:]
        vx,vy=p1[0]-p0[0],p1[1]-p0[1];den=max(1,vx*vx+vy*vy)
        n=0
        for x,y in o['ribbons']:
            q=max(0,min(1,((x-p0[0])*vx+(y-p0[1])*vy)/den))
            n+=math.dist((x,y),(p0[0]+q*vx,p0[1]+q*vy))<o['radius']
        straight=math.dist(p0,p1)>130 and len(pts)<80
        return 0 if n==3 and straight else 1 if n==2 and straight else 2 if n>=1 else 3
    if mode=='war_footwork':
        pos=o['start'];n=0
        for v in a:
            d=v.get('dir');x,y=pos%5,pos//5;dx,dy={'left':(-1,0),'right':(1,0),'up':(0,-1),'down':(0,1)}.get(d,(99,99));x+=dx;y+=dy
            if not(0<=x<5 and 0<=y<5):return 3
            pos=y*5+x
            if pos in o['broken']:return 3
            if pos==o['path'][n]:n+=1
        return 0 if n==4 else 1 if n==3 else 2 if n>=1 else 3
    if mode=='blood_scent':
        n=0
        for _,x,y in pts:
            if n<len(o['scent']) and math.dist((x,y),o['scent'][n])<o['radius']:n+=1
        return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
    if mode in ('harpy_glide','jester_shadows','black_parkour'):
        if mode=='jester_shadows':
            drops=[v for v in a if 'clone' in v]
            n=sum(math.dist((v['x'],v['y']),o['shadows'][v['clone']])<30 for v in drops if v['clone'] in (0,1))
            return 0 if n==2 and len(drops)==2 else 1 if n==2 else 2 if n==1 else 3
        if len(a)<3:return 3
        good=sum(v.get('key') in o['allowed'] for v in a)
        if mode=='black_parkour':
            jump=any(v.get('key')=='space' for v in a)
            finish=any(v.get('key')=='right' for v in a[-2:])
            return 0 if jump and finish and good>=4 else 1 if jump and good>=3 else 2 if good>=2 else 3
        if mode=='harpy_glide':
            # A/D/W/S are held controls sampled at 100 ms; staying in the
            # safe corridor matters more than merely pressing valid keys.
            x,y=55.,185.;passed=0
            for v in a:
                if not v.get('down'):continue
                k=v.get('key');x+=({'left':-24,'right':24}.get(k,0));y+=({'up':-24,'down':24}.get(k,0))+8
                if x<35 or x>325 or y<35 or y>225:return 3
                while passed<3 and x>=[115,215,300][passed]:
                    if abs(y-[145,100,65][passed])>38:return 2 if passed else 3
                    passed+=1
            return 0 if passed==3 else 1 if passed==2 else 2 if passed else 3
        return 0 if good>=o['required'] else 1 if good>=o['required']-1 else 2 if good>=2 else 3
    if mode=='jester_pour':
        cups=[0,0,0];spill=0
        for v in a:
            cup=integer(v.get('cup'),hi=2);amount=integer(v.get('drops'),lo=1,hi=4)
            if cup<0 or amount<1:return 3
            if abs(number(v.get('x'))-[70,180,290][cup])>28:return 3
            cups[cup]+=amount;spill+=max(0,cups[cup]-o['dose'][cup])
        n=sum(x==y for x,y in zip(cups,o['dose']))
        return 0 if n==3 and spill==0 else 1 if n==2 and spill==0 else 2 if n>=1 else 3
    if mode=='jester_line':
        typed=a[-1].get('typed','') if a else ''
        err=sum(x!=y for x,y in zip(typed,o['line']))+abs(len(typed)-len(o['line']))
        return 0 if typed==o['line'] else 1 if err<=2 else 2 if err<=5 else 3
    if mode=='siren_string':
        turns=sum(integer(v.get('turn'),lo=-1,hi=1) for v in a if 'turn' in v)
        d=abs(turns-o['target'])
        return 0 if d==0 else 1 if d==1 else 2 if d<=3 else 3
    if mode=='goblin_probe':
        seen=set();fault=-1
        for v in a:
            i=integer(v.get('node'),hi=3)
            if 'fault' in v:fault=integer(v.get('fault'),hi=3)
            elif i>=0:seen.add(i)
            else:return 3
        actual=max(range(4),key=lambda j:abs(o['readings'][j]-o['normal']))
        return 0 if len(seen)==4 and fault==actual else 1 if len(seen)>=3 and fault==actual else 2 if len(seen)>=2 else 3
    if mode=='goblin_gears':
        n=0;last=-1
        for v in a:
            gear=integer(v.get('gear'),hi=4)
            if gear<0:return 3
            if gear==o['gears'][n] if n<len(o['gears']) else False:n+=1
            last=gear
        return 0 if n==4 else 1 if n==3 else 2 if n>=1 else 3
    if mode=='bear_pose':
        seen={}
        for v in a:
            i=integer(v.get('paw'),hi=1)
            if i<0:return 3
            seen[i]=(number(v.get('x')),number(v.get('y')))
        if len(seen)<2:return 3
        n=sum(math.dist(seen[i],o['paws'][i])<28 for i in range(2))
        close=math.dist(seen[0],seen[1])<80
        return 0 if n==2 and close else 1 if n==2 else 2 if n==1 else 3
    if mode=='bear_lever':
        if not a:return 3
        v=a[-1];ang=number(v.get('angle'));d=abs(ang-o['angle'])
        return 0 if d<.10 else 1 if d<.22 else 2 if d<.45 else 3
    return 3

def _params(skill,user,target,mode,prompt):
    o=skill.params(user);o.update(mode=mode,hero_type=user.type_key,instruction=prompt)
    if mode=='shell_valves':
        o['valves']=[random.randrange(4) for _ in range(3)]
        if not any(o['valves']):o['valves'][0]=1
    elif mode=='ice_jigsaw':o['fit']=random.sample(range(4),4)
    elif mode=='trident_thread':o.update(gates=[[95,75],[190,185],[285,80]],radius=23)
    elif mode=='valkyrie_spear':o.update(gates=[[105,85],[205,175],[305,85]],radius=26)
    elif mode=='titan_brace':o['loads']=random.sample(range(4),4)
    elif mode=='cloak_wind':o['counter']=[random.choice(['left','right','up','down']) for _ in range(4)]
    elif mode=='blade_links':
        links=[[0,1],[1,2],[2,0],[0,1,2]];state=[0,0,0]
        for i in random.sample(range(4),random.randint(2,4)):
            for j in links[i]:state[j]^=1
        if state==[0,0,0]:state=[1,1,1]
        o.update(initial=state,links=links)
    elif mode=='sand_cut920':o.update(ribbons=[[100,80],[180,130],[260,180]],radius=23)
    elif mode=='war_footwork':o.update(start=20,path=[15,10,11,12],broken=[16,17,13,8,5,2],required=4)
    elif mode=='blood_scent':o.update(scent=[[85,80],[180,180],[275,75]],radius=35)
    elif mode in ('harpy_glide','black_parkour'):
        o.update(allowed=['left','right','up','down','space'],required=4)
    elif mode=='jester_shadows':o['shadows']=[[80,205],[280,205]]
    elif mode=='jester_pour':o.update(dose=[2,3,1])
    elif mode=='jester_line':o['line']='СМЕХ ЗА СПИНОЙ'
    elif mode=='siren_string':o['target']=random.choice([-4,-3,-2,-1,1,2,3,4])
    elif mode=='goblin_probe':o.update(readings=[20,80,35,60],normal=40,tolerance=8)
    elif mode=='goblin_gears':o.update(gears=[1,3,2,4])
    elif mode=='bear_pose':o['paws']=[[145,125],[215,125]]
    elif mode=='bear_lever':o['angle']=random.uniform(-1.15,-.35)
    return o

def install(classes):
    for (hero,key),(mode,prompt) in PACK.items():
        cls=classes[hero];original=cls._create_skills
        def create(self,_old=original,_key=key,_mode=mode,_prompt=prompt):
            skills=_old(self)
            for s in skills:
                if s.key!=_key:continue
                s.game='minigames920';s.prompt=_prompt;s.description=_prompt
                s.game_params=MethodType(lambda skill,u,t,m=_mode,p=_prompt:_params(skill,u,t,m,p),s)
                s.tier_from=MethodType(lambda skill,c,o,m=_mode:_tier(m,c,o),s)
            return skills
        cls._create_skills=create
