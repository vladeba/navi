"""Ksair: a desert sword fighter whose mini-games revolve around momentum."""
import math,random
from .character import Character
from .effects import Bleed,Shield
from .skills import Skill,DamageSkill,MiniGameSkill
from .minigames_56 import Replay,events,integer,number,records,trace,at

class SandGuard(Skill):
 def _perform(self,u,t):
  n=round(u.max_hp*.09);u.add_effect(Shield(3,n));return [f'🏜 Завеса песка: щит {n} на два хода.']
 def ai_score(self,u,t):return 13

def rotation(o,pts,down,up,mode):
 # Replay angle changes at sampled pointer positions. Large jumps cannot create a free turn.
 last=None;clock=anti=0.;unsafe=0
 for tm,x,y in pts:
  if tm<down or tm>up:continue
  dx=x-180;dy=y-130;r=math.hypot(dx,dy)
  if abs(r-85)>27:last=None;continue
  q=math.atan2(dy,dx)
  if last is not None:
   d=(q-last+math.pi)%math.tau-math.pi
   if abs(d)<=.55:
    if d>0:clock+=d
    else:anti-=d
  last=q
  if mode=='avoid':
   obstacle=(tm-o['prepare_ms'])/o['period']*math.tau
   if abs((q-obstacle+math.pi)%math.tau-math.pi)<.27:unsafe+=1
 return clock,anti,unsafe

class SandGame(Replay,MiniGameSkill):
 game='ksair780';reactor='user';hero_target=True;PREP=600;TIME_LIMIT_MS=12500
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(20,42,26,12);MODE='sweep'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);o.update(mode=self.MODE,hero_type='ksair',instruction=self.prompt)
  if self.MODE in ('sweep','avoid'):o.update(period=round(3800*o['factor']),radius=85)
  elif self.MODE=='align':
   rings=[0,0,0]
   for _ in range(random.randint(2,5)):
    i=random.randrange(3);rings[i]=(rings[i]+1)%4;rings[(i+1)%3]=(rings[(i+1)%3]+1)%4
   if rings==[0,0,0]:rings=[1,1,0]
   o.update(initial=rings)
  else:o.update(beats=[round((2500+i*2700)*o['factor']) for i in range(2)],perfect=round(230*o['factor']),good=round(450*o['factor']),partial=round(700*o['factor']))
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);prep=o['prepare_ms'];f=o['factor']
  if elapsed<prep:return 3
  if self.MODE in ('sweep','avoid'):
   pts=trace(c,o);holds=records(c,'holds',1)
   if not pts or len(holds)!=1 or not isinstance(holds[0],dict):return 3
   down=integer(holds[0].get('down_ms'),lo=prep,hi=elapsed);up=integer(holds[0].get('up_ms'),lo=prep,hi=elapsed)
   if down<prep or up-down<500*f:return 3
   cw,cc,unsafe=rotation(o,pts,down,up,self.MODE)
   if self.MODE=='sweep':return 0 if cw>=math.tau*2 else 1 if cw>=math.tau*1.5 else 2 if cw>=math.tau*.5 else 3
   return 0 if cw>=math.tau and unsafe<=2 else 1 if cw>=math.tau else 2 if cw>=math.pi else 3
  a=events(c,'actions',o,18)
  if not a:return 3
  if self.MODE=='align':
   rings=o['initial'][:]
   for v in a:
    i=integer(v.get('ring'),hi=2)
    if i<0:return 3
    rings[i]=(rings[i]+1)%4;rings[(i+1)%3]=(rings[(i+1)%3]+1)%4
   n=rings.count(0);return 0 if n==3 else 1 if n==2 else 2 if n==1 else 3
  if len(a)!=2:return 3
  d=max(abs(v['ms']-b) for v,b in zip(a,o['beats']))
  return 0 if d<=o['perfect'] else 1 if d<=o['good'] else 2 if d<=o['partial'] else 3
 def apply(self,u,t,tier,data):
  if tier==3:return ['🏜 Вращение сорвано: удар не достиг цели.']
  if self.MODE=='timing':
   # Only an ideal, expensive attack pierces both armour and ordinary absorption shields.
   u._ksair_pure=(tier==0)
   try:logs,dmg=self.strike(u,t,(1.05,1.15,.6)[tier],ignore_armor=(tier==0))
   finally:u._ksair_pure=False
   return logs+(['🏜 Чистый удар прошёл сквозь броню и щиты.'] if tier==0 else [])
  mult={'sweep':(1.5,1.15,.65),'avoid':(1.35,1.05,.6),'align':(1.25,1.0,.55)}[self.MODE][tier]
  logs,dmg=self.strike(u,t,mult)
  if self.MODE in ('sweep','avoid') and dmg>0 and t.is_alive():t.add_effect(Bleed(2,(4,3,2)[tier]));logs.append('🩸 Песчаный клинок вызывает кровотечение на два хода.')
  return logs
 def ai_score(self,u,t):return 14

def game(k,n,p,m,cost,cd):
 s=SandGame(k,n,p,cost=cost,cooldown=cd,icon='🏜');s.MODE=m;s.prompt=p;return s
class Ksair(Character):
 hero_class,type_key,resource_name,role='Пустынный страж','ksair','вращение','warrior'
 PASSIVE_NOTES=('Песчаный клинок: идеальный «Разрез сквозь бурю» наносит умеренный чистый удар сквозь броню и щиты. У приёма высокая цена и долгая перезарядка; другие умения подчиняются обычной защите.',)
 def __init__(self,name,level=1):super().__init__(name,max_hp=235,base_damage=17,armor=2.5,level=level,speed=7,dodge=.09,crit_chance=.09,max_energy=100,energy_regen=12,start_energy=70)
 def _create_skills(self):return [DamageSkill('attack','Изогнутый клинок','Обычная атака.',accuracy=.95,icon='⚔'),DamageSkill('slash','Песчаный разрез','Удар ×1.2 с кровотечением 3 HP на два хода.',multiplier=1.2,effect=lambda:Bleed(2,3),effect_chance=1,cost=18,cooldown=2,icon='🩸'),SandGuard('guard','Песчаная завеса','Щит 9% HP на два хода.',cost=18,cooldown=3,icon='🏜'),game('sweep','Вихрь клинка','Зажмите рукоять и сделайте два оборота по часовой стрелке.','sweep',22,3),game('avoid','Танец бурь','Вращайте клинок по часовой стрелке, избегая движущейся искры на кольце.','avoid',24,4),game('align','Три лезвия','Поверните три связанных клинка: каждое кольцо поворачивает соседнее. Совместите метки вверх.','align',22,4),game('timing','Разрез сквозь бурю','Два удара в золотой центр: идеальный результат пробивает броню и щиты, другие результаты — обычный урон.','timing',32,6)]
