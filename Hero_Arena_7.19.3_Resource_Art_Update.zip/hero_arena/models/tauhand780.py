"""Tauhand: a tank whose armour can crack under single heavy hits."""
import random
from .character import Character
from .effects import Burn, Bleed, Poison, DamageReduction
from .skills import Skill, DamageSkill, SelfBuffSkill, MiniGameSkill
from .minigames_56 import Replay, events, integer

class Repair(Skill):
 def _perform(self,u,t):
  old=u.cracks;u.cracks=0
  return [f'🪨 Самопочинка: устранено трещин {old}; броня восстановлена.']
 def ai_score(self,u,t):return 36 if u.cracks>=2 else 19 if u.cracks else -20

class TauGame(Replay,MiniGameSkill):
 game='tauhand780';reactor='user';hero_target=True;PREP=600;TIME_LIMIT_MS=10000
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,43,25,10);MODE='timing'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(mode=self.MODE,hero_type='tauhand',instruction=self.prompt)
  if self.MODE=='timing':o.update(impact=round(3800*f),perfect=round(220*f),good=round(500*f),partial=round(850*f))
  elif self.MODE=='mending':o.update(nodes=[[70,75],[180,65],[290,75],[115,170],[245,170]],radius=29)
  else:o.update(beats=[dict(ms=round((1500+i*1250)*f),side='left' if i%2==0 else 'right') for i in range(6)],window=round(450*f))
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms'])
  if elapsed<o['prepare_ms']:return 3
  if self.MODE=='timing':
   a=events(c,'actions',o,1)
   if not a:return 3
   d=abs(a[0]['ms']-o['impact']);return 0 if d<=o['perfect'] else 1 if d<=o['good'] else 2 if d<=o['partial'] else 3
  if self.MODE=='mending':
   a=events(c,'actions',o,10);seen=set()
   for v in a:
    i=integer(v.get('node'),hi=4)
    if i<0:return 3
    seen.add(i)
   n=len(seen);return 0 if n==5 else 1 if n>=4 else 2 if n>=2 else 3
  a=events(c,'actions',o,12);hits=0;used=set()
  for v in a:
   choices=[(abs(v['ms']-b['ms']),i,b) for i,b in enumerate(o['beats']) if i not in used]
   if not choices:break
   d,i,b=min(choices,key=lambda x:x[0])
   if d<=o['window']:
    used.add(i);hits+=v.get('side')==b['side']
  return 0 if hits==6 else 1 if hits>=4 else 2 if hits>=2 else 3
 def apply(self,u,t,tier,data):
  if self.MODE=='mending':
   healed=u.heal(round(u.max_hp*(.10,.075,.04,0)[tier]));return [f'🪨 Каменная кладка восстановила {healed} HP. Трещины брони устраняет только самопочинка.']
  mult={'timing':(1.8,1.35,.7,0),'step':(1.5,1.15,.6,0)}[self.MODE][tier]
  return self.strike(u,t,mult)[0] if mult else ['🪨 Приём не удался.']
 def ai_score(self,u,t):return 23 if self.MODE=='mending' and u.hp<u.max_hp*.6 else 14

def game(key,name,prompt,mode,cost,cd):
 s=TauGame(key,name,prompt,cost=cost,cooldown=cd,icon='🪨');s.MODE=mode;s.prompt=prompt;return s

class Tauhand(Character):
 hero_class,type_key,resource_name,role='Голем','tauhand','окаменелость','tank'
 PASSIVE_NOTES=('Монолит: один удар, снявший не менее 12% максимального HP, оставляет одну из трёх трещин; каждая снижает броню на 2. Устраняет их только «Самопочинка». Камень снижает урон яда, кровотечения и горения на 85%.',)
 def __init__(self,name,level=1):
  self.cracks=0
  super().__init__(name,max_hp=285,base_damage=11,armor=10,level=level,speed=3,dodge=.02,crit_chance=.04,max_energy=100,energy_regen=12,start_energy=70)
 def armor_total(self):return max(0,super().armor_total()-2*self.cracks)
 def dot_multiplier_for(self,e):return .15 if isinstance(e,(Burn,Bleed,Poison)) else 1
 def take_damage(self,amount,ignore_armor=False,attacker=None):
  before=self.hp;damage=super().take_damage(amount,ignore_armor,attacker)
  if before-self.hp>=self.max_hp*.12 and self.cracks<3:
   self.cracks+=1;self._events.append(f'🪨 Монолит треснул: {self.cracks}/3; броня −{self.cracks*2}.')
  return damage
 def _on_reset(self):self.cracks=0
 def to_dict(self):
  d=super().to_dict();d['cracks']=self.cracks;return d
 def _create_skills(self):return [
  DamageSkill('attack','Каменный кулак','Обычный тяжёлый удар.',accuracy=.94,icon='👊'),
  Repair('repair','Самопочинка','Устраняет все трещины и восстанавливает броню; занимает ход.',cost=18,cooldown=2,icon='🔧'),
  SelfBuffSkill('brace','Несокрушимая стойка','Снижает получаемый урон на 30% на 2 хода.',effects=[lambda:DamageReduction(3,30)],cost=22,cooldown=4,icon='🛡'),
  DamageSkill('crush','Разлом','Сокрушительный удар ×1.4.',multiplier=1.4,cost=20,cooldown=2,icon='🪨'),
  game('hammer','Удар монолита','Остановите медленный удар в золотой зоне.', 'timing',24,3),
  game('mending','Каменная кладка','Закрепите пять отдельных камней, чтобы восстановить HP. Трещины брони чинит только самопочинка.','mending',22,4),
  game('march','Поступь голема','Чередуйте левую и правую ногу в ритме шести шагов.','step',25,4)]
