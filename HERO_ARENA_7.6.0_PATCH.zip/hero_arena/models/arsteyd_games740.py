"""Arsteyd custom games. Prototype only; not yet registered in public roster."""
import math,random
from .skills import MiniGameSkill,scale_effect
from .effects import Burn
from .minigames_56 import Replay,trace,at,records,integer,near,events,number

class DragonFire740(Replay,MiniGameSkill):
 copyable=False
 game='arsteyd_fire740';PREP=600;TIME_LIMIT_MS=10000;reactor='user';hero_target=True
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,42,26,10)
 prompt='Зажмите пламя и прожгите четыре движущиеся пластины по очереди. Наводите дыхание на подсвеченную пластину.'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(hero_type='arsteyd',instruction=self.prompt,phase=random.random()*math.tau,radius=34,heat_ms=round(620*f),step_ms=max(1,round(25*f)),target_count=4);return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);engaged=integer(c.get('engaged_ms'),hi=elapsed)
  pts=trace(c,o);holds=parse_holds(c,o,elapsed)
  if elapsed<o['prepare_ms'] or engaged<o['prepare_ms'] or not pts or holds is None:return 3
  count,heat=fire_progress(o,pts,holds,elapsed)
  return 0 if count==4 else 1 if count>=3 else 2 if count else 3
 def apply(self,u,t,tier,data):
  mult=(2.0,1.55,.9,0)[tier]
  if not mult:return ['🔥 Пламя не пробило пластины.']
  logs,dealt=self.strike(u,t,mult)
  if dealt>0 and t.is_alive():t.add_effect(scale_effect(Burn(2,(4,3,2)[tier]),u));logs.append('🔥 Горение на два хода.')
  return logs
 def ai_score(self,u,t):return 17

def fire_target(o,t,index):
 q=(t-o['prepare_ms'])/(1250*o['factor'])+o['phase']+index*1.4
 return 180+66*math.sin(q),110+32*math.cos(q*.75+index*.6)
def parse_holds(c,o,elapsed):
 out=[]
 for a in records(c,'holds',80):
  if not isinstance(a,dict):return None
  x=integer(a.get('down_ms'),lo=o['prepare_ms'],hi=elapsed);y=integer(a.get('up_ms'),lo=o['prepare_ms'],hi=elapsed)
  if x<0 or y<x or (out and x<out[-1][1]):return None
  out.append((x,y))
 return out
def fire_progress(o,points,holds,elapsed):
 i=heat=0;step=o['step_ms']
 for t in range(o['prepare_ms'],min(elapsed,o['time_limit_ms'])+1,step):
  if i>=o['target_count']:break
  if any(a<=t<b for a,b in holds) and near(at(points,t),fire_target(o,t,i),o['radius']):
   heat+=step
   if heat>=o['heat_ms']:i+=1;heat=0
 return i,heat

class DragonFlight740(Replay,MiniGameSkill):
 copyable=False
 game='arsteyd_flight740';PREP=600;TIME_LIMIT_MS=8200;reactor='user';hero_target=True
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,42,26,10)
 prompt='Управляйте высотой полёта: дракон плавно следует за указателем. Пролетите через три просвета в скалах.'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(hero_type='arsteyd',instruction=self.prompt,step_ms=max(1,round(25*f)),response_ms=round(300*f),radius=43,gates=[dict(ms=round((2400+i*1700)*f),y=y) for i,y in enumerate(random.choice(([80,170,100],[165,85,155],[100,165,85])))])
  return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);engaged=integer(c.get('engaged_ms'),hi=elapsed);pts=trace(c,o)
  if elapsed<o['prepare_ms'] or engaged<o['prepare_ms'] or not pts:return 3
  y=130.;passed=0;gates=iter(o['gates']);gate=next(gates,None);step=o['step_ms']
  for t in range(o['prepare_ms'],elapsed+1,step):
   _,aim=at(pts,t);y+=max(-1.,min(1.,step/o['response_ms']))*(aim-y)
   while gate is not None and t>=gate['ms']:
    passed+=abs(y-gate['y'])<=o['radius'];gate=next(gates,None)
  return 0 if passed==3 else 1 if passed==2 else 2 if passed else 3
 def apply(self,u,t,tier,data):
  mult=(1.9,1.45,.8,0)[tier]
  if not mult:return ['🐉 Полёт сорван: удар не достиг цели.']
  return self.strike(u,t,mult)[0]
 def ai_score(self,u,t):return 16

class EmberRunes740(Replay,MiniGameSkill):
 copyable=False
 game='arsteyd_runes740';PREP=600;TIME_LIMIT_MS=14000;reactor='user';hero_target=True
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,42,26,10)
 prompt='Зажмите искру на начале и одним движением проведите её по светящемуся контуру драконьей печати.'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);o.update(hero_type='arsteyd',instruction=self.prompt,nodes=[[45,155],[110,75],[180,150],[250,75],[315,155]],radius=29,step=max(1,round(25*o['factor'])));return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);points=trace(c,o);holds=records(c,'holds',1)
  if not points or len(holds)!=1 or not isinstance(holds[0],dict):return 3
  down=integer(holds[0].get('down_ms'),lo=o['prepare_ms'],hi=elapsed);up=integer(holds[0].get('up_ms'),lo=o['prepare_ms'],hi=elapsed)
  if down<0 or up-down<250*o['factor'] or not near(at(points,down),o['nodes'][0],o['radius']):return 3
  count,off=seal_trace(o,points,down,up)
  return 0 if count==len(o['nodes']) and off<=round(350*o['factor']) else 1 if count==len(o['nodes']) else 2 if count>=3 else 3
 def apply(self,u,t,tier,data):
  power=(30,24,15,5)[tier];u.dragon.gain(power)
  mult=(1.0,.8,.5,0)[tier]
  logs=self.strike(u,t,mult)[0] if mult else ['🐉 Печать оказалась нестабильной.']
  return logs+['🐉 Сила дракона: %d/100.'%u.dragon.power]
 def ai_score(self,u,t):return 15

def point_segment_distance(p,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];t=max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy)))
 return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)

def seal_trace(o,points,down,up):
 count=off=0
 for tm in range(down,up+o['step'],o['step']):
  t=min(tm,up);p=at(points,t)
  if count<len(o['nodes']) and near(p,o['nodes'][count],o['radius']):count+=1
  if min(point_segment_distance(p,a,b) for a,b in zip(o['nodes'],o['nodes'][1:]))>o['radius']*1.35:off+=o['step']
  if t==up:break
 return count,off

class SwordDuel740(Replay,MiniGameSkill):
 copyable=False
 game='arsteyd_duel740';PREP=600;TIME_LIMIT_MS=8200;reactor='user';hero_target=True
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,42,26,10)
 prompt='Дважды отразите выпад: выберите указанную сторону до удара, затем проведите мечом от рукояти к открывшейся цели.'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);f=o['factor'];o.update(hero_type='arsteyd',instruction=self.prompt,attacks=[dict(ms=round((2300+i*2600)*f),side=random.choice(('left','right'))) for i in range(2)],start=[65,205],end=[275,95],radius=38);return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);guards=events(c,'actions',o,8);cuts=records(c,'cuts',2);f=o['factor'];good=0;last=o['prepare_ms']-1
  for a in cuts:
   if not isinstance(a,dict):return 3
   down=integer(a.get('down_ms'),lo=o['prepare_ms'],hi=elapsed);up=integer(a.get('up_ms'),lo=o['prepare_ms'],hi=elapsed)
   if down<=last or up-down<80*f:return 3
   last=up
  for attack in o['attacks']:
   impact=attack['ms'];selected=[a for a in guards if impact-1200*f<=a['ms']<impact]
   protected=bool(selected and selected[-1].get('side')==attack['side'])
   for cut in cuts:
    if not impact<=cut['down_ms']<=cut['up_ms']<=min(elapsed,impact+1200*f):continue
    if protected and near((number(cut.get('x0')),number(cut.get('y0'))),o['start'],o['radius']) and near((number(cut.get('x1')),number(cut.get('y1'))),o['end'],o['radius']):good+=1;break
  return 0 if good==2 else 1 if good==1 else 3
 def apply(self,u,t,tier,data):
  power=(26,17,8,4)[tier];u.dragon.gain(power);mult=(1.5,.9,.45,0)[tier]
  logs=self.strike(u,t,mult)[0] if mult else ['⚔ Защита и ответный удар не получились.']
  return logs+['🐉 Сила дракона: %d/100.'%u.dragon.power]
 def ai_score(self,u,t):return 16

def ember_route(o,actions):
 """Replay a tactical route through the moving dragon shadow."""
 cell=0;mask=0;turn=0;hits=0
 for action in actions:
  dx,dy={'left':(-1,0),'right':(1,0),'up':(0,-1),'down':(0,1)}.get(action.get('dir'),(0,0))
  if not dx and not dy:continue
  x=cell%5+dx;y=cell//5+dy
  if not (0<=x<5 and 0<=y<4):continue
  dest=y*5+x;old=o['shadow'][turn%len(o['shadow'])];turn+=1;new=o['shadow'][turn%len(o['shadow'])]
  if dest==old or dest==new:cell=0;hits+=1;continue
  cell=dest
  if cell in o['embers']:mask|=1<<o['embers'].index(cell)
 return cell,mask,turn,hits

class DragonTrail740(Replay,MiniGameSkill):
 copyable=False
 game='arsteyd_trail740';PREP=600;TIME_LIMIT_MS=22000;reactor='user';hero_target=True
 TIERS=('Идеально','Хорошо','Частично','Срыв');AI_WEIGHTS=(22,42,26,10)
 prompt='Соберите три угля и доберитесь до выхода. Тень дракона сдвигается после каждого шага; избегайте клетки, которую она покидает или занимает.'
 def pick_reactor(self,u,t,is_human):return u
 def game_params(self,u,t):
  o=self.params(u);o.update(hero_type='arsteyd',instruction=self.prompt,embers=random.choice(([3,10,17],[1,13,16],[4,6,17],[2,14,16])),shadow=[7,8,13,12],exit=19);return o
 def tier_from(self,c,o):
  if not isinstance(c,dict):return 3
  elapsed=integer(c.get('elapsed_ms'),hi=o['time_limit_ms']);acts=events(c,'actions',o,80)
  if elapsed<o['prepare_ms']:return 3
  cell,mask,turn,hits=ember_route(o,acts);collected=bin(mask).count('1')
  if cell==o['exit'] and collected==3:return 0 if hits==0 else 1
  if cell==o['exit'] and collected>=2:return 2
  return 3
 def apply(self,u,t,tier,data):
  from .effects import Shield
  power=(28,22,14,4)[tier];u.dragon.gain(power)
  shield=(18,13,8,0)[tier]
  if shield:u.add_effect(Shield(2,shield))
  return ['🐉 Сила дракона: %d/100; щит: %d.'%(u.dragon.power,shield)]
 def ai_score(self,u,t):return 13
