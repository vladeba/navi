"""Пошаговый бой двух героев.

Как устроен раунд:
  1. Оба героя бросают инициативу: скорость + кубик d6. Больше — ходит первым
     (при равенстве — случайно).
  2. В начале хода героя срабатывают его эффекты (яд, горение, оглушение),
     восстанавливается ресурс, уменьшаются перезарядки, срабатывают особенности
     класса (Вальхалла воина, копирование умений монаха...).
  3. Герой выбирает действие: в авто-режиме — ИИ (choose_action),
     в ручном режиме — игрок через API (POST /api/battles/<id>/turn).
  4. Если умению нужен ответ соперника-человека (уклон от «Тёмного столба огня»,
     выбор квадрата в «Контракте»), бой ставится на паузу: pending → POST /react.
  5. После действия героя атакует его призванное существо (если есть).
  6. Бой идёт, пока один не упадёт, или до MAX_ROUNDS раундов
     (тогда побеждает тот, у кого больше % здоровья; равенство — ничья).
  Бой можно сдать (surrender — победа сопернику) или отменить (cancel — без итогов).
"""
import random
import re
import time

from models import hp_journal
from models import rng as rng_module
import functools
import copy
from random import Random
from models.item import CONSUMABLES

from .effects import Announcement


def _with_rng(method):
    """4.3: всё, что делает бой, идёт через его собственный генератор (если задан seed)."""
    @functools.wraps(method)
    def wrapper(self, *a, **kw):
        if getattr(self, "rng", None) is None:
            return method(self, *a, **kw)
        with rng_module.use(self.rng):
            return method(self, *a, **kw)
    return wrapper


class Battle:
    """Бой: участники, режим, раунды, журнал, ожидание реакции и победитель."""

    _next_id = 1
    MAX_ROUNDS = 60
    FATIGUE_FROM = 22        # 4.4: с 22-го раунда — усталость (4.0: с 30-го)
    FATIGUE_STEP = 0.05      # 4.4: +5% урона и −5% лечения за каждый раунд усталости (было +4% урона)

    def __init__(self, hero1, hero2, mode="auto", ai_ids=None, items=None):
        if hero1 is hero2:
            raise ValueError("Герой не может сражаться сам с собой")
        if mode not in ("auto", "manual"):
            raise ValueError("mode должен быть auto или manual")
        self.id = Battle._next_id
        Battle._next_id += 1
        self.hero1 = hero1
        self.hero2 = hero2
        hero1._battle = self
        hero2._battle = self
        self.mode = mode
        # кем управляет ИИ: в авто-режиме — обоими, в ручном — переданными
        self.ai_ids = {hero1.id, hero2.id} if mode == "auto" else set(ai_ids or [])
        self.round = 0
        self.log = []               # список {"text", "kind", "round", "actor_id", "target_id"}
        self.winner = None
        self.draw = False
        self.cancelled = False
        self.finished = False
        self.current = None         # чей сейчас ход
        self.pending = None         # ожидание ответа соперника (уклон / квадрат)
        self.secret_found = False   # нажат ли «VS» — секрет Совуха (см. GameService)
        self.secret_unlocked = False  # Совух уже открыт по итогам этого боя
        self._order = []
        self._index = 0
        self._hp_seen = {}            # снимок HP для лога: {"id": hp, "s<id>": hp зверя}
        self.items = dict(items or {})   # 4.0: {id героя: ключ предмета} — один предмет на бой
        self.story = None                # 4.0: {"location", "stage"} для сюжетного боя
        self.free_items = set()          # 4.0: id героев ИИ, чей предмет «с собой» (не из сумки)
        self.notices = []
        self.skin_override = {}           # 4.4: {id героя: облик только на этот бой}
        self.test_arena = False           # 5.2: секретная арена — без наград/прогресса
        self.rng = None                  # 4.3: свой random.Random боя (seed — только dev/тесты)                # 4.0: уведомления для окна (открыт новый класс и т.п.)

    # ---------- журнал ----------
    def _add_log(self, text, kind=None, actor=None, target=None, flush=True):
        if kind is None:
            kind = self._guess_kind(text)
        if flush:
            self._apply_journal(len(hp_journal.journal()))
        self._sync_summons()
        self.log.append({"round": self.round, "text": str(text), "kind": kind,
                         "actor_id": actor.id if actor else None,
                         "target_id": target.id if target else None,
                         "hp_after": dict(self._hp_seen)})   # снимок HP после этого события

    def _keys(self):
        return {str(h.id): h for h in (self.hero1, self.hero2)}

    def _apply_journal(self, upto):
        """Перенести первые upto записей журнала HP в текущий снимок (чужие герои — пропускаем)."""
        mine = {str(h.id) for h in (self.hero1, self.hero2)}
        j = hp_journal.journal()
        for key, hp in j[:upto]:
            if key.lstrip("s") in mine:
                self._hp_seen[key] = hp
        del j[:upto]

    def _sync_summons(self):
        """Новый зверь появляется в снимке сразу с полным HP, исчезнувший — None."""
        for h in (self.hero1, self.hero2):
            key = "s%d" % h.id
            if h.summon is None:
                self._hp_seen[key] = None
            elif self._hp_seen.get(key) is None and h.summon.is_alive():
                self._hp_seen[key] = h.summon.hp

    def _names(self):
        names = {}
        for h in (self.hero1, self.hero2):
            names[str(h.id)] = h.name
            if h.summon:
                names["s%d" % h.id] = h.summon.name
        return names

    def _log_many(self, lines, actor=None, target=None):
        """Несколько строк одного действия. Изменения HP из журнала привязываются к строке,
        где упомянуты имя и число урона/лечения, — так полоски меняются по шагам."""
        lines = list(lines)
        names = self._names()
        for n, line in enumerate(lines):
            text = str(line)
            if n == len(lines) - 1:
                self._add_log(line, actor=actor, target=target)   # последняя строка — итог
                continue
            numbers = set(re.findall(r"\d+", text))
            cut, prev = 0, dict(self._hp_seen)
            for i, (key, hp) in enumerate(hp_journal.journal()):
                old = prev.get(key)
                prev[key] = hp
                if old is not None and old != hp and str(abs(old - hp)) in numbers and names.get(key, "\0") in text:
                    cut = i + 1
                    break   # первое подходящее изменение — следующее достанется следующей строке
            if cut:
                self._apply_journal(cut)
            self._add_log(line, actor=actor, target=target, flush=False)

    @staticmethod
    def _guess_kind(text):
        """Тип записи для раскраски и анимации в интерфейсе."""
        if isinstance(text, Announcement):
            return "event"
        if "КРИТ" in text:
            return "crit"
        if "Промах" in text or "уклоняется" in text or "промахивается" in text:
            return "miss"
        if "−" in text and "HP" in text:
            return "dot"
        if ("+" in text and "HP" in text) or "регенерирует" in text:
            return "heal"
        if "оглушён" in text or "не атакует" in text:
            return "stun"
        if any(w in text for w in ("Щит", "щит", "блокирует", "Каменная кожа", "Фаланга")):
            return "shield"
        if any(w in text for w in ("наложено", "Берсерк", "завеса", "контратакует", "Рёв",
                                    "отражает", "Невидимость")):
            return "effect"
        return "attack"

    def opponent(self, hero):
        return self.hero2 if hero is self.hero1 else self.hero1

    def is_human(self, hero):
        return self.mode == "manual" and hero.id not in self.ai_ids

    # ---------- ход боя ----------
    @_with_rng
    def start(self):
        """Подготовить героев и перейти к первому ходу."""
        for hero in (self.hero1, self.hero2):
            if not self.story:
                hero.configure_arena()
            hero.reset()
            hero.opponent = self.opponent(hero)
            hero.battle_item = self.items.get(hero.id)
            hero._free_item = bool(self.items.get(hero.id)) and hero.id in getattr(self, "free_items", set())
            self._hp_seen[str(hero.id)] = hero.hp
            self._hp_seen["s%d" % hero.id] = None
        self._add_log(f"Бой: {self.hero1.describe()}  VS  {self.hero2.describe()}", "info")
        for hero in (self.hero1, self.hero2):
            self._log_many(hero.battle_intro(), actor=hero)  # полиморфизм: самурай объявляет катану
        self._new_round()
        self._advance()

    def _new_round(self):
        self.round += 1
        if self.round >= self.FATIGUE_FROM:          # 4.0: мягкая усталость
            fat = round(self.FATIGUE_STEP * (self.round - self.FATIGUE_FROM + 1), 2)
            for h in (self.hero1, self.hero2):
                h.fatigue = fat
            if self.round == self.FATIGUE_FROM:
                self._add_log(Announcement(f"😓 Раунд {self.FATIGUE_FROM} — герои устали: каждый раунд удары сильнее, "
                                          f"а лечение слабее на {round(self.FATIGUE_STEP * 100)}%!"))
        r1, r2 = self.hero1.roll_initiative(), self.hero2.roll_initiative()
        if r1 > r2 or (r1 == r2 and random.random() < 0.5):
            self._order = [self.hero1, self.hero2]
        else:
            self._order = [self.hero2, self.hero1]
        self._index = 0
        self._add_log(f"— Раунд {self.round} — инициатива: {self.hero1.name} {r1}, "
                      f"{self.hero2.name} {r2} → первым ходит {self._order[0].name}", "round")

    def _advance(self):
        """Найти следующего героя, который может ходить (оглушённые пропускают)."""
        while not self.finished:
            if self._index >= len(self._order):
                if self.round >= self.MAX_ROUNDS:
                    self._finish_by_hp()
                    return
                self._new_round()
            actor = self._order[self._index]
            logs, can_act = actor.start_turn()
            self._log_many(logs, actor=actor)
            if self._check_end():
                return
            if can_act:
                self.current = actor
                return
            self._index += 1

    @_with_rng
    def play_turn(self, skill_key=None):
        """Сделать ход текущим героем. skill_key=None — действие выбирает ИИ."""
        if self.finished:
            raise ValueError("Бой уже закончен")
        if self.pending:
            raise ValueError("Ожидается ответ соперника (POST /api/battles/<id>/react)")
        actor = self.current
        target = self.opponent(actor)
        if skill_key is None:
            skill_key = actor.choose_action(target)  # полиморфизм: ИИ один, умения разные
        if str(skill_key).startswith("item:"):      # расходник из СВОЕЙ сумки героя (3.3)
            logs = actor.use_consumable(skill_key[5:], target)    # проверка до «Читай врага»
            self._log_many(target.on_enemy_action(actor, skill_key) + logs, actor, target)
            self._after_action(actor, target)
            return
        skill = actor.get_skill(skill_key)           # проверка доступности (400 при ошибке)
        pre = target.on_enemy_action(actor, skill_key)   # 4.0: «Читай врага» спартанца
        if pre:
            self._log_many(pre, target, actor)
            if self._check_end():
                return
            if not actor.can_use(skill):             # контрудар мог сбить умение — бьёт обычной атакой
                skill_key = "attack"
                skill = actor.get_skill("attack")

        reactor = actor if skill.reactor == "user" else target
        if hasattr(skill, "pick_reactor"):           # 4.2: «Столп света» — уворачивается человек или целится эльф
            reactor = skill.pick_reactor(actor, target, self.is_human)
        if skill.reaction and self.is_human(reactor):
            # отвечает человек: ставим бой на паузу и ждём его выбора
            skill.pay(actor)
            if skill.reaction == "minigame":
                options = skill.public_options(actor, target)
                # 5.0: ИИ-богатырь целится сам — человеку сразу «Куда увернуться?»
                if getattr(skill, "key", None) == "bogatyr_strike" and reactor is target:
                    aimed = random.sample(getattr(skill, "DIRS", ["up", "down", "left", "right"]), 2)
                    actor._bogatyr_aim = aimed
                    options = {"game": "dodge_pick", "dirs": skill.DIRS, "labels": dict(skill.LABELS),
                               "safe_count": 2, "time_limit_ms": 3000, "phase": "dodge", "aimed": aimed}
                    skill.prompt = "Богатырь замахивается! Куда увернуться?"
                    secret = {"deadline": time.time() + 3 + 1.5, "options": options,
                              "phase": "dodge", "aimed": aimed}
                    dirs_txt = ", ".join(skill.LABELS.get(d, d) for d in aimed)
                    self._add_log(Announcement(f"💪 {actor.name} бьёт в: {dirs_txt}."), actor=actor, target=target)
                else:
                    secret = skill.secret_pick(options)
            else:
                options, secret = skill.public_options(), skill.secret_pick()
            self.pending = {"skill": skill, "actor": actor, "target": target, "reactor": reactor,
                            "options": options, "secret": secret}
            self._add_log(Announcement(f"{skill.icon} {actor.name} готовит «{skill.name}»! "
                                       f"{reactor.name}: {skill.prompt}"), actor=actor, target=target)
            return
        self._log_many(actor.perform(skill_key, target), actor, target)
        self._after_action(actor, target)

    @_with_rng
    def react(self, choice):
        """Ответ соперника на умение с реакцией (уклон влево/вправо, номер квадрата).
        5.0: «Богатырский удар» — после выбора направлений богатырём открывается уворот цели."""
        if self.finished:
            raise ValueError("Бой уже закончен")
        if not self.pending:
            raise ValueError("Сейчас не нужно реагировать")
        p = self.pending
        skill = p["skill"]
        choice = skill.check_choice(choice)
        self.pending = None
        if hasattr(skill, "_followup"):
            skill._followup = None
        logs = skill.resolve(p["actor"], p["target"], choice, p["secret"])
        self._log_many(logs, p["actor"], p["target"])
        # 5.0: двухфазная мини-игра — сразу ставим вторую фазу, не заканчивая ход
        follow = getattr(skill, "_followup", None)
        if follow:
            skill._followup = None
            actor, target = p["actor"], p["target"]
            reactor = target if follow.get("reactor") == "target" else actor
            options = dict(follow["options"])
            secret = {"deadline": time.time() + options.get("time_limit_ms", 3000) / 1000 + 1.5,
                      "options": options, "phase": follow["phase"], "aimed": follow.get("aimed", [])}
            if self.is_human(reactor):
                skill.prompt = follow.get("prompt", skill.prompt)
                self.pending = {"skill": skill, "actor": actor, "target": target, "reactor": reactor,
                                "options": options, "secret": secret}
                self._add_log(Announcement(f"{skill.icon} {actor.name}: {reactor.name} — {skill.prompt}"),
                              actor=actor, target=target)
                return
            # цель под ИИ — сразу резолвим уворот
            dodge = random.choice(options.get("dirs", ["left", "right"]))
            self._log_many(skill.resolve(actor, target, {"dir": dodge}, secret), actor, target)
        self._after_action(p["actor"], p["target"])

    def _after_action(self, actor, target):
        self._log_many(actor.pop_events() + target.pop_events(), actor, target)
        if not self._check_end():
            self._log_many(actor.summon_act(target), actor, target)   # ход призванного зверя
            self._log_many(target.pop_events(), actor, target)
        if self._check_end():
            return
        self._index += 1
        self._advance()

    @_with_rng
    def run_ai(self):
        """Пока ходит герой под управлением ИИ — играть за него."""
        while not self.finished and not self.pending and self.current.id in self.ai_ids:
            self.play_turn()

    @_with_rng
    def fight(self):
        """Провести весь бой автоматически. Возвращает победителя (или None при ничьей)."""
        self.ai_ids = {self.hero1.id, self.hero2.id}
        if self.round == 0:
            self.start()
        while not self.finished:
            self.play_turn()
        return self.winner

    # ---------- сдача и отмена ----------
    @_with_rng
    def surrender(self, hero=None):
        """Сдаться: победа засчитывается сопернику."""
        if self.finished:
            raise ValueError("Бой уже закончен")
        if hero is None:
            humans = [h for h in (self.hero1, self.hero2) if self.is_human(h)]
            hero = humans[0] if len(humans) == 1 else (self.current or self.hero1)
        if hero not in (self.hero1, self.hero2):
            raise ValueError("Этот герой не участвует в бою")
        self.pending = None
        self._add_log(Announcement(f"🏳 {hero.name} сдаётся!"), actor=hero)
        self._finish(self.opponent(hero))

    def cancel(self, reason="Бой отменён"):
        """Отменить бой без победителя и без изменения статистики."""
        if self.finished:
            raise ValueError("Бой уже закончен")
        self.pending = None
        self.finished = True
        self.cancelled = True
        self.current = None
        for h in (self.hero1, self.hero2):
            if getattr(h, "_battle", None) is self:
                h._battle = None
            if hasattr(h, "cat_form"):
                h.set_form(False)
                h.form_turns = 0
                h.switch_empower = 0.0
        self._add_log(f"⛔ {reason}.", "info")
        self._capture_arena_result()

    # ---------- конец боя ----------
    def _check_end(self):
        if self.finished:
            return True
        a1, a2 = self.hero1.is_alive(), self.hero2.is_alive()
        if a1 and a2:
            return False
        if not a1 and not a2:
            self._finish(None)
        else:
            self._finish(self.hero1 if a1 else self.hero2)
        return True

    def _finish_by_hp(self):
        p1 = self.hero1.hp / self.hero1.max_hp
        p2 = self.hero2.hp / self.hero2.max_hp
        self._add_log(f"Прошло {self.MAX_ROUNDS} раундов — решает процент здоровья.", "info")
        self._finish(None if abs(p1 - p2) < 1e-9 else (self.hero1 if p1 > p2 else self.hero2))

    def _finish(self, winner):
        self.finished = True
        self.current = None
        self.pending = None
        self.winner = winner
        # 5.4.1: снять бой с героев и сбросить боевые формы (Анниса → человек)
        for h in (self.hero1, self.hero2):
            if getattr(h, "_battle", None) is self:
                h._battle = None
            if hasattr(h, "cat_form"):
                h.set_form(False)
                h.form_turns = 0
                h.switch_empower = 0.0
        if winner is None:
            self.draw = True
            self._add_log("🤝 Ничья!", "win")
            self._capture_arena_result()
            return
        loser = self.opponent(winner)
        if getattr(self, "test_arena", False):
            self.xp = (0, 0)
            self._add_log(f"🧪 Тест: победитель {winner.name} (наград нет)", "win", actor=winner)
            self._capture_arena_result()
            return
        winner.wins += 1
        loser.losses += 1
        self.xp = self.experience_for(winner, loser) if self.story else (0, 0)
        if self.story:
            winner.gain_experience(self.xp[0])
            loser.gain_experience(self.xp[1])
        self._add_log(f"🏆 Победитель: {winner.name} ({winner.hero_class})! "
                      f"Осталось HP: {winner.hp}/{winner.max_hp}", "win", actor=winner)
        self._capture_arena_result()

    def _capture_arena_result(self):
        """Keep results intact when these heroes enter another arena fight."""
        if not self.story:
            with rng_module.use(Random(0)):
                self._final_heroes = {h.id: self._hero_view(h) for h in (self.hero1, self.hero2)}

    @staticmethod
    def experience_for(winner, loser):
        """4.0: опыт (победителю, проигравшему). За слабого соперника — меньше (защита от фарма),
        проигравший получает больше, чем раньше (25 вместо 15), особенно против сильного."""
        diff = loser.level - winner.level
        win_k = max(0.2, min(1.5, 1 + 0.25 * diff))
        lose_k = max(0.5, min(1.5, 1 - 0.25 * diff))
        return int((40 + 10 * loser.level) * win_k), int(25 * lose_k)

    @property
    def status(self):
        if self.cancelled:
            return "cancelled"
        return "finished" if self.finished else "active"

    def _hero_view(self, hero):
        """4.4/5.2: облик только на этот бой — сохранённый облик героя не трогаем.
        Ключ в skin_override (даже со значением None) = принудительный облик на бой.
        5.4.1: image берём через hero.image (Анниса кошка / Трейфус пешком) с учётом battle skin."""
        saved = getattr(self, "_final_heroes", {})
        if hero.id in saved:
            return copy.deepcopy(saved[hero.id])
        data = hero.to_dict()
        ov = getattr(self, "skin_override", {})
        if hero.id in ov:
            skin = ov[hero.id]
            data["battle_skin"] = skin
            data["skin"] = skin
            old_skin = hero.skin
            try:
                hero.skin = skin  # None = базовый портрет
                data["image"] = hero.image
            finally:
                hero.skin = old_skin
        return data

    def to_dict(self):
        data = {"id": self.id, "mode": self.mode, "round": self.round, "rounds": self.round,
                "kind": "story" if getattr(self, "story", None) else "arena",
                "status": self.status, "finished": self.finished, "draw": self.draw,
                "cancelled": self.cancelled, "secret_found": self.secret_found,
                "secret_unlocked": self.secret_unlocked,
                "hero1": self.hero1.name, "hero2": self.hero2.name,
                "hero1_id": self.hero1.id, "hero2_id": self.hero2.id,
                "heroes": [self._hero_view(self.hero1), self._hero_view(self.hero2)],
                "ai_ids": sorted(self.ai_ids),
                "winner": self.winner.name if self.winner else None,
                "winner_id": self.winner.id if self.winner else None,
                "current_hero_id": self.current.id if self.current and not self.pending else None,
                "pending": None, "log": self.log, "items": {str(k): v for k, v in self.items.items()},
                "story": self.story, "fatigue": self.hero1.fatigue, "xp": getattr(self, "xp", None),
                "test_arena": bool(getattr(self, "test_arena", False)),
                "notices": self.notices}

        if self.pending:
            p = self.pending
            data["pending"] = {"type": p["skill"].reaction, "hero_id": p["reactor"].id,
                               "attacker_id": p["actor"].id, "target_id": p["target"].id,
                               "skill": p["skill"].name, "prompt": p["skill"].prompt,
                               "options": p["options"]}
        elif self.current:
            data["available_skills"] = [s.to_dict(self.current) for s in self.current.skills.values()
                                        if self.current.can_use(s)]
            k = self.current.usable_item()
            data["available_items"] = ([{"key": "item:" + k, "item": k, "count": 1,
                                         "name": CONSUMABLES[k].title, "icon": CONSUMABLES[k].icon}] if k else [])

        return data
