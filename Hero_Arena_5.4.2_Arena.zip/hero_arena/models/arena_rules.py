"""Arena stats are independent of campaign progression.

HP bands are hard design constraints. Damage is calibrated within those bands;
the campaign keeps its existing constructors and tuning.
"""

ROLE_HP_BANDS = {
    "trickster": (150, 175),
    "light": (185, 210),
    "warrior": (220, 250),
    "tank": (265, 300),
}

ARENA_HP = {
    "warrior": 240, "mage": 185, "archer": 200, "ogre": 290,
    "spartan": 245, "assassin": 160, "samurai": 225, "druid": 195,
    "monk": 220, "darkelf": 190, "owlbeast": 270, "musketeer": 210,
    "pagan": 230, "minotaur": 280, "croc": 280, "darkknight": 250,
    "goblin": 155, "satyr": 150, "ghoul": 175, "rhino": 290,
    "bogatyr": 285, "orc": 240, "dwarf": 250, "lightelf": 190,
    "shade": 185, "aarakocra": 190, "hunter": 225, "gnoll": 175,
    "centaur": 205, "bluetroll": 170, "paladin": 275, "catfolk": 169,
    "beastlord": 300, "spiderqueen": 155, "ranger": 195,
    "pandaren": 245, "gambler": 160,
}

# Additional arena-only multipliers; final values are measured against all 37 kits.
ARENA_DAMAGE = {
    "warrior": 0.93213,
    "mage": 0.73515,
    "archer": 0.995,
    "ogre": 0.75945,
    "spartan": 0.91017,
    "assassin": 1.26577,
    "samurai": 0.39734,
    "druid": 0.50466,
    "monk": 0.8255,
    "darkelf": 0.90571,
    "owlbeast": 0.89188,
    "musketeer": 1.04492,
    "pagan": 0.8597,
    "minotaur": 0.74193,
    "croc": 0.91695,
    "darkknight": 0.9216,
    "goblin": 1.17066,
    "satyr": 1.12623,
    "ghoul": 1.1467,
    "rhino": 0.7849,
    "bogatyr": 0.79085,
    "orc": 0.93727,
    "dwarf": 0.98616,
    "lightelf": 0.89621,
    "shade": 1.02555,
    "aarakocra": 1.01906,
    "hunter": 1.01105,
    "gnoll": 1.22196,
    "centaur": 1.01983,
    "bluetroll": 1.38446,
    "paladin": 0.86208,
    "catfolk": 1.06886,
    "beastlord": 0.99815,
    "spiderqueen": 1.22059,
    "ranger": 1.01464,
    "pandaren": 0.88723,
    "gambler": 1.62201
}

# Catfolk changes combat role as well as appearance. Each form has its own HP
# maximum. Wounds are carried over as a fraction, rounded down on conversion.
CATFOLK_WARRIOR_HP = 230
