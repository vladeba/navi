// ===================== Хиро арена 4.1 =====================
// Раздельные бои (арена / сюжет), блокировка второго боя, «🚪 Выйти», сюжетные герои на странице героев,
// единый магазин обликов (облик принадлежит аккаунту), режим разработчика — любой герой.
// Подключается после v40.js и переопределяет часть функций.

const BS = {arena: null, story: null};          // состояние боя отдельно для арены и для сюжета
let viewKind = "arena";                          // какой бой сейчас показан на панели
const kindOf = b => (b && (b.kind || (b.story ? "story" : "arena"))) || "arena";
const KIND_NAME = {arena: "бой на арене", story: "сюжетный бой"};
function activeBattle() { return ["arena", "story"].map(k => BS[k]).find(b => b && b.status === "active") || null; }
function blockedMsg(b) {
  return `Уже идёт ${KIND_NAME[kindOf(b)]} №${b.id}: ${b.hero1} VS ${b.hero2}. Доиграйте его, нажмите «⛔ Отменить бой» или «🏳 Сдаться».`;
}
function goTab(t) { document.querySelector(`nav button[data-tab=${t}]`).click(); }

// ---------- Панель боя переезжает между вкладками ----------
function mountPanel(kind) {
  const panel = document.getElementById("arenaPanel");
  const slot = document.getElementById(kind === "story" ? "storyBattleSlot" : "arenaSlot");
  if (panel.previousElementSibling !== slot && panel.parentElement !== slot) slot.after(panel);
  viewKind = kind;
}
function clearArena() {      // пустая арена: ни карточек, ни журнала, ни эффектов
  shownLog = 0;
  ["f0", "f1"].forEach(id => { const el = document.getElementById(id); el.innerHTML = ""; el.className = "fighter"; });
  ["log", "skillBox", "battleCtl", "roundInfo"].forEach(id => document.getElementById(id).innerHTML = "");
  const ban = document.getElementById("banner"); ban.textContent = ""; ban.style.display = "none";
  document.getElementById("arenaPanel").style.display = "none";
  hideModal();
}
async function showKind(kind) {
  while (busy) { fast = true; await sleep(50); }      // дождаться конца анимации прошлого боя
  mountPanel(kind);
  const b = BS[kind];
  if (!b) { clearArena(); battle = null; return; }
  battle = null; resetArena(); fast = true;
  await update(b); fast = false;
}

// update запоминает бой в его «ящике» (арена или сюжет)
const _update41 = update;
update = async function (b, first = false) {
  const k = kindOf(b);
  BS[k] = b;
  if (k !== viewKind) mountPanel(k);
  return _update41(b, first);
};

// ---------- Вкладки: каждая показывает свой бой ----------
document.querySelectorAll("nav button").forEach(b => b.onclick = () => {
  document.querySelectorAll("nav button, .tab").forEach(x => x.classList.remove("active"));
  b.classList.add("active"); document.getElementById(b.dataset.tab).classList.add("active");
  const t = b.dataset.tab;
  if (t === "top") loadTop();
  else if (t === "story") { loadStory(); showKind("story"); }
  else { loadHeroes(); if (t === "battle") showKind("arena"); }
});

// ---------- Незаконченные бои игрока (после перезагрузки страницы) ----------
checkActive = async function () {
  const p = currentPlayer(), box = document.getElementById("resume");
  box.style.display = "none";
  if (!p) return;
  const r = await api(`/api/players/${p.id}/active_battle`); if (!r) return;
  ["arena", "story"].forEach(k => { if (r[k]) BS[k] = r[k]; else if (BS[k] && BS[k].status === "active") BS[k] = null; });
  const a = activeBattle();
  if (a) {
    box.style.display = "block";
    box.innerHTML = `<h2>⏸ Идёт ${KIND_NAME[kindOf(a)]}</h2><div class="row"><b>№${a.id}: ${esc(a.hero1)} VS ${esc(a.hero2)}</b>
      <span class="muted">(раунд ${a.round}) — пока он не закончен, новый бой не начать</span>
      <button class="btn small" onclick="resume(${a.id})">▶ Продолжить</button></div>`;
  }
};
resume = async function (id) {
  const b = await api(`/api/battles/${id}`); if (!b) return;
  BS[kindOf(b)] = b;
  goTab(kindOf(b) === "story" ? "story" : "battle");
};

// ---------- Старт боя: блок, если уже идёт другой ----------
function guard() {
  const a = activeBattle();
  if (a) { toast("⛔ " + blockedMsg(a)); return true; }
  return false;
}
startBattle = async function () {
  if (busy || guard()) return;
  const p = currentPlayer();
  const item = document.getElementById("battleItem").value || null;
  const b = await api("/api/battles", "POST", {
    hero1_id: +document.getElementById("h1").value, hero2_id: +document.getElementById("h2").value,
    mode: battleMode, vs_ai: document.getElementById("vsAi").checked, item, player_id: p ? p.id : null});
  if (!b) return checkActive();
  document.getElementById("resume").style.display = "none";
  mountPanel("arena"); battle = null; resetArena();
  await update(b, true);
};
let lastStage = null;
storyFight = async function (stage) {
  if (busy || guard()) return;
  const hid = document.getElementById("storyHero").value;
  const itemSel = document.getElementById("storyItem");
  const item = (itemSel && itemSel.value) || null;
  const b = await api(`/api/heroes/${hid}/story_battle`, "POST", {location: "forest", stage, mode: "manual", item});
  if (!b) return checkActive();
  lastStage = stage;
  mountPanel("story"); battle = null; resetArena();
  await update(b, true);
  document.getElementById("arenaPanel").scrollIntoView({behavior: "smooth"});
};

// ---------- Кнопки боя ----------
const _renderSkills41 = renderSkills;
renderSkills = function (b) {
  _renderSkills41(b);
  const ctl = document.getElementById("battleCtl");
  if (b.status === "active")
    ctl.innerHTML = `<button class="btn small ghost" onclick="surrender()">🏳 Сдаться</button><button class="btn small red" onclick="cancelBattle()">⛔ Отменить бой</button>`;
};
surrender = async function () { if (confirm("Сдаться? Это поражение — победа достанется сопернику.")) send(`/api/battles/${battle.id}/surrender`, {}); };
const _showResult41 = showResult;
showResult = function (b) {
  _showResult41(b);
  const story = kindOf(b) === "story";
  const st = b.story && b.story.stage;
  document.getElementById("skillBox").innerHTML =
    (story ? `<button class="btn" onclick="storyFight('${st}')">🔁 Реванш</button>` : `<button class="btn" onclick="startBattle()">🔁 Реванш</button>`) +
    ` <button class="btn ghost" onclick="exitBattle('${story ? "story" : "arena"}')">🚪 Выйти</button>` +
    (story ? ` <button class="btn ghost" onclick="exitBattle('story'); window.scrollTo({top:0,behavior:'smooth'})">🗺 К карте</button>` : "");
  document.getElementById("resume").style.display = "none";
  if (story) loadStory();
};
function exitBattle(kind) {
  BS[kind] = null; battle = null;
  clearArena();
}

// ---------- Герои: арена и сюжет, оба можно сделать активным ----------
function ownedSkins(p, type) {
  return (p && p.owned_skins || []).filter(s => s.startsWith(type + ":")).map(s => s.slice(type.length + 1));
}
const _loadHeroes41 = loadHeroes;
loadHeroes = async function () {
  await _loadHeroes41();
  const p = currentPlayer();
  // переносим сюжетных героев отдельной секцией (те же карточки, что и у героев арены)
  const story = allHeroes.filter(h => p && h.owner_id === p.id && h.story);
  const tmp = allHeroes;
  const box = document.getElementById("myStoryList");
  box.innerHTML = story.map(h => storyCard(h, p)).join("") || "<p class='muted'>Сюжетного героя нет — создайте его во вкладке «📖 Сюжет».</p>";
  // облики аккаунта — в списке у каждого героя нужного класса
  document.querySelectorAll("#myHeroList .hero, #myStoryList .hero").forEach(el => {
    const id = +el.dataset.id || +((el.getAttribute("onclick") || "").match(/\d+/) || [0])[0];
    const h = tmp.find(x => x.id === id); if (!h) return;
    const list = [...new Set([...(h.skins || []), ...ownedSkins(p, h.type)])];
    if (!list.length) return;
    let row = el.querySelector(".skinrow");
    if (!row) { row = document.createElement("div"); row.className = "row skinrow"; row.style.margin = "4px 0";
      row.onclick = e => e.stopPropagation(); const sel = el.querySelector("select"); if (sel) sel.parentElement.remove();
      el.querySelector(".body").insertBefore(row, el.querySelector(".body").lastElementChild); }
    row.innerHTML = `<span class="muted">Облик:</span><select onchange="equip(${h.id}, this.value || null)"><option value="">Обычный</option>${list.map(k => `<option value="${k}" ${h.skin === k ? "selected" : ""}>${esc(skinName(h, k))}</option>`).join("")}</select>`;
  });
  if (p && p.slots) {
    document.getElementById("arenaSlots").textContent = `(${p.slots.used}/${p.slots.max} + Совух · нажмите на карточку, чтобы сделать героя активным)`;
    document.getElementById("storySlotsH").textContent = `(${p.slots.story_used}/${p.slots.story_max} · можно сделать активным, своя сумка)`;
  }
  // режим разработчика: играть можно ЛЮБЫМ героем, в том числе героями арены
  if (p && p.dev_mode) {
    const s1 = document.getElementById("h1"), v1 = s1.value;
    const all = allHeroes.filter(h => !h.story);
    s1.innerHTML = all.map(h => `<option value="${h.id}">${h.npc ? "🛠🤖" : "👑"} ${esc(h.name)} (${h.hero_class})</option>`).join("");
    if (v1 && all.some(h => h.id == v1)) s1.value = v1;
    await loadOpponents();
    document.getElementById("groupInfo").textContent = "🛠 Режим разработчика: можно играть любым героем, включая соперников арены.";
  }
};
function storyCard(h, p) {
  const act = p && p.active_hero_id === h.id;
  const prog = Object.values(h.story_progress || {}).reduce((a, b) => a + b, 0);
  return `<div class="hero mine story-hero ${act ? "active-hero" : ""}" data-id="${h.id}" onclick="selectHero(event, ${h.id})">
    <img src="${h.image}" alt="${h.hero_class}">
    <div class="body">
      <div class="name">${esc(h.name)}</div>
      <div>${act ? `<span class="badge active">⭐ Активный</span>` : ""}<span class="badge own">📖 Сюжетный</span>${roleBadge(h)}${h.skin ? `<span class="badge">🎨 ${esc(skinName(h, h.skin))}</span>` : ""}</div>
      <div class="muted">${h.hero_class}, ур. ${h.level} · опыт ${h.experience}/100 · этапов пройдено: ${prog}</div>
      ${bars(h)}${bag(h)}
      <div class="row" onclick="event.stopPropagation()">
        <button class="btn small ghost" onclick="heal(${h.id})">💚 Вылечить</button>
        <button class="btn small ghost" onclick="openInventory(${h.id})">🎒 Инвентарь</button>
        <button class="btn small ghost" onclick="document.getElementById('storyHero').innerHTML='<option value=${h.id}></option>';goTab('story')">🗺 В сюжет</button>
        <button class="btn small red" onclick="delHero(${h.id})">Удалить</button></div>
    </div></div>`;
}

// ---------- Единый магазин: расходники для выбранного героя + облики ВСЕХ классов ----------
let shopClass = "";
renderShop = async function () {
  const p = currentPlayer();
  shop = await api("/api/shop" + (p ? `?player_id=${p.id}` : "")); if (!shop) return;
  shop.consumables.forEach(c => ITEMS[c.key] = c);
  const sel = document.getElementById("shopHero");
  const mine = allHeroes.filter(h => p && h.owner_id === p.id && h.custom);
  const old = sel.value || (p && p.active_hero_id);
  sel.innerHTML = mine.map(h => `<option value="${h.id}">${h.story ? "📖" : "⚔️"} ${esc(h.name)} (${h.hero_class})</option>`).join("");
  if (old && mine.some(h => h.id == old)) sel.value = old;
  document.getElementById("shopGold").textContent = p ? `💰 ${p.gold} зол.` : "";
  const h = mine.find(x => x.id == sel.value), body = document.getElementById("shopBody");
  let html = "";
  if (h) {
    const cnt = h.consumables || {}, inv = h.inventory;
    html += `<h3 style="margin:6px 0">🎒 Расходники для ${esc(h.name)} <span class="muted">(предметы у каждого героя свои: ${inv.items.length}/${inv.max_slots} слотов, ${inv.total_weight.toFixed(1)}/${inv.max_weight} кг · в бой — один)</span></h3>
    <div class="shop-grid">${shop.consumables.map(c => {
      const heavy = inv.total_weight + c.weight > inv.max_weight + 1e-9 || inv.items.length >= inv.max_slots;
      return `<div class="shop-card"><div class="ic">${c.icon}</div><b>${esc(c.name)}</b>
      <div class="muted">${esc(c.description)}</div><div>💰 ${c.price} · ⚖ ${c.weight} кг · в сумке ${cnt[c.key] || 0}/${c.stack_max}</div>
      <button class="btn small" ${(cnt[c.key] || 0) >= c.stack_max || p.gold < c.price || heavy ? "disabled" : ""} onclick="buy(${h.id}, '${c.key}')">${heavy ? "Слишком тяжело" : "Купить"}</button></div>`; }).join("")}</div>`;
  } else html += `<p class="muted">Расходники покупают ваши герои (арены или сюжетные). Создайте героя выше.</p>`;
  const names = Object.fromEntries(classes.map(c => [c.type, c.hero_class]));
  const types = Object.keys(shop.skins);
  html += `<div class="row" style="justify-content:space-between;margin-top:10px"><h3 style="margin:6px 0">🎨 Облики всех классов <span class="muted">(покупка — для аккаунта: надевается на ЛЮБОГО вашего героя этого класса)</span></h3>
    <select onchange="shopClass=this.value;renderShop()"><option value="">Все классы</option>${types.map(t => `<option value="${t}" ${shopClass === t ? "selected" : ""}>${esc(names[t] || t)}</option>`).join("")}</select></div>`;
  for (const t of types) {
    if (shopClass && shopClass !== t) continue;
    const heroesOfType = mine.filter(x => x.type === t);
    html += `<div class="heroes-sub">${esc(names[t] || t)} ${heroesOfType.length ? `<span class="muted">· ваши герои: ${heroesOfType.map(x => esc(x.name)).join(", ")}</span>` : `<span class="muted">· у вас нет героя этого класса</span>`}</div><div class="shop-grid">`;
    html += shop.skins[t].map(s => {
      const on = heroesOfType.filter(x => x.skin === s.skin);
      const act = s.owned
        ? (heroesOfType.length ? `<select onchange="if(this.value)equip(+this.value,'${s.skin}')"><option value="">Надеть на…</option>${heroesOfType.map(x => `<option value="${x.id}">${esc(x.name)}${x.skin === s.skin ? " ✅" : ""}</option>`).join("")}</select>` : "")
        : `<button class="btn small" ${!p || p.gold < s.price || !s.available ? "disabled" : ""} onclick="buySkin('${t}','${s.skin}')">Купить</button>`;
      return `<div class="shop-card rar-${s.rarity} ${on.length ? "equipped" : ""}">${s.available ? `<img loading="lazy" src="${s.image}" alt="${esc(s.name)}">` : `<div class="soon">🖌 Скоро<br><small>${esc(s.description || "")}</small></div>`}
        <b>${esc(s.name)}</b><div class="muted">${s.rarity_name}</div>
        <div>${s.owned ? (on.length ? `✅ надет: ${on.map(x => esc(x.name)).join(", ")}` : "✔ куплен") : s.available ? `💰 ${s.price}` : "⏳ скоро в продаже"}</div>${s.available || s.owned ? act : ""}</div>`;
    }).join("") + `</div>`;
  }
  body.innerHTML = html;
};
async function buySkin(type, skin) {
  const p = currentPlayer(); if (!p) return;
  const r = await api(`/api/players/${p.id}/buy_skin`, "POST", {type, skin});
  if (r) { toast(r.message, "ok"); await loadPlayers(); await loadHeroes(); }
}
equip = async function (heroId, skin) {
  const p = currentPlayer();
  const r = await api(`/api/heroes/${heroId}/skin`, "PUT", {player_id: p ? p.id : null, skin: skin || null});
  if (r) { toast(skin ? `🎨 ${r.name}: облик надет` : `${r.name}: обычный облик`, "ok"); await loadHeroes(); }
};

// после старта — показать, если есть, незаконченный бой
setTimeout(checkActive, 600);
