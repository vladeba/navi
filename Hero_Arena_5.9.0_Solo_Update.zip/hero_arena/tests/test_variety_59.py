"""Personal tasks: physical replays, partial results, summon rules and fair clocks."""
import copy,math,random,time,unittest
from unittest.mock import patch
from models import HERO_CLASSES
from models import minigames_59 as m
from models.summons import Hamster,Bear,Falcon,Snake,Deer,random_beast

def hero(k):
 h=HERO_CLASSES[k](k);h.configure_arena();h.reset();h.turn_number=5;h.restore_energy(999);return h

def flight_plan(o):
 # Beam search of physical flap/no-flap choices on a 100ms planning grid.
 # It is a test player, not the game's grade computation or an AI damage bonus.
 prep=o['prepare_ms'];end=o['rings'][-1]['ms']+80;beam=[([],0)]
 for t in range(prep+100,end+1,100):
  candidates=[]
  for taps,_ in beam:
   for flap in (False,True):
    acts=taps+[t] if flap and (not taps or t-taps[-1]>=220*o['factor']) else taps
    if flap and acts is taps:continue
    y,v,hits,path=m.flight(o,acts,t);next_ring=next((e for e in o['rings'] if e['ms']>t),o['rings'][-1]);remaining=max(.15,(next_ring['ms']-t)/1000);pred=y+v*min(.35,remaining)
    score=sum(hits)*1000-(len(hits)-sum(hits))*1000-abs(pred-next_ring['y'])*.6-len(acts)*.1
    candidates.append((acts,score,y,v))
  # Retain distinct position/velocity states to avoid identical-prefix collapse.
  seen=set();beam=[]
  for acts,score,y,v in sorted(candidates,key=lambda a:-a[1]):
   key=(round(y/6),round(v/25))
   if key in seen:continue
   seen.add(key);beam.append((acts,score))
   if len(beam)>=65:break
 best=max(beam,key=lambda q:sum(m.flight(o,q[0],end)[2])*1000+q[1]/1000)
 return best[0]

def winning59(skill,o):
 prep=o['prepare_ms'];f=o['factor'];c={'elapsed_ms':o['time_limit_ms']-5};mode=o['mode']
 if mode=='phalanx':
  c['engaged_ms']=prep;c['points']=[dict(t=t,x=180+95*math.cos(e['angle']),y=135+95*math.sin(e['angle'])) for e in o['arrows'] for t in (e['ms']-250,e['ms']+80)]
 elif mode in ('drawblade','slingshot','ricochet'):
  down=prep+200;up=down+500;origin=o.get('origin',[125,200]);end=o.get('exit')
  if mode=='drawblade':down=o['flash'];up=down+round(250*f)
  elif mode=='slingshot':x,y=m.jump_target(o,up);end=[125-(x-125)/2,200-(y-200)/2]
  else:end=[180,210+(o['target'][1]-210)*115/220]
  c['cuts']=[dict(down_ms=down,up_ms=up,x0=origin[0],y0=origin[1],x1=end[0],y1=end[1])]
 elif mode=='labyrinth':
  dirs=[]
  for a,b in zip(o['route'],o['route'][1:]):dirs.append({1:'right',-1:'left',4:'down',-4:'up'}[b-a])
  c['actions']=[dict(ms=prep+200+i*250,dir=d) for i,d in enumerate(dirs)]
 elif mode=='chop':
  c['cuts']=[dict(down_ms=prep+100+i*750,up_ms=prep+450+i*750,x0=70 if e['direction']==1 else 290,y0=e['y'],x1=290 if e['direction']==1 else 70,y1=e['y']) for i,e in enumerate(o['notches'])]
 elif mode=='forge':c['actions']=[dict(ms=prep+200+i*300,kind=k) for i,k in enumerate(['hit','hit','cool','hit','quench'])]
 elif mode=='updraft':c['clicks']=[dict(ms=t) for t in flight_plan(o)]
 elif mode=='chords':c['actions']=[dict(ms=e['ms'],lane=e['lane']) for e in o['notes']]
 elif mode=='stalk':c['holds']=[dict(down_ms=a+round(25*f),up_ms=b-round(25*f)) for a,b in o['safe']]
 elif mode=='scales':
  c['cuts']=[]
  for i,e in enumerate(o['layers']):
   x,y=80+100*e['cracked'],125;dx,dy=[(0,-80),(80,0),(0,80),(-80,0)][e['direction']];c['cuts'].append(dict(down_ms=prep+100+i*950,up_ms=prep+500+i*950,x0=x,y0=y,x1=x+dx,y1=y+dy))
 elif mode=='justice':
  c['placements']=[]
  for i,w in enumerate(o['weights']):
   x,y=o['sources'][i];p=o['pans'][0 if w in (1,4) else 1];c['placements'].append(dict(part=i,down_ms=prep+100+i*800,up_ms=prep+500+i*800,x0=x,y0=y,x1=p[0],y1=p[1]))
 elif mode=='stone_fit':c['placements']=[dict(part=i,down_ms=prep+100+i*900,up_ms=prep+550+i*900,x0=o['sources'][i][0],y0=220,x1=100+x*32,y1=40+y*32) for i,(x,y) in enumerate([(0,0),(1,0),(0,2)])]
 elif mode=='gallows':c['placements']=[dict(part=i,down_ms=prep+100+i*850,up_ms=prep+600+i*850,x0=80+100*i,y0=220,x1=80+100*i,y1=y) for i,y in enumerate(o['locks'])]
 elif mode=='rune_pairs':
  order=[i for card in range(3) for i,v in enumerate(o['cards']) if v==card];c['actions']=[dict(ms=o['show_until']+200+i*250,card=card) for i,card in enumerate(order)]
 elif mode=='mirror_pose':c['placements']=[dict(part=i,down_ms=prep+100+i*700,up_ms=prep+450+i*700,x0=a[0],y0=a[1],x1=b[0],y1=b[1]) for i,(a,b) in enumerate(zip(o['sources'],o['targets']))]
 elif mode=='axe_whirl':
  down=prep+100;up=down+round(2500*f);c.update(down_ms=down,up_ms=up);c['points']=[dict(t=round(down+(up-down)*i/80),x=180+75*math.cos(-math.pi/2+4*math.pi*i/80),y=130+75*math.sin(-math.pi/2+4*math.pi*i/80)) for i in range(81)]
 elif mode=='web_net':
  xs=[x for x,y in o['flies']];ys=[y for x,y in o['flies']];targets=[[min(xs)-12,min(ys)-12],[max(xs)+12,min(ys)-12],[max(xs)+12,max(ys)+12],[min(xs)-12,max(ys)+12]];c['placements']=[dict(part=i,down_ms=prep+100+i*750,up_ms=prep+500+i*750,x0=a[0],y0=a[1],x1=b[0],y1=b[1]) for i,(a,b) in enumerate(zip(o['corners'],targets))]
 elif mode=='assembly':
  c['rotations']=[];c['placements']=[];t=prep+150
  for i,angle in enumerate(o['angles']):
   for n in range((-angle)%4):c['rotations'].append(dict(part=i,ms=t));t+=100
   a,b=o['sources'][i],o['slots'][i];c['placements'].append(dict(part=i,down_ms=t+100,up_ms=t+450,x0=a[0],y0=a[1],x1=b[0],y1=b[1]));t+=650
 return c

class Personal59(unittest.TestCase):
 def test_all_personal_tasks_have_real_reachable_input_and_fail_on_score_claim(self):
  for (h,k),spec in m.SPECS.items():
   with self.subTest(hero=h,key=k):
    user=hero(h);skill=user.skills[k];o=skill.public_options(user,hero('warrior'));c=winning59(skill,o);self.assertEqual(skill.tier_from(c,o),0,(h,k,o,c));self.assertEqual(skill.tier_from({'score':999,'elapsed_ms':o['time_limit_ms']},o),3)
 def test_mordred_requires_completed_stages_and_rotation(self):
  h=hero('darkknight');s=h.skills['plague'];o=s.public_options(h,hero('warrior'));c=winning59(s,o)
  for n,tier in [(0,3),(1,3),(2,2),(3,2),(4,1),(6,1),(7,0)]:
   choice={**c,'placements':c['placements'][:n]};self.assertEqual(s.tier_from(choice,o),tier,n)
  c['rotations']=[];self.assertEqual(s.tier_from(c,o),1)
 def test_personal_controls_reject_future_and_unelapsed_input(self):
  for (k,key),spec in m.SPECS.items():
   h=hero(k);t=hero('warrior');s=h.skills[key];o=s.public_options(h,t);c=winning59(s,o)
   with patch.object(s,'apply',side_effect=lambda a,b,tier,d:tier):
    secret=dict(options=o,started=time.time()-30,deadline=time.time()+10)
    self.assertEqual(s.resolve(h,t,c,secret),0,key);self.assertEqual(s.resolve(h,t,c,{**secret,'started':time.time()}),3,key);self.assertEqual(s.resolve(h,t,{**c,'elapsed_ms':0},secret),3,key)
 def test_druid_only_dead_hamster_unlocks_next_summon_and_reset_restores_first(self):
  for pet_class in [Hamster,Falcon,Snake,Deer,Bear]:
   h=hero('druid');s=h.skills['summon_beast'];self.assertTrue(s.is_available(h));h.summon=pet_class(h);self.assertFalse(s.is_available(h));h.summon.hp=0;self.assertEqual(s.is_available(h),pet_class is Hamster,pet_class);h.reset();self.assertTrue(s.is_available(h))
 def test_hamster_odds_slightly_above_snake_and_falcon_and_boss_unchanged(self):
  from models import DruidBoss
  h=hero('druid')
  with patch('random.choices',return_value=[Hamster]) as choose:random_beast(h);self.assertEqual(choose.call_args.kwargs['weights'],[25,23,22,18,12])
  boss=DruidBoss('boss');boss.summon=Bear(boss);boss.summon.hp=0;self.assertTrue(boss.skills['summon_beast'].is_available(boss))
 def test_forge_spamming_hot_metal_is_not_ideal(self):
  h=hero('dwarf');s=h.skills['fusion'];o=s.public_options(h,hero('warrior'));c=winning59(s,o);c['actions']=[a for a in c['actions'] if a['kind']!='cool'];self.assertNotEqual(s.tier_from(c,o),0)
 def test_hold_every_gaze_is_not_successful_stalking(self):
  h=hero('catfolk');s=h.skills['pounce'];o=s.public_options(h,hero('warrior'));c={'elapsed_ms':o['time_limit_ms'],'holds':[dict(down_ms=o['prepare_ms'],up_ms=o['time_limit_ms'])]};self.assertEqual(s.tier_from(c,o),3)
 def test_future_assembly_parts_and_rotations_are_not_accepted_early(self):
  h=hero('darkknight');t=hero('warrior');s=h.skills['plague'];o=s.public_options(h,t);c=winning59(s,o);c['elapsed_ms']=o['prepare_ms']+10
  with patch.object(s,'apply',side_effect=lambda u,t,tier,data:tier):
   self.assertEqual(s.resolve(h,t,c,dict(options=o,started=time.time()-2,deadline=time.time()+10)),3)
 def test_every_flight_ring_layout_is_reachable_even_with_short_game(self):
  import itertools
  h=hero('aarakocra');s=h.skills['talon']
  for factor in (1,.7):
   s._time_multiplier=factor
   for ys in itertools.permutations([95,150,195]):
    o=s.public_options(h,hero('warrior'))
    for e,y in zip(o['rings'],ys):e['y']=y
    self.assertEqual(s.tier_from(winning59(s,o),o),0,(factor,ys))
 def test_all_drums_patterns_leave_time_to_repeat_the_full_rhythm(self):
  h=hero('minotaur');s=h.skills['drums']
  for _ in range(300):
   o=s.public_options(h,hero('warrior'));last=o['beats_ms'][-1];listen=300+last+o['listen_pause_ms'];self.assertGreaterEqual(o['time_limit_ms']-listen,last+400)
 def test_stone_fit_rejects_overlap_and_off_board_stones(self):
  h=hero('rhino');s=h.skills['stone_armor'];o=s.public_options(h,hero('warrior'));c=winning59(s,o)
  self.assertEqual(s.tier_from(c,o),0)
  for a in c['placements']:a.update(x1=100,y1=40)
  self.assertNotEqual(s.tier_from(c,o),0)
  for a in c['placements']:a.update(x1=324,y1=232)
  self.assertEqual(s.tier_from(c,o),3)
 def test_ai_prioritizes_healer_without_changing_minion_health_or_lifetime(self):
  from models import Battle
  u=hero('warrior');enemy=hero('getou');b=Battle(u,enemy);enemy.raise_minion('zombie',0);enemy.raise_minion('skeleton',0)
  healer=next(s for s in enemy.living_minions() if s.kind=='skeleton');healer.hp=min(healer.hp,u.get_damage()*4)
  self.assertIs(b._selected_target(u,None,True),healer)
  self.assertIs(b._selected_target(u,'hero',False),enemy)
 def test_paladin_aegis_cannot_be_stolen_but_ordinary_shields_still_can(self):
  from models.effects import Shield
  u=hero('paladin');t=hero('goblin');u.skills['divine_shield']._perform(u,t)
  shield=next(e for e in u.get_effects() if isinstance(e,Shield));self.assertFalse(shield.stealable)
  t.skills['steal']._after_hit(t,u,1);self.assertIn(shield,u.get_effects());self.assertFalse(t.has_effect(Shield))
  plain=Shield(3,30);self.assertTrue(getattr(plain,'stealable',True))
 def test_personal_input_names_are_not_a_palette_swap(self):
  modes=[s['mode'] for s in m.SPECS.values()];self.assertEqual(len(modes),len(set(modes)));self.assertEqual(len(modes),19)

if __name__=='__main__':unittest.main()
