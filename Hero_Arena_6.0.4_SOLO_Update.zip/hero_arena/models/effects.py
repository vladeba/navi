"""Эффекты (статусы) в бою: базовый класс Effect и его наследники.

Эффект висит на герое несколько ходов. В начале каждого хода владельца
вызывается on_turn_start(): яд/горение наносят урон, оглушение не даёт ходить.
Потом tick() уменьшает длительность, истёкшие эффекты снимаются (on_expire()).
"""


class Announcement(str):
    """Строка-«объявление» о ключевом событии боя (Вальхалла, легендарный клинок...).

    Это обычная строка (наследник str), но бой узнаёт её по типу и
    подсвечивает в журнале и всплывающим уведомлением.
    """


class Effect:
    """Базовый эффект. Наследники переопределяют нужные «хуки»."""

    name = "Эффект"
    icon = "•"
    positive = False   # бафф (True) или дебафф (False)
    stacks = False     # складывается ли сила при повторном наложении

    def __init__(self, duration=1, power=0):
        self.duration = duration   # сколько ходов владельца ещё действует
        self.power = power         # сила эффекта (урон за ход, размер щита...)

    # ----- хуки, которые переопределяют наследники -----
    def on_turn_start(self, owner):
        """Вызывается в начале хода владельца. Возвращает список строк лога."""
        return []

    def on_expire(self, owner):
        """Вызывается, когда эффект закончился. Возвращает список строк лога."""
        return []

    def prevents_action(self):
        """True, если владелец пропускает ход (оглушение)."""
        return False

    def modify_incoming(self, owner, damage, attacker):
        """Изменить входящий урон (щит, контратака). Возвращает (урон, лог)."""
        return damage, []

    def damage_bonus(self):
        """Добавка к множителю урона владельца (0.4 = +40%)."""
        return 0.0

    def dodge_bonus(self):
        """Добавка к шансу уклонения владельца."""
        return 0.0

    # ----- 4.0: новые хуки -----
    def speed_bonus(self):
        """Добавка к скорости (инициативе) владельца."""
        return 0

    def accuracy_bonus(self):
        """Добавка к точности атак владельца (−0.15 = −15%)."""
        return 0.0

    def crit_bonus(self):
        """Добавка к шансу крита владельца."""
        return 0.0

    def armor_bonus(self):
        """Добавка к броне владельца."""
        return 0

    def blocks_stun(self):
        """True — владелец не может быть оглушён (Оберег, Несокрушимость)."""
        return False


    # ----- общая логика -----
    def tick(self):
        self.duration -= 1

    def is_expired(self):
        return self.duration <= 0

    def describe(self):
        return f"{self.icon} {self.name} ({self.duration} х.)"

    def to_dict(self):
        from .help_58 import effect_help
        return {"type": self.__class__.__name__, "name": self.name, "icon": self.icon,
                "duration": self.duration, "power": self.power, "positive": self.positive,
                "help":effect_help(self)}

    def __str__(self):
        return self.describe()


# ---------- Урон со временем (DoT) ----------
class DamageOverTime(Effect):
    """Наносит power урона каждый ход, броня не защищает."""

    verb = "получает урон"

    def on_turn_start(self, owner):  # переопределение
        dmg = self.power
        resist = getattr(owner, "DOT_RESIST", 0.0)   # 4.4: «Богатырское здоровье»
        if resist:
            dmg = max(1, int(round(dmg * (1 - resist))))
        if hasattr(owner, 'take_dot_damage'):
            dmg = owner.take_dot_damage(dmg)
        else:
            owner.hp = owner.hp - dmg
        return [f"{self.icon} {owner.name} {self.verb}: −{dmg} HP ({self.name})."]


class Burn(DamageOverTime):
    name, icon, verb = "Горение", "🔥", "горит"


class Bleed(DamageOverTime):
    name, icon, verb = "Кровотечение", "🩸", "истекает кровью"


class DeepBleed(Bleed):
    """Рваная рана лучника: при повторном наложении сила СКЛАДЫВАЕТСЯ."""

    name, stacks = "Рваная рана", True


class Poison(DamageOverTime):
    """Яд: урон растёт каждый ход."""

    name, icon, verb = "Яд", "☠", "страдает от яда"

    def on_turn_start(self, owner):  # переопределение: яд усиливается
        logs = super().on_turn_start(owner)
        self.power += 2
        return logs


class Acid(DamageOverTime):
    name, icon, verb = "Кислота", "🧪", "разъедается кислотой"


class DarkCurse(DamageOverTime):
    """Проклятие тьмы: урон каждый ход и −20% к урону жертвы."""

    name, icon, verb = "Проклятие тьмы", "🌑", "терзаем тьмой"

    def damage_bonus(self):  # переопределение
        return -0.2


# ---------- Контроль ----------
class Stun(Effect):
    """Оглушение: владелец пропускает ход."""

    name, icon = "Оглушение", "💫"

    def prevents_action(self):  # переопределение
        return True

    def on_turn_start(self, owner):
        return [f"💫 {owner.name} оглушён и пропускает ход!"]


# ---------- Баффы ----------
class Regeneration(Effect):
    """Регенерация: +power HP в начале каждого хода."""

    name, icon, positive = "Регенерация", "🌿", True

    def on_turn_start(self, owner):
        healed = owner.heal(self.power)
        return [f"🌿 {owner.name} восстанавливает +{healed} HP."] if healed else []


class Antiheal(Effect):
    """Запрет исцеления (удар ладонью монаха): любое лечение и регенерация не работают,
    щиты владельца ослаблены (поглощающий щит берёт вдвое меньше, Каменный щит режет 25% вместо 50%)."""

    name, icon = "Запрет исцеления", "🚫"


class Shield(Effect):
    """Щит: поглощает power урона."""

    name, icon, positive = "Щит", "🛡", True

    def modify_incoming(self, owner, damage, attacker):  # переопределение
        pierce = getattr(attacker, "shield_pierce", 0)    # тёмный эльф пробивает часть щита
        passed = int(damage * pierce)
        absorbed = min(self.power, damage - passed)
        notes = ""
        if owner.has_effect(Antiheal):                      # ослабленный щит держит вдвое меньше
            absorbed //= 2
            notes += " (ослаблен 🚫)"
        if passed:
            notes += f", {passed} урона проходит сквозь щит"
        self.power -= absorbed
        if self.power <= 0:
            self.duration = 0
        return damage - absorbed, [f"🛡 Щит {owner.name} поглощает {absorbed} урона{notes}."] if absorbed or passed else []


class StoneSkin(Shield):
    name, icon = "Каменная кожа", "🪨"


class StoneShield(Effect):
    """Каменный щит огра: −50% ЛЮБОГО урона (даже магии), сильные удары его раскалывают."""
    stealable = False   # 4.4: «форма»/особое состояние героя — «Кража» Газ-Лоу её не забирает

    name, icon, positive = "Каменный щит", "🗿", True
    NORMAL_MULTIPLIER=.45
    WEAK_MULTIPLIER=.75
    STRONG_HIT = 30   # урон, начиная с которого щит трескается

    def modify_incoming(self, owner, damage, attacker):  # переопределение
        weak = owner.has_effect(Antiheal)                   # запрет исцеления ослабляет щит: −25% вместо −50%
        reduced = max(1, int(damage * (self.WEAK_MULTIPLIER if weak else self.NORMAL_MULTIPLIER)))
        logs = [f"🗿 Каменный щит {owner.name} гасит {damage - reduced} урона{' (ослаблен 🚫)' if weak else ''}."]
        if damage >= self.STRONG_HIT and self.duration > 1:
            self.duration -= 1
            logs.append(f"💥 Сильный удар раскалывает Каменный щит (осталось {self.duration} х.)!")
        return reduced, logs

    def on_expire(self, owner):
        return [Announcement(f"🗿 Каменный щит {owner.name} рассыпается!")]


class Berserk(Effect):
    """Ярость берсерка: +power% урона (по умолчанию 40)."""

    name, icon, positive = "Берсерк", "😡", True

    def __init__(self, duration=3, power=40):
        super().__init__(duration, power)

    def damage_bonus(self):
        return self.power / 100


class Evasion(Effect):
    """Дымовая завеса: +35% к уклонению."""

    name, icon, positive = "Дымовая завеса", "🌫", True

    def dodge_bonus(self):
        return 0.35


class Invisibility(Effect):
    """Невидимость лучника: первый ход он прячется (не атакует), потом +50% уклонения."""

    name, icon, positive = "Невидимость", "👻", True

    def __init__(self, duration=4, power=50):
        super().__init__(duration, power)
        self._first = True

    def on_turn_start(self, owner):
        if self._first:
            return [f"👻 {owner.name} крадётся в тени и в этот ход не атакует."]
        return []

    def prevents_action(self):
        return self._first

    def tick(self):  # переопределение: после первого хода «прятки» заканчиваются
        super().tick()
        self._first = False

    def dodge_bonus(self):
        return self.power / 100

    def on_expire(self, owner):
        return [Announcement(f"👁 {owner.name} снова виден!")]


class CounterStance(Effect):
    """Контратака: возвращает часть полученного урона атакующему."""

    name, icon, positive = "Контратака", "↩", True

    def modify_incoming(self, owner, damage, attacker):  # переопределение
        if attacker is None or damage <= 0:
            return damage, []
        back = max(1, int(damage * self.power / 100))
        attacker.hp = attacker.hp - back
        return damage, [f"↩ {owner.name} контратакует: {attacker.name} получает {back} урона."]


class Contract(Effect):
    """Контракт на убийство (ассасин): до конца боя, −24% получаемого урона."""
    stealable = False   # 4.4: «форма»/особое состояние героя — «Кража» Газ-Лоу её не забирает

    name, icon, positive = "Контракт на убийство", "📜", True

    def __init__(self):
        super().__init__(duration=999, power=24)

    def tick(self):  # не истекает до конца боя
        pass

    def modify_incoming(self, owner, damage, attacker):
        return max(1, int(damage * (100 - self.power) / 100)), []


class Intimidated(Effect):
    """Устрашение (Рёв совуха): владелец бьёт слабее."""

    name, icon = "Устрашение", "😨"

    def damage_bonus(self):  # переопределение
        return -self.power / 100


# ================= 4.0: новые эффекты =================
class DodgeBuff(Effect):
    """+power% уклонения (Дымовая шашка, Перезарядка мушкетёра, дар Велеса)."""

    name, icon, positive = "Уклонение", "💨", True

    def dodge_bonus(self):
        return self.power / 100


class Slow(Effect):
    """Замедление: −power скорости (Топот, Штык, Сеть охотника, Снегопад)."""

    name, icon = "Замедление", "🐌"

    def speed_bonus(self):
        return -self.power


class Netted(Slow):
    """Сеть охотника: −3 скорости и −15% уклонения."""

    name, icon = "Сеть", "🕸"

    def dodge_bonus(self):
        return -0.25


class Blinded(Effect):
    """Проклятие на точность (Шёпот Велеса, Аура страха): −power% точности."""

    name, icon = "Проклятие точности", "🌫"

    def accuracy_bonus(self):
        return -self.power / 100


class FearAura(Effect):
    """Аура страха Мордреда: −15% урона и −10% точности."""

    name, icon = "Аура страха", "😱"

    def damage_bonus(self):
        return -0.15

    def accuracy_bonus(self):
        return -0.10


class Weakened(Effect):
    """«Ты слаб» тёмного эльфа: −20% урона, получаемый урон +10%."""

    name, icon = "Ты слаб", "🥀"

    def damage_bonus(self):
        return -0.20

    def modify_incoming(self, owner, damage, attacker):
        return int(damage * 1.1), []


class CritBuff(Effect):
    """Талисман удачи: +power% к шансу крита."""

    name, icon, positive = "Удача", "🍀", True

    def crit_bonus(self):
        return self.power / 100


class Sharpened(Berserk):
    """Точильный камень: +power% урона."""

    name, icon = "Заточка", "🪨"


class StunWard(Effect):
    """Оберег стойкости: иммунитет к оглушению и +power брони."""

    name, icon, positive = "Оберег", "🧿", True

    def blocks_stun(self):
        return True

    def armor_bonus(self):
        return self.power


class DamageReduction(Effect):
    """Снижение получаемого урона на power% (Стена щитов, Несокрушимость, Сборка панциря)."""

    name, icon, positive = "Стойка", "🛡", True

    def __init__(self, duration=2, power=25, stun_immune=False, title=None):
        super().__init__(duration, power)
        self.stun_immune = stun_immune
        if title:
            self.name = title

    def blocks_stun(self):
        return self.stun_immune

    def modify_incoming(self, owner, damage, attacker):
        cut = int(damage * self.power / 100)
        return max(1, damage - cut), ([f"🛡 {self.name}: {owner.name} гасит {cut} урона."] if cut else [])


class Chill(DamageOverTime):
    """Холод (Морена, Снегопад): урон каждый ход, броня не защищает."""

    name, icon, verb = "Холод", "❄", "мёрзнет"


class Undying(Effect):
    """«Последняя клятва» Мордреда: HP не падает ниже 1 от ударов."""
    stealable = False   # 4.4: «форма»/особое состояние героя — «Кража» Газ-Лоу её не забирает

    name, icon, positive = "Последняя клятва", "☠", True

    def modify_incoming(self, owner, damage, attacker):
        if damage >= owner.hp:
            return max(0, owner.hp - 1), [f"☠ Клятва держит {owner.name} на ногах!"]
        return damage, []


class CalmShield(Shield):
    """«Спокойствие» самурая: щит, который при поломке бьёт атакующего."""

    name, icon = "Спокойствие", "🍃"

    def __init__(self, duration, power, burst=10):
        super().__init__(duration, power)
        self.burst = burst

    def modify_incoming(self, owner, damage, attacker):
        damage, logs = super().modify_incoming(owner, damage, attacker)
        if self.power <= 0 and attacker is not None and self.burst:
            attacker.hp = attacker.hp - self.burst
            logs.append(f"🍃 Спокойствие ломается — волна ки бьёт {attacker.name}: −{self.burst} HP.")
            self.burst = 0
        return damage, logs


class MastBuff(Effect):
    """«Какой ты масти?» ассасина: +power% урона по цели (зависит от роли цели), 4 хода."""

    name, icon, positive = "Масть", "🃏", True

    def damage_bonus(self):
        return self.power / 100


class GodGift(Effect):
    """Дар бога (Молитва язычника): Перун, Велес, Мокошь или Морена."""

    positive = True
    GODS = {"perun": ("Дар Перуна", "⚡"), "veles": ("Дар Велеса", "🐍"),
            "mokosh": ("Дар Мокоши", "🌾"), "morena": ("Дар Морены", "❄")}

    def __init__(self, god, duration=3, power=4):
        super().__init__(duration, power)
        self.god = god
        self.name, self.icon = self.GODS[god]

    def dodge_bonus(self):
        return 0.2 if self.god == "veles" else 0.0

    def armor_bonus(self):
        return 1 if self.god == "mokosh" else 0

    def on_turn_start(self, owner):
        if self.god == "mokosh":
            healed = owner.heal(max(1, int(owner.max_hp * 0.02)))
            return [f"🌾 Мокошь лечит {owner.name}: +{healed} HP."] if healed else []
        return []

    def to_dict(self):
        data = super().to_dict()
        data["god"] = self.god
        return data


class BeastForm(Effect):
    """«Оборотень» язычника: форма волка, медведя или ворона."""

    positive = True
    FORMS = {"wolf": ("Форма волка", "🐺"), "bear": ("Форма медведя", "🐻"), "raven": ("Форма ворона", "🐦‍⬛")}

    def __init__(self, form, duration=4, quality=1.0):
        super().__init__(duration, int(quality * 100))
        self.form, self.quality = form, quality
        self.name, self.icon = self.FORMS[form]

    def speed_bonus(self):
        return round(3 * self.quality) if self.form == "wolf" else 0

    def armor_bonus(self):
        return round(3 * self.quality) if self.form == "bear" else 0

    def dodge_bonus(self):
        return 0.20 * self.quality if self.form == "raven" else 0.0

    def to_dict(self):
        data = super().to_dict()
        data["form"] = self.form
        return data


class ShellStance(Effect):
    """«Панцирь» Крока: получаемый урон −(20% + 0.2% за пункт Сытости), до −40%.
    Каждый ход Сытость −25 и лечение 2% HP (пока она есть). Свой урон −30%, броня +2."""

    name, icon, positive = "Панцирь", "🐊", True

    def __init__(self, duration=3, fixed=None, stun_immune=False):
        super().__init__(duration, 0)
        self.fixed = fixed            # «Сборка панциря»: фиксированное снижение
        self.stun_immune = stun_immune

    def reduction(self, owner):
        if self.fixed is not None:
            return self.fixed
        return min(40, 20 + int(getattr(owner, "satiety", 0) * 0.2))

    def blocks_stun(self):
        return self.stun_immune

    def damage_bonus(self):
        return -0.30

    def armor_bonus(self):
        return 2

    def modify_incoming(self, owner, damage, attacker):
        cut = int(damage * self.reduction(owner) / 100)
        return max(1, damage - cut), ([f"🐊 Панцирь {owner.name} гасит {cut} урона."] if cut else [])

    def on_turn_start(self, owner):
        logs = []
        if getattr(owner, "satiety", 0) > 0 and self.fixed is None:
            owner.satiety = max(0, owner.satiety - 25)
            healed = owner.heal(max(1, int(owner.max_hp * 0.02)))
            if healed:
                logs.append(f"🐊 {owner.name} переваривает добычу: +{healed} HP (сытость {owner.satiety}).")
        return logs

    def on_expire(self, owner):
        owner.lunge_ready = True
        return [Announcement(f"🐊 {owner.name} выходит из панциря — следующий удар ×1.3!")]


class MeleeMode(Effect):
    """«Смена ремесла» лучника: 5 ходов меч и кинжал вместо лука."""

    name, icon, positive = "Ближний бой", "🗡", True

    def on_expire(self, owner):
        return [Announcement(f"🏹 {owner.name} снова берётся за лук!")]
