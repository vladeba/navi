"""5.8 requested kit changes; old skill/save IDs and arena HP bands survive."""
from .skills import DamageSkill,SelfBuffSkill,MiniGameSkill,Skill,scale_effect
from .effects import Slow,Bleed,Poison,DodgeBuff,DamageOverTime,Stun,Announcement
from .summons import Summon
from .minigames_58 import SPECS,adapt

class Frostbite58(DamageOverTime):
    name,icon='Обморожение','❄'

class PlagueCompanion(Summon):
    HP=(45,55,70); DAMAGE=(5,6,7); LIFE=3; GHOUL_HEAL=2
    def __init__(self,owner,stage):
        self.stage=stage;self.age=0;self.freeze_used=False
        self.name=('Скелет Плети','Вурдалак Плети','Костяной дракон')[stage]
        self.icon=('💀','🧟','🐉')[stage]
        self.about=('Самостоятельно атакует и прикрывает хозяина',
                    'После успешного удара лечит хозяина на 2 HP, себя на 3 HP',
                    'Замедляет попаданием; со второго успешного удара один раз замораживает на ход')[stage]
        super().__init__(owner,max_hp=self.HP[stage],damage=self.DAMAGE[stage],armor=(1,1,2)[stage],intercept_chance=.25)
        self.lifetime=self.LIFE;self.accuracy=.85
    def attack(self,target):
        before=target.hp;logs=super().attack(target)
        if before>target.hp:
            self.age+=1
            if self.stage==1:
                heal=self.owner.heal(round(self.GHOUL_HEAL*self.owner.power_scale()));self.hp+=round(3*self.owner.power_scale())
                if heal:logs.append(f'🧟 Вурдалак лечит {self.owner.name}: +{heal} HP.')
            if self.stage==2 and target.is_alive():
                target.add_effect(Slow(2,1));target.add_effect(scale_effect(Frostbite58(2,2),self.owner))
                if self.age>=2 and not self.freeze_used:
                    self.freeze_used=True
                    if target.add_effect(Stun(1)):logs.append(f'❄ Костяной дракон замораживает {target.name} на 1 ход!')
        return logs
    def to_dict(self):return {**super().to_dict(),'stage':self.stage+1,'freeze_used':self.freeze_used}

class FormStrike58(DamageSkill):
    copyable=False
    def __init__(self,*a,cat=False,**kw):super().__init__(*a,**kw);self.cat=cat
    def is_available(self,user):return super().is_available(user) and bool(user.cat_form)==self.cat
    def ai_score(self,user,target):return super().ai_score(user,target) if bool(user.cat_form)==self.cat else 0

class CatEscape58(Skill):
    copyable=False
    def is_available(self,user):return super().is_available(user) and user.cat_form
    def _perform(self,user,target):
        healed=user.heal(round(user.max_hp*.04));user.add_effect(DodgeBuff(2,15))
        return [f'🐈 Кошачий уход: {user.name} +{healed} HP и +15% уклонения на 2 хода.']
    def ai_score(self,user,target):
        if not user.cat_form or user.has_effect(DodgeBuff):return 0
        from .ai import healing
        return 6+healing(user,user.max_hp*.04)

ADDITIONS={
 'feliss':lambda:[DamageSkill('tail_sweep','Подсечка хвостом','×1.0 и −2 скорости на 2 хода; не требует Слабого места',multiplier=1.0,effect=lambda:Slow(2,2),cost=18,cooldown=4,icon='🦎')],
 'getou':lambda:[DamageSkill('grave_needle','Ядовитый шип','Слабый личный удар ×0.25 и яд 1 HP на 2 хода; работает без призывов',multiplier=.25,effect=lambda:Poison(2,1),cost=12,cooldown=3,icon='☠')],
 'catfolk':lambda:[
    FormStrike58('hunter_blade','Клинок охотницы','Только человек: удар ×1.15, пробивает 25% брони',multiplier=1.15,armor_pierce=.25,cost=16,cooldown=3,icon='🗡'),
    FormStrike58('claw_dash','Рывок когтей','Только кошка: два удара по ×0.6 и кровотечение 2 HP на 2 хода',cat=True,multiplier=.6,hits=2,effect=lambda:Bleed(2,2),cost=22,cooldown=3,icon='🐾'),
    CatEscape58('cat_escape','Кошачий уход','Только кошка: лечение 4% HP и +15% уклонения на 2 хода',cost=22,cooldown=5,icon='🐈')],
}

def install(classes):
    touched={h for h,_ in SPECS}|set(ADDITIONS)
    for key in touched:
        cls=classes[key];old=cls._create_skills
        def factory(self,_old=old,_key=key):
            skills=[]
            for skill in _old(self):
                s=SPECS.get((_key,skill.key))
                if s:skill=adapt(skill,s)
                if _key=='feliss' and skill.key=='venom_sting':skill.description='×1.1 и яд на 3 хода: сила 3, по цели со Слабым местом — 4'
                if _key=='darkknight' and skill.key=='plague':skill.min_turn=3
                skills.append(skill)
            for (hero,key),s in SPECS.items():
                if hero!=_key or not s.get('new'):continue
                skill=MiniGameSkill(key,s['title'],s['reward'],cost=s['cost'],cooldown=s['cd'],icon=s['icon'])
                skills.append(adapt(skill,s))
            skills.extend(ADDITIONS[_key]() if _key in ADDITIONS else [])
            if _key in ('getou','feliss'):
                for sk in skills:sk.copyable=False
            return skills
        cls._create_skills=factory
    from .heroes_new import DruidBoss
    DruidBoss.PASSIVE_NOTES=tuple(getattr(DruidBoss,'PASSIVE_NOTES',()))
    classes['druid'].PASSIVE_NOTES=tuple(getattr(classes['druid'],'PASSIVE_NOTES',()))+(lambda c:'«Прощальный дар»: за гибель хомяка +%s HP, змеи +%s, сокола +%s, оленя +%s, медведя +%s; один раз на зверя. После гибели можно призвать нового.'%tuple(c.PARTING_HEAL[k] for k in ('Hamster','Snake','Falcon','Deer','Bear')),)
    classes['leon'].PASSIVE_NOTES=tuple(getattr(classes['leon'],'PASSIVE_NOTES',()))+('«Прорез щита»: 29% прямого урона проходит сквозь поглощающие щиты',)
