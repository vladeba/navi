"""Shared game version for both entrypoints and the sharing helper."""
APP_VERSION = "6.0.4-solo-review"
