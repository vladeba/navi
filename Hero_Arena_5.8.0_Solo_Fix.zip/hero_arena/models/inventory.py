"""Инвентарь героя."""


class Inventory:
    """Хранит предметы и следит за ограничением веса."""

    def __init__(self, max_weight=5.0, max_slots=10):   # 4.0: сумка — 10 ячеек и до 5 кг

        self.max_weight = max_weight
        self.max_slots = max_slots
        self._items = []  # защищённый список: менять только через методы

    @property
    def total_weight(self):
        return sum(item.weight for item in self._items)

    def add_item(self, item):
        """Добавить предмет, проверив вес и количество слотов."""
        if len(self._items) >= self.max_slots:
            raise ValueError(f"Сумка заполнена: все {self.max_slots} слотов заняты")
        if self.total_weight + item.weight > self.max_weight + 1e-9:
            raise ValueError(f"Слишком тяжело: в сумке {self.total_weight:.1f} кг, «{item.name}» весит "
                             f"{item.weight:.1f} кг, а максимум {self.max_weight:.0f} кг")

        self._items.append(item)

    def remove_item(self, item_id):
        for item in self._items:
            if item.id == item_id:
                self._items.remove(item)
                return item
        raise KeyError(f"Предмет {item_id} не найден в инвентаре")

    def get_items(self):
        return list(self._items)  # копия, чтобы снаружи не испортили список

    def __len__(self):
        return len(self._items)

    def to_dict(self):
        return {"items": [i.to_dict() for i in self._items],
                "total_weight": round(self.total_weight, 2), "free_slots": self.max_slots - len(self._items),

                "max_weight": self.max_weight, "max_slots": self.max_slots}
