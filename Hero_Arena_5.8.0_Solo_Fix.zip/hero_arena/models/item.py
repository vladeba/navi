"""Предметы: базовый класс Item и наследники Weapon, Potion."""
import random


class Item:
    """Базовый предмет, который можно положить в инвентарь."""

    _next_id = 1  # счётчик id на уровне класса

    def __init__(self, name, price, weight=1.0, rarity="обычный"):
        self.id = Item._next_id
        Item._next_id += 1
        self.name = name
        self.price = price
        self.weight = weight
        self.rarity = rarity

    def use(self, character):
        """Использовать предмет. В базовом классе ничего не делает."""
        return f"{self.name}: ничего не произошло."

    def describe(self):
        return f"Предмет «{self.name}» ({self.rarity}), цена {self.price} зол."

    def to_dict(self):
        return {"id": self.id, "type": self.__class__.__name__, "name": self.name,
                "price": self.price, "weight": self.weight, "rarity": self.rarity}

    def __str__(self):
        return self.describe()


class Weapon(Item):
    """Оружие: увеличивает урон героя."""

    def __init__(self, name, price, damage_bonus, weight=3.0, rarity="обычный"):
        super().__init__(name, price, weight, rarity)
        self.damage_bonus = damage_bonus

    def use(self, character):  # переопределение
        character.equip(self)
        return f"{character.name} экипирует «{self.name}» (+{self.damage_bonus} к урону)."

    def describe(self):  # переопределение
        return f"Оружие «{self.name}»: +{self.damage_bonus} урона, цена {self.price} зол."

    def to_dict(self):
        data = super().to_dict()
        data["damage_bonus"] = self.damage_bonus
        return data


class Potion(Item):
    """Зелье: восстанавливает здоровье."""

    def __init__(self, name, price, heal_amount, weight=0.5, rarity="обычный"):
        super().__init__(name, price, weight, rarity)
        self.heal_amount = heal_amount

    def use(self, character):  # переопределение
        healed = character.heal(self.heal_amount)
        return f"{character.name} выпивает «{self.name}» и восстанавливает {healed} HP."

    def describe(self):  # переопределение
        return f"Зелье «{self.name}»: лечит {self.heal_amount} HP, цена {self.price} зол."

    def to_dict(self):
        data = super().to_dict()
        data["heal_amount"] = self.heal_amount
        return data


class Katana(Weapon):
    """Катана самурая. Наследники — конкретные клинки с разными свойствами.

    Шансы выпадения при создании самурая: обычная 45%, Йочерин 22.5%,
    Кёчерин 22.5%, легендарная Масамунэ 10%.
    """

    chance = 0
    legendary = False

    def __init__(self, name, damage_bonus, counter_chance=0.1, dodge_bonus=0.0,
                 bleed_chance=0.15, enemy_dodge=None, never_miss=False, fate_chance=0.0,
                 armor_pierce=0.0, price=100, rarity="обычный"):
        super().__init__(name, price, damage_bonus, weight=2.0, rarity=rarity)
        self.counter_chance = counter_chance   # шанс контратаки при получении удара
        self.dodge_bonus = dodge_bonus         # добавка к уклонению самурая
        self.bleed_chance = bleed_chance       # шанс наложить кровотечение при попадании
        self.enemy_dodge = enemy_dodge         # если задано — уклонение врага считается таким
        self.never_miss = never_miss           # никогда не промахивается
        self.fate_chance = fate_chance         # шанс «Удара судьбы» (100 урона)
        self.armor_pierce = armor_pierce       # 5.2: доля брони цели, которую клинок пробивает

    @staticmethod
    def roll():
        """Случайная катана по шансам выпадения (фабричный метод)."""
        classes = [OrdinaryKatana, Yoshirin, Kyocherin, Masamune]
        cls = random.choices(classes, weights=[c.chance for c in classes])[0]
        return cls()

    def describe(self):  # переопределение
        parts = [f"+{self.damage_bonus} урона", f"контратака {int(self.counter_chance * 100)}%",
                 f"кровотечение {int(self.bleed_chance * 100)}%"]
        if self.dodge_bonus:
            parts.append(f"+{int(self.dodge_bonus * 100)}% уклонения")
        if self.enemy_dodge is not None:
            parts.append(f"враг уклоняется лишь в {int(self.enemy_dodge * 100)}%")
        if self.never_miss:
            parts.append("не промахивается")
        if self.armor_pierce:
            parts.append(f"пробивание брони {int(self.armor_pierce * 100)}%")
        if self.fate_chance:
            parts.append(f"«Удар судьбы» {int(self.fate_chance * 100)}%")
        star = "⭐ " if self.legendary else ""
        return f"{star}Катана «{self.name}» ({self.rarity}): " + ", ".join(parts)

    def to_dict(self):
        data = super().to_dict()
        data.update(counter_chance=self.counter_chance, dodge_bonus=self.dodge_bonus,
                    bleed_chance=self.bleed_chance, enemy_dodge=self.enemy_dodge,
                    never_miss=self.never_miss, fate_chance=self.fate_chance,
                    armor_pierce=self.armor_pierce,
                    legendary=self.legendary, description=self.describe())
        return data


class OrdinaryKatana(Katana):
    chance = 45

    def __init__(self):
        super().__init__("Обычная катана", damage_bonus=3, counter_chance=0.15,   # 4.0: усилена
                         dodge_bonus=0.07, bleed_chance=0.25)


class Yoshirin(Katana):
    chance = 22.5

    def __init__(self):
        super().__init__("Йочерин", damage_bonus=3, counter_chance=0.3, dodge_bonus=0.12,
                         bleed_chance=0.15, rarity="редкий")


class Kyocherin(Katana):
    chance = 22.5

    def __init__(self):
        super().__init__("Кёчерин", damage_bonus=3, counter_chance=0.1, bleed_chance=0.4,
                         enemy_dodge=0.01, rarity="редкий")


class Masamune(Katana):
    chance = 10
    legendary = True

    def __init__(self):
        # 4.0: больше НЕ «никогда не промахивается» — враг уклоняется лишь в 2% случаев
        # 5.2: +3 урона (как сильные катаны) и 25% пробивания брони — удачный ролл ощутим,
        # но не ломает общий винрейт самурая (~10% дропа)
        super().__init__("Масамунэ", damage_bonus=3, counter_chance=0.22, dodge_bonus=0.05,
                         bleed_chance=0.32, enemy_dodge=0.02, fate_chance=0.03,
                         armor_pierce=0.25, price=1000, rarity="легендарный")



KATANAS = {cls.__name__: cls for cls in (OrdinaryKatana, Yoshirin, Kyocherin, Masamune)}


# ---------- Расходники для боя (магазин 3.3, переработаны в 4.0) ----------
class Consumable(Item):
    """Расходник: лежит в сумке КОНКРЕТНОГО героя и применяется в бою вместо умения (тратит ход).

    4.0: в бой берётся один предмет; лечение и щиты считаются в % от макс. HP;
    у каждого предмета есть вес и класс, против которого он слабее (weak_vs → эффект ×0.5).
    """

    key = "consumable"
    title = "Расходник"
    icon = "📦"
    stack_max = 10          # сколько штук может лежать в сумке
    battle_usable = True
    description = ""
    weak_vs = None          # 4.0: type_key класса, против которого предмет слабее
    WEAK_FACTOR = 0.5

    def __init__(self, name, price, weight=0.5, rarity="обычный"):
        super().__init__(name, price, weight, rarity)

    def power(self, user, target):
        """Сила предмета: ×0.5 против «неудобного» класса, растёт с уровнем героя."""
        k = user.power_scale() if hasattr(user, "power_scale") else 1.0
        if target is not None and self.weak_vs and getattr(target, "type_key", None) == self.weak_vs:
            k *= self.WEAK_FACTOR
        return k

    def weak_note(self, target):
        if target is not None and self.weak_vs and getattr(target, "type_key", None) == self.weak_vs:
            return " (слабее против этого класса)"
        return ""

    def battle_use(self, user, target):
        """Применить в бою. Возвращает строки лога. Наследники переопределяют."""
        return [f"{self.icon} {user.name} достаёт «{self.name}», но ничего не происходит."]

    def ai_score(self, user, target):
        """Насколько ИИ хочет применить предмет сейчас (сравнивается с лучшим умением)."""
        return 10

    def use(self, character):  # переопределение: вне боя — без соперника
        return " ".join(self.battle_use(character, None))

    def describe(self):  # переопределение
        return f"{self.icon} «{self.name}»: {self.description}. Цена {self.price} зол., вес {self.weight} кг"

    def to_dict(self):
        data = super().to_dict()
        data.update(key=self.key, icon=self.icon, stack_max=self.stack_max,
                    description=self.description, weak_vs=self.weak_vs)
        return data


class Kunai(Consumable):
    title = "Кунай"
    key, icon, stack_max, weak_vs = "kunai", "🗡", 5, "spartan"
    description = "Бросок: 22–27 урона сквозь броню, точность 90%. Слабее против спартанца (щит)"

    def __init__(self):
        super().__init__(self.title, price=15, weight=0.2)

    def battle_use(self, user, target):  # переопределение
        if random.random() > max(0.1, 0.9 - target.get_dodge() / 2):
            return [f"🗡 {user.name} бросает кунай — мимо!"]
        dmg = target.take_damage(int(random.randint(22, 27) * self.power(user, target)), ignore_armor=True, attacker=None)
        return [f"🗡 {user.name} бросает кунай: {dmg} урона по {target.name}!{self.weak_note(target)}"]

    def ai_score(self, user, target):
        return 9


class HealingPotion(Consumable):
    title = "Зелье лечения"
    key, icon, stack_max, weak_vs = "heal_potion", "🧪", 3, "monk"
    description = "+11% макс. HP (не работает под «Запретом исцеления»). Слабее против монаха"

    def __init__(self):
        super().__init__(self.title, price=25, weight=0.5)

    def battle_use(self, user, target):  # переопределение
        k = self.WEAK_FACTOR if target is not None and target.type_key == self.weak_vs else 1.0
        healed = user.heal(int(user.max_hp * 0.11 * k))
        return [f"🧪 {user.name} выпивает зелье лечения: +{healed} HP.{self.weak_note(target)}"]

    def ai_score(self, user, target):
        return 30 if user.hp < user.max_hp * 0.4 else 0


class EnergyPotion(Consumable):
    title = "Зелье маны/энергии"
    key, icon, stack_max, weak_vs = "energy_potion", "🔷", 3, "warrior"
    description = "+110 к ресурсу героя (мана, ярость, энергия…). Слабее против воина"

    def __init__(self):
        super().__init__(self.title, price=20, weight=0.5)

    def battle_use(self, user, target):  # переопределение
        before = user.energy
        k = self.WEAK_FACTOR if target is not None and target.type_key == self.weak_vs else 1.0
        user.restore_energy(int(110 * k))
        return [f"🔷 {user.name} пьёт зелье: +{user.energy - before} ({user.resource_name}).{self.weak_note(target)}"]

    def ai_score(self, user, target):
        return 16 if user.energy < 25 else 0


class Bomb(Consumable):
    title = "Бомба"
    key, icon, stack_max, weak_vs = "bomb", "💣", 2, "ogre"
    description = "19–24 урона, 35% оглушить на 1 ход. Слабее против огра"

    def __init__(self):
        super().__init__(self.title, price=35, weight=1.0, rarity="редкий")

    def battle_use(self, user, target):  # переопределение
        from models.effects import Stun   # локальный импорт: нет цикла импортов
        dmg = target.take_damage(int(random.randint(19, 24) * self.power(user, target)), attacker=None)
        logs = [f"💣 {user.name} кидает бомбу: {dmg} урона по {target.name}!{self.weak_note(target)}"]
        if target.is_alive() and random.random() < 0.3 and target.add_effect(Stun(1)):
            logs.append(f"💫 {target.name} оглушён взрывом!")
        return logs

    def ai_score(self, user, target):
        return 11


# ----- 4.0: новые предметы -----
class SmokeBomb(Consumable):
    title = "Дымовая шашка"
    key, icon, stack_max, weak_vs = "smoke_bomb", "💨", 3, "archer"
    description = "+45% уклонения на 4 хода. Слабее против лучника"

    def __init__(self):
        super().__init__(self.title, price=25, weight=0.4)

    def battle_use(self, user, target):
        from models.effects import DodgeBuff
        k = self.WEAK_FACTOR if target is not None and target.type_key == self.weak_vs else 1.0
        user.add_effect(DodgeBuff(4, int(45 * k)))
        return [f"💨 {user.name} бросает дымовую шашку: +{int(45 * k)}% уклонения на 4 хода.{self.weak_note(target)}"]

    def ai_score(self, user, target):
        return 12 if user.hp < user.max_hp * 0.6 else 4


class StunWardCharm(Consumable):
    title = "Оберег стойкости"
    key, icon, stack_max, weak_vs = "ward", "🧿", 2, "darkelf"
    description = "5 ходов: иммунитет к оглушению и +6 брони. Слабее против тёмного эльфа"

    def __init__(self):
        super().__init__(self.title, price=30, weight=0.3, rarity="редкий")

    def battle_use(self, user, target):
        from models.effects import StunWard
        armor = 2 if target is not None and target.type_key == self.weak_vs else 6
        user.add_effect(StunWard(5, armor))
        return [f"🧿 {user.name} надевает оберег: иммунитет к оглушению, +{armor} брони на 5 ходов."]

    def ai_score(self, user, target):
        return 13 if user.hp < user.max_hp * 0.7 else 5


class CleansingScroll(Consumable):
    title = "Свиток очищения"
    key, icon, stack_max, weak_vs = "cleanse", "📜", 2, "assassin"
    description = "Снимает все дебаффы (яд, горение, проклятия) и лечит 10% HP. Слабее против ассасина"

    def __init__(self):
        super().__init__(self.title, price=30, weight=0.2, rarity="редкий")

    def battle_use(self, user, target):
        bad = [e for e in user.get_effects() if not e.positive]
        user._effects = [e for e in user.get_effects() if e.positive]
        k = self.WEAK_FACTOR if target is not None and target.type_key == self.weak_vs else 1.0
        healed = user.heal(int(user.max_hp * 0.10 * k))
        names = ", ".join(e.name for e in bad) or "нечего снимать"
        return [f"📜 {user.name} читает свиток очищения: снято — {names}; +{healed} HP."]

    def ai_score(self, user, target):
        return 6 + 8 * sum(1 for e in user.get_effects() if not e.positive)


class RegenElixir(Consumable):
    title = "Эликсир регенерации"
    key, icon, stack_max, weak_vs = "regen_elixir", "🌿", 3, "monk"
    description = "Регенерация 2.5% макс. HP в ход на 4 хода. Слабее против монаха"

    def __init__(self):
        super().__init__(self.title, price=30, weight=0.5)

    def battle_use(self, user, target):
        from models.effects import Regeneration
        k = self.WEAK_FACTOR if target is not None and target.type_key == self.weak_vs else 1.0
        per = max(1, int(user.max_hp * 0.025 * k))
        user.add_effect(Regeneration(4, per))
        return [f"🌿 {user.name} пьёт эликсир регенерации: +{per} HP в ход на 4 хода."]

    def ai_score(self, user, target):
        return 22 if user.hp < user.max_hp * 0.55 else 0


class PoisonVial(Consumable):
    title = "Ядовитая склянка"
    key, icon, stack_max, weak_vs = "poison_vial", "🧫", 3, "druid"
    description = "Яд на 3 хода (3 в ход и растёт). Слабее против друида"

    def __init__(self):
        super().__init__(self.title, price=25, weight=0.4)

    def battle_use(self, user, target):
        from models.effects import Poison
        power = max(1, int(round(3 * self.power(user, target))))
        target.add_effect(Poison(3, power))
        return [f"🧫 {user.name} разбивает ядовитую склянку: {target.name} отравлен ({power}/ход).{self.weak_note(target)}"]

    def ai_score(self, user, target):
        from models.effects import Poison
        return 0 if target.has_effect(Poison) else 12


class Whetstone(Consumable):
    title = "Точильный камень"
    key, icon, stack_max, weak_vs = "whetstone", "🪨", 2, "spartan"
    description = "+50% урона на 5 ходов. Слабее против спартанца"

    def __init__(self):
        super().__init__(self.title, price=30, weight=0.8)

    def battle_use(self, user, target):
        from models.effects import Sharpened
        k = self.WEAK_FACTOR if target is not None and target.type_key == self.weak_vs else 1.0
        user.add_effect(Sharpened(5, int(50 * k)))
        return [f"🪨 {user.name} точит оружие: +{int(50 * k)}% урона на 5 ходов."]

    def ai_score(self, user, target):
        return 11


class HunterNet(Consumable):
    title = "Сеть охотника"
    key, icon, stack_max, weak_vs = "net", "🕸", 2, "assassin"
    description = "Сеть: 11–14 урона, 35% запутать (пропуск хода), −3 скорости и −25% уклонения врага на 3 хода. Слабее против ассасина"

    def __init__(self):
        super().__init__(self.title, price=25, weight=1.0)

    def battle_use(self, user, target):
        from models.effects import Netted
        turns = 1 if target.type_key == self.weak_vs else 3
        from models.effects import Stun
        dmg = target.take_damage(int(random.randint(11, 14) * self.power(user, target)), attacker=None)
        target.add_effect(Netted(turns, 3))
        logs = [f"🕸 {user.name} набрасывает сеть: {dmg} урона, {target.name} медленнее и хуже уклоняется ({turns} х.)."]
        if target.is_alive() and random.random() < (0.15 if turns == 1 else 0.35) and target.add_effect(Stun(1)):
            logs.append(f"🕸 {target.name} запутался в сети и пропустит ход!")
        return logs

    def ai_score(self, user, target):
        return 9 + 20 * target.get_dodge()


class LuckTalisman(Consumable):
    title = "Талисман удачи"
    key, icon, stack_max, weak_vs = "luck", "🍀", 2, "monk"
    description = "+60% к шансу крита и +12% уклонения на 5 ходов. Слабее против монаха"

    def __init__(self):
        super().__init__(self.title, price=30, weight=0.1, rarity="редкий")

    def battle_use(self, user, target):
        from models.effects import CritBuff
        k = self.WEAK_FACTOR if target is not None and target.type_key == self.weak_vs else 1.0
        from models.effects import DodgeBuff
        user.add_effect(CritBuff(5, int(60 * k)))
        user.add_effect(DodgeBuff(5, int(12 * k)))
        return [f"🍀 {user.name} сжимает талисман удачи: +{int(60 * k)}% крита и +{int(12 * k)}% уклонения на 5 ходов."]

    def ai_score(self, user, target):
        return 10


CONSUMABLES = {cls.key: cls for cls in (Kunai, HealingPotion, EnergyPotion, Bomb, SmokeBomb, StunWardCharm,
                                        CleansingScroll, RegenElixir, PoisonVial, Whetstone, HunterNet,
                                        LuckTalisman)}

# ---------- Облики (скины) ----------
# 3.3: по 3 обычных облика на каждый класс: static/images/skins/<класс>_<облик>.png
# 4.0: у обликов есть редкость. Старые 3 — «Обычные» и подешевели (120 → 80).
SKINS = {"gold": ("Золотой", 80), "blood": ("Кровавый", 80), "frost": ("Ледяной", 80)}
RARITIES = {"common": ("⚪ Обычный", 80), "rare": ("🔵 Редкий", 250), "epic": ("🟣 Эпический", 600),
            "legendary": ("🟡 Легендарный", 1500), "mythic": ("🔴 Мифический", 4000)}   # 4.2: мифический


_PROTOTYPES = {}


def consumable_prototype(key):
    """4.0: образец расходника (для оценки ИИ и витрины) — создаётся один раз и не тратит id предметов."""
    if key not in _PROTOTYPES:
        saved = Item._next_id
        _PROTOTYPES[key] = CONSUMABLES[key]()
        Item._next_id = saved
    return _PROTOTYPES[key]
