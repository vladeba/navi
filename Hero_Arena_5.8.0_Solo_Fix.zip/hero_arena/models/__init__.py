"""Пакет моделей (классов предметной области)."""
from .item import (Item, Weapon, Potion, Katana, OrdinaryKatana, Yoshirin, Kyocherin, Masamune, KATANAS,
                   Consumable, Kunai, HealingPotion, EnergyPotion, Bomb, CONSUMABLES, SKINS)
from .inventory import Inventory
from .character import (Character, Warrior, Mage, Archer, Ogre, Spartan, Assassin,
                        Samurai, Druid, Monk, DarkElf, Owlbeast, HERO_CLASSES)
from .effects import (Announcement, Effect, DamageOverTime, Burn, Bleed, DeepBleed, Poison, Acid,
                      DarkCurse, Stun, Regeneration, Shield, StoneSkin, StoneShield, Berserk,
                      Evasion, Invisibility, CounterStance, Contract, Antiheal, Intimidated)
from .skills import (Skill, DamageSkill, HealSkill, SelfBuffSkill, BackstabSkill, LifestealSkill,
                     SummonSkill, ReactionSkill, ContractSkill, WeaknessSkill, DebuffSkill)
from .summons import Summon, Bear, Falcon, Snake, Hamster, WaterSpirit, BEASTS, random_beast
from .player import Player
from .battle import Battle
from .heroes_new import (Musketeer, Pagan, Minotaur, Croc, DarkKnight, Wolf, GhostCat, BloodBear, GreatDeer, DruidBoss,
                         Mob, NEW_HEROES, MOBS)
from .skills import MiniGameSkill, ChoiceSkill
from .summons import Deer, Clone, SkeletonSquad, BeastCompanion
from .item import (SmokeBomb, StunWardCharm, CleansingScroll, RegenElixir, PoisonVial, Whetstone, HunterNet,
                   LuckTalisman, RARITIES)
from .skin_themes import SKIN_THEMES
from .story import STORY, Location, Stage, StoryBattle
from .heroes_42 import (GazLow, Satyr, Ghoul, Rhino, Durrila, Orc, Dwarf, LightElf, Nefruit, NEW_HEROES_42,
                        CatchShadowSkill, BogatyrStrike, AimDodgeSkill)
from .heroes_54 import (Aarakocra, Hunter, Gnoll, Centaur, BlueTroll, Paladin, Catfolk, BeastLord,
                        SpiderQueen, Ranger, Pandaren, Gambler, NEW_HEROES_54, DEFAULT_NAMES_54)
from .summons import OwlNephews, Decoy, ForestSpirit


# 4.3: случайность моделей — через прокси (генератор конкретного боя, см. models/rng.py)
from . import rng as _rng, battle as _b, character as _c, heroes_42 as _h42, heroes_new as _hn, item as _it, \
    minigames as _mg, minigames_42 as _mg42, skills as _sk, summons as _su, story as _st
from . import heroes_54 as _h54, minigames_54 as _mg54, mage_skills as _mage
from .heroes_55 import Keltazar,Feliss,Cyclops,Mersey,Leon
from .necromancy_55 import Getou
from . import heroes_55 as _h55, rituals_55 as _r55, necromancy_55 as _n55
_rng.install(_b, _c, _h42, _hn, _h54, _it, _mg, _mg42, _mg54, _mage, _h55, _r55, _n55, _sk, _su, _st)

from . import passives_56 as _p56
_p56.install(HERO_CLASSES)

from . import minigames_56 as _mg56
_rng.install(_mg56)
_mg56.install(HERO_CLASSES)

from . import minigames_58 as _mg58, rework_58 as _rw58
_rng.install(_mg58)
_rw58.install(HERO_CLASSES)
