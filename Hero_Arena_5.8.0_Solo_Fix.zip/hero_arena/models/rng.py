"""4.3: генератор случайных чисел боя.

Модели пользуются `random` как обычно, но вместо модуля им подставлен прокси RNG: если для текущего
потока включён генератор конкретного боя (with use(battle.rng)), вызовы идут в него, иначе — в общий
модуль random. Так seed одного боя (только режим разработчика / тесты) не трогает глобальный ГСЧ
и другие бои, а моки random.random в тестах продолжают работать."""
import contextlib
import random as _random
import threading

_local = threading.local()


class _RandomProxy:
    """Прокси с тем же интерфейсом, что модуль random (random(), choice(), uniform()...)."""

    def __getattr__(self, name):
        rng = getattr(_local, "rng", None)
        return getattr(rng if rng is not None else _random, name)


RNG = _RandomProxy()


@contextlib.contextmanager
def use(rng):
    """Временно направить случайность моделей в генератор rng (None — общий random)."""
    prev = getattr(_local, "rng", None)
    _local.rng = rng
    try:
        yield rng
    finally:
        _local.rng = prev


def install(*modules):
    for m in modules:
        if getattr(m, "random", None) is _random:
            m.random = RNG
