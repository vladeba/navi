"""Input-replayed games for the six new heroes. No client-supplied score is trusted."""
import math
import random
import time
from .skills import MiniGameSkill, scale_effect
from .effects import Announcement, Stun, Blinded, Bleed
from .mage_skills import integer, sequence


LIMITS={'dread_flinch':4200,'blood_split':0,'blood_tide':5500,'prey_track':4500,
 'scale_pressure':3000,'weakpoint_bar':5500,'watchful_nogo':6200,'horn_streak':5000,
 'stone_balance':5000,'fang_drift':5000,'execution_charge':4500,'sentence_hold':5000,
 'slit_gaze':5000,'blade_orbits':6500,'king_risk':5500,'predator_afterimage':4000,
 'royal_read':9000,'raise_bones':9000,'raise_zombie':6000,'build_homunculus':8000,
 'puppet_threads':6000,'flesh_suture':8000}
SUPPORT={'watchful_nogo','stone_balance','royal_read','raise_bones','raise_zombie',
         'build_homunculus','puppet_threads','flesh_suture'}


def number(v,default=0,low=-1e6,high=1e6):
    return float(v) if isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and low<=v<=high else default


def points(choice,limit):
    result=[];last=-1
    for p in sequence(choice,'points',500):
        if not isinstance(p,dict):return []
        t=integer(p.get('t'),high=limit)
        if t<=last:return []
        result.append([t,number(p.get('x'),-999,-1,360),number(p.get('y'),-999,-1,260)]);last=t
    return result


def interpolate(path,t,stepped=False):
    if not path:return -999,-999
    if t<=path[0][0]:return path[0][1:]
    for a,b in zip(path,path[1:]):
        if t<b[0]:
            f=0 if stepped else (t-a[0])/max(1,b[0]-a[0])
            return a[1]+f*(b[1]-a[1]),a[2]+f*(b[2]-a[2])
    return path[-1][1:]


def tracked(choice,o):
    path=points(choice,o['time_limit_ms']);inside=0
    if not path or number(choice.get('elapsed_ms'))<o['time_limit_ms']*.9:return 0
    eligible=0
    for t in range(0,o['time_limit_ms'],40):
        if o.get('stepped'):
            last=max((p[0] for p in o['path'] if p[0]<=t),default=0)
            if t-last<o.get('reaction_grace_ms',0):continue
        eligible+=1
        x,y=interpolate(path,t);tx,ty=interpolate(o['path'],t,o.get('stepped',False))
        if math.hypot(x-tx,y-ty)<=o['radius']:inside+=1
    return inside/max(1,eligible)


def taps(choice,limit):
    result=[];last=-100
    for value in sequence(choice,'taps',120):
        t=integer(value,high=limit)
        if t<0 or t-last<55:return []
        result.append(t);last=t
    return result


def pressure(choice,o):
    value=best=0.;last=0
    events=[(t,10) for t in taps(choice,o['time_limit_ms'])]+[(t,-p) for t,p in o['kicks']]
    for t,delta in sorted(events):
        value=max(0,value-(t-last)*.009)+delta;value=max(0,min(100,value));best=max(best,value);last=t
    return best


def bar_value(choice,o):
    t=integer(choice.get('stop_ms'),high=o['time_limit_ms']) if isinstance(choice,dict) else -1
    return abs(math.sin(2*math.pi*(t+o['phase'])/o['period'])) if t>=0 else -10


def intersections(nodes,edges):
    def side(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    total=0
    for i,(a,b) in enumerate(edges):
        for c,d in edges[i+1:]:
            if len({a,b,c,d})<4:continue
            s1,s2=side(nodes[a],nodes[b],nodes[c]),side(nodes[a],nodes[b],nodes[d])
            s3,s4=side(nodes[c],nodes[d],nodes[a]),side(nodes[c],nodes[d],nodes[b])
            overlap=max(min(nodes[a][0],nodes[b][0]),min(nodes[c][0],nodes[d][0]))<=min(max(nodes[a][0],nodes[b][0]),max(nodes[c][0],nodes[d][0]))+1e-6 and max(min(nodes[a][1],nodes[b][1]),min(nodes[c][1],nodes[d][1]))<=min(max(nodes[a][1],nodes[b][1]),max(nodes[c][1],nodes[d][1]))+1e-6
            if s1*s2<=1e-6 and s3*s4<=1e-6 and overlap:total+=1
    return total


def assembly_count(choice,o):
    correct=set()
    for p in sequence(choice,'placements',20):
        if not isinstance(p,dict):continue
        part=integer(p.get('part'),high=len(o['slots'])-1)
        slot=integer(p.get('slot'),high=len(o['slots'])-1)
        if part>=0 and slot==o['slots'][part]:
            if 'locks' in o:
                ms=integer(p.get('ms'),high=o['time_limit_ms'])
                if ms<0:continue
                period,phase=o['locks'][part]
                if abs(math.sin(2*math.pi*(ms+phase)/period))>o['lock_width']:continue
            correct.add(part)
    return correct


class Ritual(MiniGameSkill):
    copyable=False
    TIERS=('Идеал','Хорошо','Частично','Срыв')
    AI_WEIGHTS=(35,45,15,5)
    TIER_VALUE=(2.1,1.6,1,.4)
    def __init__(self,*a,game,**kw):
        super().__init__(*a,**kw);self.game=game;self.TIME_LIMIT_MS=LIMITS[game]
        self.prompt=self.description;self.deals_damage=game not in SUPPORT
        values={'prey_track':(1.3,1,.6,0),'scale_pressure':(1.9,1.5,1,.5),
            'weakpoint_bar':(2.2,1.7,1.1,.5),'horn_streak':(2.1,1.7,1.4,1.2),
            'fang_drift':(1.5,1.2,.9,.45),'execution_charge':(3,2.2,1.3,0),
            'sentence_hold':(2.1,1.6,.9,0),'slit_gaze':(.7,.5,.3,0),
            'blade_orbits':(1.9,1.5,1,.4),'king_risk':(2,1.6,1.2,.5),
            'predator_afterimage':(1.6,1.3,.9,.3)}
        self.TIER_VALUE=values.get(game,(1,1,1,1) if game in SUPPORT or game in ('dread_flinch','blood_split') else self.TIER_VALUE)
        if game=='puppet_threads':
            self.TIERS=('Без пересечений','1 пересечение','2 пересечения','3 пересечения','4+ пересечения');self.AI_WEIGHTS=(25,35,25,10,5);self.TIER_VALUE=(1,1,1,1,0)
        if game=='flesh_suture':
            self.TIERS=('4 шва','3 шва','2 шва','1 шов','Срыв');self.AI_WEIGHTS=(25,35,25,10,5);self.TIER_VALUE=(1,1,1,1,0)
    def describe_for(self,user):
        if self.game in ('raise_bones','raise_zombie','build_homunculus'):
            from .necromancy_55 import STATS
            kind={'raise_bones':'skeleton','raise_zombie':'zombie','build_homunculus':'homunculus'}[self.game]
            hp,dmg,armor,life=STATS[kind][0]
            factor=user.summon_power() if hasattr(user,'summon_power') else 1
            return f'Идеал: {round(hp*user.power_scale())} HP, урон {round(dmg*user.power_scale()*factor)}, {life} раундов · '+self.description
        if self.game=='dread_flinch':return f'Урон иссушения при идеале {round(4*user.power_scale())} × 2 хода; ослабление и лечение · '+self.description
        if self.game=='blood_split':return f'Урон ×0.6–3.0; лечение до {round(user.get_damage()*2)} HP; зависит от распределения · '+self.description
        mult=self.TIER_VALUE[0]
        target=getattr(user,'_combat_target',None) or user.opponent
        if self.game in ('weakpoint_bar','scale_pressure') and target:
            from .heroes_55 import marks
            e=marks(target,user);mult+=.2*(e.power if e else 0)
        if self.game=='blood_tide':mult=2.1*(1+(1-user.hp/user.max_hp)*.8)
        if self.game=='fang_drift':mult=1.5+.2*getattr(user,'focus',0)
        return (f'Урон при идеале ~{round(user.get_damage()*mult)} ({mult:g}× силы) · ' if self.deals_damage else '')+self.description
    def is_available(self,user):
        if not super().is_available(user):return False
        if self.game.startswith(('raise_','build_')):
            kind={'raise_bones':'skeleton','raise_zombie':'zombie','build_homunculus':'homunculus'}[self.game]
            return hasattr(user,'can_summon') and user.can_summon(kind)
        if self.game=='puppet_threads':return hasattr(user,'living_minions') and bool(user.living_minions())
        if self.game=='flesh_suture':return hasattr(user,'living_minions') and (user.hp<user.max_hp or any(s.hp<s.max_hp for s in user.living_minions()))
        return True
    def pay(self,user):
        if not self.is_available(user):raise ValueError('Для этого ритуала нет подходящего слота или существа')
        super().pay(user)
    def game_params(self,user,target):
        from .heroes_55 import marks
        limit=max(900,round(self.TIME_LIMIT_MS*getattr(self,'_time_multiplier',1))) if self.TIME_LIMIT_MS else 0
        o={'time_limit_ms':limit,'accent':'#bba2ed','hero_type':getattr(user,'type_key',''),'power':user.get_damage() if user else 10}
        e=marks(target,user) if user is not None and target is not None else None
        stacks=e.power if e else 0
        o['stacks']=stacks;o['focus']=getattr(user,'focus',0)
        if self.game in ('prey_track','fang_drift','sentence_hold'):
            jump=self.game=='prey_track';step=max(120,round((450 if jump else 800)*limit/self.TIME_LIMIT_MS))
            o.update(path=[[t,random.randint(65,295),random.randint(55,205)] for t in range(0,limit+step,step)],
                     radius=28 if jump else 38,stepped=jump,reaction_grace_ms=round(180*limit/self.TIME_LIMIT_MS) if jump else 0)
        if self.game in ('blood_tide','weakpoint_bar','slit_gaze','execution_charge'):
            missing=1-user.hp/user.max_hp if user else 0
            o.update(period=round(2600-1500*missing) if self.game=='blood_tide' else 2400,
                phase=random.randint(0,1800),width=.1+.06*stacks if self.game=='weakpoint_bar' else .18-.12*missing if self.game=='blood_tide' else .10,
                missing=missing)
        if self.game in ('dread_flinch','watchful_nogo'):
            count=4 if self.game=='dread_flinch' else 6
            times=[round((i+.55+random.uniform(-.10,.10))*limit/count) for i in range(count)]
            real={random.randrange(count)} if count==4 else set(random.sample(range(count),3))
            o['flashes']=[{'ms':t,'true':i in real} for i,t in enumerate(times)];o['window']=300
        if self.game=='scale_pressure':
            o['kicks']=[[t,random.randint(13,22)*(1-.2*stacks)] for t in sorted(random.sample(range(350,limit-150,100),4))]
        if self.game=='horn_streak':
            o['beats']=[round(limit*v) for v in (.14,.30,.44,.56,.67,.77,.86,.94)]
            o['windows']=[max(45,130-12*i) for i in range(8)]
        if self.game=='stone_balance':
            o['kicks']=[[t,random.choice((-1,1))*random.uniform(.15,.28)] for t in range(350,limit,450)]
        if self.game=='blade_orbits':o.update(periods=[1900,2700],phases=[random.randint(0,1800),random.randint(0,2600)])
        if self.game=='flesh_suture':o.update(suture_period=round(1200*limit/self.TIME_LIMIT_MS),green=[.5,.75],attempts=4)
        if self.game=='royal_read':
            openings=[random.randrange(3)]
            for _ in range(3):openings.append(random.choice([i for i in range(3) if i!=openings[-1]]))
            ready=round(limit/3);o['prepare_ms']=ready
            o['stances']=[{'start':ready+round(i*(limit-ready)/4),'end':ready+round((i+1)*(limit-ready)/4),'open':lane} for i,lane in enumerate(openings)]
        if self.game=='predator_afterimage':o.update(target=[random.randint(60,300),random.randint(50,210)],show_ms=min(900,limit//3))
        if self.game in ('raise_bones','raise_zombie','build_homunculus'):
            n={'raise_bones':9,'raise_zombie':3,'build_homunculus':5,'flesh_suture':4}[self.game]
            o.update(slots=random.sample(range(n),n),parts=n)
            if self.game=='build_homunculus':
                o['slots']=list(range(n))
                factor=limit/self.TIME_LIMIT_MS
                o['locks']=[[round(random.randint(1100,1500)*factor),random.randint(0,1200)] for _ in range(n)]
                o['lock_width']=.38
        if self.game=='puppet_threads':
            pos=[[180+110*math.cos(i*math.pi/4),130+100*math.sin(i*math.pi/4)] for i in range(8)]
            edges=[[i,(i+1)%8] for i in range(8)]
            order=list(range(8))
            for _ in range(100):
                random.shuffle(order)
                if intersections([pos[i] for i in order],edges)==4:break
            o.update(nodes=[pos[i] for i in order],edges=edges)
        return o
    def secret_pick(self,options=None):
        secret=super().secret_pick(options);secret['started']=time.time()
        if self.game=='king_risk':secret['rupture_ms']=random.randint(2400,5400)
        return secret
    def resolve(self,user,target,choice,secret):
        o=secret.get('options',{});limit=o.get('time_limit_ms',self.TIME_LIMIT_MS)
        if isinstance(choice,dict) and limit:
            claimed=number(choice.get('elapsed_ms'),0,0,100000)
            wall=(time.time()-secret.get('started',time.time()))*1000
            if claimed>limit or claimed>wall+350:choice='timeout'
            if isinstance(choice,dict):
                times=[choice[k] for k in ('stop_ms','held_ms') if k in choice]+sequence(choice,'taps',120)
                if self.game=='build_homunculus':times += [p.get('ms',-1) for p in sequence(choice,'placements',20) if isinstance(p,dict)]
                if self.game=='royal_read':times += [a.get('ms',-1) for a in sequence(choice,'attacks',4) if isinstance(a,dict)]
                if self.game=='flesh_suture':times += [a.get(k,-1) for a in sequence(choice,'stitches',4) if isinstance(a,dict) for k in ('down_ms','up_ms')]
                if any(integer(t,high=limit)<0 or t>claimed+2 for t in times):choice='timeout'
        if self.game=='king_risk' and isinstance(choice,dict):
            choice=dict(choice);choice['_ruptured']=number(choice.get('held_ms'))>secret.get('rupture_ms',0)
        return super().resolve(user,target,choice,secret)
    def tier_from(self,choice,o):
        if not isinstance(choice,dict):return len(self.TIERS)-1
        g=self.game;score=0
        if 'taps' in choice:
            raw=choice['taps']
            if not isinstance(raw,list) or (raw and len(taps(choice,o['time_limit_ms']))!=len(raw)):return len(self.TIERS)-1
        if g=='execution_charge' and (number(choice.get('held_ms'))<400 or choice.get('held_ms')!=choice.get('stop_ms')):return 3
        if g=='blood_split':return 0 if integer(choice.get('attack_percent'),high=100)>=0 else 3
        if g in ('prey_track','fang_drift','sentence_hold'):
            score=tracked(choice,o)
            bounds=(.95,.75,.4) if g=='prey_track' else (.88,.65,.35)
            return next((i for i,b in enumerate(bounds) if score>=b),3)
        if g in ('blood_tide','weakpoint_bar','slit_gaze','execution_charge'):
            value=bar_value(choice,o);distance=abs(value-.8)
            return 0 if distance<=o['width'] else 1 if distance<=o['width']+.12 else 2 if distance<=.38 else 3
        if g in ('dread_flinch','watchful_nogo'):
            clicks=taps(choice,o['time_limit_ms']);matched=set();false=0;latencies=[]
            for click in clicks:
                hit=next((i for i,f in enumerate(o['flashes']) if f['true'] and i not in matched and 0<=click-f['ms']<=o['window']),None)
                if hit is None:false+=1
                else:matched.add(hit);latencies.append(click-o['flashes'][hit]['ms'])
            if g=='dread_flinch':
                if false or not latencies:return 3
                return 0 if latencies[0]<=130 else 1 if latencies[0]<=220 else 2
            score=len(matched)-false
            return 0 if score>=3 else 1 if score>=2 else 2 if score>=1 else 3
        if g=='scale_pressure':
            score=pressure(choice,o);return 0 if score>=90 else 1 if score>=65 else 2 if score>=35 else 3
        if g=='horn_streak':
            click=taps(choice,o['time_limit_ms']);streak=best=0;used=set()
            for beat,window in zip(o['beats'],o['windows']):
                hit=next((i for i,t in enumerate(click) if i not in used and abs(t-beat)<=window),None)
                if hit is not None:used.add(hit);streak+=1;best=max(best,streak)
                else:streak=0
            return 0 if best>=7 else 1 if best>=5 else 2 if best>=3 else 3
        if g=='stone_balance':
            p=points(choice,o['time_limit_ms']);position=velocity=0.;inside=0;kicks=dict(o['kicks'])
            if number(choice.get('elapsed_ms'))<o['time_limit_ms']*.9:return 3
            for t in range(0,o['time_limit_ms'],25):
                for at,kick in o['kicks']:
                    if t<=at<t+25:velocity+=kick
                control=max(-1,min(1,(interpolate(p,t)[0]-180)/160)) if p else 0
                velocity=(velocity+control*.045)*.96;position=max(-1.4,min(1.4,position+velocity*.12))
                if abs(position)<.25:inside+=1
            score=inside/max(1,len(range(0,o['time_limit_ms'],25)))
            return 0 if score>=.85 else 1 if score>=.65 else 2 if score>=.4 else 3
        if g=='blade_orbits':
            t=integer(choice.get('stop_ms'),high=o['time_limit_ms'])
            if t<0:return 3
            a,b=[2*math.pi*(t+ph)/period for ph,period in zip(o['phases'],o['periods'])]
            distance=abs((a-b+math.pi)%(2*math.pi)-math.pi)
            return 0 if distance<.18 else 1 if distance<.42 else 2 if distance<.85 else 3
        if g=='king_risk':
            if choice.get('_ruptured'):return 3
            t=integer(choice.get('held_ms'),high=o['time_limit_ms'])
            return 0 if t>=3800 else 1 if t>=2400 else 2 if t>=1200 else 3
        if g=='predator_afterimage':
            if number(choice.get('elapsed_ms'))<o['show_ms']:return 3
            distance=math.hypot(number(choice.get('x'),-999)-o['target'][0],number(choice.get('y'),-999)-o['target'][1])
            return 0 if distance<=15 else 1 if distance<=30 else 2 if distance<=55 else 3
        if g=='flesh_suture':
            raw=choice.get('stitches')
            if not isinstance(raw,list) or len(raw)>4:return 4
            correct=0;last=-1;elapsed=number(choice.get('elapsed_ms'),-1,0,o['time_limit_ms'])
            for a in raw:
                if not isinstance(a,dict):return 4
                down=integer(a.get('down_ms'),high=o['time_limit_ms'])
                up=integer(a.get('up_ms'),high=o['time_limit_ms'])
                if down<=last or up<=down or up>elapsed:return 4
                held=(up-down)/o['suture_period']
                correct+=o['green'][0]<=held<=o['green'][1]
                last=up
            return 4-correct
        if g=='royal_read':
            raw=choice.get('attacks')
            if not isinstance(raw,list) or len(raw)>4:return 3
            seen=set();correct=0;last=-1
            elapsed=number(choice.get('elapsed_ms'),-1,0,o['time_limit_ms'])
            for a in raw:
                if not isinstance(a,dict):return 3
                ms=integer(a.get('ms'),high=o['time_limit_ms'])
                lane=integer(a.get('lane'),high=2)
                if ms<=last or ms>elapsed or lane<0:return 3
                phase=next((i for i,p in enumerate(o['stances']) if p['start']<=ms<p['end']),None)
                if phase is None or phase in seen:return 3
                seen.add(phase);last=ms
                correct+=lane==o['stances'][phase]['open']
            return 0 if correct==4 else 1 if correct==3 else 2 if correct==2 else 3
        if g in ('raise_bones','raise_zombie','build_homunculus'):
            correct=assembly_count(choice,o);n=len(correct)
            if g=='raise_bones':
                stage=0
                for end in (3,6,9):
                    if all(i in correct for i in range(end)):stage+=1
                return 3-stage
            if g=='raise_zombie':return 3-min(3,n)
            if g=='build_homunculus':return 0 if n==5 else 1 if n==4 else 2 if n>=2 else 3
            return max(0,4-n)  # Five grades for repair are handled by count in apply.
        if g=='puppet_threads':
            nodes=sequence(choice,'nodes',8)
            if len(nodes)!=8 or any(not isinstance(p,list) or len(p)!=2 for p in nodes):return 4
            clean=[[number(p[0],-999,20,340),number(p[1],-999,20,240)] for p in nodes]
            if any(-999 in p for p in clean):return 4
            if any(math.dist(a,b)<18 for i,a in enumerate(clean) for b in clean[i+1:]):return 4
            count=intersections(clean,o['edges'])
            return min(4,count)
        return 3
    def allocation(self,user,target):
        from .ai import strike_value,healing
        hit=max(0,min(1,user.hit_chance(self,target)))
        choices=[]
        for percent in range(0,101,5):
            a=percent/100
            value=strike_value(user,target,.6+2.4*a,force=False)+healing(user,user.get_damage()*2*(1-a))
            if a>.65:value-=(1-hit)*round(user.max_hp*.06*a)
            choices.append((value,percent))
        return max(choices)[1],max(choices)[0]
    def ai_tier(self,user,target):
        # Resource allocation is a deliberate choice, not a random dexterity test.
        return 0 if self.game=='blood_split' else super().ai_tier(user,target)
    def ai_choice(self,user,target,tier):
        if self.game=='blood_split':return {'attack_percent':self.allocation(user,target)[0]}
        if self.game=='flesh_suture':return None
        return None
    def apply(self,user,target,tier,data):
        from .heroes_55 import (marks,add_marks,spend_marks,verdict,Dread,Drain,TwoHitShield,
                                NextCritical,ShortGame)
        logs=[Announcement(f'{self.icon} {user.name} — «{self.name}»: {self.TIERS[tier]}.')]
        g=self.game;mult=(2.1,1.6,1,.4)[min(tier,3)]
        def hit(value,**kw):
            lines,damage=self.strike(user,target,value,**kw);logs.extend(lines);return damage
        if g=='dread_flinch':
            if tier<3:
                target.add_effect(Dread(2,(20,15,8)[tier]));target.add_effect(Drain(user,round((4,3,2)[tier]*user.power_scale())))
            return logs
        if g=='blood_split':
            if tier==3:return logs
            percent=number((data or {}).get('attack_percent'),50,0,100)/100
            damage=hit(.6+2.4*percent,force=False)
            healed=user.heal(round(user.get_damage()*2*(1-percent)))
            if not damage and percent>.65:
                loss=round(user.max_hp*.06*percent);user.hp-=loss;logs.append(f'🩸 Откат крови: {user.name} теряет {loss} HP.')
            logs.append(f'🩸 Распределение: {round(percent*100)}% атака, {user.name} +{healed} HP.');return logs
        if g=='blood_tide':
            missing=1-user.hp/user.max_hp
            old=self.lifesteal;self.lifesteal=(.65,.5,.3,0)[tier]
            try:hit(mult*(1+missing*.8))
            finally:self.lifesteal=old
            return logs
        if g=='prey_track':
            if tier<3:
                if tier==0:self.crit_bonus=1
                try:hit((1.3,1,.6)[tier])
                finally:self.crit_bonus=0
                if target.is_alive():logs+=add_marks(user,target,(3,2,1)[tier])
            return logs
        if g in ('scale_pressure','weakpoint_bar'):
            e=marks(target,user);n=e.power if e else 0
            hit(((1.9,1.5,1,.5)[tier] if g=='scale_pressure' else (2.2,1.7,1.1,.5)[tier])+.2*n,pierce=.35 if tier==0 else .15)
            spend_marks(user,target);return logs
        if g=='watchful_nogo':
            gain=(2,1,1,0)[tier];user.focus_target=target.id;user.focus=min(4,user.focus+gain)
            logs.append(f'👁 Фокус {user.focus}/4 на {target.name}.');return logs
        if g=='horn_streak':
            damage=hit((2.1,1.7,1.4,1.2)[tier])
            if damage and random.random()<( .35,.25,.12,0)[tier]:target.add_effect(Stun(1))
            return logs
        if g=='stone_balance':
            user.add_effect(TwoHitShield(round((20,16,11,5)[tier]*user.power_scale())));return logs
        if g=='fang_drift':
            focus=user.focus if user.focus_target==target.id else 0
            old=self.lifesteal;self.lifesteal=.3
            try:hit((1.5+.2*focus)*(1,.8,.6,.3)[tier])
            finally:self.lifesteal=old
            user.focus=0
            if target.is_alive() and tier<3:target.add_effect(scale_effect(Bleed(2,(4,3,2)[tier]),user))
            return logs
        if g=='execution_charge':
            if tier<3:hit((3,2.2,1.3)[tier])
            if tier>=2:
                loss=max(1,round(user.max_hp*(.07 if tier==3 else .02)));user.hp-=loss
                if tier==3:user.add_effect(Stun(1))
                logs.append(f'🪓 Потеря равновесия: {user.name} −{loss} HP'+('; пропускает следующий ход.' if tier==3 else '.'))
            return logs
        if g=='sentence_hold':
            mark=verdict(user,target);ready=mark is not None and mark.power==0
            if tier==3:
                loss=max(1,round(user.max_hp*.1));user.hp-=loss;logs.append(f'🩸 Срыв казни: {user.name} −{loss} HP.')
            else:
                old=self.crit_bonus;self.crit_bonus=1 if ready else 0
                try:hit((3.2,2.5,1.5)[tier] if ready else (2.1,1.6,.9)[tier],ignore_armor=ready)
                finally:self.crit_bonus=old
            if mark:target._effects.remove(mark);logs.append('⌛ Приговор израсходован.')
            return logs
        if g=='slit_gaze':
            if tier<3:
                target.add_effect(Blinded(2,(12,9,5)[tier]));target.add_effect(ShortGame(4,(30,20,10)[tier]));hit((.7,.5,.3)[tier])
            return logs
        if g=='blade_orbits':
            combo=getattr(user,'_combo_before',0)
            if combo==2:
                for _ in range(2):
                    if target.is_alive():hit((1.35,1.1,.8,.4)[tier])
            else:hit((1.9,1.5,1,.4)[tier])
            return logs
        if g=='king_risk':hit((2,1.6,1.2,.5)[tier]);return logs
        if g=='predator_afterimage':hit((1.6,1.3,.9,.3)[tier]);return logs
        if g=='royal_read':
            if tier<2:user.add_effect(NextCritical(3,25 if tier==0 else 0))
            return logs
        if g in ('raise_bones','raise_zombie','build_homunculus'):
            kind={'raise_bones':'skeleton','raise_zombie':'zombie','build_homunculus':'homunculus'}[g]
            if g in ('raise_bones','build_homunculus') and tier==3:return logs+['Ритуал не завершён: призыв не появился.']
            logs+=user.raise_minion(kind,tier);return logs
        if g=='puppet_threads':
            for s in user.living_minions():s.command_boost=(.25,.20,.15,.10,.05)[tier];s.command_pierce=.35 if tier==0 else 0;s.command_expires=getattr(getattr(user,'_battle',None),'round',0)+2
            return logs+['🕸 Следующие атаки существ усилены нитями господства.']
        if g=='flesh_suture':
            count=max(0,4-tier)
            total=0
            for s in user.living_minions():total+=s.heal(round(count*4*user.power_scale()))
            healed=user.heal(round(count*2*user.power_scale()));return logs+[f'🪡 Существа +{total} HP; {user.name} +{healed} HP.']
        return logs
    def ai_score(self,user,target):
        from .ai import strike_value,threat
        from .heroes_55 import marks,verdict
        g=self.game
        if not self.is_available(user):return 0
        if g.startswith(('raise_','build_')):return user.summon_value(g,target)
        if g=='puppet_threads':return sum(s.get_damage() for s in user.living_minions())*.23+1
        if g=='flesh_suture':return sum(min(s.max_hp-s.hp,12*user.power_scale()) for s in user.living_minions())*.85+min(user.max_hp-user.hp,6*user.power_scale())
        if g=='watchful_nogo':
            focus=user.focus if user.focus_target==target.id else 0
            return (4-focus)*4.5 if focus<4 else 0
        if g=='horn_streak':
            from .ai import tier_average,effect_value
            stun=effect_value(user,target,Stun(1))
            return tier_average(self,user,[strike_value(user,target,m,force=True)+chance*stun for m,chance in zip((2.1,1.7,1.4,1.2),(.35,.25,.12,0))])
        if g=='stone_balance':
            from .heroes_55 import TwoHitShield
            return 0 if user.has_effect(TwoHitShield) else min(26*user.power_scale(),threat(target,user)*2)
        if g=='royal_read':return user.get_damage()*.65 if not user.has_effect(__import__(__package__+'.heroes_55',fromlist=['NextCritical']).NextCritical) else 0
        value=strike_value(user,target,1.65,force=True)
        if g=='dread_flinch':
            from .ai import healing,effect_value,tier_average
            from .heroes_55 import Dread,Drain
            existing=next((e for e in target.get_effects() if isinstance(e,Drain)),None)
            values=[]
            for i in range(4):
                if i==3:values.append(0);continue
                dot=min(target.hp,(4,3,2)[i]*2*user.power_scale()*(1-getattr(target,'DOT_RESIST',0)))
                if existing:dot=max(0,dot-existing.power*existing.duration)
                values.append(dot+healing(user,dot)+effect_value(user,target,Dread(2,(20,15,8)[i])))
            return tier_average(self,user,values)
        if g=='blood_split':return self.allocation(user,target)[1]
        if g=='blood_tide':return value*1.1+min(user.max_hp-user.hp,value*.5)
        if g=='prey_track':
            e=marks(target,user);return value*.6+(3-(e.power if e else 0))*3
        if g in ('scale_pressure','weakpoint_bar'):
            e=marks(target,user);return value*(1+.16*(e.power if e else 0))
        if g=='fang_drift':return value*(.8+.12*(user.focus if user.focus_target==target.id else 0))+min(user.max_hp-user.hp,value*.3)
        if g=='execution_charge':return value-max(0,user.max_hp*.007)
        if g=='sentence_hold':
            mark=verdict(user,target);return value*(2 if mark and mark.power==0 else .85)-user.max_hp*.005
        if g=='slit_gaze':return value*.4+target.get_damage()*.15+2
        if g=='blade_orbits':return value*(1.5 if user.combo==2 and user.combo_target==target.id else .9)
        if g=='predator_afterimage' and not user.combo:value+=3
        return value
