"""Баланс 5.4.1 для 37 классов после исправления выбора действий ИИ.
HP_TUNING и DMG_TUNING — подстройка поверх базовых статов. Урон ограничен 0.90–1.10;
у самурая сохранены DMG 1.10 и мастерство ИИ 1.5. Два пула Повелителя зверей — 200+100.
KIT_TUNING сближает базовую броню классов для уменьшения числа жёстких контрпар.
Финальные коэффициенты проверяются матрицей 37x37; методика и результаты входят в пакет баланса.
Сюжетная таблица STORY_VS ниже сохранена без изменений."""
HP_TUNING = {  # множитель HP после калибровки 5.4.1
    "warrior": 1.1,
    "mage": 0.9104,
    "archer": 1.0386,
    "ogre": 1.0768,
    "spartan": 1.1,
    "assassin": 1.0511,
    "samurai": 1.0209,
    "druid": 0.9603,
    "monk": 1.0101,
    "darkelf": 0.9666,
    "owlbeast": 1.0493,
    "musketeer": 1.0689,
    "pagan": 0.969,
    "minotaur": 0.9676,
    "croc": 1.1,
    "darkknight": 0.9952,  # 5.4 after siphon
    "goblin": 1.0084,
    "satyr": 0.9,
    "ghoul": 1.0648,
    "rhino": 1.1,
    "bogatyr": 1.1,
    "orc": 0.9914,
    "dwarf": 1.0717,
    "lightelf": 1.0265,
    "shade": 0.9557,
    # 5.4
    "aarakocra": 0.9916, "hunter": 0.9903, "gnoll": 1.0456, "centaur": 0.98,
    "bluetroll": 1.0749, "paladin": 0.9431, "catfolk": 1.0205, "beastlord": 1.0,  # 5.4.1: kodo+rider exact
    "spiderqueen": 0.9687, "ranger": 0.9785, "pandaren": 0.9574, "gambler": 0.9568,
}
DMG_TUNING = {  # множитель урона (4.3: 0.9–1.1)
    "warrior": 1.1,
    "mage": 0.9409,
    "archer": 1.0866,
    "ogre": 1.0926,
    "spartan": 1.0524,
    "assassin": 1.0597,
    "samurai": 1.1,
    "druid": 0.9886,
    "monk": 1.0143,
    "darkelf": 0.995,
    "owlbeast": 1.0575,
    "musketeer": 1.0784,
    "pagan": 0.9853,
    "minotaur": 1.0048,
    "croc": 1.0402,
    "darkknight": 0.9824,  # 5.4 after siphon
    "goblin": 1.029,
    "satyr": 0.9149,
    "ghoul": 1.0623,
    "rhino": 1.0872,
    "bogatyr": 1.0648,
    "orc": 0.9996,
    "dwarf": 1.0702,
    "lightelf": 1.0396,
    "shade": 0.9877,
    # 5.4
    "aarakocra": 0.9795, "hunter": 0.9745, "gnoll": 1.0425, "centaur": 0.97,
    "bluetroll": 1.0785, "paladin": 0.9258, "catfolk": 1.0606, "beastlord": 1.0097,
    "spiderqueen": 0.9395, "ranger": 0.9824, "pandaren": 0.9612, "gambler": 1.003,
}

# мастерство ИИ в мини-играх (1.0 — по весам AI_WEIGHTS); см. skills.ai_weights
AI_SKILL = {  # 4.3: 1–5
    "warrior": 4.831,
    "mage": 1.0,
    "archer": 1.0,
    "ogre": 3.979,
    "spartan": 1.453,
    "assassin": 0.7,  # 5.4 mastery gap
    "samurai": 1.5,
    "druid": 1.108,
    "monk": 4.63,
    "darkelf": 0.65,  # 5.4 mastery gap
    "owlbeast": 5.0,
    "musketeer": 1.756,
    "pagan": 0.7,  # 5.4 mastery gap
    "minotaur": 1.077,
    "croc": 3.231,
    "darkknight": 3.47,
    "goblin": 1.0,
    "satyr": 4.826,
    "ghoul": 5.0,
    "rhino": 1.625,
    "bogatyr": 5.0,
    "orc": 5.0,
    "dwarf": 1.0,
    "lightelf": 5.0,
    "shade": 5.0,
    "aarakocra": 1.5, "hunter": 1.5, "gnoll": 1.5, "centaur": 1.5,
    "bluetroll": 0.85, "paladin": 1.5, "catfolk": 1.5, "beastlord": 1.5,
    "spiderqueen": 1.5, "ranger": 1.5, "pandaren": 1.5, "gambler": 1.5,
}

# 5.4.1: поправки базовой брони, учтённые в итоговой матрице
KIT_TUNING = {
    "warrior": {
        "armor": -1
    },
    "mage": {
        "armor": 1
    },
    "spartan": {
        "armor": -2
    },
    "musketeer": {
        "armor": 1
    },
    "croc": {
        "armor": -2
    },
    "darkknight": {
        "armor": -1
    },
    "goblin": {
        "armor": 1
    },
    "satyr": {
        "armor": 1
    },
    "ghoul": {
        "armor": 1
    },
    "rhino": {
        "armor": -2
    },
    "bogatyr": {
        "armor": -1
    },
    "dwarf": {
        "armor": -1
    },
    "shade": {
        "armor": 1
    },
    "aarakocra": {
        "armor": 1
    },
    "gnoll": {
        "armor": 1
    },
    "paladin": {
        "armor": -2
    },
    "catfolk": {
        "armor": 1
    },
    "spiderqueen": {
        "armor": 1
    },
    "ranger": {
        "armor": 1
    },
    "gambler": {
        "armor": 1
    }
}

# 5.0: сюжетные таблицы силы моба (HP+урон) vs класс героя. Больше factor → сильнее моб → ниже WR.
# Боссы altair/druid/shibek/croc_boss: 55–65%; элиты gazlow/grozokryl: 60–80%. Только сюжет.
STORY_VS = {
    "gazlow": { "warrior": 0.986, "mage": 0.91, "archer": 0.98, "ogre": 0.94, "spartan": 0.974, "assassin": 0.925, "samurai": 0.95, "druid": 0.935, "monk": 0.96, "darkelf": 0.905, "musketeer": 0.901, "pagan": 0.91, "minotaur": 0.926, "croc": 0.9, "darkknight": 0.987, "goblin": 0.951, "satyr": 0.96, "ghoul": 0.925, "rhino": 0.928, "bogatyr": 0.941, "orc": 0.925, "dwarf": 1.03, "lightelf": 0.97, "shade": 1.04 },
    "grozokryl": { "warrior": 0.984, "mage": 0.872, "archer": 0.875, "ogre": 0.885, "spartan": 0.976, "assassin": 0.859, "samurai": 0.877, "druid": 0.9, "monk": 0.9, "darkelf": 0.92, "musketeer": 0.93, "pagan": 0.946, "minotaur": 0.984, "croc": 0.96, "darkknight": 0.91, "goblin": 0.89, "satyr": 0.926, "ghoul": 0.895, "rhino": 0.984, "bogatyr": 1.01, "orc": 0.99, "dwarf": 1.004, "lightelf": 0.911, "shade": 0.891 },
    "altair": { "warrior": 0.964, "mage": 1.07, "archer": 1.049, "ogre": 0.859, "spartan": 0.821, "assassin": 0.887, "samurai": 1.118, "druid": 1.093, "monk": 1.012, "darkelf": 0.92, "musketeer": 1.004, "pagan": 0.964, "minotaur": 0.809, "croc": 0.854, "darkknight": 0.988, "goblin": 0.981, "satyr": 0.952, "ghoul": 1.008, "rhino": 0.93, "bogatyr": 0.867, "orc": 0.913, "dwarf": 0.912, "lightelf": 1.08, "shade": 0.874 },
    "druid": { "warrior": 1.01, "mage": 0.9, "archer": 0.933, "ogre": 0.925, "spartan": 0.989, "assassin": 0.81, "samurai": 0.96, "druid": 0.99, "monk": 0.97, "darkelf": 0.937, "musketeer": 0.99, "pagan": 0.921, "minotaur": 1.064, "croc": 1.006, "darkknight": 0.975, "goblin": 1.03, "satyr": 0.93, "ghoul": 0.909, "rhino": 1.052, "bogatyr": 1.07, "orc": 0.98, "dwarf": 1.039, "lightelf": 0.99, "shade": 0.93 },
    "shibek": { "warrior": 1.024, "mage": 0.989, "archer": 1.01, "ogre": 1.025, "spartan": 1.047, "assassin": 0.955, "samurai": 1.062, "druid": 0.998, "monk": 1.017, "darkelf": 0.968, "musketeer": 0.963, "pagan": 0.974, "minotaur": 1.036, "croc": 1.045, "darkknight": 1.052, "goblin": 0.98, "satyr": 1.029, "ghoul": 0.954, "rhino": 1.0, "bogatyr": 1.026, "orc": 1.014, "dwarf": 0.981, "lightelf": 1.0, "shade": 0.905 },
    "croc_boss": { "warrior": 0.964, "mage": 0.974, "archer": 0.995, "ogre": 0.988, "spartan": 0.98, "assassin": 0.945, "samurai": 0.99, "druid": 0.97, "monk": 0.98, "darkelf": 0.97, "musketeer": 0.994, "pagan": 1.057, "minotaur": 1.026, "croc": 0.98, "darkknight": 0.941, "goblin": 1.021, "satyr": 0.99, "ghoul": 1.036, "rhino": 1.004, "bogatyr": 1.009, "orc": 1.036, "dwarf": 0.99, "lightelf": 0.945, "shade": 0.97 },
}
RADO_VS = STORY_VS["druid"]  # 4.4 alias
