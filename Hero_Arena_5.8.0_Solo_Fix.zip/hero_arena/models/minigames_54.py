"""5.4: мини-игры новых героев (и усиление мастерства для старых)."""
import random
import time

from .effects import (Announcement, Shield, Stun, Bleed, Burn, Poison, Slow, DodgeBuff,
                      Berserk, DamageReduction, Regeneration, Antiheal)
from .skills import MiniGameSkill, Skill, DamageSkill, scale_effect


# ---- Dark Knight: life drain mini-game ----
class SoulSiphonSkill(MiniGameSkill):
    """«Похищение души»: кликайте по душам врага. Идеально — сильный вампиризм."""

    game, prompt = "click_targets", "Ловите души врага!"
    MG_ICON, MG_ACCENT = "👻", "#7b5cff"
    TIME_LIMIT_MS = 3000
    TARGETS, ICON = 5, "👻"
    TIERS = tuple(f"{k}/5" for k in range(5, -1, -1))
    AI_WEIGHTS = (12, 22, 28, 20, 12, 6)
    # mastery-heavy: perfect much stronger than average
    HIT_STEAL = (0.0, 0.35, 0.55, 0.75, 0.95, 1.25)  # by hits
    HIT_MULT = (0.0, 0.35, 0.55, 0.8, 1.05, 1.4)

    def game_params(self, user, target):
        return {"count": self.TARGETS, "icon": self.ICON,
                "spawn_ms": self.TIME_LIMIT_MS // (self.TARGETS + 1)}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return self.TARGETS - max(0, min(self.TARGETS, k))

    def apply(self, user, target, tier, data):
        hits = self.TARGETS - tier
        if hits <= 0:
            return [f"👻 {user.name} не поймал ни одной души."]
        logs = [Announcement(f"👻 {user.name} — «Похищение души»: {hits}/5!") if hits >= 5
                else f"👻 {user.name} — «Похищение души»: {hits}/5."]
        part, dmg = self.strike(user, target, self.HIT_MULT[hits], ignore_armor=hits >= 4)
        logs += part
        if dmg:
            healed = user.heal(int(dmg * self.HIT_STEAL[hits]))
            logs.append(f"🩸 {user.name} высасывает {healed} HP.")
        return logs

    def ai_score(self, user, target):
        return 18 if user.hp < user.max_hp * 0.7 else 10


# ---- Samurai new minigame ----
class IaiFlashSkill(MiniGameSkill):
    """«Вспышка иай»: одно нажатие по таймингу — очень узкое окно (темп броска ножей)."""

    game, prompt = "timing_ring", "Нажмите в момент вспышки клинка!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "⚔", "#c8d0dc", "#e05555"
    MG_HINT = "Нажмите, когда кольцо совпадёт со вспышкой клинка"
    TIME_LIMIT_MS = 2800
    TIERS = ("Иай!", "Рез", "Промах")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (2.2, 1.35, 0.4)

    def game_params(self, user, target):
        return {"period_ms": random.randint(700, 950)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 70 else 1 if err <= 160 else 2

    def apply(self, user, target, tier, data):
        head = f"⚡ {user.name} — «Вспышка иай»: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, _ = self.strike(user, target, self.TIER_VALUE[tier],
                              ignore_armor=tier == 0, pierce=0.4 if tier == 1 else None)
        return logs + part

    def ai_score(self, user, target):
        from .ai import strike_value,tier_average
        return tier_average(self,user,[strike_value(user,target,mult,ignore_armor=i==0,
                            pierce=0.4 if i==1 else 0,force=True) for i,mult in enumerate(self.TIER_VALUE)])


# ---- Shared helpers for new heroes ----
class FlightDiveSkill(MiniGameSkill):
    """Пикирование ааракокры."""

    game, prompt = "dive_track", "Пикируйте по вертикали в цель!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🦅", "#7ec8ff", "#e8f6ff"
    MG_HINT = "Нажмите, когда кольцо совпадёт с целью пикирования"
    TIME_LIMIT_MS = 2800
    TIERS = ("в цель!", "царапнул", "мимо")
    AI_WEIGHTS = (25, 45, 30)
    TIER_VALUE = (2.35, 1.45, 0.5)

    def game_params(self, user, target):
        return {"period_ms": random.randint(700, 1000)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 70 else 1 if err <= 160 else 2

    def apply(self, user, target, tier, data):
        head = f"🦅 {user.name} пикирует: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, dmg = self.strike(user, target, self.TIER_VALUE[tier], pierce=0.5 if tier <= 1 else None)
        logs += part
        if tier == 0 and dmg and target.is_alive():
            target.add_effect(scale_effect(Bleed(3, 4), user))
            logs.append(f"🩸 Когти рвут {target.name}.")
        return logs


class TrapSetSkill(MiniGameSkill):
    """Дэрил: установка капканов."""

    game, prompt = "trap_grid", "Расставьте капканы на клетках!"
    MG_ICON, MG_ACCENT = "🪤", "#c48a3c"
    TIME_LIMIT_MS = 3000
    TARGETS, ICON = 4, "🪤"
    TIERS = ("4/4", "3/4", "2/4", "1/4", "0/4")
    AI_WEIGHTS = (18, 30, 28, 16, 8)

    def game_params(self, user, target):
        return {"count": 4, "icon": "🪤", "spawn_ms": 600}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 4 - max(0, min(4, k))

    def apply(self, user, target, tier, data):
        hits = 4 - tier
        if hits <= 0:
            return [f"🪤 {user.name} не успел поставить капканы."]
        mult = (0.0, 0.55, 0.9, 1.25, 1.7)[hits]
        logs = [Announcement(f"🪤 Капканы: {hits}/4!") if hits == 4 else f"🪤 Капканы: {hits}/4."]
        part, _ = self.strike(user, target, mult)
        logs += part
        if hits >= 3:
            target.add_effect(Slow(2, 2))
            logs.append(f"⛓ {target.name} попал в капкан (−2 скорости).")
        if hits == 4:
            target.add_effect(Stun(1))
            logs.append(f"💫 Идеальный капкан оглушает {target.name}!")
        return logs


class MarkShotSkill(MiniGameSkill):
    """Дэрил: меткий выстрел."""

    game, prompt = "mark_lock", "Захватите метку и выстрелите!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🎯", "#e08a3c", "#f0d090"
    MG_HINT = "Нажмите, когда кольцо совпадёт с меткой"
    TIME_LIMIT_MS = 2800
    TIERS = ("в глаз!", "в корпус", "мимо")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (2.5, 1.5, 0.45)

    def game_params(self, user, target):
        return {"period_ms": random.randint(720, 980)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 65 else 1 if err <= 150 else 2

    def apply(self, user, target, tier, data):
        head = f"🎯 {user.name} — меткий выстрел: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, _ = self.strike(user, target, self.TIER_VALUE[tier], ignore_armor=tier == 0)
        return logs + part


class BoneDiceSkill(MiniGameSkill):
    """Рексор: одна кость 1..6. Бафф растёт с числом (1=мин, 6=макс), без штрафа.
    Клик останавливает анимацию; точный стоп слегка улучшает шанс высокого числа (мастерство)."""

    game, prompt = "dice_roll", "Бросьте кость удачи — кликните, чтобы остановить!"
    MG_ICON, MG_ACCENT = "🎲", "#e8c84a"
    MG_HINT = "Кликните, когда кость вспыхнет ярче — выше шанс большого числа"
    TIME_LIMIT_MS = 3200
    # tier 0 = выпало 6 (лучшее) … tier 5 = выпало 1
    TIERS = ("⚅ 6", "⚄ 5", "⚃ 4", "⚂ 3", "⚁ 2", "⚀ 1")
    # гнолл был выше нормы — меньше экстремумов, пик на 3–4
    AI_WEIGHTS = (8, 12, 20, 24, 20, 16)
    # сила баффа / длительность / доп.удар по числу 1..6
    BUFF_PWR = (4, 7, 10, 13, 16, 20)        # % берсерка (гнолл был выше нормы)
    BUFF_TURNS = (1, 2, 2, 2, 3, 3)
    STRIKE_MULT = (0.5, 0.65, 0.8, 0.9, 1.05, 1.15)
    DODGE_BONUS = (0, 0, 0, 5, 8, 10)         # % с 4+

    def game_params(self, user, target):
        return {
            "icon": "🎲",
            "faces": [1, 2, 3, 4, 5, 6],
            "spin_ms": 80,
            "sweet_ms": 420,   # окно «яркой» вспышки для мастерства
            "period_ms": 900,
        }

    def _roll_from_choice(self, choice):
        if isinstance(choice, dict):
            # Клиент 5.4.1 присылает и roll, и base_roll. Мастерство оцениваем
            # от исходной грани, чтобы roll не обходил бонус и не усиливался дважды.
            if "base_roll" in choice:
                raw_roll = choice["base_roll"]
            elif "roll" in choice:
                raw_roll = choice["roll"]
            else:
                raw_roll = random.randint(1, 6)
            base = max(1, min(6, int(raw_roll)))
            # mastery: stop timing — error_ms мал → шанс +1 к броску
            err = choice.get("error_ms")
            mastery = choice.get("mastery") or (err is not None and abs(float(err)) <= 90)
            if mastery and base < 6 and random.random() < 0.55:
                base += 1
            return base
        if isinstance(choice, int):
            return max(1, min(6, choice))
        return random.randint(1, 6)

    def tier_from(self, choice, options):
        roll = self._roll_from_choice(choice)
        return 6 - roll  # 6→0 … 1→5

    def apply(self, user, target, tier, data):
        roll = 6 - max(0, min(5, tier))
        idx = roll - 1
        pwr = self.BUFF_PWR[idx]
        turns = self.BUFF_TURNS[idx]
        user.add_effect(Berserk(turns, pwr))
        dodge = self.DODGE_BONUS[idx]
        logs = [Announcement(f"🎲 {user.name} выбрасывает {roll}! Бафф: +{pwr}% урона на {turns} х.")
                if roll >= 5 else
                f"🎲 {user.name} выбрасывает {roll}: +{pwr}% урона на {turns} х."]
        if dodge:
            user.add_effect(DodgeBuff(turns, dodge))
            logs.append(f"🗡 +{dodge}% уклонения на {turns} х.")
        part, _ = self.strike(user, target, self.STRIKE_MULT[idx])
        logs += part
        return logs

    def describe_for(self, user):
        return ("Одна кость 1…6: чем больше число, тем сильнее бафф "
                "(1 → +4% Урон 1 х.; 6 → +20% Урон 3 х. и +10% уклонения). Без штрафа. "
                "Клик по вспышке слегка повышает шанс")

    TIER_VALUE = (1.3, 1.15, 1.0, 0.85, 0.7, 0.55)


class HyenaLaughSkill(MiniGameSkill):
    """Рексор: смех гиены — крадёт ресурс."""

    game, prompt = "laugh_rhythm", "Повторите ржание гиены!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "😈", "#e8c84a", "#8aaf4a"
    MG_HINT = "Нажмите, когда кольцо совпадёт с хохотом"
    TIME_LIMIT_MS = 2600
    TIERS = ("ржёт!", "хихикает", "сбился")
    AI_WEIGHTS = (25, 45, 30)

    def game_params(self, user, target):
        return {"period_ms": random.randint(680, 920)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 65 else 1 if err <= 150 else 2

    def apply(self, user, target, tier, data):
        amount = (35, 18, 5)[tier]
        drained = min(amount, int(getattr(target, "energy", 0) or 0))
        if drained and hasattr(target, "spend_energy"):
            target.spend_energy(drained)
        user.restore_energy(amount)
        part, _ = self.strike(user, target, (1.4, 0.9, 0.4)[tier])
        head = f"😈 {user.name} — смех гиены ({self.TIERS[tier]}): +{amount} ресурса"
        if drained:
            head += f" (украл {drained})"
        logs = [Announcement(head) if tier == 0 else head]
        if tier == 0:
            target.add_effect(Stun(1))
            logs.append(f"💫 Смех оглушает {target.name}!")
        return logs + part


class TotemPulseSkill(MiniGameSkill):
    """Талар: пульс тотема."""

    game, prompt = "totem_order", "Активируйте тотемы по порядку!"
    MG_ICON, MG_ACCENT = "🛕", "#c9a227"
    TIME_LIMIT_MS = 3000
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (22, 40, 28, 10)

    def game_params(self, user, target):
        return {"count": 3, "icon": "🛕", "spawn_ms": 700}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 3 - max(0, min(3, k))

    def apply(self, user, target, tier, data):
        hits = 3 - tier
        heal_pct = (0.0, 0.06, 0.11, 0.18)[hits]
        healed = user.heal(int(user.max_hp * heal_pct)) if hits else 0
        logs = [Announcement(f"🛕 Тотемы: {hits}/3, +{healed} HP!") if hits == 3
                else f"🛕 Тотемы: {hits}/3, +{healed} HP."]
        if hits >= 2:
            target.add_effect(scale_effect(Poison(3, 3 + hits), user))
            logs.append(f"☠️ Проклятие тотема отравляет {target.name}.")
        if hits == 3:
            user.add_effect(Shield(3, max(1, int(user.max_hp * 0.12))))
            logs.append("🛡 Тотем защиты: щит 12% HP.")
        return logs


class HarpCurseSkill(MiniGameSkill):
    """Талар: арфа проклятий."""

    game, prompt = "timing_multi", "Сыграйте две ноты арфы!"
    MG_ICON, MG_ACCENT, MG_TARGET_COLOR = "🎵", "#b98cff", "#f5b942"
    MG_HINT = "Нажмите в зоне ноты арфы"
    TIME_LIMIT_MS = 3200
    TIERS = ("аккорд!", "мелодия", "фальшь")
    AI_WEIGHTS = (22, 48, 30)

    def game_params(self, user, target):
        return {"presses": 2, "zone": round(random.uniform(0.3, 0.7), 2), "perfect_w": 0.055,
                "good_w": 0.14, "period_ms": 900, "icon": "🎵", "labels": ["Нота 1", "Нота 2"]}

    def tier_from(self, choice, options):
        if not isinstance(choice, dict):
            return 2
        perfect, good = int(choice.get("perfect", 0)), int(choice.get("hits", 0))
        return 0 if perfect >= 2 else 1 if good >= 1 else 2

    def apply(self, user, target, tier, data):
        if tier == 2:
            return [f"🎵 Арфа фальшивит — проклятие срывается."]
        from .effects import Blinded
        target.add_effect(Slow(2 + (1 if tier == 0 else 0), 2))
        target.add_effect(Blinded(3 if tier == 0 else 2, 25 if tier == 0 else 12))
        if tier == 0:
            target.add_effect(Antiheal(2))
        part, _ = self.strike(user, target, 1.6 if tier == 0 else 1.0)
        head = f"🎵 {user.name} — арфа ({self.TIERS[tier]})"
        return [Announcement(head) if tier == 0 else head] + part


class MacheteCatchSkill(MiniGameSkill):
    """Рокх-анн: ДВА мачете на разных дугах — мини-игра на точность.
    Идеал ≤50 мс на каждое; промах = самоудар. Идеал щедро награждает (тролль слаб в среднем)."""

    game, prompt = "boomerang_dual", "Поймайте ОБА мачете на скрещивающихся дугах!"
    MG_ICON, MG_ACCENT = "🪃", "#3ecfcf"
    MG_HINT = "Два клинка, кликайте при проходе центра; золотой участок — идеал"
    TIME_LIMIT_MS = 5000
    # 2 caught perfect / 1 / 0 — plus quality
    TIERS = ("двойной идеал", "один идеал", "задел", "мимо — по себе")
    AI_WEIGHTS = (10, 22, 38, 30)  # идеал редок; промах ощутим
    # payoff: perfect huge; average modest; miss hurts self
    PERFECT_MS = 50   # точный тайминг, но доступнее исходных ±32 мс
    GOOD_MS = 110
    TIER_VALUE = (2.45, 1.35, 0.7, 0.0)

    def game_params(self, user, target):
        # две дуги с разной фазой и скоростью — окно лова задаётся PERFECT_MS на клиенте
        return {
            "blades": 2,
            "period_a_ms": random.randint(700, 820),  # умеренно замедленный первый клинок
            "period_b_ms": random.randint(900, 1040),
            "phase_b": random.randint(120, 280),      # сдвиг второй дуги
            "perfect_ms": self.PERFECT_MS,
            "good_ms": self.GOOD_MS,
            "icon": "🪃",
            "accent": "#3ecfcf",
        }

    def tier_from(self, choice, options):
        """choice: {catches: [{error_ms}, {error_ms}]} или errors:[...]"""
        if not isinstance(choice, dict):
            return 3
        errs = []
        if "catches" in choice:
            for c in choice.get("catches") or []:
                errs.append(abs(float(c.get("error_ms", 9999))))
        elif "errors" in choice:
            errs = [abs(float(x)) for x in choice["errors"]]
        else:
            errs = [abs(float(choice.get("error_ms", 9999)))]
        while len(errs) < 2:
            errs.append(9999)
        perfect = sum(1 for e in errs[:2] if e <= self.PERFECT_MS)
        good = sum(1 for e in errs[:2] if e <= self.GOOD_MS)
        if perfect >= 2:
            return 0
        if perfect == 1 or good >= 2:
            return 1
        if good == 1:
            return 2
        return 3

    def apply(self, user, target, tier, data):
        thrown = getattr(user, "thrown_machetes", [])
        if thrown:
            thrown.pop(0)
        if tier == 3:
            # самоудар — мачете врезается в ловца
            self_dmg = max(1, int(user.max_hp * 0.055))
            user.hp = max(1, user.hp - self_dmg)
            return [f"🪃 {user.name} не поймал возврат: мачете полоснуло его на {self_dmg} HP!"]
        head = f"🪃 {user.name} — ловля мачете: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        mult = self.TIER_VALUE[tier]
        hits = 2 if tier == 0 else (2 if tier == 1 else 1)
        per = mult / hits
        for _ in range(hits):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, per, pierce=0.45 if tier == 0 else 0.25)
            logs += part
        if tier == 0 and target.is_alive():
            target.add_effect(scale_effect(Bleed(3, 6), user))
            logs.append(f"🩸 Оба клинка рвут {target.name}!")
        return logs

    def describe_for(self, user):
        return (f"Два мачете на дугах: идеал ≤{self.PERFECT_MS} мс на каждый "
                f"(ловля ≤{self.GOOD_MS} мс). Идеал — огромный Урон; промах — удар по себе.")

    def difficulty_stats(self):
        """Текущие окна ловли для интерфейса и проверок."""
        return {"perfect_ms": self.PERFECT_MS, "good_ms": self.GOOD_MS, "blades": 2}


class TwinSpinSkill(MiniGameSkill):
    """Рокх-анн: два независимых спин-бара — остановите оба в зелёной зоне."""

    game, prompt = "dual_stop", "Остановите оба мачете в зелёной зоне!"
    MG_ICON, MG_ACCENT = "🪓", "#3ecfcf"
    TIME_LIMIT_MS = 3000
    TIERS = ("2/2", "1/2", "0/2")
    AI_WEIGHTS = (24, 46, 30)
    PERFECT_W = 0.045  # уже timing_multi harp (0.055)

    def game_params(self, user, target):
        return {
            "bars": 2,
            "period_ms": [random.randint(480, 560), random.randint(560, 660)],
            "zone": 0.62,
            "perfect_w": self.PERFECT_W,
            "good_w": 0.10,
            "icon": "🪓",
            "accent": "#3ecfcf",
        }

    def tier_from(self, choice, options):
        hits = 0
        if isinstance(choice, dict):
            hits = int(choice.get("hits", 0))
            if "stops" in choice:
                hits = sum(1 for s in choice["stops"] if s.get("ok"))
        return 2 - max(0, min(2, hits))

    def apply(self, user, target, tier, data):
        hits = 2 - tier
        logs = [f"🌀 Спин мачете: {hits}/2."]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, 1.15 if hits == 2 else 0.85)
            logs += part
        if hits == 2:
            logs = [Announcement("🌀 Двойной спин идеально!")] + logs[1:]
        return logs


class HammerJudgmentSkill(MiniGameSkill):
    """Серена: суд молота."""

    game, prompt = "judgment_scale", "Уравновесьте весы правосудия!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🔨", "#ffe08a", "#fff4c8"
    MG_HINT = "Нажмите, когда кольцо совпадёт с молотом"
    TIME_LIMIT_MS = 2800
    TIERS = ("ПРАВОСУДИЕ", "удар", "промах")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (2.0, 1.25, 0.5)

    def game_params(self, user, target):
        return {"period_ms": random.randint(720, 980)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 70 else 1 if err <= 155 else 2

    def apply(self, user, target, tier, data):
        head = f"🔨 {user.name} — суд молота: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, _ = self.strike(user, target, self.TIER_VALUE[tier])
        logs += part
        if tier <= 1:
            chance_ok = tier == 0 or random.random() < 0.55
            if chance_ok:
                target.add_effect(Stun(1))
                logs.append(f"💫 {target.name} оглушён!")
        if tier == 0:
            user.add_effect(Shield(2, max(1, int(user.max_hp * 0.1))))
            logs.append("🛡 Правосудие даёт щит.")
        return logs


class PounceSkill(MiniGameSkill):
    """Анниса: прыжок кошки."""

    game, prompt = "pounce_pads", "Прыгайте по меткам кошки!"
    MG_ICON, MG_ACCENT = "🐾", "#f0a0c0"
    TIME_LIMIT_MS = 2800
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (22, 40, 28, 10)

    def game_params(self, user, target):
        return {"count": 3, "icon": "🐾", "spawn_ms": 650}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 3 - max(0, min(3, k))

    def apply(self, user, target, tier, data):
        hits = 3 - tier
        mult = (0.0, 0.7, 1.2, 1.85)[hits]
        logs = [Announcement(f"🐾 Прыжок: {hits}/3!") if hits == 3 else f"🐾 Прыжок: {hits}/3."]
        if hits:
            part, _ = self.strike(user, target, mult, pierce=0.3)
            logs += part
        if hits == 3 and not getattr(user, "cat_form", False):
            # auto tip toward cat form readiness
            user._pounce_ready = True
        return logs


class KodoChargeSkill(MiniGameSkill):
    """Трейфус: заряд кодоя."""

    game, prompt = "charge_steer", "Направьте кодоя в цель!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🐂", "#e8d9a8", "#a67c3a"
    MG_HINT = "Нажмите, когда кольцо совпадёт с рогом кодоя"
    TIME_LIMIT_MS = 2800
    TIERS = ("таран!", "удар", "промах")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (2.15, 1.3, 0.45)

    def is_available(self, user):
        return super().is_available(user) and getattr(user, "kodo_alive", True)

    def game_params(self, user, target):
        return {"period_ms": random.randint(720, 980)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 70 else 1 if err <= 155 else 2

    def apply(self, user, target, tier, data):
        head = f"🐃 Кодой таранит: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, _ = self.strike(user, target, self.TIER_VALUE[tier])
        logs += part
        if tier == 0:
            target.add_effect(Stun(1))
            logs.append(f"💫 Таран оглушает {target.name}!")
        return logs


class AxeStormSkill(MiniGameSkill):
    """Трейфус: буря топоров (после гибели кодоя сильнее)."""

    game, prompt = "axe_orbit", "Сбейте орбитальные топоры!"
    MG_ICON, MG_ACCENT = "🪓", "#c9a227"
    TIME_LIMIT_MS = 3000
    TIERS = tuple(f"{k}/4" for k in range(4, -1, -1))
    AI_WEIGHTS = (18, 30, 28, 16, 8)

    def game_params(self, user, target):
        return {"count": 4, "icon": "🪓", "spawn_ms": 600}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 4 - max(0, min(4, k))

    def apply(self, user, target, tier, data):
        hits = 4 - tier
        bonus = 1.2 if not getattr(user, "kodo_alive", True) else 1.0
        logs = [f"🪓 Топоры: {hits}/4" + (" (ярость!)" if bonus > 1 else "")]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, 0.45 * bonus)
            logs += part
        if hits == 4:
            logs[0] = Announcement(logs[0] + " — идеально!")
        return logs


class WebTrapSkill(MiniGameSkill):
    game, prompt = "web_weave", "Сплетите паутину-сеть!"
    MG_ICON, MG_ACCENT = "🕸", "#a45cff"
    TIME_LIMIT_MS = 2800
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (22, 40, 28, 10)

    def game_params(self, user, target):
        return {"count": 3, "icon": "🕸", "spawn_ms": 650}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 3 - max(0, min(3, k))

    def apply(self, user, target, tier, data):
        hits = 3 - tier
        logs = [f"🕸 Паутина: {hits}/3."]
        if hits >= 1:
            target.add_effect(Slow(2, 1 + hits))
        if hits >= 2:
            target.add_effect(scale_effect(Poison(3, 4), user))
        if hits == 3:
            target.add_effect(Stun(1))
            logs = [Announcement("🕸 Идеальная сеть! Оглушение + яд + замедление.")]
        part, _ = self.strike(user, target, (0.0, 0.6, 1.0, 1.5)[hits])
        return logs + part


class SpiderlingSkill(MiniGameSkill):
    game, prompt = "spawn_burst", "Призовите паучков кликами!"
    MG_ICON, MG_ACCENT = "🕷", "#8a4cff"
    TIME_LIMIT_MS = 3000
    TIERS = ("4/4", "3/4", "2/4", "1/4", "0/4")
    AI_WEIGHTS = (16, 28, 30, 18, 8)

    def game_params(self, user, target):
        return {"count": 4, "icon": "🕷", "spawn_ms": 600}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 4 - max(0, min(4, k))

    def apply(self, user, target, tier, data):
        hits = 4 - tier
        logs = [Announcement(f"🕷 Выводок гнезда: {hits}/4!") if hits == 4 else f"🕷 Выводок гнезда: {hits}/4."]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, _ = self.strike(user, target, 0.4)
            logs += part
            if target.is_alive() and random.random() < 0.35:
                target.add_effect(scale_effect(Poison(2, 3), user))
        return logs


class QueenBiteSkill(MiniGameSkill):
    game, prompt = "fang_snap", "Сомкните клыки в момент укуса!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🕷", "#a45cff", "#5a2080"
    MG_HINT = "Нажмите, когда кольцо совпадёт с клыком"
    TIME_LIMIT_MS = 2600
    TIERS = ("смертельный", "ядовитый", "слаб")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (2.2, 1.35, 0.5)

    def game_params(self, user, target):
        return {"period_ms": random.randint(680, 920)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 65 else 1 if err <= 145 else 2

    def apply(self, user, target, tier, data):
        head = f"👑 Поцелуй вдовы: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, _ = self.strike(user, target, self.TIER_VALUE[tier], ignore_armor=tier == 0)
        logs += part
        power = (7, 4, 2)[tier]
        target.add_effect(scale_effect(Poison(4, power), user))
        logs.append(f"☠️ Яд {power}/ход.")
        return logs


class BleedVolleySkill(MiniGameSkill):
    game, prompt = "volley_fan", "Выпустите веер стрел!"
    MG_ICON, MG_ACCENT = "🩸", "#e05555"
    TIME_LIMIT_MS = 3000
    TIERS = tuple(f"{k}/5" for k in range(5, -1, -1))
    AI_WEIGHTS = (14, 24, 28, 18, 10, 6)

    def game_params(self, user, target):
        return {"count": 5, "icon": "🏹", "spawn_ms": 500}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 5 - max(0, min(5, k))

    def apply(self, user, target, tier, data):
        hits = 5 - tier
        logs = [Announcement(f"🏹 Залп: {hits}/5!") if hits >= 5 else f"🏹 Залп: {hits}/5."]
        for _ in range(hits):
            if not target.is_alive():
                break
            part, dmg = self.strike(user, target, 0.38)
            logs += part
            if dmg and target.is_alive():
                target.add_effect(scale_effect(Bleed(3, 3), user))
        return logs


class SpearThrowSkillMG(MiniGameSkill):
    game, prompt = "spear_power", "Наберите силу броска копья!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🔱", "#5dba6a", "#c8e8a0"
    MG_HINT = "Нажмите, когда кольцо совпадёт с копьём"
    TIME_LIMIT_MS = 2800
    TIERS = ("в сердце!", "в тело", "мимо")
    AI_WEIGHTS = (22, 48, 30)
    TIER_VALUE = (2.3, 1.4, 0.45)

    def game_params(self, user, target):
        return {"period_ms": random.randint(700, 960)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 65 else 1 if err <= 150 else 2

    def apply(self, user, target, tier, data):
        head = f"🔱 Копьё: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 else head]
        part, dmg = self.strike(user, target, self.TIER_VALUE[tier], pierce=0.5)
        logs += part
        if tier <= 1 and dmg:
            target.add_effect(scale_effect(Bleed(4, 5 if tier == 0 else 3), user))
            logs.append("🩸 Глубокая рана!")
        return logs


class DouseSkillMG(MiniGameSkill):
    game, prompt = "splash_aim", "Облейте врага точным плевком браги!"
    MG_ICON, MG_ACCENT = "🍺", "#c9a227"
    TIME_LIMIT_MS = 2800
    TIERS = ("3/3", "2/3", "1/3", "0/3")
    AI_WEIGHTS = (22, 40, 28, 10)

    def ai_score(self, user, target):
        from .ai import horizon,tier_average
        ignite=user.skills.get('ignite')
        if (getattr(target,'doused_turns',0)>1 or not ignite or horizon(user,target)<1.5
                or user.cooldown_left('ignite')>1 or user.blocked_left('ignite')>1
                or user.energy-self.cost+user.energy_regen<ignite.cost):
            return 0
        gain=ignite.expected_damage(user,target,True)-ignite.expected_damage(user,target,False)
        return tier_average(self,user,[gain,gain,gain,0])

    def game_params(self, user, target):
        return {"count": 3, "icon": "🍺", "spawn_ms": 650}

    def tier_from(self, choice, options):
        k = int(choice.get("hits", 0)) if isinstance(choice, dict) else int(choice or 0)
        return 3 - max(0, min(3, k))

    def apply(self, user, target, tier, data):
        hits = 3 - tier
        if hits <= 0:
            return [f"🍺 {user.name} пролил всё мимо."]
        turns = 2 + hits
        target.doused_turns = max(getattr(target, "doused_turns", 0), turns)
        target.add_effect(Slow(2, 1))
        head = f"🍺 {target.name} облит выпивкой на {turns} х.!"
        return [Announcement(head) if hits == 3 else head]


class BreathIgniteSkill(MiniGameSkill):
    game, prompt = "breath_hold", "Удержите дыхание и выдохните огонь!"
    MG_ICON, MG_TARGET_COLOR, MG_RING_COLOR = "🔥", "#ff6a2a", "#ffb040"
    MG_HINT = "Нажмите, когда кольцо совпадёт с пламенем"
    TIME_LIMIT_MS = 2600
    TIERS = ("инферно", "пламя", "искря")
    AI_WEIGHTS = (22, 48, 30)

    def expected_damage(self, user, target, doused):
        from .ai import strike_value,tier_average,effect_value
        values=[]
        for i,mult in enumerate((1.8,1.15,0.55)):
            burn=(8,5,3)[i] if doused else (4,2,1)[i]
            values.append(strike_value(user,target,mult*(1.55 if doused else 1),
                                      ignore_armor=doused and i==0,force=True)
                          +effect_value(user,target,Burn(3,burn)))
        return tier_average(self,user,values)

    def ai_score(self, user, target):
        return self.expected_damage(user,target,getattr(target,'doused_turns',0)>0)

    def game_params(self, user, target):
        return {"period_ms": random.randint(680, 920)}

    def tier_from(self, choice, options):
        err = abs(float(choice.get("error_ms", 9999))) if isinstance(choice, dict) else 9999
        return 0 if err <= 65 else 1 if err <= 145 else 2

    def apply(self, user, target, tier, data):
        doused = getattr(target, "doused_turns", 0) > 0
        base = (1.8, 1.15, 0.55)[tier]
        if doused:
            base *= 1.55
            burn_p = (8, 5, 3)[tier]
            target.doused_turns = 0
            extra = " (по пропитке!)"
        else:
            burn_p = (4, 2, 1)[tier]
            extra = ""
        head = f"🔥 Дыхание{extra}: {self.TIERS[tier]}"
        logs = [Announcement(head) if tier == 0 and doused else head]
        part, _ = self.strike(user, target, base, ignore_armor=doused and tier == 0)
        logs += part
        target.add_effect(scale_effect(Burn(3, burn_p), user))
        logs.append(f"🔥 Горение {burn_p}/ход.")
        return logs


class CardDrawSkill(MiniGameSkill):
    """Вейл: Слепой розыгрыш — 4 карты (валет→туз), у каждой своё действие.
    Уникальная мини-игра veil_blind_draw (не shared card_pick). Джокера нет."""

    game, prompt = "veil_blind_draw", "Перетасуйте и выберите ОДНУ карту!"
    MG_ICON, MG_ACCENT = "🂠", "#d4af37"
    MG_HINT = "Валет / Дама / Король / Туз — у каждой свой эффект"
    TIME_LIMIT_MS = 6500
    # tier index unused for payoff; cards are equal-ish situational
    TIERS = ("туз", "король", "дама", "валет")
    # AI picks card keys with equal-ish weights (situational value, not strict power ladder)
    AI_WEIGHTS = (25, 25, 25, 25)  # ace, king, queen, jack — equal for AI EV
    CARDS = ("ace", "king", "queen", "jack")
    CARD_NAMES = {"ace": "Туз", "king": "Король", "queen": "Дама", "jack": "Валет"}
    CARD_FACES = {"ace": "🂡", "king": "🂮", "queen": "🂭", "jack": "🂫"}
    CARD_EFFECTS = {
        "ace": "💣 большой урон (×2.15, частично сквозь броню)",
        "king": "🛡 щит 12% HP и +1 удача-ресурс",
        "queen": "🩸 кровотечение врагу на 3 хода + укол ×0.85",
        "jack": "💨 +28% уклонения на 2 хода",
    }

    def game_params(self, user, target):
        cards = list(self.CARDS)
        random.shuffle(cards)
        return {
            "cards": cards,  # order under the backs (secret to client until flip)
            "faces_back": True,
            "count": 4,
            "labels": [self.CARD_NAMES[c] for c in self.CARDS],
            "effects": {k: self.CARD_EFFECTS[k] for k in self.CARDS},
            "face_icons": dict(self.CARD_FACES),
            "accent": self.MG_ACCENT,
            "icon": self.MG_ICON,
            "theme": "veil",
            "hint": self.MG_HINT,
        }

    def tier_from(self, choice, options):
        cards = (options or {}).get("cards") or list(self.CARDS)
        idx = 0
        if isinstance(choice, dict):
            idx = int(choice.get("index", 0))
        elif isinstance(choice, (int, float)):
            idx = int(choice)
        idx = max(0, min(len(cards) - 1, idx))
        card = cards[idx]
        # map to TIERS order for AI display only
        try:
            return list(self.CARDS).index(card)
        except ValueError:
            return 3

    def resolve(self, user, target, choice, secret):
        options = secret.get("options") if isinstance(secret, dict) else {}
        cards = (options or {}).get("cards") or list(self.CARDS)
        idx = 0
        late = isinstance(secret, dict) and secret.get("deadline") and time.time() > secret["deadline"]
        if choice in ("timeout", None) or late:
            card = "jack"  # слабый безопасный исход при таймауте
        else:
            if isinstance(choice, dict):
                idx = int(choice.get("index", 0))
            elif isinstance(choice, (int, float)):
                idx = int(choice)
            idx = max(0, min(len(cards) - 1, idx))
            card = cards[idx]
        return self.apply(user, target, 0, card)

    def _perform(self, user, target):
        if getattr(user, "perfect", False):
            # идеальный игрок выбирает туз (урон) — для balance.perfect
            card = "ace"
        else:
            card = random.choice(list(self.CARDS))
        return self.apply(user, target, 0, card)

    def apply(self, user, target, tier, card):
        card = card if card in self.CARD_NAMES else "jack"
        name = self.CARD_NAMES[card]
        face = self.CARD_FACES[card]
        eff = self.CARD_EFFECTS[card]
        head = f"🃏 {user.name} открывает {face} {name}: {eff}"
        logs = [Announcement(head) if card == "ace" else head]

        if card == "ace":
            part, _ = self.strike(user, target, 2.15, pierce=0.35)
            logs += part
        elif card == "king":
            shield = max(1, int(user.max_hp * 0.12))
            user.add_effect(Shield(2, shield))
            gain = 18
            if hasattr(user, "restore_energy"):
                user.restore_energy(gain)
            logs.append(f"🛡 {user.name} получает щит {shield} HP и +{gain} {user.resource_name}.")
        elif card == "queen":
            part, _ = self.strike(user, target, 0.85)
            logs += part
            if target.is_alive():
                target.add_effect(scale_effect(Bleed(3, 5), user))
                logs.append(f"🩸 {name} накладывает кровотечение на {target.name}.")
        else:  # jack
            user.add_effect(DodgeBuff(2, 28))
            logs.append(f"💨 {user.name} — уклонение +28% на 2 хода (Валет).")
        return logs

    def expected_value(self):
        # для ai_score: средний «вес» situational ≈ 1.4 ударного эквивалента
        return 1.4

    def ai_score(self, user, target):
        return 14

    def describe_for(self, user):
        return ("Слепой розыгрыш: 4 карты Вейла. Валет — уклонение, Дама — кровотечение, "
                "Король — щит+удача, Туз — большой Урон. Выберите одну после тасовки.")

