"""Журнал изменений HP (3.3): бой раскладывает его по записям лога, чтобы полоски HP
в интерфейсе менялись пошагово — ровно в момент события, а не сразу до итога.
4.3: журнал свой у каждого потока (threading.local) — параллельные бои в многопоточном Flask
больше не «воруют» записи друг у друга; бой к тому же берёт только записи своих героев."""
import threading

MAX_SIZE = 2000   # защита от роста вне боя
_local = threading.local()


def journal():
    """Список пар (ключ, новое HP) текущего потока: "7" — герой id 7, "s7" — зверь героя 7."""
    j = getattr(_local, "journal", None)
    if j is None:
        j = _local.journal = []
    return j


def record(key, hp):
    j = journal()
    if len(j) >= MAX_SIZE:
        del j[:MAX_SIZE // 2]
    j.append((key, hp))


def __getattr__(name):   # совместимость: hp_journal.JOURNAL — журнал текущего потока
    if name == "JOURNAL":
        return journal()
    raise AttributeError(name)
