"""4.2: новые эффекты (дебаффы мини-игр, расколы брони, формы, метки)."""
from .effects import Effect, Blinded, Bleed


class Distracted(Blinded):
    """«Рассеянность» мага (провал «Рунической печати»): −15% точности."""
    name, icon = "Рассеянность", "😵‍💫"


class Feint(Blinded):
    """«Финт» Газ-Лоу: враг бьёт по пустому месту (−30% точности)."""
    name, icon = "Финт", "🎭"


class Devastation(Effect):
    """«Опустошение» Гуля после выпада: −30% урона и −15% уклонения."""
    name, icon = "Опустошение", "🥀"

    def damage_bonus(self):
        return -0.30

    def dodge_bonus(self):
        return -0.15


class Disarmed(Effect):
    """«Безоружен» Моргала (топор улетел мимо): −30% урона."""
    name, icon = "Безоружен", "🪓"

    def damage_bonus(self):
        return -0.30


class Winded(Effect):
    """«Отдышка» Дуррилы после богатырского удара: −2 брони."""
    name, icon = "Отдышка", "😮‍💨"

    def armor_bonus(self):
        return -self.power


class ArmorBreak(Effect):
    """Снижение брони на power (Взлом замка, «Раскол» Моргала, секира-молот Эриксона). Складывается до cap."""
    name, icon = "Раскол брони", "💔"
    stacks = True
    cap = 4

    def armor_bonus(self):
        return -min(self.power, self.cap)


class LockBreak(ArmorBreak):
    name, icon = "Вскрытая защита", "🔓"
    stacks = False


class Fear(Effect):
    """«Страх» Нефруита: −10% урона."""
    name, icon = "Страх", "😱"

    def damage_bonus(self):
        return -0.10


class Exposed(Effect):
    """Тень поймана: уклонение Нефруита падает до 0."""
    name, icon = "Тень поймана", "🔦"

    def dodge_bonus(self):
        return -1.0


class Vulnerable(Effect):
    """Получаемый урон +power% (форма «секира-молот», провал «Соединения»)."""
    name, icon = "Уязвимость", "🎯"

    def modify_incoming(self, owner, damage, attacker):
        return int(damage * (100 + self.power) / 100), []


class AxeHammerForm(Vulnerable):
    """Форма «секира-молот» Эриксона: удары ×1.3, 25% оглушить, −1 брони врагу; получаемый урон +power%."""
    name, icon, positive = "Секира-молот", "⚒", True


class Guard(Effect):
    """«Глухая оборона» и т.п.: −power% получаемого урона (без иммунитета к оглушению)."""
    name, icon, positive = "Глухая оборона", "🛡", True

    def __init__(self, duration=2, power=35, title=None):
        super().__init__(duration, power)
        if title:
            self.name = title

    def modify_incoming(self, owner, damage, attacker):
        # 4.4: «обороны» не складываются — действует только самая сильная (стойка + щит-стена давали −61%)
        guards = [e for e in owner.get_effects() if isinstance(e, Guard) and e.duration > 0] if hasattr(owner, "get_effects") else []
        if guards and max(guards, key=lambda e: e.power) is not self:
            return damage, []
        cut = int(damage * self.power / 100)
        return max(1, damage - cut), ([f"🛡 {self.name}: {owner.name} гасит {cut} урона."] if cut else [])


class ParryStance(Effect):
    """«Контрудар» Конана: до его следующего хода 50% парировать атаку героя и ударить в ответ ×0.8."""
    name, icon, positive = "Контрудар", "⚔", True

    def modify_incoming(self, owner, damage, attacker):
        from models.rng import RNG as random
        if attacker is None or not hasattr(attacker, "skills") or random.random() >= 0.5 or self.duration <= 0:
            return damage, []
        self.duration = 0
        back = max(1, int(owner.get_damage() * 0.8 * owner.damage_multiplier()) - attacker.armor_total())
        attacker.hp = attacker.hp - back
        return 0, [f"⚔ {owner.name} парирует удар и бьёт в ответ: {attacker.name} получает {back} урона."]


class BroadChest(Effect):
    """«Широкая грудь» Дуррилы: следующий удар вдвое слабее, мощь с него идёт в двойном размере."""
    name, icon, positive = "Широкая грудь", "💪", True

    def modify_incoming(self, owner, damage, attacker):
        if attacker is None:
            return damage, []
        self.duration = 0
        half = max(1, damage // 2)
        if hasattr(owner, "add_might"):
            owner.add_might(half * 2, cap=False)
        return half, [f"💪 Широкая грудь {owner.name}: удар ослаблен вдвое ({damage}→{half}), мощь ×2."]


class Reflect(Effect):
    """Отражение части урона (Каменная броня Риноу)."""
    name, icon, positive = "Отражение", "🪨", True

    def modify_incoming(self, owner, damage, attacker):
        if attacker is None or damage <= 0:
            return damage, []
        back = max(1, int(damage * self.power / 100))
        attacker.hp = attacker.hp - back
        return damage, [f"🪨 {owner.name} отражает {back} урона в {attacker.name}."]


class CupsTrick(Effect):
    """«Напёрстки»: следующая ОБЫЧНАЯ атака врага гарантированно мимо (мини-игры и призывы не спасают)."""
    name, icon, positive = "Пустой стакан", "🥤", True


class Decoy(Effect):
    """Пометка «двойник Газ-Лоу жив» (сам двойник — призыв)."""
    name, icon, positive = "Подмена", "👥", True


class Blessing(Effect):
    """«Благословение» Каэля: +15% точности и +10% уклонения."""
    name, icon, positive = "Благословение", "✨", True

    def accuracy_bonus(self):
        return 0.15

    def dodge_bonus(self):
        return 0.10


class Rooted(Effect):
    """«Оковы корней» друида: враг не может уклоняться, −2 скорости."""
    name, icon = "Оковы корней", "⛓"

    def speed_bonus(self):
        return -2

    def dodge_bonus(self):
        return -1.0


class LungeReady(Effect):
    """«Затаиться» Гуля: следующий выпад сильнее."""
    name, icon, positive = "Затаился", "🫥", True

    def dodge_bonus(self):
        return 0.40 if self.duration >= 1 and self.power else 0.0
