"""Double-click entrypoint for the local single-player game."""
import os
import sys
import traceback
from pathlib import Path


def main():
    folder = Path(__file__).resolve().parent
    os.chdir(folder)
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(errors='backslashreplace')
    try:
        if sys.version_info < (3, 10):
            raise RuntimeError('Для игры нужен Python 3.10 или новее.')
        from solo_app import app as game
        port = int(os.environ.get('PORT', '5000'))
        if not 1 <= port <= 65535:
            raise ValueError('Неверный порт игры.')
        print('\nАрена героев — одиночная игра', flush=True)
        print('Открой в браузере: http://127.0.0.1:' + str(port), flush=True)
        print('Оставь это окно открытым, пока играешь.\n', flush=True)
        game.run(host='127.0.0.1', port=port, debug=False, use_reloader=False)
        return 0
    except KeyboardInterrupt:
        return 0
    except (Exception, SystemExit) as exc:
        if isinstance(exc, SystemExit) and exc.code in (None, 0):
            return 0
        details = traceback.format_exc()
        error_file = folder / 'START_ERROR.txt'
        saved = False
        try:
            error_file.write_text(details, encoding='utf-8')
            saved = True
        except OSError:
            pass
        print('\nНе удалось запустить игру.\n', file=sys.stderr)
        print(details, file=sys.stderr)
        if saved:
            print('Текст ошибки сохранён рядом с app.py: START_ERROR.txt', file=sys.stderr)
        print('Пришли этот файл или фотографию этого окна для исправления.', file=sys.stderr, flush=True)
        if os.name == 'nt':
            try:
                input('\nНажми Enter, чтобы закрыть окно…')
            except (EOFError, OSError):
                pass
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
else:
    # Keep the existing import API for tests, Flask tooling and balance scripts.
    from solo_app import app, service, APP_VERSION
