"""Shared game version for both entrypoints and the sharing helper."""
APP_VERSION = "5.8.0"
