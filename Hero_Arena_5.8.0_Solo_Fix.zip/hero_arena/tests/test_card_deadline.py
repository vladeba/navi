"""A delayed card result must follow the same timeout contract as other games."""
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import time
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import app, service
from models import Battle, HERO_CLASSES


class CardDeadlineTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        self.old_save = service.save_path
        self.temporary = TemporaryDirectory()
        service.save_path = str(Path(self.temporary.name) / "save.json")
        self.addCleanup(self.temporary.cleanup)
        self.addCleanup(setattr, service, "save_path", self.old_save)

    def resolve_card(self, *, expired=False, explicit_timeout=False, omit_deadline=False,
                     invalid_index=False):
        user = HERO_CLASSES["gambler"]("Deadline regression")
        target = HERO_CLASSES["warrior"]("Deadline target")
        battle = Battle(user, target, mode="manual")
        service._battles[battle.id] = battle
        self.addCleanup(service._battles.pop, battle.id, None)
        battle.start()
        while battle.current is not user:
            battle.play_turn("attack")
        battle.play_turn("card_draw")
        self.assertEqual(battle.pending["skill"].key, "card_draw")
        secret = battle.pending["secret"]
        secret["deadline"] = time.time() + (-1 if expired else 60)
        if omit_deadline:
            secret.pop("deadline")
        ace_index = secret["options"]["cards"].index("ace")
        choice = "timeout" if explicit_timeout else {"index": "invalid" if invalid_index else ace_index}
        response = self.client.post(f"/api/battles/{battle.id}/react", json={"choice": choice})
        self.assertEqual(response.status_code, 200)
        messages = [entry["text"] for entry in response.get_json()["log"] if "открывает" in entry["text"]]
        self.assertEqual(len(messages), 1)
        self.assertIsNone(battle.pending)
        return messages[0]

    def test_timely_selection_keeps_chosen_card(self):
        self.assertIn("Туз", self.resolve_card())

    def test_expired_selection_uses_timeout_jack(self):
        self.assertIn("Валет", self.resolve_card(expired=True))

    def test_explicit_timeout_still_uses_jack(self):
        self.assertIn("Валет", self.resolve_card(explicit_timeout=True))

    def test_legacy_missing_deadline_preserves_selection(self):
        self.assertIn("Туз", self.resolve_card(omit_deadline=True))

    def test_expired_input_is_not_parsed_as_fresh_selection(self):
        self.assertIn("Валет", self.resolve_card(expired=True, invalid_index=True))


if __name__ == "__main__":
    unittest.main()
