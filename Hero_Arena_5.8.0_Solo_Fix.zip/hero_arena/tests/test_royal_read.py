"""Leon reads changing guard; replayed inputs determine the next-attack reward."""
import time,unittest
from unittest.mock import patch
from models import HERO_CLASSES
from models.heroes_55 import NextCritical

class RoyalRead(unittest.TestCase):
    def setUp(self):
        self.hero=HERO_CLASSES['leon']('Леон');self.target=HERO_CLASSES['warrior']('Цель')
        self.hero.configure_arena();self.hero.reset();self.skill=self.hero.skills['composure']
        self.options=self.skill.public_options(self.hero,self.target)
    def choice(self,correct=4):
        attacks=[{'lane':p['open'] if i<correct else (p['open']+1)%3,'ms':p['start']+250}
                 for i,p in enumerate(self.options['stances'])]
        return {'attacks':attacks,'elapsed_ms':attacks[-1]['ms']}
    def test_explicit_stances_and_single_opening(self):
        self.assertEqual(self.options['game'],'royal_read');self.assertEqual(len(self.options['stances']),4)
        for a,b in zip(self.options['stances'],self.options['stances'][1:]):
            self.assertEqual(a['end'],b['start']);self.assertNotEqual(a['open'],b['open'])
    def test_grade_counts_actual_open_zones(self):
        for count,tier in [(4,0),(3,1),(2,2),(1,3),(0,3)]:
            self.assertEqual(self.skill.tier_from(self.choice(count),self.options),tier)
    def test_empty_waiting_no_longer_wins(self):
        self.assertEqual(self.skill.tier_from({'elapsed_ms':9000,'attacks':[]},self.options),3)
    def test_same_stance_cannot_be_spammed(self):
        c=self.choice();c['attacks'][1]['ms']=c['attacks'][0]['ms']+100
        self.assertEqual(self.skill.tier_from(c,self.options),3)
    def test_invalid_lane_and_future_timestamp_rejected(self):
        for value in (float('nan'),True,-1,3,'0'):
            c=self.choice();c['attacks'][0]['lane']=value
            self.assertEqual(self.skill.tier_from(c,self.options),3)
        c=self.choice();c['elapsed_ms']=100
        self.assertEqual(self.skill.tier_from(c,self.options),3)
    def test_reward_is_next_attack_not_immediate_damage(self):
        hp=self.target.hp
        self.skill.apply(self.hero,self.target,0,{})
        self.assertEqual(self.target.hp,hp);effect=next((e for e in self.hero.get_effects() if isinstance(e,NextCritical)),None)
        self.assertIsNotNone(effect);self.assertEqual(effect.power,25)
    def test_three_correct_get_critical_without_execute_bonus(self):
        self.skill.apply(self.hero,self.target,1,{})
        self.assertEqual(next((e for e in self.hero.get_effects() if isinstance(e,NextCritical)),None).power,0)
    def test_shortened_game_compresses_all_stances(self):
        self.skill._time_multiplier=.7
        o=self.skill.public_options(self.hero,self.target)
        self.assertEqual(o['time_limit_ms'],6300);self.assertEqual(o['stances'][-1]['end'],6300)

if __name__=='__main__':unittest.main()
