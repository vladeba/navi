"""Requested balance changes, reachable input grades and read-only contextual help."""
import math,random,time,unittest
from unittest.mock import patch
from models import HERO_CLASSES,Battle
from models import minigames_58 as m
from models.effects import Shield,Poison,Antiheal,Stun,Bleed
from models.item import OrdinaryKatana,Yoshirin
from models.summons import Bear,Hamster,Falcon,Snake,Deer,random_beast
from models.help_58 import hero_help

def hero(k):
 h=HERO_CLASSES[k](k);h.configure_arena();h.reset();h.turn_number=5;h.restore_energy(999);return h

def winning58(skill,o):
 c={'elapsed_ms':o['time_limit_ms']-10};mode=o['mode'];f=o['factor'];prep=o['prepare_ms']
 if mode in ('stop','summon'):
  start=prep;c['clicks']=[]
  for i in range(o['rounds']):
   t=start+round(o['period']*o['zone']/2);c['clicks'].append({'ms':t});start=t+round(200*f)
 elif mode=='hold':c.update(down_ms=prep+100,up_ms=prep+100+round(o['charge_ms']*.68))
 elif mode in ('aim','sniper'):
  c['shots']=[]
  for i in range(o['shots']):
   t=prep+round((700+i*650)*f);x,y=m.aim_position(o,t,i);c['shots'].append(dict(ms=t,x=x,y=y))
 elif mode=='focus':
  c['engaged_ms']=prep;c['points']=[dict(t=t,x=m.at(o['path'],t)[0],y=m.at(o['path'],t)[1]) for t in range(prep,prep+o['track_ms']+1,20)]
 elif mode in ('path','circuit'):
  down=prep+100;up=down+round((len(o['nodes'])-1)*300*f);c.update(down_ms=down,up_ms=up)
  c['points']=[dict(t=round(down+(up-down)*i/((len(o['nodes'])-1)*5)),x=x,y=y) for i,(_,x,y) in enumerate(path_samples(o['nodes'],down,up))]
 elif mode=='flick':
  c['cuts']=[dict(down_ms=round(prep+100+i*500*f),up_ms=round(prep+350+i*500*f),x0=180,y0=232,x1=p[0],y1=p[1]) for i,p in enumerate(o['targets'])]
 elif mode in ('lanes','runes','zones'):c['actions']=[dict(lane=e['lane'],ms=e.get('ms',round((e['start']+e['end'])/2))) for e in o['waves']]
 elif mode=='rhythm':c['clicks']=[dict(ms=t) for t in o['beats']]
 elif mode in ('steer','catch'):
  c['engaged_ms']=prep;c['points']=[dict(t=t,x=e['x'],y=220) for e in o['gates' if mode=='steer' else 'drops'] for t in (e['ms']-150,e['ms']+100)]
 elif mode=='echo':c['actions']=[dict(lane=v,ms=o['show_until']+round((150+i*300)*f)) for i,v in enumerate(o['sequence'])]
 elif mode=='machete':c['actions']=[dict(hand=e['hand'],ms=e['ms']) for e in o['returns']]
 return c

def path_samples(nodes,down,up):
 out=[];total=(len(nodes)-1)*5
 for i in range(total+1):
  seg=min(len(nodes)-2,i//5);f=(i-seg*5)/5;a,b=nodes[seg],nodes[seg+1]
  out.append((round(down+(up-down)*i/total),a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f))
 return out

class Replay58(unittest.TestCase):
 def games(self):
  for (key,sk),spec in m.SPECS.items():
   h=hero(key);yield h,h.skills[sk]
 def test_all34_games_have_reachable_ideal_and_input_free_failure(self):
  count=0
  for h,s in self.games():
   with self.subTest(hero=h.type_key,skill=s.key):
    o=s.public_options(h,hero('warrior'));c=winning58(s,o);self.assertEqual(s.tier_from(c,o),0,(s.key,c,o));self.assertEqual(s.tier_from({},o),3);self.assertEqual(s.tier_from({'hits':999,'score':999,'elapsed_ms':o['time_limit_ms']},o),3)
   count+=1
  self.assertEqual(count,34)
 def test_shortened_games_scale_targets_and_windows(self):
  for h,s in self.games():
   s._time_multiplier=.7;o=s.public_options(h,hero('warrior'));self.assertEqual(s.tier_from(winning58(s,o),o),0,(h.type_key,s.key))
 def test_resolver_rejects_future_deadline_and_malformed_events(self):
  for h,s in self.games():
   t=hero('warrior');o=s.public_options(h,t);c=winning58(s,o);secret=dict(options=o,started=time.time()-20,deadline=time.time()+10)
   with patch.object(s,'apply',side_effect=lambda u,t,tier,data:tier):
    self.assertEqual(s.resolve(h,t,c,secret),0,s.key)
    for bad in (None,{'score':999,'elapsed_ms':100},{**c,'elapsed_ms':True},{**c,'elapsed_ms':float('nan')},{**c,'points':[{'t':True,'x':1,'y':1}]}):self.assertEqual(s.resolve(h,t,bad,secret),3,(s.key,bad))
    self.assertEqual(s.resolve(h,t,c,{**secret,'started':time.time()}),3)
    self.assertEqual(s.resolve(h,t,c,{**secret,'deadline':time.time()-1}),3)
 def test_partial_success_not_all_or_nothing(self):
  for h,s in self.games():
   o=s.public_options(h,hero('warrior'));mode=o['mode'];c=winning58(s,o)
   if mode in ('lanes','runes','zones','echo'):c['actions']=c['actions'][:2]
   elif mode=='rhythm':c['clicks']=c['clicks'][:2]
   elif mode=='summon':c['clicks']=c['clicks'][:2]
   elif mode=='machete':c['actions']=c['actions'][:1]
   elif mode=='aim' and o['shots']>1:c['shots']=c['shots'][:2]
   elif mode=='hold':c['up_ms']=c['down_ms']+round(o['charge_ms']*.5)
   elif mode=='stop':c['clicks'][0]['ms']=o['prepare_ms']+round(o['period']*(o['zone']+.14)/2)
   else:continue
   self.assertIn(s.tier_from(c,o),(1,2),(h.type_key,s.key,mode))
 def test_duel_visible_center_hits_and_no_future_prediction(self):
  h=hero('musketeer');s=h.skills['duel_shot'];o=s.public_options(h,hero('warrior'));c=winning58(s,o);self.assertEqual(s.tier_from(c,o),0);c['shots'][0]['x']+=36;self.assertEqual(s.tier_from(c,o),1);c['shots'][0]['x']=5;c['shots'][0]['y']=5;self.assertEqual(s.tier_from(c,o),3)
  s.apply(h,hero('warrior'),0,None);self.assertFalse(h.loaded);self.assertFalse(s.is_available(h));self.assertFalse(h.skills['sniper_shot'].is_available(h))
 def test_summon_stages_cannot_be_spammed_in_one_green_window(self):
  h=hero('darkknight');s=h.skills['plague'];o=s.public_options(h,hero('warrior'));c=winning58(s,o);t=c['clicks'][0]['ms'];c['clicks']=[dict(ms=t+i) for i in range(3)];self.assertEqual(s.tier_from(c,o),3)
 def test_machete_has_two_clear_returns_and_server_derived_self_damage(self):
  h=hero('bluetroll');s=h.skills['machete_cross'];o=s.public_options(h,hero('warrior'));self.assertEqual(len(o['returns']),2);c=winning58(s,o);self.assertEqual(m.machete_metrics(c,o),(0,0));c['actions']=c['actions'][:1];self.assertEqual(m.machete_metrics(c,o),(2,1));h.hp=1;s.apply(h,hero('warrior'),3,{'bad_catches':2});self.assertFalse(h.is_alive())

class Balance58(unittest.TestCase):
 def test_card_engine_and_heal_reduced(self):
  h=hero('gambler');t=hero('warrior');h.spend_energy(h.energy);h.skills['blue_card']._perform(h,t);self.assertEqual(h.energy,24);h.hp=50;before=h.hp;h.skills['green_card']._perform(h,t);self.assertEqual(h.hp-before,int(h.max_hp*.07))
 def test_red_critical_peak_reduced_with_combo_and_restores_crit(self):
  h=hero('gambler');t=hero('druid');h.veil_combo=1;before=t.hp;old=h.crit_multiplier
  with patch('random.random',return_value=0),patch('random.uniform',return_value=1.1):h.skills['red_card']._perform(h,t)
  self.assertLess(before-t.hp,75);self.assertGreater(before-t.hp,30);self.assertEqual(h.crit_multiplier,old);self.assertEqual(h.veil_combo,0)
 def test_only_ordinary_katana_gets_flat_boost(self):
  h=hero('samurai');h.katana=OrdinaryKatana();a=h.get_damage();h.katana=Yoshirin();b=h.get_damage();self.assertAlmostEqual(a-b,1.0)
 def test_monk_base_damage_up_and_new_skills_present(self):
  h=hero('monk');self.assertEqual(h._base_damage,11.3);self.assertIn('breaking_palm',h.skills)
  expected={'spartan':'spear_challenge','darkelf':'ash_sigil','musketeer':'sniper_shot','minotaur':'bulwark_charge','paladin':'dawn_circle','orc':'rage_axe','feliss':'tail_sweep','getou':'grave_needle'}
  for k,key in expected.items():self.assertIn(key,hero(k).skills)
 def test_werewolf_exact_cost_and_ice_shield_less_reward(self):
  self.assertEqual(hero('pagan').skills['werewolf'].cost,45);self.assertEqual(hero('mage').skills['ice_shield'].ABSORB,[30,26,20,10])
 def test_lion_bypasses_shield_and_confidence_can_advance(self):
  h=hero('leon');t=hero('warrior');t.add_effect(Shield(10,999));before=t.hp
  with patch('random.random',return_value=.5),patch('random.uniform',return_value=1):h.skills['predator_instinct']._perform(h,t)
  self.assertLess(t.hp,before);self.assertEqual(h.shield_pierce,.35)
 def test_feliss_auto_single_mark_refresh_and_source_separation(self):
  from models.heroes_55 import marks,add_marks
  h=hero('feliss');other=hero('feliss');t=hero('warrior');add_marks(h,t,3);self.assertEqual(marks(t,h).power,1);self.assertIsNone(marks(t,other));self.assertEqual(h.CRIT_PER_WEAKPOINT,.12)
  t.turn_number+=1;h.skills['attack'].fixed_hit=1;h.skills['attack']._perform(h,t);self.assertEqual(marks(t,h).power,1);self.assertEqual(marks(t,h).expiries,[t.turn_number+3])
 def test_keltazar_bonus_only_low_hp_lifesteal(self):
  h=hero('keltazar');h.hp=round(h.max_hp*.31);self.assertEqual(h.lifesteal_multiplier(),1);h.hp=round(h.max_hp*.2);self.assertEqual(h.lifesteal_multiplier(),1.2);before=h.hp;h.heal(10);self.assertEqual(h.hp-before,10)
 def test_suture_available_for_wounded_master_without_army_and_no_full_health_spam(self):
  h=hero('getou');s=h.skills['flesh_stitch'];self.assertFalse(s.is_available(h));h.hp-=20;self.assertTrue(s.is_available(h));before=h.hp;s.apply(h,hero('warrior'),0,None);self.assertEqual(h.hp-before,8);self.assertEqual((s.cost,s.cooldown),(22,5))
 def test_getou_weak_personal_attack_finishes_without_summons(self):
  h=hero('getou');t=hero('warrior');t.hp=2;h.skills['grave_needle'].accuracy=1
  with patch('random.random',return_value=.5):h.skills['grave_needle']._perform(h,t)
  self.assertFalse(t.is_alive());self.assertFalse(h.living_minions())
 def test_cat_skills_are_bound_to_current_form(self):
  h=hero('catfolk');self.assertTrue(h.skills['hunter_blade'].is_available(h));self.assertFalse(h.skills['claw_dash'].is_available(h));h.cat_form=True;self.assertFalse(h.skills['hunter_blade'].is_available(h));self.assertTrue(h.skills['claw_dash'].is_available(h));self.assertTrue(h.skills['cat_escape'].is_available(h))
 def test_druid_death_heal_once_no_replace_reset_or_antiheal_bypass(self):
  h=hero('druid');h.hp-=30;pet=Hamster(h);h.summon=pet;before=h.hp;pet.hp=0;self.assertEqual(h.hp-before,round(h.max_hp*.04));pet.hp=0;self.assertEqual(h.hp-before,round(h.max_hp*.04));pet.hp=pet.max_hp;pet.hp=0;self.assertEqual(h.hp-before,round(h.max_hp*.04))
  before=h.hp;h.summon=Bear(h);self.assertEqual(h.hp,before);h.add_effect(Antiheal(2));h.summon.hp=0;self.assertEqual(h.hp,before)
 def test_druid_probabilities_and_bear_hp_player_only(self):
  h=hero('druid');self.assertEqual(Bear(h).max_hp,105);self.assertEqual(Bear(None).max_hp,85)
  with patch('random.choices',return_value=[Snake]) as choose:random_beast(h);self.assertEqual(choose.call_args.kwargs['weights'],[12,25,24,24,15])
 def test_plague_three_distinct_stages_and_freeze_not_repeatable(self):
  h=hero('darkknight');s=h.skills['plague'];t=hero('warrior')
  for tier,name in [(2,'Скелет'),(1,'Вурдалак'),(0,'Костяной дракон')]:s.apply(h,t,tier,None);self.assertIn(name,h.summon.name)
  dragon=h.summon;dragon.damage=20
  with patch('random.random',return_value=.5),patch('random.uniform',return_value=1):
   dragon.attack(t);self.assertFalse(dragon.freeze_used);dragon.attack(t);self.assertTrue(dragon.freeze_used);t._effects=[];dragon.attack(t);self.assertFalse(t.has_effect(Stun))
 def test_help_forecasts_pure_and_explain_combo(self):
  for k,cls in HERO_CLASSES.items():
   h=hero(k);t=hero('warrior');before=random.getstate();ids=h._next_id;old=dict(getattr(h,'_passive56',{}));info=hero_help(h)
   for sk in h.skills.values():
    if hasattr(sk,'SPEC'):sk.ai_score(h,t)
   self.assertEqual(before,random.getstate(),k);self.assertEqual(ids,h._next_id,k);self.assertEqual(old,getattr(h,'_passive56',{}),k);self.assertTrue(info['Пассивка'])
  self.assertIn('Царь зверей',hero_help(hero('leon'))['Комбо']);self.assertIn('75%',hero_help(hero('leon'))['Уверенность'])

if __name__=='__main__':unittest.main()

class InnateIntegration58(unittest.TestCase):
 def test_hunter_bonus_changes_actual_hit_and_resets(self):
  from models import passives_56 as p
  h=hero('hunter');t=hero('warrior');t._armor=10;h._base_damage=35;h.crit_chance=0;s=h.skills['mark_shot']
  with patch('random.uniform',return_value=1):
   p.paid(h,s);before=t.hp;s.apply(h,t,1,None);plain=before-t.hp
   p.paid(h,h.skills['traps']);p.paid(h,s);before=t.hp;s.apply(h,t,1,None);varied=before-t.hp
  self.assertGreater(varied,plain);h.reset();self.assertEqual(p.pierce(h,s,True),0)
 def test_gambler_critical_intercept_does_not_spend_hero_guard(self):
  from models import passives_56 as p
  h=hero('gambler');h.summon=Bear(h);a=hero('warrior');a.crit_chance=1
  with patch.object(h,'pick_defender',return_value=h.summon):a.skills['attack']._single_hit(a,h,force_hit=True)
  self.assertFalse(h._passive56.get('crit_guard_used'));self.assertEqual(p.critical_guard(h,50),40)
 def test_troll_return_heal_requires_actual_hp_loss(self):
  h=hero('bluetroll');t=hero('warrior');b=Battle(h,t,mode='manual');b.start();h.hp=30;t.add_effect(Shield(5,999));h.thrown_machetes=[dict(turns=1,effect='damage')];h.start_turn();self.assertEqual(h.hp,30)
  t._effects=[];h.thrown_machetes=[dict(turns=1,effect='damage')];h.start_turn();self.assertEqual(h.hp,32)
 def test_gift_expiry_never_overwrites_larger_shield(self):
  from models import passives_56 as p
  from models.effects import GodGift
  h=hero('pagan');gift=GodGift(next(iter(GodGift.GODS)),3,1);h.add_effect(gift);p.turn_start(h);h._effects.remove(gift);h.add_effect(Shield(5,50));p.turn_start(h);self.assertEqual(sum(e.power for e in h._effects if isinstance(e,Shield)),50)
 def test_orc_minigame_lifesteal_once_in_manual_and_ai_paths(self):
  for manual in (True,False):
   h=hero('orc');h.hp=30;t=hero('warrior');s=h.skills['axe_throw']
   with patch.object(h,'heal',wraps=h.heal) as heal,patch.object(s,'ai_tier',return_value=0):
    if manual:s.pay(h);s.apply(h,t,0,None)
    else:h.perform(s.key,t)
   self.assertEqual(heal.call_count,1);self.assertGreater(h.hp,30)
 def test_druid_boss_does_not_receive_playable_death_passive(self):
  from models import DruidBoss
  h=DruidBoss('Босс');self.assertEqual(Bear(h).max_hp,85);h.hp-=30;hp=h.hp;Bear(h).hp=0;self.assertEqual(h.hp,hp)
 def test_passive_and_context_descriptions_do_not_create_summons(self):
  from models import hp_journal,Character
  from models.summons import Summon
  h=hero('druid');hp_journal.journal().clear();state=random.getstate();i=Character._next_id
  for _ in range(5):h.to_dict();hero_help(h)
  self.assertEqual(random.getstate(),state);self.assertEqual(Character._next_id,i);self.assertEqual(hp_journal.journal(),[])
 def test_passives_have_distinct_automatic_conditions(self):
  from models import passives_56 as p
  texts=[text for _,text in p.NEW.values()];self.assertEqual(len(set(texts)),15)
  for k in ('darkelf','musketeer','pagan','goblin','hunter','centaur','bluetroll','spiderqueen','pandaren','gambler'):
   self.assertNotIn('restore_energy',__import__('inspect').getsource(p.paid));self.assertTrue(hero_help(hero(k))['Пассивка'])
