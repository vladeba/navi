"""Real mage mechanics: input replay, companions, tactical values and API reactions."""
import copy
import math
import random
import unittest
from tempfile import TemporaryDirectory
from pathlib import Path
from unittest.mock import patch

from app import app, service
from models import Battle, HERO_CLASSES, hp_journal
from models.effects import Shield, Stun, Burn, DamageReduction
from models.mage_skills import (RuneWeaveSkill, CraftedWaterSpirit, StoneGolem, Conductive,
    WaterSculptSkill, IceAssemblySkill, FireballCraftSkill, GolemStackSkill, CircuitLightningSkill)
from services.game_service import GameService


class MageSpellcraftTests(unittest.TestCase):
    def setUp(self):
        self.mage = HERO_CLASSES['mage']('Маг проверки')
        self.mage.configure_arena(); self.mage.reset()
        self.target = HERO_CLASSES['paladin']('Цель проверки')
        self.target.configure_arena(); self.target.reset()

    def test_ten_abilities_and_six_distinct_games(self):
        self.assertEqual(len(self.mage.skills), 10)
        games = [s.game for s in self.mage.skills.values() if hasattr(s, 'game')]
        self.assertEqual(len(games), 6); self.assertEqual(len(set(games)), 6)
        self.assertNotIn('memory', games)
        self.assertEqual(self.mage.max_hp, 185)

    def test_support_spellcraft_is_classified_as_defense(self):
        for key in ('ice_shield','stone_golem','water_spirit'):
            self.assertEqual(self.mage.action_category(self.mage,key),'defense')
        for key in ('rune_seal','fireball','lightning'):
            self.assertEqual(self.mage.action_category(self.mage,key),'skill')

    def test_runes_have_visible_references_and_reward_alignment(self):
        s = self.mage.skills['rune_seal']; o = s.public_options(self.mage, self.target)
        self.assertEqual(len(o['targets']), 4)
        self.assertTrue(all(a != b for a, b in zip(o['targets'], o['rotations'])))
        self.assertEqual(s.tier_from({'rotations': o['targets']}, o), 0)
        self.assertEqual(s.tier_from({'rotations': o['rotations']}, o), 3)
        self.assertEqual(s.tier_from({'score': 999999}, o), 3)
        self.mage.spend_energy(50); before = self.mage.energy
        s.apply(self.mage, self.target, 0, None)
        self.assertEqual(self.mage.energy, before+15)
        self.assertGreater(s.TIER_VALUE[0], 2.4)

    def test_water_quality_counts_unique_correct_placements(self):
        s = self.mage.skills['water_spirit']; o = s.public_options(self.mage, self.target)
        placements = [{'part': i, 'slot': o['target_slots'][i]} for i in range(6)]
        for n, tier in ((6,0),(4,1),(2,2),(0,3)):
            self.assertEqual(s.tier_from({'placements': placements[:n]}, o), tier)
        self.assertEqual(s.tier_from({'placements': [placements[0]]*6}, o), 3)
        self.assertEqual(s.tier_from({'placements': [{'part': -1, 'slot': 3}, None]}, o), 3)
        self.assertEqual(s.tier_from({'score': 9999}, o), 3)

    def test_perfect_spirit_exact_stats_and_campaign_scaling_once(self):
        skill = self.mage.skills['water_spirit']
        skill.apply(self.mage, self.target, 0, None)
        spirit = self.mage.summon
        self.assertEqual((spirit.hp, spirit.max_hp, spirit.damage, spirit.lifetime), (85,85,5,7))
        campaign = HERO_CLASSES['mage']('Сюжет', level=9); campaign.story = True
        campaign.skills['water_spirit'].apply(campaign, self.target, 0, None)
        self.assertEqual(campaign.summon.max_hp, int(85*campaign.power_scale()))
        self.assertEqual(campaign.summon.lifetime, 7)
        options = campaign.skills['water_spirit'].public_options(campaign, self.target)
        self.assertEqual(options['ideal_hp'], campaign.summon.max_hp)
        self.assertIn(str(campaign.summon.max_hp), campaign.skills['water_spirit'].describe_for(campaign))

    def test_live_spirit_and_golem_exclude_each_other_before_mana_spend(self):
        for first, second in (('water_spirit','stone_golem'),('stone_golem','water_spirit')):
            self.mage.reset(); self.mage.restore_energy(100)
            self.mage.skills[first].apply(self.mage, self.target, 0, None)
            other = self.mage.skills[second]; before = self.mage.energy
            self.assertFalse(self.mage.can_use(other))
            with self.assertRaises(ValueError):other.pay(self.mage)
            self.assertEqual(self.mage.energy, before)
            self.mage.summon.hp = 0
            self.assertTrue(self.mage.can_use(other))

    def test_new_companion_replaces_dead_entity_in_hp_animation(self):
        battle = Battle(self.mage, self.target, mode='manual'); battle.start()
        logs = self.mage.skills['water_spirit'].apply(self.mage, self.target, 0, None)
        battle._log_many(logs, self.mage, self.target)
        self.mage.summon.hp = 0
        battle._log_many(['Первый призыв погиб'], self.mage, self.target)
        logs = self.mage.skills['stone_golem'].apply(self.mage, self.target, 0, None)
        battle._log_many(logs, self.mage, self.target)
        self.assertEqual(battle.log[-1]['hp_after']['s'+str(self.mage.id)], 100)

    def test_companion_expiry_uses_rounds_even_without_mage_actions(self):
        battle = Battle(self.mage, self.target, mode='manual'); battle.start()
        skill = self.mage.skills['water_spirit']; skill.apply(self.mage, self.target, 0, None)
        spirit = self.mage.summon; start = battle.round
        self.assertEqual(spirit.expires_round, start+7)
        spirit.tick_life(); self.assertEqual(spirit.lifetime, 7)
        self.mage.add_effect(Stun(10))
        for elapsed in range(1,7):
            battle._new_round()
            self.assertTrue(spirit.is_alive())
            self.assertEqual(spirit.lifetime, 7-elapsed)
        battle._new_round()
        self.assertFalse(spirit.is_alive()); self.assertIsNone(self.mage.summon)
        self.assertEqual(battle.round, start+7)

    def test_water_applies_conductivity_and_lightning_consumes_it(self):
        spirit = CraftedWaterSpirit(self.mage, 0)
        spirit.attack(self.target)
        self.assertTrue(self.target.has_effect(Conductive))
        lightning = self.mage.skills['lightning']; self.target.add_effect(Shield(3, 40))
        with patch.object(lightning, 'strike', return_value=([], 0)) as strike:
            lightning.apply(self.mage, self.target, 0, None)
        self.assertAlmostEqual(strike.call_args.args[2], 2.8*1.25)
        self.assertFalse(self.target.has_effect(Conductive))
        shield = next(e for e in self.target.get_effects() if isinstance(e, Shield))
        self.assertEqual(shield.power, 25)

    def test_golem_absorbs_a_direct_attack_and_stuns_on_real_hit(self):
        self.mage.summon = golem = StoneGolem(self.mage, 0)
        before = self.mage.hp
        with patch('models.rng._random.random', return_value=0), patch('models.rng._random.uniform', return_value=1):
            self.target.attack(self.mage)
            self.assertEqual(self.mage.hp, before)
            self.assertLess(golem.hp, golem.max_hp)
            golem.attack(self.target)
        self.assertTrue(self.target.has_effect(Stun))
        self.target._effects = [Shield(3,100)]
        with patch('models.rng._random.random', return_value=0):golem.attack(self.target)
        self.assertFalse(self.target.has_effect(Stun))

    def test_golem_opening_guard_covers_one_hit_then_uses_quality_chance(self):
        golem = StoneGolem(self.mage, 0); self.mage.summon = golem
        before = self.mage.hp
        with patch('models.rng._random.random', return_value=.99):
            self.target.skills['attack']._single_hit(self.target, self.mage, force_hit=True)
            self.assertEqual(self.mage.hp, before)
            self.assertFalse(golem.opening_guard)
            self.assertEqual(golem.intercept_chance, .5)
            self.target.skills['attack']._single_hit(self.target, self.mage, force_hit=True)
            self.assertLess(self.mage.hp, before)

    def test_ice_requires_contiguous_closed_contour(self):
        s = self.mage.skills['ice_shield']; o = s.public_options(self.mage, self.target)
        self.assertEqual(s.tier_from({'path': [0,1,2,3,4,5,0]}, o), 0)
        self.assertEqual(s.tier_from({'path': [0,1,2,3,4]}, o), 1)
        self.assertEqual(s.tier_from({'path': [0,2,3,4,5,0]}, o), 3)
        s.apply(self.mage, self.target, 0, None)
        shield = next(e for e in self.mage.get_effects() if isinstance(e, Shield))
        self.assertEqual((shield.power, shield.duration), (30,3))

    def test_fire_replays_heat_and_rejects_overheat_and_bad_timestamps(self):
        s = self.mage.skills['fireball']
        o = {'start_heat':12,'heat_per_s':36,'cool_per_s':12,'period_ms':1600,'phase_ms':0}
        perfect = {'events':[{'ms':0,'down':True}], 'elapsed_ms':2000}
        self.assertEqual(s.tier_from(perfect, o), 0)
        overheat = {'events':[{'ms':0,'down':True},{'ms':3000,'down':False}], 'elapsed_ms':4000}
        self.assertEqual(s.tier_from(overheat, o), 3)
        self.assertEqual(s.tier_from({'events':[{'ms':4001,'down':True}],'elapsed_ms':2000},o),3)
        self.assertEqual(s.tier_from({'events':[], 'elapsed_ms':float('nan')},o),3)
        self.assertEqual(s.tier_from({'score':999},o),3)
        self.assertEqual(s.tier_from('timeout',o),3)

    def test_golem_stack_is_geometric_and_duplicate_scores_do_not_count(self):
        s = self.mage.skills['stone_golem']; o = s.public_options(self.mage, self.target)
        times=[]; previous=-1
        for period, phase in zip(o['periods'],o['phases']):
            t=next(t for t in range(previous+1,6501) if abs(math.sin(2*math.pi*(t+phase)/period))<.001)
            times.append(t);previous=t
        self.assertEqual(s.tier_from({'drops':times},o),0)
        self.assertEqual(s.tier_from({'drops':[-1,0,float('nan')]},o),3)
        self.assertEqual(s.tier_from({'layers':5,'width':999999},o),3)

    @staticmethod
    def solve_circuit(options):
        result=[]
        # Generator guarantees a valid path in the original (unrotated) ports.
        for cell in options['cells']:result.append(0)
        return result

    def test_lightning_circuit_is_solvable_and_validated_on_server(self):
        s=self.mage.skills['lightning']
        for _ in range(100):
            o=s.public_options(self.mage,self.target)
            solution=self.solve_circuit(o)
            self.assertEqual(s.tier_from({'rotations':solution},o),0)
            self.assertEqual(s.tier_from({'score':999999},o),3)
            self.assertEqual(s.tier_from({'rotations':[4]*12},o),3)
            self.assertEqual(s.tier_from({'rotations':[float('nan')]*12},o),3)

    def test_timeout_and_late_results_never_grant_best_tier(self):
        for key in ('rune_seal','water_spirit','ice_shield','fireball','stone_golem','lightning'):
            s=self.mage.skills[key]; options=s.public_options(self.mage,self.target)
            with self.subTest(key=key), patch.object(s,'apply',return_value=[]) as apply:
                s.resolve(self.mage,self.target,{}, {'deadline':1,'options':options})
                self.assertEqual(apply.call_args.args[2],3)
                s.resolve(self.mage,self.target,'timeout', {'deadline':None,'options':options})
                self.assertEqual(apply.call_args.args[2],3)

    def test_mage_ai_scores_do_not_change_state_or_rng(self):
        def state():return (self.mage.hp,self.mage.energy,self.mage.summon,copy.deepcopy(self.mage._cooldowns),[(e.name,e.duration,e.power) for e in self.target.get_effects()])
        before=state();rng=random.getstate();journal=list(hp_journal.journal())
        for s in self.mage.skills.values():self.assertTrue(math.isfinite(s.ai_score(self.mage,self.target)))
        self.assertEqual(before,state());self.assertEqual(rng,random.getstate());self.assertEqual(journal,hp_journal.journal())

    def test_companion_reservation_does_not_wait_for_the_excluded_summon(self):
        from models.ai import reserve_penalty
        water = self.mage.skills['water_spirit']; golem = self.mage.skills['stone_golem']
        self.mage.spend_energy(50)
        forecasts = {s.key: 0 for s in self.mage.skills.values()}
        forecasts[golem.key] = 1000
        self.assertEqual(reserve_penalty(water, self.mage, self.target, forecasts), 0)

    def test_golem_prediction_accounts_for_both_shields_and_stun_immunity(self):
        golem = self.mage.skills['stone_golem']
        exposed = golem.ai_score(self.mage, self.target)
        self.mage.add_effect(Shield(3,100))
        self.assertLess(golem.ai_score(self.mage, self.target), exposed)
        self.mage._effects = []
        self.target.add_effect(Shield(3,100))
        self.assertLess(golem.ai_score(self.mage, self.target), exposed)
        self.target._effects = []
        self.target.add_effect(DamageReduction(2,25,stun_immune=True))
        self.assertLess(golem.ai_score(self.mage, self.target), exposed)

    def test_golem_is_valued_as_urgent_defense_instead_of_a_default_opener(self):
        golem = self.mage.skills['stone_golem']
        healthy = golem.ai_score(self.mage, self.target)
        self.mage.hp = 20
        self.assertGreater(golem.ai_score(self.mage, self.target), healthy)

    def test_lobby_and_existing_saves_receive_new_kit_without_losing_progress(self):
        with TemporaryDirectory() as folder:
            game=GameService(str(Path(folder)/'save.json'));h=self.mage
            h.wins=11;h.skins=['gold'];h.skin='gold';game._heroes[h.id]=h;game.save();game.load();loaded=game.get_hero(h.id)
            self.assertEqual((loaded.wins,loaded.skin,len(loaded.skills)),(11,'gold',10))
            loaded.summon=StoneGolem(loaded);loaded.hp=10
            view=loaded.lobby_dict();self.assertEqual(view['hp'],185);self.assertIsNone(view['summon'])

    def test_api_all_six_manual_games_pay_once_and_resume(self):
        client=app.test_client()
        for key in ('rune_seal','water_spirit','ice_shield','fireball','stone_golem','lightning'):
            a=HERO_CLASSES['mage']('API маг');b=HERO_CLASSES['paladin']('API цель')
            battle=Battle(a,b,mode='manual');service._battles[battle.id]=battle
            self.addCleanup(service._battles.pop,battle.id,None)
            battle.start();battle.current=a
            energy=a.energy
            response=client.post(f'/api/battles/{battle.id}/turn',json={'skill':key})
            self.assertEqual(response.status_code,200,response.get_json())
            pending=response.get_json()['pending'];self.assertTrue(pending['options']['game'].startswith('mage_'))
            self.assertEqual(a.energy,energy-a.skills[key].cost)
            response=client.post(f'/api/battles/{battle.id}/react',json={'choice':'timeout'})
            self.assertEqual(response.status_code,200,response.get_json())
            self.assertIsNone(battle.pending)


if __name__=='__main__':unittest.main()
