"""The mythic skin must retain its own art through actual form transitions."""
from io import BytesIO
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import app, service
from models import Battle, HERO_CLASSES
from PIL import Image


class CatfolkArtTests(unittest.TestCase):
    def test_mythic_art_exists_as_game_sized_jpeg(self):
        client = app.test_client()
        response = client.get('/static/images/skins/catfolk_celestial_cat_cat.jpg')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.mimetype, 'image/jpeg')
        with Image.open(BytesIO(response.data)) as image:
            self.assertEqual(image.size, (512, 512))
            self.assertEqual(image.mode, 'RGB')
            image.load()

    def test_real_transform_and_battle_override_keep_mythic_form(self):
        human = '/static/images/skins/catfolk_celestial_cat.jpg'
        beast = '/static/images/skins/catfolk_celestial_cat_cat.jpg'
        cat = HERO_CLASSES['catfolk']('Mythic regression')
        cat.add_skin('celestial_cat')
        cat.equip_skin('celestial_cat')
        self.assertEqual(cat.image, human)
        battle = Battle(cat, HERO_CLASSES['warrior']('Form target'), mode='manual')
        service._battles[battle.id] = battle
        self.addCleanup(service._battles.pop, battle.id, None)
        battle.start()
        while battle.current is not cat:
            battle.play_turn('attack')
        response = app.test_client().post(f'/api/battles/{battle.id}/turn', json={'skill': 'transform'})
        self.assertEqual(response.status_code, 200)
        view = next(h for h in response.json['heroes'] if h['id'] == cat.id)
        self.assertTrue(view['cat_form'])
        self.assertEqual(view['image'], beast)
        self.assertEqual(view['role'], 'warrior')
        # A random/NPC battle skin must also select its matching cat art,
        # without replacing the permanent skin on the model.
        cat.skin = None
        battle.skin_override[cat.id] = 'celestial_cat'
        self.assertEqual(battle._hero_view(cat)['image'], beast)
        self.assertIsNone(cat.skin)
        cat.reset()
        self.assertEqual(cat.image, '/images/catfolk')


if __name__ == '__main__':
    unittest.main()
