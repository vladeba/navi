"""Regression coverage for the live dice payload and its Flask reaction path."""
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import app, service
from models import Battle, HERO_CLASSES


class DiceMasteryTests(unittest.TestCase):
    def setUp(self):
        self.skill = HERO_CLASSES["gnoll"]("Dice unit regression").skills["bone_dice"]

    def test_live_payload_applies_optional_bonus_once(self):
        # roll may already contain a displayed/adjusted value. Only base_roll
        # is the starting point, so the server can never turn 3 -> 4 -> 5.
        for displayed in (3, 4):
            with self.subTest(displayed=displayed), patch("random.random", return_value=0.54) as bonus:
                result = self.skill._roll_from_choice(
                    {"roll": displayed, "base_roll": 3, "mastery": True, "error_ms": 0})
                self.assertEqual(result, 4)
                bonus.assert_called_once_with()

    def test_bonus_probability_boundary_and_cap(self):
        with patch("random.random", return_value=0.55):
            self.assertEqual(self.skill._roll_from_choice(
                {"roll": 3, "base_roll": 3, "mastery": True}), 3)
        with patch("random.random") as bonus:
            self.assertEqual(self.skill._roll_from_choice(
                {"roll": 6, "base_roll": 6, "mastery": True}), 6)
            bonus.assert_not_called()

    def test_timing_boundary_and_timeout_payload(self):
        with patch("random.random", return_value=0.0) as bonus:
            self.assertEqual(self.skill._roll_from_choice({"roll": 3, "error_ms": 90}), 4)
            self.assertEqual(self.skill._roll_from_choice({"roll": 3, "error_ms": 91}), 3)
            self.assertEqual(self.skill._roll_from_choice(
                {"roll": 3, "base_roll": 3, "mastery": False, "error_ms": 9999}), 3)
            bonus.assert_called_once_with()

    def test_legacy_exact_rolls_and_clamping(self):
        with patch("random.random") as bonus, patch("random.randint") as roll:
            for choice, expected in ((3, 3), (0, 1), (9, 6),
                                     ({"roll": 4}, 4), ({"roll": 0}, 1), ({"roll": 9}, 6)):
                with self.subTest(choice=choice):
                    self.assertEqual(self.skill._roll_from_choice(choice), expected)
            bonus.assert_not_called()
            roll.assert_not_called()

    def test_known_base_does_not_consume_unused_random_roll(self):
        with patch("random.randint") as roll:
            self.assertEqual(self.skill._roll_from_choice({"base_roll": 3}), 3)
            roll.assert_not_called()
        with patch("random.randint", return_value=4) as roll:
            self.assertEqual(self.skill._roll_from_choice({}), 4)
            roll.assert_called_once_with(1, 6)

    def test_flask_reaction_uses_mastery_result_in_buff(self):
        client = app.test_client()
        old_save = service.save_path
        with TemporaryDirectory() as temporary:
            service.save_path = str(Path(temporary) / "save.json")
            try:
                for choice, chance, expected, power in (
                    ({"roll": 3, "base_roll": 3, "mastery": True, "error_ms": 0}, 0.0, 4, 13),
                    ({"roll": 3, "base_roll": 3, "mastery": True, "error_ms": 0}, 0.9, 3, 10),
                    ({"roll": 3, "base_roll": 3, "mastery": False, "error_ms": 9999}, 0.0, 3, 10),
                    ({"roll": 6, "base_roll": 6, "mastery": True, "error_ms": 0}, 0.0, 6, 20),
                    ({"roll": 3}, 0.0, 3, 10),
                ):
                    with self.subTest(choice=choice, chance=chance):
                        gnoll = HERO_CLASSES["gnoll"]("Dice Flask regression")
                        target = HERO_CLASSES["warrior"]("Dice Flask target")
                        battle = Battle(gnoll, target, mode="manual")
                        service._battles[battle.id] = battle
                        try:
                            battle.start()
                            while battle.current is not gnoll:
                                battle.play_turn("attack")
                            battle.play_turn("bone_dice")
                            self.assertEqual(battle.pending["skill"].key, "bone_dice")
                            with patch("random.random", return_value=chance):
                                response = client.post(f"/api/battles/{battle.id}/react",
                                                       json={"choice": choice})
                            self.assertEqual(response.status_code, 200)
                            messages = [entry["text"] for entry in response.get_json()["log"]
                                        if "выбрасывает" in entry["text"]]
                            self.assertEqual(len(messages), 1)
                            self.assertIn(f"выбрасывает {expected}", messages[0])
                            self.assertIn(f"+{power}%", messages[0])
                            self.assertIsNone(battle.pending)
                            self.assertEqual(client.post(f"/api/battles/{battle.id}/react",
                                                         json={"choice": choice}).status_code, 400)
                        finally:
                            service._battles.pop(battle.id, None)
            finally:
                service.save_path = old_save


if __name__ == "__main__":
    unittest.main()
