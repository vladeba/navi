"""Decision regressions for the 5.4.1 balance pass (real hero kits)."""
import copy
import random
import unittest
from unittest.mock import patch

from models import HERO_CLASSES
from models.ai import action_score,effect_value,healing,strike_value
from models.effects import Antiheal,Burn,Poison,DamageReduction,Shield,Stun
from models.effects_42 import Guard
from models.skills import DamageSkill
from models.item import Kyocherin


class BalanceAI(unittest.TestCase):
    def heroes(self,cls='shade',enemy='warrior'):
        user,target=HERO_CLASSES[cls]('A'),HERO_CLASSES[enemy]('B')
        user.opponent,target.opponent=target,user
        user.turn_number=target.turn_number=5
        user.restore_energy(100)
        return user,target

    def test_paid_duplicate_is_not_randomly_used(self):
        user,target=self.heroes()
        user.skills={k:s for k,s in user.skills.items() if k in ('attack','dark_touch')}
        for seed in range(200):
            random.seed(seed)
            self.assertEqual(user.choose_action(target),'attack')

    def test_score_does_not_roll_or_change_fighters(self):
        for cls in ('orc','darkknight','minotaur','mage','samurai','shade','ranger','pandaren','paladin','croc'):
            user,target=self.heroes(cls)
            before=(user.hp,user.energy,dict(user._cooldowns),list(user._effects),target.hp,target.energy,list(target._effects))
            rng=random.getstate()
            for s in user.skills.values():
                action_score(s,user,target)
            self.assertEqual(random.getstate(),rng,cls)
            self.assertEqual(before,(user.hp,user.energy,dict(user._cooldowns),list(user._effects),target.hp,target.energy,list(target._effects)),cls)

    def test_armor_is_paid_for_each_hit(self):
        user,target=self.heroes('samurai')
        target._armor=10
        one=strike_value(user,target,1.8,1,force=True)
        many=strike_value(user,target,0.6,3,force=True)
        self.assertGreater(one,many)

    def test_katana_accuracy_is_respected(self):
        user,target=self.heroes('samurai')
        user.katana=Kyocherin()
        skill=user.skills['iaijutsu']
        target.dodge=0.7
        value=skill.ai_score(user,target)
        # The katana's own hit rule, rather than generic accuracy-dodge.
        with patch.object(user,'hit_chance',return_value=0.4):
            low=skill.ai_score(user,target)
        self.assertGreater(value,low)

    def test_shunpo_accounts_for_armor_piercing(self):
        user,target=self.heroes('samurai')
        target._armor=15
        low=user.skills['shunpo'].ai_score(user,target)
        target._armor=0
        high=user.skills['shunpo'].ai_score(user,target)
        self.assertGreater(high,low)

    def test_iai_mastery_changes_expected_value(self):
        user,target=self.heroes('samurai')
        skill=user.skills['iai_flash']
        with patch.dict('models.tuning.AI_SKILL',{'samurai':1.0}):normal=skill.ai_score(user,target)
        with patch.dict('models.tuning.AI_SKILL',{'samurai':1.5}):better=skill.ai_score(user,target)
        self.assertGreater(better,normal)

    def test_heal_is_zero_under_antiheal(self):
        user,target=self.heroes('paladin');user.hp=40
        self.assertGreater(user.skills['lay_hands'].ai_score(user,target),0)
        user.add_effect(Antiheal(2))
        self.assertEqual(user.skills['lay_hands'].ai_score(user,target),0)

    def test_heal_caps_missing_hp_and_fatigue(self):
        user,target=self.heroes('mage');user.hp=user.max_hp-2
        self.assertEqual(user.skills['heal'].ai_score(user,target),2)
        user.hp=10;user.fatigue=1
        self.assertEqual(user.skills['heal'].ai_score(user,target),0)

    def test_existing_buff_not_recast(self):
        user,target=self.heroes('paladin');skill=user.skills['bless']
        user.add_effect(skill.effects[0]())
        self.assertEqual(skill.ai_score(user,target),0)

    def test_blind_not_recast(self):
        user,target=self.heroes('ranger');skill=user.skills['mark']
        target.add_effect(skill.effect())
        self.assertEqual(skill.ai_score(user,target),0)

    def test_roots_cannot_remove_more_dodge_than_target_has(self):
        user,target=self.heroes('druid');target.dodge=0
        skill=user.skills['root_chains'];eff=skill.effect()
        self.assertLess(effect_value(user,target,eff),2)

    def test_stun_immunity_removes_control_value(self):
        user,target=self.heroes('paladin')
        self.assertGreater(effect_value(user,target,Stun(1)),0)
        target.add_effect(DamageReduction(2,25,stun_immune=True))
        self.assertEqual(effect_value(user,target,Stun(1)),0)

    def test_dont_reset_growing_poison(self):
        user,target=self.heroes('spiderqueen')
        target.add_effect(Poison(3,20))
        self.assertEqual(effect_value(user,target,Poison(3,4)),0)

    def test_blood_harvest_full_hp_price_against_guard(self):
        user,target=self.heroes('darkknight')
        target.add_effect(Guard(2,90))
        self.assertLess(action_score(user.skills['blood_harvest'],user,target),
                        action_score(user.skills['attack'],user,target))

    def test_plague_armor_and_remaining_time_matter(self):
        user,target=self.heroes('darkknight');skill=user.skills['plague']
        target._armor=0
        useful=skill.ai_score(user,target)
        target._armor=20
        self.assertLess(skill.ai_score(user,target),useful)
        target.hp=1
        self.assertLess(skill.ai_score(user,target),useful)

    def test_douse_requires_usable_follow_up(self):
        user,target=self.heroes('pandaren');skill=user.skills['douse']
        self.assertGreater(skill.ai_score(user,target),0)
        user.set_cooldown('ignite',4)
        self.assertEqual(skill.ai_score(user,target),0)
        user._cooldowns={};user._blocked={'ignite':3}
        self.assertEqual(skill.ai_score(user,target),0)

    def test_douse_not_repeated_while_target_is_wet(self):
        user,target=self.heroes('pandaren');target.doused_turns=4
        self.assertEqual(user.skills['douse'].ai_score(user,target),0)

    def test_ignite_values_wet_target(self):
        user,target=self.heroes('pandaren');skill=user.skills['ignite']
        dry=skill.ai_score(user,target);target.doused_turns=3
        self.assertGreater(skill.ai_score(user,target),dry)

    def test_shell_values_cleansing_burn(self):
        user,target=self.heroes('croc');skill=user.skills['mud_shell']
        plain=skill.ai_score(user,target);user.add_effect(Burn(3,12))
        self.assertGreater(skill.ai_score(user,target),plain+20)

    def test_shell_not_used_when_it_cannot_avert_lethal_damage(self):
        user,target=self.heroes('croc');user.hp=1
        self.assertEqual(user.skills['mud_shell'].ai_score(user,target),0)

    def test_shell_not_used_instead_of_a_finishing_attack(self):
        user,target=self.heroes('croc');target.hp=1;user.add_effect(Burn(3,12))
        self.assertEqual(user.skills['mud_shell'].ai_score(user,target),0)

    def test_lunge_values_actual_saved_satiety(self):
        user,target=self.heroes('croc');user.lunge_ready=True
        user.satiety=0;low=user.skills['lunge'].ai_score(user,target)
        user.satiety=100;high=user.skills['lunge'].ai_score(user,target)
        self.assertGreater(high,low)

    def test_shell_not_used_to_cleanse_a_weak_expiring_burn(self):
        user,target=self.heroes('croc');user.add_effect(Burn(1,3))
        self.assertEqual(user.skills['mud_shell'].ai_score(user,target),0)

    def test_resource_price_prefers_saving_when_low(self):
        user,target=self.heroes('shade');skill=user.skills['dark_touch']
        full=action_score(skill,user,target);user.spend_energy(90)
        self.assertLess(action_score(skill,user,target),full)

    def test_injured_archer_not_forced_to_hide(self):
        user,target=self.heroes('archer');user.hp=user.max_hp//3
        user.skills={k:s for k,s in user.skills.items() if k in ('attack','invisibility')}
        with patch.object(user.skills['invisibility'],'ai_score',return_value=0):
            for seed in range(30):
                random.seed(seed)
                self.assertEqual(user.choose_action(target),'attack')

    def test_save_for_ready_heal_instead_of_paid_filler(self):
        user,target=self.heroes('paladin');user.hp=30;user.spend_energy(75)
        user.skills={k:s for k,s in user.skills.items() if k in ('attack','shield_bash','lay_hands')}
        with patch.object(user.skills['attack'],'ai_score',return_value=10), \
             patch.object(user.skills['shield_bash'],'ai_score',return_value=20), \
             patch.object(user.skills['lay_hands'],'ai_score',return_value=50):
            self.assertEqual(user.choose_action(target),'attack')
            user._blocked['lay_hands']=4
            self.assertEqual(user.choose_action(target),'shield_bash')

    def test_exploration_never_picks_below_free_attack(self):
        user,target=self.heroes('shade')
        user.skills={k:s for k,s in user.skills.items() if k in ('attack','dark_touch')}
        with patch.object(user.skills['attack'],'ai_score',return_value=10), \
             patch.object(user.skills['dark_touch'],'ai_score',return_value=10.9):
            for seed in range(100):
                random.seed(seed)
                self.assertEqual(user.choose_action(target),'attack')

    def test_small_score_gain_does_not_flip_whole_rotation(self):
        user,target=self.heroes('shade')
        user.skills={k:s for k,s in user.skills.items() if k in ('attack','dark_touch')}
        counts=[]
        for gain in (0.01,0.5):
            used=0
            with patch('models.ai.action_score',side_effect=lambda s,u,t,forecasts:10 if s.key=='attack' else 10+gain):
                for seed in range(500):
                    random.seed(seed)
                    used+=user.choose_action(target)=='dark_touch'
            counts.append(used)
        self.assertLess(counts[0],40)
        self.assertGreater(counts[1],200)
        self.assertGreater(counts[1],counts[0])


if __name__=='__main__':unittest.main()
