"""The visible green-zone suture replays holds and heals actual missing HP."""
import unittest
from models import HERO_CLASSES
from models.necromancy_55 import STATS

class FleshSuture(unittest.TestCase):
    def setUp(self):
        self.g=HERO_CLASSES['getou']('Гэтоу');self.g.configure_arena();self.g.reset()
        self.enemy=HERO_CLASSES['warrior']('Цель');self.g.opponent=self.enemy
        self.g.raise_minion('zombie',0);self.skill=self.g.skills['flesh_stitch'];self.o=self.skill.public_options(self.g,self.enemy)
    def choice(self,n):
        spans=[{'down_ms':i*1500,'up_ms':i*1500+(750 if i<n else 200)} for i in range(4)]
        return {'stitches':spans,'elapsed_ms':6000}
    def test_four_clear_attempts_grade_independently(self):
        self.assertEqual(self.o['game'],'flesh_suture')
        for n in range(5):self.assertEqual(self.skill.tier_from(self.choice(n),self.o),4-n)
    def test_old_matching_input_no_longer_wins(self):
        self.assertEqual(self.skill.tier_from({'placements':[{'part':0,'slot':0}],'elapsed_ms':8000},self.o),4)
    def test_overlapping_holds_and_future_times_rejected(self):
        c=self.choice(4);c['stitches'][1]['down_ms']=100
        self.assertEqual(self.skill.tier_from(c,self.o),4)
        c=self.choice(4);c['elapsed_ms']=100
        self.assertEqual(self.skill.tier_from(c,self.o),4)
        for bad in (float('nan'),-1,True,'750'):
            c=self.choice(4);c['stitches'][0]['up_ms']=bad
            self.assertEqual(self.skill.tier_from(c,self.o),4)
    def test_four_successful_sutures_heal_each_pet_and_owner(self):
        self.g.raise_minion('skeleton',0)
        for pet in self.g.living_minions():pet.hp-=20
        self.g.hp-=30;hp=self.g.hp
        self.skill.apply(self.g,self.enemy,0,{})
        self.assertEqual(self.g.hp,hp+8)
        for pet in self.g.living_minions():self.assertEqual(pet.hp,pet.max_hp-4)
    def test_short_game_compresses_hold_speed_too(self):
        self.skill._time_multiplier=.7;o=self.skill.public_options(self.g,self.enemy)
        self.assertEqual(o['time_limit_ms'],5600);self.assertEqual(o['suture_period'],840)
    def test_every_quality_has_requested_health_and_life_buff(self):
        self.assertEqual([(r[0],r[3]) for r in STATS['skeleton']],[(55,10),(51,10),(43,10)])
        self.assertEqual([(r[0],r[3]) for r in STATS['zombie']],[(45,9),(41,9),(37,9),(33,9)])
        self.assertEqual([(r[0],r[3]) for r in STATS['homunculus']],[(90,8),(75,8),(60,8)])

if __name__=='__main__':unittest.main()
