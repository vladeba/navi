"""The double-click launcher keeps a failed Windows launch visible."""
import contextlib,io,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import app as launcher

class SoloLaunch(unittest.TestCase):
 def test_local_app_has_no_online_routes_or_imported_online_dependency(self):
  c=launcher.app.test_client()
  page=c.get('/').get_data(as_text=True)
  self.assertEqual(c.get('/api').json['version'],'5.8.0')
  self.assertNotIn('href="/online"',page)
  for route in ['/online','/api/online/roster']:
   self.assertEqual(c.get(route).status_code,404)
 def test_main_starts_one_local_server_and_prints_url(self):
  out=io.StringIO()
  with patch.object(launcher.os,'chdir'),patch.object(launcher.sys,'stdout',out),patch.dict(os.environ,{'PORT':'5585'}),patch('solo_app.app.run') as run:
   self.assertEqual(launcher.main(),0)
   run.assert_called_once_with(host='127.0.0.1',port=5585,debug=False,use_reloader=False)
  self.assertIn('http://127.0.0.1:5585',out.getvalue())
 def test_existing_python38_and39_are_not_rejected_by_launcher(self):
  for version in ((3,8,20),(3,9,25)):
   with self.subTest(version=version),patch.object(launcher.os,'chdir'),patch.object(launcher.sys,'version_info',version),patch.dict(os.environ,{'PORT':'5585'}),patch('solo_app.app.run') as run,contextlib.redirect_stdout(io.StringIO()):
    self.assertEqual(launcher.main(),0);run.assert_called_once()
 def test_missing_module_is_logged_and_windows_waits_for_enter(self):
  with tempfile.TemporaryDirectory() as d:
   fake_file=str(Path(d)/'app.py')
   class WindowsOS:
    name='nt';environ={}
    @staticmethod
    def chdir(path):pass
   with patch.object(launcher,'__file__',fake_file),patch.object(launcher,'os',WindowsOS),patch.dict(sys.modules,{'solo_app':None}),patch('builtins.input',return_value='') as pause,contextlib.redirect_stderr(io.StringIO()):
    self.assertEqual(launcher.main(),1);pause.assert_called_once()
   text=(Path(d)/'START_ERROR.txt').read_text(encoding='utf-8')
   self.assertIn('solo_app',text);self.assertIn('ModuleNotFoundError',text)

if __name__=='__main__':unittest.main()
