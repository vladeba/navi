"""Existing heroes receive class armor changes without losing custom offsets."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from models import HERO_CLASSES
from models.tuning import KIT_TUNING
from services.game_service import GameService


class BalanceSaveMigration(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'save.json'
        self.service=GameService(save_path=str(self.path))
        self.service._heroes={};self.service._players={};self.service._items={}

    def legacy_save(self,heroes,offsets=None):
        offsets=offsets or {}
        self.service._heroes={h.id:h for h in heroes};self.service.save()
        data=json.loads(self.path.read_text())
        for row in data['heroes']:
            row['armor']-=KIT_TUNING.get(row['type'],{}).get('armor',0)
            row['armor']+=offsets.get(row['type'],0)
            row.pop('armor_base')
        self.path.write_text(json.dumps(data))

    def test_legacy_default_armor_migrates_only_once(self):
        heroes=[HERO_CLASSES[k]('H') for k in ('paladin','mage','goblin')]
        expected={h.id:h.armor for h in heroes};self.legacy_save(heroes)
        self.service.load()
        self.assertEqual({i:self.service.get_hero(i).armor for i in expected},expected)
        self.service.save();self.service.load()
        self.assertEqual({i:self.service.get_hero(i).armor for i in expected},expected)
        data=json.loads(self.path.read_text())
        self.assertTrue(all('armor_base' in h for h in data['heroes']))

    def test_legacy_custom_armor_offset_is_preserved(self):
        hero=HERO_CLASSES['mage']('Custom')
        expected=hero.armor+3;self.legacy_save([hero],{'mage':3})
        self.service.load();self.assertEqual(self.service.get_hero(hero.id).armor,expected)

    def test_current_save_keeps_personal_armor(self):
        hero=HERO_CLASSES['paladin']('Current');hero.armor=7
        self.service._heroes={hero.id:hero};self.service.save();self.service.load()
        self.assertEqual(self.service.get_hero(hero.id).armor,7)

    def test_progress_and_current_level_hp_survive_migration(self):
        hero=HERO_CLASSES['paladin']('Progress',level=8)
        hero.story=True
        hero.experience=31;hero.wins=7;hero.story_progress={'forest':3}
        expected_hp=hero.max_hp;self.legacy_save([hero]);self.service.load()
        loaded=self.service.get_hero(hero.id)
        self.assertEqual((loaded.level,loaded.experience,loaded.wins),(8,31,7))
        self.assertEqual(loaded.story_progress,{'forest':3})
        self.assertEqual(loaded.max_hp,expected_hp)


if __name__=='__main__':unittest.main()
