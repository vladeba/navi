"""Behavioral regressions for six kits and multi-target combat."""
import copy,json,math,random,time,unittest
from unittest.mock import patch
from models import HERO_CLASSES,Battle,Character,hp_journal
from models.arena_rules import ROLE_HP_BANDS
from models.heroes_55 import (WeakPoint,add_marks,marks,place_verdict,verdict,TwoHitShield,
                             NextCritical,ShortGame)
from models.necromancy_55 import dismiss,finish_bombs
from models.effects import Blinded,Stun,Antiheal
from models.rituals_55 import interpolate


def hero(key):
    h=HERO_CLASSES[key](key);h.configure_arena();h.reset();return h


class SixHeroes(unittest.TestCase):
    def setUp(self):self.foe=hero('paladin')
    def cast(self,h,key,target=None):
        target=target or self.foe;h.opponent=target;h._combat_target=target
        result=h.skills[key].execute(h,target);h.after_action(target);return result
    def test_roster_and_ability_counts(self):
        self.assertEqual(len(HERO_CLASSES),43)
        counts={'keltazar':7,'feliss':7,'cyclops':10,'mersey':10,'leon':9,'getou':10}
        games=[]
        for key,n in counts.items():
            h=hero(key);self.assertEqual(len(h.skills),n)
            games += [(s.game,getattr(s,'SPEC',{}).get('mode')) for s in h.skills.values() if hasattr(s,'game')]
        self.assertEqual(len(games),22);self.assertEqual(len(set(games)),22)
    def test_final_user_choice_keeps_role_hp_bands(self):
        for key in HERO_CLASSES:
            h=hero(key)
            self.assertTrue(ROLE_HP_BANDS[h.role][0]<=h.max_hp<=ROLE_HP_BANDS[h.role][1],key)
    def test_weak_points_are_source_specific_and_capped(self):
        a,b=hero('feliss'),hero('feliss');add_marks(a,self.foe,8)
        e=marks(self.foe,a);self.assertEqual(e.power,1)
        self.assertEqual(e.modify_incoming(self.foe,100,a)[0],118)
        self.assertEqual(e.modify_incoming(self.foe,100,b)[0],100)
        a._active_target=self.foe
        self.assertAlmostEqual(a.get_crit()-a.crit_chance,.12)
    def test_marks_expire_individually_without_refreshing_all(self):
        a=hero('feliss');add_marks(a,self.foe,1)
        self.foe.turn_number=1;add_marks(a,self.foe,1)
        e=marks(self.foe,a);self.foe.turn_number=3;e.on_turn_start(self.foe)
        self.assertEqual(e.power,1);self.foe.turn_number=4;e.on_turn_start(self.foe);self.assertEqual(e.power,0)
    def test_venom_uses_the_sources_marks(self):
        from models.effects import Poison
        a=hero('feliss');add_marks(a,self.foe,3)
        a.skills['venom_sting']._after_hit(a,self.foe,8)
        self.assertEqual(next(e for e in self.foe.get_effects() if isinstance(e,Poison)).power,4)
    def test_blood_feast_cost_is_current_hp_and_not_energy(self):
        a=hero('keltazar');a.hp=100;before=a.energy;a.skills['blood_feast'].pay(a)
        self.assertEqual(a.hp,85);self.assertEqual(a.energy,before)
        a.hp=1;self.assertFalse(a.skills['blood_feast'].is_available(a))
    def test_cursed_flesh_amplifies_damage_after_armor(self):
        a=hero('keltazar');before=a.hp;dmg=a.take_damage(101)
        self.assertEqual(dmg,118);self.assertEqual(before-a.hp,118)
    def test_blindness_is_fifty_percent_stronger(self):
        a=hero('cyclops');s=a.skills['attack'];base=a.hit_chance(s,self.foe)
        a.add_effect(Blinded(2,20));self.assertAlmostEqual(base-a.hit_chance(s,self.foe),.30)
    def test_focus_comes_from_game_and_is_target_bound(self):
        a=hero('cyclops');s=a.skills['watchful_eye'];a.focus_target=self.foe.id
        s.apply(a,self.foe,0,None);s.apply(a,self.foe,0,None);s.apply(a,self.foe,0,None)
        self.assertEqual(a.focus,4);a.start_turn();self.assertEqual(a.focus,4)
        other=hero('mage');a.begin_action(a.skills['attack'],other);self.assertEqual(a.focus,0)
    def test_stone_flesh_blocks_exactly_two_hits_not_dot(self):
        a=hero('cyclops');e=TwoHitShield(20)
        self.assertEqual(e.modify_incoming(a,30,None)[0],30)
        self.assertEqual(e.modify_incoming(a,30,self.foe)[0],10)
        self.assertEqual(e.modify_incoming(a,30,self.foe)[0],10)
        self.assertEqual(e.modify_incoming(a,30,self.foe)[0],30)
    def test_judgment_counts_target_turns_and_cannot_refresh(self):
        a=hero('mersey');place_verdict(a,self.foe);e=verdict(a,self.foe)
        a.start_turn();self.assertEqual(e.power,3)
        for _ in range(3):self.foe.start_turn()
        self.assertEqual(e.power,0)
        with self.assertRaises(ValueError):place_verdict(a,self.foe)
    def test_failed_execution_spends_verdict_and_hurts_executioner(self):
        a=hero('mersey');place_verdict(a,self.foe);before=a.hp;enemy=self.foe.hp
        a.skills['sentence_end'].apply(a,self.foe,3,None)
        self.assertLess(a.hp,before);self.assertEqual(self.foe.hp,enemy);self.assertIsNone(verdict(a,self.foe))
    def test_short_game_affects_next_paid_game_once(self):
        a=hero('mage');s=a.skills['fireball'];a.opponent=self.foe
        a.add_effect(ShortGame(4,30));s.pay(a);o=s.public_options(a,self.foe)
        self.assertEqual(o['time_limit_ms'],3500);self.assertFalse(a.has_effect(ShortGame))
        a.restore_energy(100);s.pay(a);self.assertEqual(s.public_options(a,self.foe)['time_limit_ms'],5000)
    def test_lion_distinct_openers_and_finisher_reset(self):
        a=hero('leon');self.cast(a,'predator_instinct');self.assertEqual(a.combo,1)
        self.cast(a,'predator_instinct');self.assertEqual(a.combo,1)
        self.cast(a,'predator_ambush');self.assertEqual(a.combo,2)
        self.cast(a,'royal_will');self.assertEqual(a.combo,0);self.assertTrue(a.has_effect(NextCritical))
    def test_lion_followup_roar_and_skipped_turn(self):
        a=hero('leon');self.cast(a,'predator_instinct');self.cast(a,'beast_king');self.assertEqual(a.combo,2)
        self.cast(a,'king_roar');self.assertEqual(a.combo,2)
        a.on_skip();self.assertEqual(a.combo,0)
    def test_confidence_thresholds_count_once_and_initiative_lowers(self):
        a=hero('leon');a.on_initiative(False);self.assertEqual(a.confidence,-1)
        self.foe.hp=self.foe.max_hp//5;a.on_hit_landed(self.foe,a.skills['attack']);self.assertEqual(a.confidence,2)
        a.on_hit_landed(self.foe,a.skills['attack']);self.assertEqual(a.confidence,2)
        for _ in range(10):a.on_initiative(False)
        self.assertEqual(a.confidence,-2)
    def test_getou_two_different_slots_reject_before_mana(self):
        a=hero('getou');a.opponent=self.foe;a.raise_minion('skeleton',0);a.raise_minion('zombie',0)
        self.assertEqual(len(a.living_minions()),2);before=a.energy
        with self.assertRaises(ValueError):a.skills['build_homunculus'].pay(a)
        self.assertEqual(a.energy,before)
        a.minions[0].hp=0;self.assertTrue(a.can_summon('homunculus'))
    def test_getou_cannot_duplicate_skeleton_variants(self):
        a=hero('getou');a.raise_minion('skeleton',0)
        self.assertFalse(a.can_summon('skeleton'))
        with self.assertRaises(ValueError):a.raise_minion('skeleton',1)
    def test_creatures_have_stable_distinct_hp_journal_keys(self):
        a=hero('getou');a.raise_minion('skeleton',0);a.raise_minion('zombie',0)
        self.assertNotEqual(a.minions[0].id,a.minions[1].id)
        hp_journal.journal().clear();a.minions[1].hp-=3
        self.assertEqual(hp_journal.journal()[-1][0],a.minions[1].id)
    def test_target_selection_hits_pet_and_rejects_invalid_target(self):
        a,g=hero('warrior'),hero('getou');b=Battle(a,g,mode='manual');b.start();g.raise_minion('zombie',0)
        pet=g.minions[0];self.assertIs(b._selected_target(a,pet.id,False),pet)
        before=pet.hp;owner=g.hp
        with patch('models.rng._random.random',return_value=0):a.skills['attack'].execute(a,pet)
        self.assertLess(pet.hp,before);self.assertEqual(g.hp,owner)
        with self.assertRaises(ValueError):b._selected_target(a,'s999_0',False)
    def test_zombie_regenerates_only_while_alive(self):
        g=hero('getou');g.opponent=self.foe;g.raise_minion('zombie',0);s=g.minions[0];s.hp=10
        s.act(self.foe);self.assertEqual(s.hp,16)
        s.take_damage(100,attacker=self.foe);s.act(self.foe);self.assertEqual(s.hp,0)
    def test_soul_mana_limited_to_one_death_per_round(self):
        g=hero('getou');g.opponent=self.foe;g.spend_energy(50)
        g.raise_minion('skeleton',2);g.raise_minion('zombie',0)
        for s in g.minions:s.take_damage(100,attacker=self.foe)
        self.assertEqual(g.energy,58)
    def test_bomber_waits_for_next_killer_turn(self):
        g=hero('getou');g.opponent=self.foe;g.raise_minion('skeleton',1)
        g.minions[0].take_damage(100,attacker=self.foe);hp=self.foe.hp
        self.assertEqual(finish_bombs(self.foe),[]);self.assertEqual(self.foe.hp,hp)
        self.foe.turn_number+=1;self.assertTrue(finish_bombs(self.foe));self.assertLess(self.foe.hp,hp)
    def test_dismiss_and_expiry_do_not_trigger_soul_or_bomb(self):
        g=hero('getou');g.opponent=self.foe;g.spend_energy(50);g.raise_minion('skeleton',1);dismiss(g)
        self.assertEqual(g.energy,50);self.assertFalse(getattr(self.foe,'_necro_bombs',[]))
    def test_summon_expiry_even_when_owner_stunned(self):
        g=hero('getou');b=Battle(g,self.foe,mode='manual');b.start();g.raise_minion('zombie',0);s=g.minions[0]
        g.add_effect(Stun(20))
        for _ in range(8):b._new_round()
        self.assertTrue(s.is_alive())
        b._new_round()
        self.assertFalse(s.is_alive());self.assertTrue(g.can_summon('zombie'))
    def test_repair_heals_actual_missing_hp_only(self):
        g=hero('getou');g.raise_minion('zombie',0);s=g.minions[0];g.hp-=30
        s.hp-=2;before=g.hp;g.skills['flesh_stitch'].apply(g,self.foe,0,None)
        self.assertEqual(g.hp,before+8);self.assertEqual(s.hp,s.max_hp)
        before=g.hp;g.skills['flesh_stitch'].apply(g,self.foe,0,None);self.assertEqual(g.hp,before+8)
        g.hp=g.max_hp-1;g.skills['flesh_stitch'].apply(g,self.foe,0,None);self.assertEqual(g.hp,g.max_hp)
        self.assertFalse(g.skills['flesh_stitch'].is_available(g))
    def test_one_completed_stitch_is_not_rounded_down_to_failure(self):
        g=hero('getou');g.raise_minion('zombie',0);s=g.minions[0];s.hp=10
        g.skills['flesh_stitch'].apply(g,self.foe,3,None);self.assertEqual(s.hp,14)
    def test_necromancer_base_command_does_not_attack_directly(self):
        g=hero('getou');before=self.foe.hp;self.cast(g,'attack');self.assertEqual(self.foe.hp,before)
    def test_campaign_companion_scales_once(self):
        g=HERO_CLASSES['getou']('Сюжет',level=9);g.story=True;g.raise_minion('homunculus',0)
        self.assertEqual(g.minions[0].max_hp,round(90*g.power_scale()))
    def test_lobby_cleans_both_minions_without_healing_battle(self):
        g=hero('getou');g.raise_minion('zombie',0);g.hp-=20;pet=g.minions[0];hp=g.hp
        d=g.lobby_dict();self.assertEqual(d['hp'],d['max_hp']);self.assertEqual(d['summons'],[])
        self.assertEqual(g.hp,hp);self.assertTrue(pet.is_alive())
    def test_new_skill_forecasts_do_not_mutate_rng_id_or_hp_journal(self):
        for key in ('keltazar','feliss','cyclops','mersey','leon','getou'):
            a=hero(key);a.opponent=self.foe
            if key=='getou':a.raise_minion('zombie',0)
            hp_journal.journal().clear();state=random.getstate();next_id=Character._next_id;before=repr(a.to_dict())
            for s in a.skills.values():s.ai_score(a,self.foe)
            self.assertEqual(random.getstate(),state,key);self.assertEqual(Character._next_id,next_id,key)
            self.assertEqual(repr(a.to_dict()),before,key);self.assertEqual(hp_journal.journal(),[],key)
    def test_all_game_options_json_serializable_and_score_not_trusted(self):
        for key in ('keltazar','feliss','cyclops','mersey','leon','getou'):
            a=hero(key)
            for s in a.skills.values():
                if not hasattr(s,'game'):continue
                o=s.public_options(a,self.foe);json.dumps(o,allow_nan=False)
                self.assertEqual(s.tier_from({'score':999999},o),len(s.TIERS)-1,s.game)
    def test_forged_or_nan_stillness_input_is_rejected(self):
        a=hero('leon');s=a.skills['composure'];o=s.public_options(a,self.foe)
        for bad in ([float('nan')],[-1],[0,0],['x']):
            self.assertEqual(s.tier_from({'elapsed_ms':o['time_limit_ms'],'taps':bad},o),3)
    def test_client_cannot_claim_future_timestamps(self):
        a=hero('cyclops');s=a.skills['watchful_eye'];o=s.public_options(a,self.foe)
        secret=s.secret_pick(o);secret['started']=time.time()-1
        s.resolve(a,self.foe,{'elapsed_ms':100,'taps':[5000]},secret)
        self.assertEqual(a.focus,0)
    def test_assembly_counts_unique_parts_and_completed_stages(self):
        a=hero('getou');s=a.skills['raise_bones'];o=s.public_options(a,self.foe)
        p=[{'part':i,'slot':o['slots'][i]} for i in range(9)]
        for n,tier in ((0,3),(3,2),(6,1),(9,0)):
            self.assertEqual(s.tier_from({'placements':p[:n]},o),tier)
        self.assertEqual(s.tier_from({'placements':[p[0]]*9},o),3)

    def test_venom_forecast_includes_future_poison_ticks(self):
        from models.skills import DamageSkill
        a=hero('feliss');s=a.skills['venom_sting'];add_marks(a,self.foe,3)
        self.assertGreater(s.ai_score(a,self.foe),DamageSkill.ai_score(s,a,self.foe)+10)

    def test_ranging_forecast_includes_setup_value(self):
        from models.skills import DamageSkill
        a=hero('feliss');s=a.skills['ranging']
        self.assertGreater(s.ai_score(a,self.foe),DamageSkill.ai_score(s,a,self.foe)+3)

    def test_squint_forecast_accounts_for_true_hit_and_multiplier(self):
        from models.effects import DodgeBuff
        a=hero('cyclops');self.foe.add_effect(DodgeBuff(3,40))
        self.assertGreater(a.skills['squint'].ai_score(a,self.foe),a.skills['attack'].ai_score(a,self.foe)*1.5)

    def test_drain_heals_actual_hp_lost_and_respects_dot_resistance(self):
        from models.heroes_55 import Drain
        a=hero('keltazar');a.hp-=30;before=a.hp;self.foe.hp=2
        Drain(a,4).on_turn_start(self.foe);self.assertEqual(a.hp,before+2)
        self.foe.hp=100;self.foe.DOT_RESIST=.5;before=a.hp
        Drain(a,4).on_turn_start(self.foe);self.assertEqual(a.hp,before+2)

    def test_smooth_tracking_is_reachable_with_human_reaction_delay(self):
        a=hero('feliss');s=a.skills['prey_pulse'];o=s.public_options(a,self.foe)
        samples=[]
        for t in range(0,o['time_limit_ms']+1,20):
            x,y=interpolate(o['path'],max(0,t-120),False);samples.append({'t':t,'x':x,'y':y})
        self.assertEqual(s.tier_from({'elapsed_ms':o['time_limit_ms'],'points':samples,'engaged_ms':o['prepare_ms']},o),0)

    def test_homunculus_requires_open_locks_not_just_matching_parts(self):
        a=hero('getou');s=a.skills['build_homunculus'];o=s.public_options(a,self.foe)
        placements=[]
        for part,(period,phase) in enumerate(o['locks']):
            ms=next(t for t in range(100,o['time_limit_ms']) if abs(math.sin(2*math.pi*(t+phase)/period))<.02)
            placements.append({'part':part,'slot':o['slots'][part],'ms':ms})
        self.assertEqual(s.tier_from({'placements':placements},o),0)
        self.assertEqual(s.tier_from({'placements':[{'part':i,'slot':slot} for i,slot in enumerate(o['slots'])]},o),3)


if __name__=='__main__':unittest.main()
