"""Arena progression, clean lobby views and campaign separation regressions."""
import json
import random
from fractions import Fraction
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from app import app, service
from models import Battle, HERO_CLASSES, hp_journal
from models.arena_rules import ARENA_HP, ROLE_HP_BANDS
from models.effects import Antiheal, Bleed, Berserk
from models.story import STORY, StoryBattle
from models.rng import use
from services.game_service import GameService


class ArenaModesTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def register(self, key):
        hero = HERO_CLASSES[key]('Режим ' + key)
        service._heroes[hero.id] = hero
        self.addCleanup(service._heroes.pop, hero.id, None)
        return hero

    def test_all_arena_classes_obey_disjoint_hp_bands(self):
        self.assertEqual(set(ARENA_HP), set(HERO_CLASSES))
        for key, cls in HERO_CLASSES.items():
            for legacy_level in (1, 10, 25):
                with self.subTest(key=key, legacy_level=legacy_level):
                    h = cls('Старый герой', level=legacy_level)
                    h.configure_arena(); h.reset()
                    lo, hi = ROLE_HP_BANDS[h.role]
                    self.assertLessEqual(lo, h.max_hp)
                    self.assertLessEqual(h.max_hp, hi)
                    self.assertEqual(h.level, 1)

    def test_arena_api_cannot_create_or_upgrade_a_level_advantage(self):
        response = self.client.post('/api/heroes', json={
            'type': 'bluetroll', 'name': 'Независимый', 'level': 25})
        self.assertEqual(response.status_code, 201)
        d = response.get_json(); h = service.get_hero(d['id'])
        self.addCleanup(service._heroes.pop, h.id, None)
        self.assertEqual(h.max_hp, ARENA_HP['bluetroll'])
        self.assertNotIn('level', d)
        self.assertNotIn('experience', d)
        self.client.patch('/api/heroes/' + str(h.id), json={'level': 25})
        h.gain_experience(100000); h.set_level(25)
        self.assertEqual((h.level, h.experience, h.max_hp), (1, 0, ARENA_HP['bluetroll']))

    def test_arena_battles_ignore_legacy_levels_and_give_no_xp(self):
        a, b = self.register('paladin'), self.register('bluetroll')
        a.set_level(25); b.set_level(8)
        a.experience = 63; b.experience = 42
        battle = service.create_battle({'hero1_id': a.id, 'hero2_id': b.id})
        self.addCleanup(service._battles.pop, battle.id, None)
        self.assertEqual(battle.xp, (0, 0))
        self.assertEqual((a.level, b.level, a.experience, b.experience), (1, 1, 0, 0))
        self.assertEqual(a.wins + b.wins, 1)
        for d in battle.to_dict()['heroes']:
            self.assertNotIn('level', d)
            self.assertNotIn('ур.', d['description'])

    def test_opponents_have_no_level_group_filter(self):
        a, b = self.register('warrior'), self.register('paladin')
        a.set_level(25); b.set_level(1)
        self.assertIn(b, service.opponents_for(a.id))

    def test_lobby_cleans_all_classes_without_modifying_combat_or_rng(self):
        for key, cls in HERO_CLASSES.items():
            with self.subTest(key=key):
                h = cls('Бой'); h.configure_arena(); h.reset()
                h.hp = 0; h.spend_energy(h.energy)
                h.add_effect(Antiheal(5)); h.add_effect(Berserk(3, 20))
                h.set_cooldown('attack', 4); h.fatigue = .5
                with use(random.Random(0)):
                    original = h.to_dict()
                rng = random.getstate(); ids = (h._next_id, Battle._next_id)
                journal = list(hp_journal.journal())
                d = h.lobby_dict()
                self.assertEqual(d['hp'], d['max_hp'])
                self.assertEqual(d['energy'], d['max_energy'])
                self.assertEqual(d['effects'], [])
                self.assertEqual(d['fatigue'], 0)
                self.assertIsNone(d['summon'])
                with use(random.Random(0)):
                    self.assertEqual(h.to_dict(), original)
                self.assertEqual(random.getstate(), rng)
                self.assertEqual((h._next_id, Battle._next_id), ids)
                self.assertEqual(hp_journal.journal(), journal)

    def test_live_battle_api_remains_wounded_when_lobby_is_full(self):
        a, b = self.register('gnoll'), self.register('paladin')
        battle = Battle(a, b, mode='manual')
        service._battles[battle.id] = battle
        self.addCleanup(service._battles.pop, battle.id, None)
        battle.start(); a.hp = 12; a.add_effect(Bleed(4, 3))
        live = self.client.get(f'/api/battles/{battle.id}').get_json()
        lobby = self.client.get(f'/api/heroes/{a.id}').get_json()
        self.assertEqual(live['heroes'][0]['hp'], 12)
        self.assertTrue(live['heroes'][0]['effects'])
        self.assertEqual(lobby['hp'], lobby['max_hp'])
        self.assertFalse(lobby['effects'])
        self.assertEqual(a.hp, 12)

    def test_loss_draw_cancel_and_surrender_all_have_clean_lobby(self):
        for end in ('loss', 'draw', 'cancel', 'surrender'):
            with self.subTest(end=end):
                a, b = self.register('gnoll'), self.register('paladin')
                battle = Battle(a, b, mode='manual'); battle.start()
                a.hp = 8; a.add_effect(Bleed(4, 3))
                if end == 'loss':
                    a.hp = 0; battle._check_end()
                elif end == 'draw':
                    a.hp = b.hp = 0; battle._check_end()
                elif end == 'cancel':
                    battle.cancel()
                else:
                    battle.surrender(a)
                d = self.client.get(f'/api/heroes/{a.id}').get_json()
                self.assertEqual(d['hp'], d['max_hp'])
                self.assertFalse(d['effects'])
                self.assertEqual(d['energy'], d['max_energy'])

    def test_mount_preview_revives_kodo_without_reviving_combat_mount(self):
        h = self.register('beastlord'); h.configure_arena(); h.hp = 40
        d = h.lobby_dict()
        self.assertEqual([bar['hp'] for bar in d['hp_bars']], [200, 100])
        self.assertTrue(d['kodo_alive'])
        self.assertFalse(h.kodo_alive)
        self.assertEqual(h.hp, 40)

    def test_finished_result_survives_lobby_preview_and_rematch(self):
        a, b = self.register('gnoll'), self.register('paladin')
        battle = Battle(a, b); battle.fight()
        result = battle.to_dict()['heroes']
        for h in (a, b):
            h.lobby_dict()
        Battle(a, b).fight()
        self.assertEqual(battle.to_dict()['heroes'], result)

    def test_campaign_hero_does_not_enter_arena_leaderboard(self):
        h = self.register('paladin'); h.story = True; h.wins = 100
        self.assertNotIn(h.id, [row['id'] for row in service.leaderboard()['heroes']])

    def test_catfolk_changes_hp_band_without_healing_percentage(self):
        h = self.register('catfolk'); h.configure_arena(); h.reset(); h.hp = 83
        for _ in range(5):
            before = Fraction(h.hp, h.max_hp)
            h.set_form(not h.cat_form)
            lo, hi = ROLE_HP_BANDS[h.role]
            self.assertTrue(lo <= h.max_hp <= hi)
            self.assertLessEqual(Fraction(h.hp, h.max_hp), before)
        h.hp = 1; h.set_form(not h.cat_form)
        self.assertTrue(h.is_alive())
        lobby = h.lobby_dict()
        self.assertEqual((lobby['role'], lobby['max_hp'], lobby['hp']), ('trickster', 169, 169))

    def test_campaign_keeps_levels_stats_and_xp(self):
        h = self.register('paladin'); h.story = True; h.set_level(8)
        expected_hp = h.max_hp
        h.gain_experience(h.xp_needed())
        self.assertEqual(h.level, 9)
        self.assertGreater(h.max_hp, expected_hp)
        mob = STORY['slums'].stages[0].make_mob()
        battle = StoryBattle(h, mob, STORY['slums'], STORY['slums'].stages[0])
        battle.start()
        self.assertEqual(h.level, 9)
        self.assertIn('level', h.to_dict())
        xp = h.experience
        mob.hp = 0; battle._check_end()
        self.assertGreater(battle.xp[0], 0)
        self.assertTrue(h.experience > xp or h.level > 9)

    def test_legacy_save_migrates_arena_only_and_is_idempotent(self):
        with TemporaryDirectory() as folder:
            path = Path(folder) / 'save.json'; game = GameService(str(path))
            a = HERO_CLASSES['bluetroll']('Арена', level=20)
            s = HERO_CLASSES['paladin']('Сюжет', level=8); s.story = True
            a.experience = 23; a.wins = 15; a.losses = 7
            a.skins = ['gold']; a.skin = 'gold'; a.armor += 2
            s.experience = 31; s.story_progress = {'slums': 2}
            game._heroes = {a.id: a, s.id: s}; game.save()
            for _ in range(2):
                game.load(); aa = game.get_hero(a.id); ss = game.get_hero(s.id)
                self.assertEqual((aa.level, aa.experience, aa.max_hp), (1, 0, 170))
                self.assertEqual((aa.wins, aa.losses, aa.skin, aa.armor), (15, 7, 'gold', a.armor))
                self.assertEqual((ss.level, ss.experience, ss.max_hp), (8, 31, s.max_hp))
                self.assertEqual(ss.story_progress, s.story_progress)
                game.save()


if __name__ == '__main__':
    unittest.main()
