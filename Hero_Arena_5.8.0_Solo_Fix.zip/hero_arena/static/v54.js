/* 5.4 / 5.4.1: split HP bar, бумеранг, форма кошки, карты, card_pick мини-игра */
(function () {

  function splitFromHero(h, totalHp) {
    const bars = h.hp_bars;
    if (!bars || bars.length < 2) return null;
    const kodoMax = bars[0].max, riderMax = bars[1].max;
    const totalMax = Math.max(1, (h.max_hp || (kodoMax + riderMax)));
    // Reconstruct this snapshot, not the final mount-alive flag: the journal
    // may still be showing earlier hits before the mount died.
    const hp = Math.max(0, Math.min(totalMax, totalHp != null ? totalHp :
      (h.hp != null ? h.hp : (bars[0].hp + bars[1].hp))));
    const kodoHp = Math.max(0, Math.min(kodoMax, hp - riderMax));
    const riderHp = Math.min(riderMax, hp);
    return {
      kodoHp, kodoMax, riderHp, riderMax, totalMax,
      label: `🐂 Кодой ${kodoHp}/${kodoMax} | 🧔 Наездник ${riderHp}/${riderMax}`
    };
  }

  function splitBarHtml(h, totalHp) {
    const s = splitFromHero(h, totalHp);
    if (!s) return null;
    const kPct = Math.max(0, 100 * s.kodoHp / s.totalMax);
    const rPct = Math.max(0, 100 * s.riderHp / s.totalMax);
    const kMaxPct = Math.max(0, 100 * s.kodoMax / s.totalMax);
    return `<div class="bar hpbar hpbar-split" data-split="1" data-kodo-max="${s.kodoMax}" data-rider-max="${s.riderMax}" data-total-max="${s.totalMax}">
      <div class="hp-seg-track">
        <div class="hp-seg-zone kodo-zone" style="width:${kMaxPct}%"></div>
        <div class="hp-seg-zone rider-zone" style="width:${100 - kMaxPct}%"></div>
        <div class="hp-seg-fills">
          <i class="hp-seg kodo" style="width:${kPct}%"></i>
          <i class="hp-seg rider" style="left:${kMaxPct}%;width:${rPct}%"></i>
        </div>
        <div class="hp-seg-divider" style="left:${kMaxPct}%"></div>
      </div>
      <span>${s.label}</span>
    </div>`;
  }

  // Override bars() to use combined segmented HP for beastlord
  if (typeof bars === "function") {
    const _bars = bars;
    window.bars = function (h) {
      const split = h.hp_bars ? splitBarHtml(h, h.hp) : null;
      if (!split) return _bars(h);
      return split +
        `<div class="bar enbar"><div style="width:${pct(h.energy, h.max_energy)}%"></div><span>${h.resource_name} ${h.energy}/${h.max_energy}</span></div>`;
    };
  }

  // Patch applyHp so split bar animates from total snap
  if (typeof applyHp === "function") {
    const _applyHp = applyHp;
    window.applyHp = function (snap, animated) {
      const changed = _applyHp(snap, animated);
      if (!snap || !battle || !battle.heroes) return changed;
      battle.heroes.forEach((h, i) => {
        if (!h.hp_bars) return;
        const el = document.getElementById("f" + i);
        if (!el) return;
        const bar = el.querySelector(".hpbar-split");
        if (!bar) return;
        const total = snap[String(h.id)];
        if (total === undefined || total === null) return;
        const s = splitFromHero(h, total);
        if (!s) return;
        const kPct = Math.max(0, 100 * s.kodoHp / s.totalMax);
        const rPct = Math.max(0, 100 * s.riderHp / s.totalMax);
        const kEl = bar.querySelector(".hp-seg.kodo");
        const rEl = bar.querySelector(".hp-seg.rider");
        const span = bar.querySelector("span");
        if (kEl) kEl.style.width = kPct + "%";
        if (rEl) rEl.style.width = rPct + "%";
        if (span) span.textContent = s.label;
      });
      return changed;
    };
  }

  // Extras under bars (machete, cards, cat) — keep, but avoid duplicate split rows
  const _heroExtras = (h) => {
    let html = "";
    if (h.machete_in_flight > 0) {
      html += `<div class="badge" style="background:#3a2a1a">🪃 мачете в полёте: ${h.machete_in_flight}</div>`;
    }
    if (h.card_lock) {
      const map = {blue: "🟦 синяя", red: "🟥 красная", yellow: "🟨 жёлтая", green: "🟩 зелёная"};
      html += `<div class="badge" style="background:#1a1a2a">🔒 нельзя снова: ${map[h.card_lock] || h.card_lock}</div>`;
    }
    if (h.cat_form) html += `<div class="badge">🐱 форма кошки · Воин</div>`;
    if (h.type === "catfolk" && !h.cat_form) html += `<div class="badge">👤 человек · Ловкач</div>`;
    if (h.doused_turns > 0) html += `<div class="badge" style="background:#4a2a00">🍺 пропитка ${h.doused_turns}</div>`;
    return html;
  };

  if (typeof window.renderBattleHero === "function") {
    const _rb = window.renderBattleHero;
    window.renderBattleHero = function (h) {
      return _rb(h) + _heroExtras(h);
    };
  }


  // ---- 5.4.1: status chips — always re-paint after any fighter rebuild ----
  function statusChipsFor(h) {
    const chips = [];
    const list = Array.isArray(h && h.effects) ? h.effects : [];
    list.forEach(e => {
      if (!e) return;
      const name = e.name != null ? String(e.name) : (e.type || "эффект");
      const icon = e.icon || "•";
      const dur = (e.duration != null && Number(e.duration) < 900) ? String(e.duration) : "";
      const cls = e.positive ? "pos" : "neg";
      chips.push(`<span class="${cls}" title="${esc(name)}">${icon} ${esc(name)} ${dur}</span>`);
    });
    // custom statuses as chips
    if (h.card_lock) {
      const map = {blue: "🟦 синяя", red: "🟥 красная", yellow: "🟨 жёлтая", green: "🟩 зелёная"};
      chips.push(`<span class="neg" title="цвет на КД">🔒 ${map[h.card_lock] || h.card_lock}</span>`);
    }
    if (h.veil_combo > 0) {
      chips.push(`<span class="pos" title="комбо Вейла">🎴 комбо ${h.veil_combo}</span>`);
    }
    if (h.cat_form) chips.push(`<span class="pos" title="форма">🐱 кошка</span>`);
    if (h.type === "catfolk" && !h.cat_form) chips.push(`<span class="pos" title="форма">👤 человек</span>`);
    if (h.doused_turns > 0) chips.push(`<span class="neg" title="пропитка">🍺 пропитка ${h.doused_turns}</span>`);
    if (h.machete_in_flight > 0) chips.push(`<span class="pos" title="мачете">🪃 в полёте ${h.machete_in_flight}</span>`);
    if (h.kodo_alive === false) chips.push(`<span class="neg" title="кодой">💀 кодой пал</span>`);
    else if (h.hp_split && h.kodo_alive) chips.push(`<span class="pos" title="кодой">🐂 кодой</span>`);
    return chips.join("");
  }

  function paintStatusChips(b) {
    if (!b || !b.heroes) return;
    b.heroes.forEach((h, i) => {
      const el = document.getElementById("f" + i);
      if (!el) return;
      let box = el.querySelector(":scope > .effects");
      if (!box) {
        box = document.createElement("div");
        box.className = "effects";
        // after bars / before summon or at end
        const summon = el.querySelector(":scope > .summon");
        if (summon) el.insertBefore(box, summon);
        else el.appendChild(box);
      }
      box.innerHTML = statusChipsFor(h);
    });
  }

  // Also append extras after renderFighters rebuilds HTML
  if (typeof renderFighters === "function") {
    const _rf = renderFighters;
    window.renderFighters = function (b, snap, hideFx) {
      _rf(b, snap, hideFx);
      // CRITICAL: always re-paint chips from live hero payloads (fixes intermittent vanish
      // after mini-game / card / skin / hideFx intro paths that cleared .effects)
      try { paintStatusChips(b); } catch (e) { console.warn("[v54] chips", e); }
      (b.heroes || []).forEach((h, i) => {
        const el = document.getElementById("f" + i);
        if (!el) return;
        const extra = _heroExtras(h);
        let wrap = el.querySelector(".v54-extra");
        if (extra) {
          if (!wrap) {
            wrap = document.createElement("div");
            wrap.className = "v54-extra";
            el.appendChild(wrap);
          }
          wrap.innerHTML = extra;
        } else if (wrap) {
          wrap.innerHTML = "";
        }
      });
    };
  }

  const style = document.createElement("style");
  style.textContent = `
  .hpbar-split{position:relative;height:20px}
  .hpbar-split .hp-seg-track{position:absolute;inset:0;width:100%;display:flex;overflow:hidden;border-radius:inherit;z-index:0;background:none}
  .hpbar-split .hp-seg-zone{height:100%;opacity:.18}
  .hpbar-split .kodo-zone{background:#c9a227}
  .hpbar-split .rider-zone{background:#4cd07d}
  .hpbar-split .hp-seg-fills{position:absolute;inset:0;pointer-events:none}
  .hpbar-split .hp-seg{position:absolute;top:0;left:0;display:block;height:100%;transition:width .28s cubic-bezier(.2,.8,.2,1)}
  .hpbar-split .hp-seg.kodo{background:linear-gradient(90deg,#a67c1a,#e0c35a)}
  .hpbar-split .hp-seg.rider{background:linear-gradient(90deg,#2a9a55,#6ee09a)}
  .hpbar-split .hp-seg-divider{position:absolute;top:0;bottom:0;width:2px;background:#fff8;z-index:2;box-shadow:0 0 4px #0008}
  .hpbar-split > div:first-child:not(.hp-seg-track){display:none} /* hide default fill if any */
  .hpbar-split > span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;z-index:3;font-size:11px;line-height:1;text-shadow:0 1px 2px #000a;white-space:nowrap}
  .skill.locked-color{opacity:.45;outline:1px solid #666}
  .v54-extra{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}
  .fighter .effects{min-height:22px;margin-top:4px}
  .fighter .effects span{border:1px solid #f5b94255;border-radius:5px;padding:2px 6px;margin:2px;display:inline-block;background:#0e0c14ee}
  
  `;
  document.head.appendChild(style);


  // ---- 5.4.1: per-hero mini-game visuals (shield+gold only for Spartan) ----
  function mgTheme(o) {
    return {
      icon: o.icon || "◎",
      target: o.target_color || o.accent || "#f5b942",
      ring: o.ring_color || "#4cd07d",
      accent: o.accent || o.target_color || "#f5b942",
      hint: o.hint || null,
    };
  }

  if (typeof MINIGAMES !== "undefined" && MINIGAMES.timing_ring) {
    const _tr = MINIGAMES.timing_ring.bind(MINIGAMES);
    MINIGAMES.timing_ring = function (o, head) {
      const t = mgTheme(o);
      const isShield = t.icon === "🛡";
      const hint = t.hint || (isShield
        ? "Нажмите в любом месте поля, когда кольцо совпадёт со щитом"
        : `Нажмите в любом месте поля, когда кольцо совпадёт с целью (${t.icon})`);
      openBox(head + `<div class="mg-area" id="mgA" style="width:300px;height:300px;cursor:pointer">
        <div style="position:absolute;left:50%;top:50%;width:90px;height:90px;margin:-45px;border-radius:50%;border:6px solid ${t.target};display:flex;align-items:center;justify-content:center;font-size:40px;box-shadow:0 0 16px ${t.target}88;background:#0006">${t.icon}</div>
        <div id="ring" style="position:absolute;left:50%;top:50%;border-radius:50%;border:4px solid ${t.ring};box-shadow:0 0 10px ${t.ring}66"></div></div>` + timerBar + `<div class="muted">${hint}</div>`);
      const ring = document.getElementById("ring"), P = o.period_ms, M = P * 0.75;
      const sz = ph => 300 - (300 - 96) * (ph / M);
      const loop = () => { if (mg.done) return; const ph = (performance.now() - mg.t0) % P, s = Math.max(20, sz(ph));
        ring.style.width = ring.style.height = s + "px"; ring.style.margin = (-s / 2) + "px"; mg.raf = requestAnimationFrame(loop); };
      mgStart(o, () => ({error_ms: 9999}));
      loop();
      document.getElementById("mgA").onpointerdown = () => { const ph = (performance.now() - mg.t0) % P; mgFinish({error_ms: Math.round(Math.min(Math.abs(ph - M), P - Math.abs(ph - M)))}); };
    };
  }

  if (typeof MINIGAMES !== "undefined" && MINIGAMES.click_targets) {
    const _ct = MINIGAMES.click_targets.bind(MINIGAMES);
    MINIGAMES.click_targets = function (o, head, me, foe) {
      const t = mgTheme(o);
      if (!o.icon && t.icon) o = Object.assign({}, o, {icon: t.icon});
      _ct(o, head, me, foe);
      const area = document.getElementById("mgA");
      if (area) {
        area.style.boxShadow = `inset 0 0 0 2px ${t.accent}55, 0 0 18px ${t.accent}33`;
        area.style.outline = `1px solid ${t.accent}44`;
      }
      const style = document.createElement("style");
      style.textContent = `.mg-tok{border:2px solid ${t.accent} !important;box-shadow:0 0 10px ${t.accent}88;border-radius:50%}`;
      document.getElementById("modalBox").appendChild(style);
    };
  }

  if (typeof MINIGAMES !== "undefined" && MINIGAMES.timing_multi) {
    const _tm = MINIGAMES.timing_multi.bind(MINIGAMES);
    MINIGAMES.timing_multi = function (o, head) {
      const t = mgTheme(o);
      o = Object.assign({}, o, {icon: o.icon || t.icon});
      _tm(o, head);
      const gold = document.querySelector("#modalBox [style*='var(--gold)']");
      // recolor perfect zone if present
      document.querySelectorAll("#modalBox div").forEach(el => {
        if (el.style && el.style.background === "var(--gold)") el.style.background = t.target || t.accent;
      });
      if (t.hint) {
        const muted = document.querySelector("#modalBox .muted");
        if (muted) muted.textContent = t.hint;
      }
    };
  }

  if (typeof MINIGAMES !== "undefined" && MINIGAMES.hold_zone) {
    const _hz = MINIGAMES.hold_zone.bind(MINIGAMES);
    MINIGAMES.hold_zone = function (o, head) {
      _hz(o, head);
      const t = mgTheme(o);
      const gz = document.getElementById("gz");
      if (gz) gz.style.background = t.target || t.accent;
      const vb = document.getElementById("vb");
      if (vb) vb.style.boxShadow = `0 0 12px ${t.accent}66`;
    };
  }

  if (typeof MINIGAMES !== "undefined" && MINIGAMES.hold_release) {
    const _hr = MINIGAMES.hold_release.bind(MINIGAMES);
    MINIGAMES.hold_release = function (o, head) {
      _hr(o, head);
      const t = mgTheme(o);
      document.querySelectorAll("#modalBox .pz").forEach(el => el.style.background = t.target || "#f5b942");
      document.querySelectorAll("#modalBox .gz").forEach(el => el.style.background = t.ring || t.accent || "#4cd07d");
      const btn = document.getElementById("holdBtn");
      if (btn && t.icon) btn.textContent = `${t.icon} Зажмите`;
    };
  }

  if (typeof MINIGAMES !== "undefined" && MINIGAMES.rhythm) {
    const _rh = MINIGAMES.rhythm.bind(MINIGAMES);
    MINIGAMES.rhythm = function (o, head) {
      _rh(o, head);
      const t = mgTheme(o);
      const drum = document.getElementById("drum");
      if (drum) { drum.textContent = t.icon || "🥁"; drum.style.textShadow = `0 0 16px ${t.accent}`; }
    };
  }

  if (typeof MINIGAMES !== "undefined" && MINIGAMES.rings) {
    const _rg = MINIGAMES.rings.bind(MINIGAMES);
    MINIGAMES.rings = function (o, head) {
      _rg(o, head);
      const t = mgTheme(o);
      document.querySelectorAll("#modalBox .r").forEach(el => {
        el.style.borderColor = t.accent;
        el.style.boxShadow = `0 0 8px ${t.accent}66`;
      });
    };
  }



  // ---- 5.4.1: Рексор — анимированный бросок кости 1..6 ----
  if (typeof MINIGAMES !== "undefined") {
    MINIGAMES.dice_roll = function (o, head) {
      const t = (typeof mgTheme === "function") ? mgTheme(o) : {icon:"🎲", accent:"#e8c84a"};
      const faces = ["⚀","⚁","⚂","⚃","⚄","⚅"];
      const period = o.period_ms || 900;
      const sweet = o.sweet_ms || 420;
      openBox(head + `<div class="mg-area" id="mgA" style="width:280px;height:280px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-direction:column;box-shadow:inset 0 0 0 2px ${t.accent}66,0 0 20px ${t.accent}44">
        <div id="dieFace" style="font-size:96px;line-height:1;filter:drop-shadow(0 0 12px ${t.accent})">🎲</div>
        <div id="dieNum" style="font-size:28px;color:${t.accent};margin-top:8px;font-weight:bold">—</div>
        <div class="muted" style="margin-top:10px">Кликните, чтобы остановить кость</div>
      </div>` + timerBar + `<div class="muted">${o.hint || t.hint || "Яркая вспышка = выше шанс большого числа"}</div>`);
      let face = 1, glowing = false;
      const die = document.getElementById("dieFace");
      const num = document.getElementById("dieNum");
      const loop = () => {
        if (mg.done) return;
        const ph = (performance.now() - mg.t0) % period;
        glowing = ph < sweet;
        face = 1 + Math.floor(Math.random() * 6);
        die.textContent = faces[face - 1];
        num.textContent = String(face);
        die.style.transform = glowing ? "scale(1.12)" : "scale(1)";
        die.style.filter = glowing ? `drop-shadow(0 0 18px ${t.accent}) brightness(1.25)` : `drop-shadow(0 0 8px ${t.accent})`;
        mg.raf = requestAnimationFrame(loop);
      };
      mgStart(o, () => ({roll: face, base_roll: face, mastery: false, error_ms: 9999}));
      loop();
      const stop = () => {
        if (mg.done) return;
        const ph = (performance.now() - mg.t0) % period;
        const err = Math.min(ph, Math.abs(ph - sweet), period - ph);
        const mastery = err <= 90 || glowing;
        let roll = face;
        // клиент показывает число; сервер может подкрутить при mastery
        mgFinish({roll, base_roll: face, mastery, error_ms: Math.round(err)});
      };
      document.getElementById("mgA").onpointerdown = stop;
    };
  }


  // ---- 5.4.1: Рокх-анн — двойная дуга мачете ----
  if (typeof MINIGAMES !== "undefined") {
    MINIGAMES.boomerang_dual = function (o, head) {
      const accent = o.accent || "#3ecfcf";
      const perfect = o.perfect_ms || 50;
      const good = o.good_ms || 110;
      const Pa = o.period_a_ms || 760, Pb = o.period_b_ms || 970, phase = o.phase_b ?? 180;
      // Both visible paths cross the actual timing target at t = 0.5.
      const posOnArc = (t, up) => [40 + 240 * t,
        160 + (up ? -1 : 1) * 100 * Math.sin(2 * Math.PI * t)];
      const arcPath = (up, from = 0, to = 1) => Array.from({length: 81}, (_, i) => {
        const [x, y] = posOnArc(from + (to - from) * i / 80, up);
        return `${i ? "L" : "M"}${x},${y}`;
      }).join(" ");
      const zones = (up, period) => `<path d="${arcPath(up)}" fill="none" stroke="${accent}44" stroke-width="3"/>
        <path d="${arcPath(up, .5-good/period, .5+good/period)}" fill="none" stroke="${accent}88" stroke-width="7"/>
        <path d="${arcPath(up, .5-perfect/period, .5+perfect/period)}" fill="none" stroke="#ffe082" stroke-width="5"/>`;
      openBox(head + `<div class="mg-area" id="mgA" style="width:320px;height:320px;cursor:pointer;position:relative;touch-action:manipulation;box-shadow:inset 0 0 0 2px ${accent}66">
        <svg viewBox="0 0 320 320" style="position:absolute;inset:0;width:100%;height:100%">
          ${zones(true, Pa)}${zones(false, Pb)}
          <circle cx="160" cy="160" r="14" fill="none" stroke="#fff8" stroke-width="2" stroke-dasharray="4 3"/>
        </svg>
        <div id="bladeA" style="position:absolute;font-size:28px;transform:translate(-50%,-50%)">🪃</div>
        <div id="bladeB" style="position:absolute;font-size:28px;transform:translate(-50%,-50%)">🪓</div>
        <div id="catchFeedback" aria-live="polite" style="position:absolute;bottom:8px;left:0;right:0;text-align:center">Две попытки — по одной на клинок</div>
      </div>` + timerBar + `<div class="muted">Нажмите в любом месте поля, когда клинок проходит центр. Бирюзовый участок — ловля (±${good} мс), золотой — идеал (±${perfect} мс). Затем поймайте второй. Ранний или поздний клик тратит попытку.</div>`);
      const catches = [];
      const stateNow = () => {
        const now = performance.now() - mg.t0;
        return {ta: (now % Pa) / Pa, tb: ((now + phase) % Pb) / Pb};
      };
      const loop = () => {
        if (mg.done) return;
        const st = stateNow();
        [st.ta, st.tb].forEach((t, i) => {
          if (catches.some(c => c.i === i)) return;
          const [x, y] = posOnArc(t, i === 0);
          const el = document.getElementById(i === 0 ? "bladeA" : "bladeB");
          const err = Math.abs(t - .5) * (i === 0 ? Pa : Pb);
          if (el) {
            el.style.left = x + "px"; el.style.top = y + "px";
            el.style.filter = err <= good ? `drop-shadow(0 0 10px ${err <= perfect ? "#ffe082" : accent})` : "";
          }
        });
        mg.raf = requestAnimationFrame(loop);
      };
      mgStart(o, () => ({catches, errors: catches.map(c => c.error_ms)}));
      loop();
      document.getElementById("mgA").onpointerdown = () => {
        if (mg.done) return;
        // Measure the input event, not a potentially stale animation frame.
        const st = stateNow();
        const errors = [Math.abs(st.ta - .5) * Pa, Math.abs(st.tb - .5) * Pb];
        const remaining = [0, 1].filter(i => !catches.some(c => c.i === i));
        if (!remaining.length) return;
        const pick = remaining.reduce((a, b) => errors[a] <= errors[b] ? a : b);
        const err = Math.round(errors[pick]);
        catches.push({i: pick, error_ms: err});
        const el = document.getElementById(pick === 0 ? "bladeA" : "bladeB");
        if (el) el.style.visibility = "hidden";
        document.getElementById("catchFeedback").textContent =
          `Клинок ${pick + 1}: ${err <= perfect ? "идеал" : err <= good ? "пойман" : "промах"}` +
          (catches.length < 2 ? " — ловите второй!" : "");
        if (catches.length >= 2) mgFinish({catches, errors: catches.map(c => c.error_ms)});
      };
    };

    MINIGAMES.dual_stop = function (o, head) {
      const accent = o.accent || "#3ecfcf";
      const periods = o.period_ms || [500, 600];
      const Z = o.zone || 0.62, pw = o.perfect_w || 0.045, gw = o.good_w || 0.1;
      openBox(head + periods.map((P, i) =>
        `<div style="position:relative;height:28px;background:#222;border-radius:8px;margin:10px 0">
          <div style="position:absolute;left:${(Z-gw)*100}%;width:${gw*200}%;height:100%;background:#1a6a6a"></div>
          <div style="position:absolute;left:${(Z-pw)*100}%;width:${pw*200}%;height:100%;background:${accent}"></div>
          <div id="dsK${i}" style="position:absolute;top:-3px;width:4px;height:34px;background:#fff"></div>
          <button class="btn small" id="dsB${i}" style="position:absolute;right:-4px;top:-6px">стоп ${i+1}</button>
        </div>`).join("") + timerBar + `<div class="muted">Остановите оба маркера в узкой зоне</div>`);
      const stops = [];
      const x = (P, t0) => { const t = ((performance.now() - t0) % (2 * P)) / P; return t < 1 ? t : 2 - t; };
      const loop = () => {
        if (mg.done) return;
        periods.forEach((P, i) => {
          const el = document.getElementById("dsK" + i);
          if (el && !stops[i]) el.style.left = (x(P, mg.t0) * 100) + "%";
        });
        mg.raf = requestAnimationFrame(loop);
      };
      mgStart(o, () => ({hits: stops.filter(s => s && s.ok).length, stops}));
      loop();
      periods.forEach((P, i) => {
        document.getElementById("dsB" + i).onclick = () => {
          if (stops[i] || mg.done) return;
          const d = Math.abs(x(P, mg.t0) - Z);
          stops[i] = {ok: d <= gw, perfect: d <= pw, err: d};
          document.getElementById("dsB" + i).disabled = true;
          if (stops.filter(Boolean).length >= periods.length)
            mgFinish({hits: stops.filter(s => s && s.ok).length, stops});
        };
      });
    };
  }


  // ---- 5.4.1: Вейл — Слепой розыгрыш (уникальная veil_blind_draw) ----
  if (typeof MINIGAMES !== "undefined") {
    MINIGAMES.veil_blind_draw = function (o, head) {
      const accent = o.accent || "#d4af37";
      const cards = (o.cards || ["ace","king","queen","jack"]).slice();
      const faces = o.face_icons || {ace:"🂡",king:"🂮",queen:"🂭",jack:"🂫"};
      const effects = o.effects || {};
      const names = {ace:"Туз",king:"Король",queen:"Дама",jack:"Валет"};
      // Veil-themed backs (not generic 🂠 alone)
      const backArt = (i) =>
        `<div class="veil-back" style="width:72px;height:102px;border-radius:8px;border:2px solid ${accent};
          background:linear-gradient(145deg,#1a1028 0%,#3a2048 40%,#1a1028 100%);
          box-shadow:inset 0 0 0 3px #0008,0 0 12px ${accent}55;display:flex;flex-direction:column;
          align-items:center;justify-content:center;position:relative;overflow:hidden">
          <div style="position:absolute;inset:6px;border:1px solid ${accent}88;border-radius:5px"></div>
          <div style="font-size:22px;filter:drop-shadow(0 0 6px ${accent})">🃏</div>
          <div style="font-size:11px;color:${accent};letter-spacing:1px;margin-top:4px">ВЕЙЛ</div>
          <div style="font-size:10px;color:#c9a">★ ${i+1}</div>
        </div>`;

      openBox(head + `<div class="mg-area" id="mgA" style="width:100%;max-width:420px;min-height:160px;padding:18px 8px;
        display:flex;flex-direction:column;align-items:center;gap:10px;box-shadow:inset 0 0 0 2px ${accent}55">
        <div id="veilShuffle" class="muted">Тасовка колоды Вейла…</div>
        <div id="veilRow" style="display:flex;gap:12px;justify-content:center;flex-wrap:nowrap;min-height:110px"></div>
        <div id="veilHint" class="muted">Выберите ровно одну карту. Остальные заблокируются, затем все откроются.</div>
      </div>` + timerBar);

      const row = document.getElementById("veilRow");
      let picked = null;
      let order = cards.map((_, i) => i); // display indices into cards[]

      const renderBacks = (anim) => {
        row.innerHTML = order.map((ci, slot) =>
          `<button type="button" class="veil-card" data-slot="${slot}" data-ci="${ci}"
            style="padding:0;border:none;background:transparent;cursor:pointer;transition:transform .18s;
            ${anim ? `animation:veilShuffle .45s ease ${slot*0.05}s` : ""}">${backArt(slot)}</button>`
        ).join("");
      };

      // shuffle animation: permute visually a few times
      let shuffles = 0;
      const doShuffle = () => {
        // Fisher-Yates on order (visual), cards array stays the secret mapping by ci
        for (let i = order.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [order[i], order[j]] = [order[j], order[i]];
        }
        renderBacks(true);
        shuffles++;
        if (shuffles < 5) setTimeout(doShuffle, 280);
        else {
          document.getElementById("veilShuffle").textContent = "Выберите одну карту";
          bindPick();
        }
      };

      const flipAll = (chosenSlot) => {
        [...row.querySelectorAll(".veil-card")].forEach(btn => {
          const ci = +btn.dataset.ci;
          const card = cards[ci];
          const mine = +btn.dataset.slot === chosenSlot;
          btn.disabled = true;
          btn.style.cursor = "default";
          btn.innerHTML = `<div style="width:72px;height:102px;border-radius:8px;border:2px solid ${mine ? accent : "#666"};
            background:linear-gradient(180deg,#2a1838,#120a1a);color:#fff;display:flex;flex-direction:column;
            align-items:center;justify-content:center;padding:4px;box-shadow:${mine ? `0 0 16px ${accent}` : "none"}">
            <div style="font-size:28px">${faces[card] || "🂠"}</div>
            <div style="font-size:12px;color:${accent};font-weight:bold">${names[card] || card}</div>
            <div style="font-size:9px;line-height:1.2;margin-top:4px;color:#ccc;text-align:center">${effects[card] || ""}</div>
            ${mine ? `<div style="font-size:10px;color:${accent};margin-top:2px">✓ ваш выбор</div>` : ""}
          </div>`;
        });
      };

      const bindPick = () => {
        row.querySelectorAll(".veil-card").forEach(btn => {
          btn.onclick = () => {
            if (picked !== null || mg.done) return;
            picked = +btn.dataset.ci; // index into cards[] (secret order)
            const slot = +btn.dataset.slot;
            // lock others
            row.querySelectorAll(".veil-card").forEach(b => {
              b.disabled = true;
              b.style.opacity = (+b.dataset.slot === slot) ? "1" : "0.45";
              b.style.cursor = "default";
            });
            document.getElementById("veilHint").textContent = "Открываем карты…";
            setTimeout(() => {
              flipAll(slot);
              setTimeout(() => mgFinish({index: picked, card: cards[picked]}), 700);
            }, 350);
          };
        });
      };

      // style keyframes once
      if (!document.getElementById("veilBlindCSS")) {
        const st = document.createElement("style");
        st.id = "veilBlindCSS";
        st.textContent = `@keyframes veilShuffle{0%{transform:translateY(0) rotate(0)}40%{transform:translateY(-12px) rotate(-6deg)}100%{transform:translateY(0) rotate(0)}}`;
        document.head.appendChild(st);
      }

      mgStart(o, () => ({index: picked != null ? picked : 0, card: cards[picked != null ? picked : 0]}));
      renderBacks(true);
      setTimeout(doShuffle, 200);
    };

    // keep card_pick as thin alias only if something still references it (not Veil)
    if (!MINIGAMES.card_pick) {
      MINIGAMES.card_pick = function (o, head) {
        openBox(head + timerBar + `<div class="muted">card_pick deprecated — use veil_blind_draw</div>`);
        mgStart(o, () => ({index: 0}));
      };
    }
  }

  if (typeof update === "function" && typeof paintStatusChips === "function") {
    const _upd54 = update;
    window.update = async function (b, first) {
      const r = await _upd54.apply(this, arguments);
      try { paintStatusChips(b || battle); } catch (e) {}
      return r;
    };
  }
  // paintStatusChips after update

  // ---- 5.4.1: unique MG UIs (no shared timing_ring/click_targets for new heroes) ----
  (function () {
    if (typeof MINIGAMES === "undefined") return;
    const theme = (o) => ({
      icon: o.icon || "◎", accent: o.accent || o.target_color || "#f5b942",
      hint: o.hint || "",
    });
    // Vertical dive track
    MINIGAMES.dive_track = function (o, head) {
      const t = theme(o); const P = o.period_ms || 700;
      openBox(head + `<div class="mg-area" id="mgA" style="width:120px;height:300px;margin:12px auto;cursor:pointer;box-shadow:inset 0 0 0 2px ${t.accent}66;position:relative">
        <div style="position:absolute;left:10%;right:10%;top:18%;height:14%;background:${t.accent}55;border:2px solid ${t.accent}"></div>
        <div id="diveMk" style="position:absolute;left:50%;width:40px;height:40px;margin-left:-20px;font-size:28px;transform:translateY(0)">${t.icon || "🪶"}</div>
      </div>` + timerBar + `<div class="muted">${t.hint || "Клик, когда метка в зоне"}</div>`);
      const mk = document.getElementById("diveMk");
      const loop = () => { if (mg.done) return; const ph = (performance.now() - mg.t0) % P; const y = (ph / P) * 260; mk.style.top = y + "px"; mg._ph = ph; mg.raf = requestAnimationFrame(loop); };
      mgStart(o, () => ({error_ms: 9999})); loop();
      document.getElementById("mgA").onpointerdown = () => {
        const ideal = P * 0.22; const err = Math.round(Math.min(Math.abs(mg._ph - ideal), P - Math.abs(mg._ph - ideal)));
        mgFinish({error_ms: err});
      };
    };
    // Generic themed timing (unique key, Spartan shield NOT used)
    function makeTiming(name, defaultIcon) {
      MINIGAMES[name] = function (o, head) {
        o = Object.assign({icon: defaultIcon}, o);
        const t = theme(o); const P = o.period_ms || 750; const M = P * 0.75;
        openBox(head + `<div class="mg-area" id="mgA" style="width:280px;height:280px;cursor:pointer;box-shadow:inset 0 0 0 2px ${t.accent}55">
          <div style="position:absolute;left:50%;top:50%;width:88px;height:88px;margin:-44px;border-radius:50%;border:5px solid ${t.accent};display:flex;align-items:center;justify-content:center;font-size:40px;background:#0006">${t.icon}</div>
          <div id="ring" style="position:absolute;left:50%;top:50%;border-radius:50%;border:4px solid #fff8"></div></div>` + timerBar + `<div class="muted">${t.hint || "Клик в момент совпадения"}</div>`);
        const ring = document.getElementById("ring");
        const loop = () => { if (mg.done) return; const ph = (performance.now() - mg.t0) % P; const s = Math.max(24, 280 - (280 - 96) * (ph / M));
          ring.style.width = ring.style.height = s + "px"; ring.style.margin = (-s / 2) + "px"; mg.raf = requestAnimationFrame(loop); };
        mgStart(o, () => ({error_ms: 9999})); loop();
        document.getElementById("mgA").onpointerdown = () => { const ph = (performance.now() - mg.t0) % P; mgFinish({error_ms: Math.round(Math.min(Math.abs(ph - M), P - Math.abs(ph - M)))}); };
      };
    }
    function makeClick(name, defaultIcon) {
      MINIGAMES[name] = function (o, head) {
        const t = theme(o); const n = o.count || 5; const icon = o.icon || defaultIcon;
        let hits = 0;
        openBox(head + timerBar + `<div class="mg-area" id="mgA" style="width:320px;height:240px;position:relative;box-shadow:inset 0 0 0 2px ${t.accent}55"></div>
          <div class="muted">${t.hint || "Кликайте цели"} · <b id="mgCnt">0</b>/${n}</div>`);
        const area = document.getElementById("mgA");
        mgStart(o, () => ({hits}));
        const spawn = () => {
          if (mg.done || hits >= n) return;
          const el = document.createElement("div");
          el.textContent = icon; el.style.cssText = `position:absolute;left:${10 + Math.random() * 70}%;top:${10 + Math.random() * 70}%;font-size:28px;cursor:pointer;filter:drop-shadow(0 0 6px ${t.accent})`;
          el.onpointerdown = (e) => { e.stopPropagation(); hits++; el.remove(); document.getElementById("mgCnt").textContent = hits; if (hits >= n) mgFinish({hits}); };
          area.appendChild(el);
          setTimeout(() => { if (el.parentNode) el.remove(); if (!mg.done) spawn(); }, o.spawn_ms || 700);
        };
        spawn();
      };
    }
    makeTiming("mark_lock", "🎯");
    makeTiming("laugh_rhythm", "🤣");
    makeTiming("judgment_scale", "⚖");
    makeTiming("charge_steer", "🐃");
    makeTiming("fang_snap", "🦷");
    makeTiming("spear_power", "🔱");
    makeTiming("breath_hold", "🔥");
    makeClick("trap_grid", "🪤");
    makeClick("totem_order", "🛕");
    makeClick("pounce_pads", "🐾");
    makeClick("axe_orbit", "🪓");
    makeClick("web_weave", "🕸");
    makeClick("spawn_burst", "🕷");
    makeClick("volley_fan", "🏹");
    makeClick("splash_aim", "🍺");
    // Power bar variants
    MINIGAMES.spear_power = function (o, head) {
      const t = theme(Object.assign({icon: "🔱"}, o));
      const P = o.period_ms || 900; const Z = 0.72, pw = 0.05;
      openBox(head + `<div style="position:relative;height:28px;background:#222;border-radius:8px;margin:16px 0">
        <div style="position:absolute;left:${(Z - 0.1) * 100}%;width:20%;height:100%;background:#1a4a6a"></div>
        <div style="position:absolute;left:${(Z - pw) * 100}%;width:${pw * 200}%;height:100%;background:${t.accent}"></div>
        <div id="spK" style="position:absolute;top:-3px;width:4px;height:34px;background:#fff"></div>
      </div><button class="btn" id="spB">Бросок!</button>` + timerBar);
      const x = () => { const tt = ((performance.now() - mg.t0) % (2 * P)) / P; return tt < 1 ? tt : 2 - tt; };
      const loop = () => { if (mg.done) return; document.getElementById("spK").style.left = (x() * 100) + "%"; mg.raf = requestAnimationFrame(loop); };
      mgStart(o, () => ({error_ms: 9999})); loop();
      document.getElementById("spB").onclick = () => { const d = Math.abs(x() - Z); mgFinish({error_ms: Math.round(d * P)}); };
    };
    MINIGAMES.breath_hold = function (o, head) {
      const t = theme(Object.assign({icon: "🔥"}, o));
      let held = 0, down = false;
      openBox(head + `<div class="mg-area" id="mgA" style="width:280px;height:180px;display:flex;align-items:center;justify-content:center;flex-direction:column;box-shadow:inset 0 0 0 2px ${t.accent}66;cursor:pointer">
        <div style="font-size:48px">${t.icon}</div><div id="bhV" style="font-size:22px;color:${t.accent}">0%</div>
        <div class="muted">Удерживайте, отпустите в зоне 60–85%</div></div>` + timerBar);
      mgStart(o, () => ({error_ms: 9999, ratio: held}));
      const area = document.getElementById("mgA");
      area.onpointerdown = () => { down = true; };
      area.onpointerup = () => {
        if (!down || mg.done) return; down = false;
        const ideal = 0.72; const err = Math.round(Math.abs(held - ideal) * 1000);
        mgFinish({error_ms: err, ratio: held});
      };
      const loop = () => {
        if (mg.done) return;
        if (down) held = Math.min(1, held + 0.012);
        document.getElementById("bhV").textContent = Math.round(held * 100) + "%";
        mg.raf = requestAnimationFrame(loop);
      };
      loop();
    };
    MINIGAMES.judgment_scale = function (o, head) {
      const t = theme(Object.assign({icon: "⚖"}, o));
      const P = o.period_ms || 800;
      openBox(head + `<div class="mg-area" id="mgA" style="width:300px;height:160px;cursor:pointer;position:relative;box-shadow:inset 0 0 0 2px ${t.accent}55">
        <div style="position:absolute;left:50%;top:20px;width:2px;height:80px;background:#fff6"></div>
        <div id="scBeam" style="position:absolute;left:20%;right:20%;top:50%;height:6px;background:${t.accent};transform-origin:center;transform:rotate(0deg)"></div>
        <div style="position:absolute;left:50%;top:44%;width:24px;height:24px;margin:-12px;border:2px solid #fff;border-radius:50%"></div>
      </div>` + timerBar + `<div class="muted">Клик, когда весы горизонтальны</div>`);
      const beam = document.getElementById("scBeam");
      const loop = () => { if (mg.done) return; const ph = (performance.now() - mg.t0) % P; const ang = Math.sin(ph / P * Math.PI * 2) * 28; beam.style.transform = `rotate(${ang}deg)`; mg._ang = ang; mg.raf = requestAnimationFrame(loop); };
      mgStart(o, () => ({error_ms: 9999})); loop();
      document.getElementById("mgA").onpointerdown = () => mgFinish({error_ms: Math.round(Math.abs(mg._ang || 0) * 8)});
    };
  })();

  console.info("[v54] 5.4.1 UI + boomerang_dual + dual_stop");
})();
