// ===================== Hero Arena 5.1 =====================
(function () {
  const st = document.createElement("style");
  st.textContent = `
  /* кат-сцена: фигура КРУПНАЯ по центру, поверх фона/статуй, с тенью и ободком */
  #cutscene .cs-shade{z-index:1}
  #cutscene .cs-figure{
    position:absolute !important;left:50% !important;right:auto !important;
    bottom:8% !important;height:min(88vh,780px) !important;width:auto !important;max-width:92vw !important;
    object-fit:contain !important;object-position:center bottom !important;
    transform:translateX(-50%) translateY(24px) scale(1.02) !important;
    opacity:0;transition:opacity .7s,transform .7s,filter .7s;
    filter:drop-shadow(0 18px 36px #000e) drop-shadow(0 0 22px #f5b94266) drop-shadow(0 0 10px #fff3);
    pointer-events:none;z-index:4 !important;
  }
  #cutscene .cs-figure.on{opacity:1;transform:translateX(-50%) translateY(0) scale(1.08) !important}
  #cutscene .cs-figure.fairy{
    height:min(38vh,300px) !important;bottom:28% !important;left:58% !important;
    transform:translateX(-50%) !important;filter:drop-shadow(0 10px 24px #000c) drop-shadow(0 0 28px #fff6b0);
    z-index:4 !important;
  }
  #cutscene .cs-figure.fairy.on{transform:translateX(-50%) !important}
  #cutscene .cs-figure-side{
    position:absolute !important;left:14% !important;right:auto !important;
    bottom:18% !important;height:min(38vh,300px) !important;width:auto !important;
    object-fit:contain !important;transform:none !important;
    filter:drop-shadow(0 10px 24px #000c) drop-shadow(0 0 28px #fff6b0);
    opacity:0;visibility:hidden;pointer-events:none;z-index:5 !important;
    transition:opacity .5s;
  }
  #cutscene .cs-figure-side.on{opacity:1;visibility:visible}
  #cutscene .cs-box{z-index:6}
  #cutscene .cs-title{z-index:5}
  #cutscene .cs-portrait{width:200px !important;height:200px !important}
  #cutscene .cs-portrait.demon{width:230px !important;height:230px !important}
  /* карта мира */
  #worldMapModal{position:fixed;inset:0;z-index:70;background:#000c;display:none;align-items:center;justify-content:center;padding:16px}
  #worldMapModal .wm-box{position:relative;max-width:min(720px,96vw);width:100%;background:#140f1a;border:2px solid #f5b94288;border-radius:16px;padding:14px;box-shadow:0 0 40px #000}
  #worldMapModal .wm-map{position:relative;width:100%;aspect-ratio:3/4;border-radius:12px;background:#1a1610 center/cover;border:1px solid #3d5a3d}
  #worldMapModal .wm-pin{position:absolute;transform:translate(-50%,-50%);min-width:120px;padding:8px 10px;border-radius:10px;background:#0d0a12ee;border:2px solid #7a6a4a;color:#eee;cursor:pointer;text-align:center;font-size:13px}
  #worldMapModal .wm-pin.open{border-color:var(--gold);box-shadow:0 0 16px #f5b94288}
  #worldMapModal .wm-pin.done{border-color:var(--green)}
  #worldMapModal .wm-pin.locked{filter:grayscale(1) brightness(.6);cursor:not-allowed}
  #worldMapModal .wm-close{position:absolute;top:8px;right:10px}
  .node.elite{border-color:#f5b942}
  .replay-cs{margin-top:6px;font-size:13px;padding:6px 10px}
  .story-bag-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:10px}
  .story-fight-btn{display:block;width:100%;margin-top:12px;padding:14px 18px !important;font-size:18px !important;font-weight:700;letter-spacing:.02em;background:linear-gradient(180deg,#f5d76e,#c9962a) !important;color:#1a1208 !important;border:2px solid #ffe9a8 !important;border-radius:12px !important;box-shadow:0 0 18px #f5b94288,0 4px 0 #8a6a18;cursor:pointer;animation:storyFightPulse 2.2s ease-in-out infinite}
  .story-fight-btn:hover{filter:brightness(1.08)}
  .story-fight-btn:disabled{animation:none;opacity:.55;cursor:not-allowed;box-shadow:none;background:#555 !important;color:#ccc !important;border-color:#666 !important}
  @keyframes storyFightPulse{0%,100%{box-shadow:0 0 14px #f5b94266,0 4px 0 #8a6a18}50%{box-shadow:0 0 26px #f5b942cc,0 4px 0 #8a6a18}}
  .story-stage-card{display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap}
  .story-stage-card > img{width:140px;border-radius:10px;object-fit:cover;flex:0 0 auto}
  .story-stage-body{flex:1 1 220px;min-width:0}
  .story-enemy-desc{margin:6px 0 10px;padding:8px 10px;border-left:3px solid #f5b94299;background:#1a152288;border-radius:0 8px 8px 0;color:#ddd;font-size:13.5px;line-height:1.45;font-style:italic}
  `;
  document.head.appendChild(st);
  // world map modal
  if (!document.getElementById("worldMapModal")) {
    const m = document.createElement("div");
    m.id = "worldMapModal";
    m.innerHTML = `<div class="wm-box"><button class="btn ghost wm-close" onclick="closeWorldMap()">✕</button>
      <h2 style="margin:4px 0 10px;color:var(--gold);text-align:center">🗺 Карта мира</h2>
      <div class="wm-map" id="wmMap"></div>
      <p class="muted" style="text-align:center;margin-top:8px">Пройденные локации можно открыть снова: кат-сцены — да, бои — закрыты.</p></div>`;
    document.body.appendChild(m);
    m.addEventListener("click", e => { if (e.target === m) closeWorldMap(); });
  }
})();

// after-катсцена чинится в v43.js (5.1); здесь — Шрек и кнопки

// ----- dialogueScene: дефолтный фон не лес -----
const _ds51 = dialogueScene;
dialogueScene = function (lines, background, title, figure) {
  const bg = background || (storyData && (storyData.locations.find(l => l.key === storyLocKey) || {}).cutscene_bg) || "/static/images/story/slums_street.jpg";
  const scenes = _ds51(lines, bg, title, figure);
  // 5.1i: у КАЖДОЙ сцены этапа — фигура врага по умолчанию
  (scenes || []).forEach(sc => {
    if (figure) {
      sc.figure = figure;
      sc.enemy_figure = figure;
    }
  });
  return scenes;
};


async function maybeStartShrek(b) {
  if (!b || !b.story || b.story.stage !== "fisherman") return;
  if (window._shrekCutsceneStarted) return;
  const hid = b.hero1_id;
  const ov = await api(`/api/story?hero_id=${hid}`);
  if (ov) storyData = ov;
  const f = (storyData && storyData.flags) || {};
  if (!f.secret_shrek_secret || f.secret_done_shrek_secret) return;
  if (f.seen_shrek_secret) return;
  window._shrekCutsceneStarted = true;
  storyLocKey = "swamp";
  storyData.flags = storyData.flags || {};
  storyData.flags.seen_shrek_secret = true;
  try { await setStoryFlag(hid, "seen_shrek_secret"); } catch (e) {}
  toast("🤫 Секретный бой открыт!", "event");
  // катсцена один раз → сразу бой без повторного before в storyFight
  storyDialogue("shrek_secret", "before", () => _doStoryFight(hid, "swamp", "shrek_secret", null));
}

// ----- 6: центрированные фигуры уже в CSS; спикеры — сервер отдаёт русские имена -----

// ----- 3: не дублировать before в storyNext -----
storyNext = async function () {
  exitBattle("story");
  window._storyLocPinned = false; // после боя возвращаемся к актуальному прогрессу
  await loadStory();
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  // секретный шрек: если катсцена уже шла из maybeStartShrek — не трогаем;
  // иначе показать карточку (без автозапуска катсцены)
  const secret = (loc.stages || []).find(s => s.secret && s.status === "open" && !s.fight_locked);
  if (secret) {
    if (window._shrekCutsceneStarted) {
      window.scrollTo({top: 0, behavior: "smooth"});
      return;
    }
    storyLocKey = loc.key;
    pickStage(secret.key);
    toast(`Секрет: ${secret.name}`, "event");
    window.scrollTo({top: 0, behavior: "smooth"});
    return;
  }
  const open = loc.stages.find(s => s.status === "open" && !s.hidden);
  if (open) {
    pickStage(open.key);
    toast(`Следующий: ${open.name}`, "ok");
    document.querySelector(`#storyMap .node.open`)?.scrollIntoView({behavior: "smooth", block: "center"});
  } else if (loc.choice_pending) {
    // развилка уже показана из showResult
    toast("Выберите дорогу на развилке", "warn");
  } else if (loc.cleared) {
    const next = storyData.locations.find(l => l.unlocked && !l.cleared);
    if (next) { switchLoc(next.key); toast(`Открыта локация: ${next.title}`, "event"); }
    else toast("✦ Продолжение следует…", "event");
  }
  window.scrollTo({top: 0, behavior: "smooth"});
};

// ----- 4: before стаи волков только при chain=0; флаги seen_* на сервер -----
const _storyFight51 = storyFight;
storyFight = async function (stage) {
  if (busy || (typeof guard === "function" && guard())) return;
  const hid = document.getElementById("storyHero").value;
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  const s = loc.stages.find(x => x.key === stage);
  if (!s) return;
  if (s.fight_locked || (loc.cleared && s.status !== "open")) {
    return toast("🔒 Бой закрыт — можно только пересмотреть кат-сцену", "warn");
  }
  const itemSel = document.getElementById("storyItem");
  const item = (itemSel && itemSel.value) || null;

  const markSeen = async (flag) => {
    storyData.flags = storyData.flags || {};
    storyData.flags[flag] = true;
    try { await setStoryFlag(hid, flag); } catch (e) {}
  };

  // цепочка: кат-сцена только перед первой головой/волком
  const chainFlag = s.chain ? ((storyData.flags || {})[`chain_${s.chain}`] || s.chain_progress || 0) : 0;
  if (s.chain && (chainFlag > 0 || window._chainSkip === stage)) {
    window._chainSkip = null;
    return _doStoryFight(hid, loc.key, stage, item);
  }

  const flag = s.boss ? `${loc.key}_boss_before_seen` : `seen_${stage}`;
  if (s.before && s.before.length && !(storyData.flags || {})[flag]) {
    return storyDialogue(stage, "before", async () => {
      await markSeen(flag);
      if (stage === "giant_croc") return runPullLegThenFight(hid, loc.key, stage, item);
      await _doStoryFight(hid, loc.key, stage, item);
    });
  }
  if (stage === "giant_croc" && !(storyData.flags || {}).pulled_leg_done) {
    return runPullLegThenFight(hid, loc.key, stage, item);
  }
  await _doStoryFight(hid, loc.key, stage, item);
};

// ----- 7: таймер pull_leg + передача ratio на сервер -----
runPullLegThenFight = function (hid, location, stage, item) {
  const head = `<h3>🦵 Вытащи ногу!</h3><p class="muted">Крокодил сомкнул челюсти — кликай быстрее! Время идёт.</p>`;
  const prev = window.mgFinish;
  window.mgFinish = function (choice) {
    window.mgFinish = prev;
    if (typeof closeBox === "function") closeBox();
    storyData.flags = storyData.flags || {};
    storyData.flags.pulled_leg_done = true;
    const ratio = (choice && typeof choice.ratio === "number") ? choice.ratio : 0;
    if (ratio < 1) toast("Нога всё ещё в пасти — потеряешь здоровье!", "warn");
    else toast("Нога свободна!", "ok");
    _doStoryFight(hid, location, stage, item, {pull_leg_ratio: ratio});
  };
  MINIGAMES.pull_leg({clicks: 18, time_limit_ms: 5000}, head);
};

MINIGAMES.pull_leg = function (o, head) {
  openBox(head + `<p class="muted">Кликай быстро, пока идёт таймер!</p>
    <div class="bar" style="height:22px;margin:12px 0"><div id="plFill" style="width:0%;height:100%;background:#4cd07d"></div></div>
    <button class="btn" id="plBtn" style="font-size:22px;padding:14px 28px">🦵 Вытащить!</button>
    <div class="muted">Прогресс: <b id="plPct">0</b>%</div>` + timerBar);
  let clicks = 0, need = o.clicks || 18;
  mgStart(o, () => ({ratio: Math.min(1, clicks / need)}));
  document.getElementById("plBtn").onpointerdown = () => {
    if (mg && mg.done) return;
    clicks++;
    const r = Math.min(1, clicks / need);
    document.getElementById("plFill").style.width = (r * 100) + "%";
    document.getElementById("plPct").textContent = Math.round(r * 100);
    if (r >= 1) mgFinish({ratio: 1});
  };
};

_doStoryFight = async function (hid, location, stage, item, extra) {
  const body = {location, stage, mode: "manual", item, ...(extra || {})};
  const b = await api(`/api/heroes/${hid}/story_battle`, "POST", body);
  if (!b) return checkActive && checkActive();
  lastStage = stage;
  if (typeof mountPanel === "function") mountPanel("story");
  battle = null; resetArena();
  await update(b, true);
  document.getElementById("arenaPanel").scrollIntoView({behavior: "smooth"});
};

// ----- pickStage: фон локации + replay катсцен + fight_locked -----
function storyRewardLabel(s) {
  if (s && s.reward_label) return s.reward_label;
  const raw = s && s.reward_item;
  if (!raw) return "";
  if (s.reward_parts && s.reward_parts.length)
    return s.reward_parts.map(p => `${p.icon || "📦"} ${p.name || p.key}`).join(" + ");
  return String(raw).split("+").map(k => {
    k = k.trim();
    const [ic, nm] = itemInfo(k);
    return `${ic} ${nm}`;
  }).join(" + ");
}

pickStage = async function (key) {
  const hid = document.getElementById("storyHero").value;
  if (!storyData || !hid) return toast("Сначала создайте сюжетного героя");
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  const s = loc.stages.find(x => x.key === key);
  if (!s || s.hidden) return;
  if (s.status === "locked" && !s.secret) return toast("🔒 Этап закрыт — победите предыдущего противника");
  storyStage = s;
  const bag = storyData.story_bag || {};
  if (typeof ensureShop === "function") await ensureShop();
  const kind = s.boss ? "Босс локации" : s.elite ? "⭐ Элита" : "Противник";
  const fightBtn = (s.fight_locked || loc.cleared)
    ? `<button class="btn story-fight-btn" disabled title="Бои в пройденных локациях закрыты">🔒 Бой закрыт</button>`
    : `<button class="btn story-fight-btn" onclick="storyFight('${s.key}')">${s.status === "done" ? "🔁 Реванш" : "⚔ В бой"}</button>`;
  // до боя — только достигнутый этап (open/done); после боя — только после победы
  const canBefore = s.replay_before != null ? s.replay_before : (s.status === "open" || s.status === "done");
  const canAfter = s.replay_after != null ? s.replay_after : (s.status === "done");
  const replays = [];
  if (s.before && s.before.length && canBefore)
    replays.push(`<button class="btn ghost replay-cs" onclick="storyDialogue('${s.key}','before')">🎬 Кат-сцена до боя</button>`);
  if (s.after && s.after.length && canAfter)
    replays.push(`<button class="btn ghost replay-cs" onclick="storyDialogue('${s.key}','after')">🎬 Кат-сцена после боя</button>`);
  const speaker = s.name || s.title || "Противник";
  const role = (s.role_name && !/^[a-z_]+$/.test(s.role_name)) ? ` · роль: ${esc(s.role_name)}` : "";
  const rewardTxt = storyRewardLabel(s);
  const reward = rewardTxt ? ` · 🎒 ${rewardTxt}` : "";
  const curKey = window._storyCurrentLocKey
    || ((storyData.locations || []).find(l => l.unlocked && !l.cleared) || {}).key;
  const backBtn = (curKey && curKey !== loc.key)
    ? `<button class="btn small" onclick="goCurrentStoryLoc()">▶ К текущей локации</button>` : "";
  const locTabs = `<div class="row" style="margin-bottom:10px;flex-wrap:wrap;gap:4px">${(storyData.locations || []).map(l =>
    `<button class="btn small ghost ${l.key===loc.key?"active":""}" ${l.unlocked?"":"disabled"} title="${l.unlocked?"":"Сначала пройдите предыдущую"}"
      onclick="switchLoc('${l.key}')">${esc(l.title)}${l.cleared?" ✅":""}</button>`).join("")}${backBtn}</div>`;
  const descHtml = s.desc ? `<div class="story-enemy-desc">${esc(s.desc)}</div>` : "";
  document.getElementById("storyInfo").innerHTML = `${locTabs}<div class="story-stage-card"><img src="${s.image}" onerror="this.src='/static/images/wolf.jpg'">
    <div class="story-stage-body"><h3 style="margin:0;color:var(--gold)">${s.icon} ${esc(s.card_title || s.title)} ${s.status === "done" ? "✅" : ""}</h3>
    <div class="muted">${kind} · ур. ${s.display_level != null ? s.display_level : (s.level || "?")}${role}${loc.cleared?" · 🔒 бои закрыты":""}</div>
    ${descHtml}
    <p style="font-style:italic">💬 ${esc(speaker)}: «${esc(s.line)}»</p>
    <div class="muted">Награда: до ${s.xp} опыта и ${s.gold} золота${reward}</div>
    <div class="story-bag-row">🎒 Сумка:
      <select id="storyItem"><option value="">— без предмета —</option>${Object.entries(bag).map(([k, n]) =>
        `<option value="${k}">${itemInfo(k)[0]} ${esc(itemInfo(k)[1])} ×${n}</option>`).join("")}</select>
    </div>
    ${fightBtn}
    <div class="row" style="margin-top:8px;flex-wrap:wrap;gap:6px">${replays.join(" ")}</div>
    </div></div>`;
};

// ----- карта локации: фон текущей локации, скрыть skipped -----
renderStoryMap = function (loc, hid) {
  document.getElementById("storyTitle").textContent = loc.title + (loc.cleared ? " ✅ пройден" : "");
  const map = document.getElementById("storyMap");
  map.style.background = `url("${loc.image}") center/cover`;
  map.innerHTML = loc.stages.filter(s => !s.hidden && (!s.secret || s.status !== "locked")).map(s => `
    <div class="node ${hid ? s.status : "locked"} ${s.boss ? "boss" : ""} ${s.elite ? "elite" : ""} ${s.secret ? "secret" : ""}"
      style="left:${s.x}%;top:${s.y}%" onclick="pickStage('${s.key}')">
      ${s.icon}<label>${esc(s.name || s.title)}${s.boss ? " 👑" : s.elite ? " ⭐" : ""}</label></div>`).join("");
};

// ----- loadStory: кнопка карты мира -----
const _loadStory51 = loadStory;
loadStory = async function () {
  await _loadStory51();
  const btn = document.getElementById("worldMapBtn");
  const hid = document.getElementById("storyHero") && document.getElementById("storyHero").value;
  if (btn) btn.style.display = hid ? "" : "none";
};

// ----- 11: карта мира -----
function openWorldMap() {
  if (!storyData) return;
  const box = document.getElementById("wmMap");
  const img = storyData.world_map || "/static/images/story/world_map.jpg";
  box.style.backgroundImage = `url("${img}")`;
  // 5.1: только текущие локации сюжета (трущобы/лес/роща/болото)
  const pins = [
    {key: "slums", label: "🏚 Трущобы", x: 50, y: 18},
    {key: "forest", label: "🌲 Тёмный лес", x: 50, y: 40},
    {key: "grove", label: "🕸 Проклятая роща", x: 50, y: 62},
    {key: "swamp", label: "🐸 Болото", x: 50, y: 84},
  ];
  box.innerHTML = pins.map(p => {
    const loc = (storyData.locations || []).find(l => l.key === p.key);
    let cls = "locked";
    if (!loc) cls = "locked";
    else if (loc.cleared) cls = "done";
    else if (loc.unlocked) cls = "open";
    const click = (loc && loc.unlocked) ? `onclick="closeWorldMap();switchLoc('${p.key}')"` : "";
    return `<div class="wm-pin ${cls}" style="left:${p.x}%;top:${p.y}%" ${click}>${esc(p.label)}${loc && loc.cleared ? " ✅" : ""}</div>`;
  }).join("");
  document.getElementById("worldMapModal").style.display = "flex";
}
function closeWorldMap() {
  document.getElementById("worldMapModal").style.display = "none";
}

// ----- showResult: убрать реванш если fight locked; цепочка без повторной катсцены -----
const _sr51b = showResult;
// already wrapped above as _showResult51; extend reward buttons
(function () {
  const prev = showResult;
  showResult = function (b) {
    prev(b);
    if (kindOf(b) !== "story") return;
    const won = b.winner_id === b.hero1_id;
    const s = b.story || {};
    if (won && s.chain_continue) {
      window._chainSkip = s.stage;
      storyData.flags = storyData.flags || {};
      // локально обновим счётчик, чтобы кат-сцена не повторилась
      const loc = (storyData.locations || []).find(l => l.key === s.location);
      const st = loc && loc.stages.find(x => x.key === s.stage);
      if (st && st.chain) {
        st.chain_progress = s.chain_progress || ((st.chain_progress || 0) + 1);
        storyData.flags[`chain_${st.chain}`] = st.chain_progress;
      }
      return;
    }
    const box = document.getElementById("skillBox");
    if (!box) return;
    if (won) {
      const reward = box.querySelector(".reward-card");
      const rewardHtml = reward ? reward.outerHTML : "";
      box.innerHTML = `${rewardHtml}<button class="btn" onclick="storyNext()">Дальше ▶</button>
        <button class="btn small ghost" onclick="exitBattle('story');window.scrollTo({top:0,behavior:'smooth'})">🗺 К карте</button>`;
    }
  };
})();

// ----- pickStoryPath: после выбора обновить карту -----
const _pickPath = pickStoryPath;
pickStoryPath = async function (flag, value) {
  await _pickPath(flag, value);
  toast(value === "light" ? "Светлая дорога открыта" : "Тёмная дорога открыта", "ok");
};

// ----- storyDialogue для секретов с другого ключа локации -----
const _sd51 = storyDialogue;
storyDialogue = function (key, which, then) {
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  let s = loc.stages.find(x => x.key === key);
  if (!s) {
    for (const L of storyData.locations) {
      s = L.stages.find(x => x.key === key);
      if (s) break;
    }
  }
  if (!s) return then && then();
  const canBefore = s.replay_before != null ? s.replay_before : (s.status === "open" || s.status === "done");
  const canAfter = s.replay_after != null ? s.replay_after : (s.status === "done");
  if (which === "after" && !canAfter) {
    toast("🔒 Кат-сцена после боя откроется, когда победите этого противника", "warn");
    return then && then();
  }
  if (which === "before" && !canBefore) {
    toast("🔒 Этап ещё не достигнут", "warn");
    return then && then();
  }
  const lines = (which === "after" ? s.after : s.before) || [];
  if (!lines.length) return then && then();
  const parentLoc = storyData.locations.find(l => l.stages.some(x => x.key === key)) || loc;
  const fig = s.figure || null;
  // 5.1g: после боя — after_background + нейтральный заголовок (локация), не «Имя — босс»
  let bg, title;
  if (which === "after") {
    bg = s.after_background || s.background || parentLoc.cutscene_bg || parentLoc.image;
    title = parentLoc.title || "";
  } else {
    bg = s.background || parentLoc.cutscene_bg || parentLoc.image;
    title = s.card_title || s.title || "";
  }
  playCutscene(dialogueScene(lines, bg, title, fig), storyData.hero, then);
};

// ===== 5.1 cutscene anti-flash =====
// Причины: playCutscene открывал оверлей со старым #csFigure.src+.on;
// смена fig.src на видимой картинке без preload; narrator не прятал фигуру.
// Решение: очистка до показа, preload, показ только после onload, прятать на narrator/hero.
(function () {
  const st = document.createElement("style");
  st.textContent = `
  #cutscene .cs-figure{opacity:0;pointer-events:none;visibility:hidden}
  #cutscene .cs-figure.on{opacity:1;visibility:visible}
  #cutscene .cs-figure.cs-loading{opacity:0 !important;visibility:hidden !important}
  #cutscene .cs-portrait{transition:opacity .2s}
  `;
  document.head.appendChild(st);

  let _figGen = 0, _portGen = 0;

  function _csEnsureFigure() {
    let fig = document.getElementById("csFigure");
    if (!fig) {
      fig = document.createElement("img");
      fig.id = "csFigure"; fig.className = "cs-figure"; fig.alt = "";
      const root = document.getElementById("cutscene");
      // под shade, над bg
      root.appendChild(fig);
    }
    return fig;
  }

  function _csClearFigure() {
    try { _csClearSide(); } catch (e) {}
    const gen = ++_figGen;
    const fig = document.getElementById("csFigure");
    if (!fig) return;
    // 5.3.3: сначала fade-out, потом убрать src
    fig.classList.remove("on", "fairy");
    fig.style.opacity = "0";
    setTimeout(() => {
      if (gen !== _figGen) return;
      fig.classList.add("cs-loading");
      fig.removeAttribute("src");
      fig.style.visibility = "hidden";
    }, 650);
  }

  function _csPreload(urls) {
    const list = [...new Set((urls || []).filter(Boolean))];
    return Promise.all(list.map(u => new Promise(res => {
      const im = new Image();
      im.onload = im.onerror = () => res(u);
      im.src = u;
    })));
  }

  function _csShowFigure(src, fairy) {
    const fig = _csEnsureFigure();
    if (!src) { _csClearFigure(); return; }
    if (fig.getAttribute("src") === src && fig.classList.contains("on") && !fig.classList.contains("cs-loading")) {
      fig.classList.toggle("fairy", !!fairy);
      return;
    }
    const gen = ++_figGen;
    fig.classList.remove("on", "fairy");
    fig.classList.add("cs-loading");
    fig.style.visibility = "hidden";
    fig.style.opacity = "0";
    const im = new Image();
    im.onload = () => {
      if (gen !== _figGen) return;
      fig.src = src;
      fig.classList.toggle("fairy", !!fairy);
      fig.classList.remove("cs-loading");
      fig.style.visibility = "visible";
      requestAnimationFrame(() => {
        if (gen !== _figGen) return;
        fig.classList.add("on");
        fig.style.opacity = "";
      });
    };
    im.onerror = () => { if (gen === _figGen) _csClearFigure(); };
    im.src = src;
  }

  function _csShowPortrait(src, cls) {
    const img = document.getElementById("csPortrait");
    if (!img) return;
    img.className = "cs-portrait " + (cls || "");
    if (!src) {
      _portGen++;
      img.style.display = "none";
      img.removeAttribute("src");
      img.style.opacity = "0";
      return;
    }
    if (img.getAttribute("src") === src && img.style.display !== "none") return;
    const gen = ++_portGen;
    img.style.opacity = "0";
    const im = new Image();
    im.onload = () => {
      if (gen !== _portGen) return;
      img.src = src;
      img.style.display = "";
      requestAnimationFrame(() => { if (gen === _portGen) img.style.opacity = "1"; });
    };
    im.onerror = () => {
      if (gen !== _portGen) return;
      img.style.display = "none";
      img.removeAttribute("src");
    };
    im.src = src;
  }

  function _csCollectUrls(scenes, hero) {
    const urls = [];
    (scenes || []).forEach(sc => {
      if (sc.background) urls.push(sc.background);
      if (sc.figure) urls.push(sc.figure);
      (sc.lines || []).forEach(line => {
        if (line.figure) urls.push(line.figure);
        if (line.image) urls.push(line.image);
      });
    });
    if (hero && hero.image) urls.push(hero.image);
    return urls;
  }

  function _csSideEl() {
    let el = document.getElementById("csFigureSide");
    if (!el) {
      el = document.createElement("img");
      el.id = "csFigureSide"; el.className = "cs-figure-side"; el.alt = "";
      const root = document.getElementById("cutscene");
      if (root) root.appendChild(el);
    }
    return el;
  }
  function _csClearSide() {
    const el = document.getElementById("csFigureSide");
    if (!el) return;
    el.classList.remove("on");
    el.removeAttribute("src");
  }
  function _csShowSide(src) {
    const el = _csSideEl();
    if (!src) { _csClearSide(); return; }
    const show = () => { el.classList.add("on"); };
    if (el.getAttribute("src") === src) { show(); return; }
    el.classList.remove("on");
    el.onload = () => { if (el.getAttribute("src") === src) show(); };
    el.src = src;
  }

  // 5.3.4: вернули логику 5.3.2 — в pre-fight фигура врага всегда на сцене,
  // если у сцены задан sc.figure / sc.enemy_figure (даже на репликах Дейлы/рассказчика).
  // Уход Альтаира после его реплик — через split after в v53.js (part2 без figure).
  // После боя без реплик врага figure уже null (strip в v53) → фигуры нет.
  function _csApplySpeakerFigure(sc, line) {
    if (!line) return;
    const enemy = (sc && (sc.figure || sc.enemy_figure)) || null;
    // Дейла: враг по центру (если есть), Дейла сбоку. Иначе — только Дейла.
    // .cs-figure-side скрыт CSS в v53 → на экране один силуэт врага; портрет — Дейла.
    if (line.speaker === "dayla") {
      const daylaSrc = line.figure || "/static/images/story/cutouts/fig_dayla.png";
      if (enemy) {
        _csShowFigure(enemy, false);
        _csShowSide(daylaSrc);
      } else {
        _csClearSide();
        _csShowFigure(daylaSrc, true);
      }
      return;
    }
    _csClearSide();
    // Рассказчик / герой / таверна — ВСЕГДА фигура врага этапа, если есть
    if (line.speaker === "hero" || line.speaker === "narrator" || line.speaker === "tavern") {
      if (enemy) _csShowFigure(enemy, false);
      else if (line.figure) _csShowFigure(line.figure, /dayla|fairy/i.test(line.figure || ""));
      // не чистим в пустоту во время реплик — оставляем предыдущую, если врага нет
      return;
    }
    // Реплика самого врага или другого персонажа
    const src = line.figure || enemy || null;
    if (!src) return;
    _csShowFigure(src, /dayla|fairy/i.test(src));
  }


  // ---- playCutscene: очистка + preload ----
  const _play0 = playCutscene;
  playCutscene = async function (scenes, hero, onDone) {
    _csClearFigure();
    const port = document.getElementById("csPortrait");
    if (port) { port.style.display = "none"; port.removeAttribute("src"); port.style.opacity = "0"; }
    const title = document.getElementById("csTitle");
    if (title) { title.classList.remove("on"); title.textContent = ""; }
    const box = document.getElementById("csBox");
    if (box) box.classList.remove("on");
    const bg = document.getElementById("csBg");
    if (bg) bg.classList.remove("on");
    try { await _csPreload(_csCollectUrls(scenes, hero)); } catch (e) {}
    _play0(scenes, hero, onDone);
  };

  const _end0 = _csEnd;
  _csEnd = function () {
    _csClearFigure();
    const port = document.getElementById("csPortrait");
    if (port) { port.style.display = "none"; port.removeAttribute("src"); port.style.opacity = "0"; }
    _end0();
  };

  // ---- сцена: только фон/заголовок как в v43, без мгновенной смены фигуры ----
  _csScene = function () {
    if (!_cs) return;
    const sc = _cs.scenes[_cs.si];
    const bg = document.getElementById("csBg"), title = document.getElementById("csTitle"), box = document.getElementById("csBox");
    const fade = document.getElementById("csFade");
    fade.classList.remove("off"); bg.classList.remove("on"); title.classList.remove("on"); box.classList.remove("on");
    _csClearFigure();
    const port = document.getElementById("csPortrait");
    if (port) { port.style.display = "none"; port.style.opacity = "0"; }
    const wait = _cs.si === 0 ? 50 : 800;
    setTimeout(() => {
      if (!_cs || _cs.scenes[_cs.si] !== sc) return;
      bg.style.backgroundImage = `url('${sc.background}')`;
      title.textContent = sc.title || "";
      fade.classList.add("off"); bg.classList.add("on");
      setTimeout(() => title.classList.add("on"), 400);
      _cs.li = -1;
      // 5.3.4 / 5.1i: сразу показать фигуру врага этапа (любой первый спикер).
      // Если figure=null (after без реплик врага / part2 Альтаира) — превью пустое.
      if (sc.figure || sc.enemy_figure) {
        _csShowFigure(sc.figure || sc.enemy_figure, false);
      } else {
        const first = (sc.lines && sc.lines[0]) || null;
        if (first && first.speaker === "dayla") {
          _csShowFigure(first.figure || "/static/images/story/cutouts/fig_dayla.png", true);
        }
      }
      setTimeout(_csNext, 900);
    }, wait);
  };

  // ---- реплика: текст + портрет/фигура после preload ----
  _csNext = function () {
    if (!_cs) return;
    const sc = _cs.scenes[_cs.si];
    if (_cs.timer) {
      clearInterval(_cs.timer); _cs.timer = null;
      document.getElementById("csLine").textContent = _csFill(sc.lines[_cs.li].text, _cs.hero);
      return;
    }
    _cs.li++;
    if (_cs.li >= sc.lines.length) {
      _cs.si++;
      if (_cs.si >= _cs.scenes.length) return _csEnd();
      return _csScene();
    }
    const line = sc.lines[_cs.li], box = document.getElementById("csBox");
    let src = line.image, name = line.name;
    if (line.speaker === "hero" || (line.speaker === "narrator" && sc.portrait === "hero")) {
      src = _cs.hero && _cs.hero.image;
      name = line.speaker === "hero" ? (_cs.hero && _cs.hero.name) : null;
    } else if (line.speaker === "narrator") {
      const p = sc.portrait;
      src = p === "karrgall" ? "/static/images/story/karrgall.jpg" : p === "dayla" ? "/static/images/story/dayla.jpg" : null;
    } else if (line.speaker === "tavern") {
      src = _cs.hero && _cs.hero.image;
    }
    const cls = (STORY_SPEAKER_CLASS[line.speaker] || (line.speaker === "narrator" ? STORY_SPEAKER_CLASS[sc.portrait] || "" : ""));
    _csShowPortrait(src, cls);
    document.getElementById("csName").textContent = name || "";
    box.classList.add("on");
    _csApplySpeakerFigure(sc, line);

    const full = _csFill(line.text, _cs.hero), out = document.getElementById("csLine");
    out.textContent = ""; let i = 0;
    const typing = setInterval(() => {
      if (!_cs) { clearInterval(typing); return; }
      out.textContent = full.slice(0, ++i);
      if (i >= full.length) { clearInterval(typing); if (_cs) _cs.timer = null; }
    }, 22);
    _cs.timer = typing;
  };

  // экспорт для тестов
  window.__csAntiFlash = { clear: _csClearFigure, show: _csShowFigure, preload: _csPreload };
})();


// ----- 5.1f: лента действий — отдельный блок под карточкой, JS-состояние -----
(function () {
  const MAX_FEED = 4;
  window._actionFeeds = window._actionFeeds || {}; // battleId -> { heroId: [{text,kind}] } newest first
  let _feedBattleId = null;

  function _feedKey(b) {
    return b && (b.id != null) ? String(b.id) : "active";
  }

  function clearFeedsFor(b) {
    const id = _feedKey(b);
    _feedBattleId = id;
    window._actionFeeds[id] = {};
  }

  function ensureBattleBag(b) {
    const id = _feedKey(b);
    if (_feedBattleId !== id) clearFeedsFor(b);
    if (!window._actionFeeds[id]) window._actionFeeds[id] = {};
    return window._actionFeeds[id];
  }

  function pushActionFeed(b, heroId, text, kind) {
    if (!b || heroId == null || !text) return;
    const bag = ensureBattleBag(b);
    const k = String(heroId);
    if (!bag[k]) bag[k] = [];
    const line = String(text).length > 90 ? String(text).slice(0, 87) + "…" : String(text);
    if (bag[k][0] && bag[k][0].text === line) return;
    bag[k].unshift({ text: line, kind: kind || "info" });
    if (bag[k].length > MAX_FEED) bag[k].length = MAX_FEED;
  }

  function ingestLogEntry(b, e) {
    if (!b || !e || !e.text) return;
    (b.heroes || []).forEach(h => {
      if (e.text.includes(h.name)) pushActionFeed(b, h.id, e.text, e.kind);
    });
  }

  function rebuildFromLog(b, upto) {
    clearFeedsFor(b);
    if (!b || !b.log) return;
    const end = Math.min(upto == null ? b.log.length : upto, b.log.length);
    const start = Math.max(0, end - 24);
    for (let i = start; i < end; i++) ingestLogEntry(b, b.log[i]);
  }

  function feedEl(i) {
    return document.getElementById("feed" + i);
  }

  function paintActionFeeds(b) {
    if (!b || !b.heroes) return;
    const bag = ensureBattleBag(b);
    b.heroes.forEach((h, i) => {
      const feed = feedEl(i);
      if (!feed) return;
      // убрать старую ленту внутри карточки (v50), чтобы не дублировать/не конфликтовать с skill UI
      const el = document.getElementById("f" + i);
      if (el) el.querySelectorAll(".action-feed").forEach(n => n.remove());
      const lines = bag[String(h.id)] || [];
      const opac = [1, 0.82, 0.64, 0.5];
      feed.innerHTML = lines.map((L, idx) =>
        `<div class="k-${esc(L.kind || "info")}" style="opacity:${opac[idx] != null ? opac[idx] : 0.4}">${esc(L.text)}</div>`
      ).join("");
    });
  }

  const st = document.createElement("style");
  st.textContent = `
  .fighter-col .action-feed{margin-top:0}
  .fighter .action-feed{display:none !important} /* лента только в #feed0/#feed1 */
  `;
  document.head.appendChild(st);

  const _rfFeed = renderFighters;
  renderFighters = function (b, snap, hideFx) {
    _rfFeed(b, snap, hideFx);
    if (b) paintActionFeeds(b);
    // 5.1j: честный display_level врага сюжета на карточке боя
    if (b && b.heroes) {
      b.heroes.forEach((h, i) => {
        const el = document.getElementById("f" + i);
        if (!el) return;
        const muted = el.querySelector(".muted");
        if (!muted) return;
        let dl = h.display_level;
        if (dl == null && b.story && b.ai_ids && b.ai_ids.includes(h.id)) dl = b.story.display_level;
        if (dl == null || Number(dl) === Number(h.level)) return;
        muted.innerHTML = muted.innerHTML.replace(/ур\.\s*\d+/, "ур. " + dl);
      });
    }
  };

  const _plFeed = playLog;
  playLog = async function (b) {
    if (!b) return _plFeed(b);
    ensureBattleBag(b);
    // история до текущего хвоста
    rebuildFromLog(b, typeof shownLog === "number" ? shownLog : 0);
    paintActionFeeds(b);

    const box = document.getElementById("log");
    const mo = new MutationObserver(muts => {
      if (!battle) return;
      muts.forEach(m => m.addedNodes.forEach(node => {
        if (!node || node.nodeType !== 1) return;
        const text = node.textContent || "";
        if (!text) return;
        const kind = (node.className || "").toString().replace(/^k-/, "") || "info";
        battle.heroes.forEach(h => {
          if (text.includes(h.name)) pushActionFeed(battle, h.id, text, kind);
        });
        paintActionFeeds(battle);
      }));
    });
    if (box) mo.observe(box, { childList: true });
    try {
      await _plFeed(b);
    } finally {
      mo.disconnect();
    }
    // полная синхронизация после анимации / fast-пропуска
    rebuildFromLog(b, typeof shownLog === "number" ? shownLog : (b.log || []).length);
    paintActionFeeds(b || battle);
  };

  if (typeof resetArena === "function") {
    const _ra = resetArena;
    resetArena = function () {
      _feedBattleId = null;
      window._actionFeeds = {};
      ["feed0", "feed1"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = "";
      });
      return _ra.apply(this, arguments);
    };
  }

  // после renderSkills лента не должна пропадать — перекрасим
  if (typeof renderSkills === "function") {
    const _rs = renderSkills;
    renderSkills = function (b) {
      _rs(b);
      if (b) paintActionFeeds(b);
    };
  }

  window.__actionFeed = { push: pushActionFeed, paint: paintActionFeeds, rebuild: rebuildFromLog };
})();

// ----- 5.1c: реплей вступления не сбрасывает локацию -----
const _playIntro51 = typeof playIntro === "function" ? playIntro : null;
if (_playIntro51) {
  playIntro = function (replay) {
    const keep = storyLocKey;
    const pinned = window._storyLocPinned;
    _playIntro51(replay);
    // playIntro не должен менять локацию; на всякий случай вернём
    storyLocKey = keep;
    window._storyLocPinned = pinned;
  };
}

// ----- 5.1d: после refresh снова предложить создать героя, если своих нет -----
const _refreshAll51 = refreshAll;
refreshAll = async function () {
  await _refreshAll51();
  if (typeof _decorateHeroCards === "function") _decorateHeroCards();
  if (typeof checkFirstVisit === "function") await checkFirstVisit();
};
