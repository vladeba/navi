// ===================== Hero Arena 5 =====================
(function () {
  const st = document.createElement("style");
  st.textContent = `
  /* 9: верхняя панель крупнее */
  header{padding:14px 22px !important}
  header h1{font-size:28px !important;letter-spacing:1px}
  nav button{font-size:16px !important;padding:10px 18px !important;margin:0 4px !important;border-radius:10px !important}
  #playerBox{font-size:15px !important}
  /* 6: свечение облика */
  .fighter{position:relative}
  .fighter .skin-cap{font-size:12px;margin-top:2px}
  .fighter.rar-common{box-shadow:0 0 12px #9aa inset,0 0 8px #9aa8}
  .fighter.rar-rare{box-shadow:0 0 16px #3b82f6 inset,0 0 12px #3b82f688}
  .fighter.rar-epic{box-shadow:0 0 18px #a855f7 inset,0 0 14px #a855f788}
  .fighter.rar-legendary{box-shadow:0 0 20px #f5b942 inset,0 0 16px #f5b94288}
  .fighter.rar-mythic{animation:mythicGlow 2.4s ease-in-out infinite}
  @keyframes mythicGlow{0%,100%{box-shadow:0 0 18px #ef4444,0 0 8px #f59e0b}50%{box-shadow:0 0 28px #a855f7,0 0 16px #22d3ee}}
  /* 11: лента действий */
  .action-feed{margin-top:8px;max-height:88px;overflow:hidden;font-size:12px;line-height:1.35;text-align:left}
  .action-feed div{opacity:1;transition:opacity .4s;padding:1px 0;border-bottom:1px solid #ffffff10}
  .action-feed div:nth-child(2){opacity:.75}
  .action-feed div:nth-child(3){opacity:.5}
  .action-feed div:nth-child(n+4){opacity:.3}
  /* сюжетный фон боя */
  #arenaPanel.story-bg{background-size:cover;background-position:center;position:relative}
  #arenaPanel.story-bg::before{content:"";position:absolute;inset:0;background:#000a;backdrop-filter:blur(2px);pointer-events:none;border-radius:inherit}
  #arenaPanel.story-bg > *{position:relative;z-index:1}
  /* кат-сцена: фигура */
  #cutscene .cs-figure{position:absolute;right:4%;bottom:18%;height:min(62vh,520px);width:auto;opacity:0;transform:translateX(40px);transition:opacity .7s,transform .7s;filter:drop-shadow(0 8px 24px #000c);pointer-events:none;z-index:1}
  #cutscene .cs-figure.on{opacity:1;transform:translateX(0)}
  #cutscene .cs-figure.fairy{height:min(28vh,220px);right:12%;bottom:28%;animation:csFly 2.4s ease-in-out infinite}
  .reward-card{background:#1a1522;border:1px solid #f5b94255;border-radius:12px;padding:12px 16px;margin:8px 0;text-align:left}
  .reward-card .bar{height:10px;background:#333;border-radius:6px;overflow:hidden;margin:4px 0}
  .reward-card .bar > div{height:100%;background:linear-gradient(90deg,#f5b942,#4cd07d)}
  .node.elite label::before{content:"⭐ "}
  .node.open{box-shadow:0 0 16px #f5b942cc}
  `;
  document.head.appendChild(st);
})();

const RARITY_OF = {};  // class:skin → rarity; skin names can repeat across classes

async function ensureRarityMap() {
  await ensureShop();
  if (!shop) return;
  Object.entries(shop.skins || {}).forEach(([type, list]) =>
    list.forEach(s => { RARITY_OF[`${type}:${s.skin}`] = s.rarity; }));
}

// ----- 6: подпись облика + свечение -----
const _rf50 = renderFighters;
renderFighters = function (b, snap = null, hideFx = false) {
  _rf50(b, snap, hideFx);
  ensureRarityMap();
  b.heroes.forEach((h, i) => {
    const el = document.getElementById("f" + i); if (!el) return;
    const skin = h.battle_skin || h.skin;
    el.classList.remove("rar-common", "rar-rare", "rar-epic", "rar-legendary", "rar-mythic");
    if (skin) {
      const rar = RARITY_OF[`${h.type}:${skin}`] || "common";
      el.classList.add("rar-" + rar);
      let cap = el.querySelector(".skin-cap");
      if (!cap) { cap = document.createElement("div"); cap.className = "skin-cap"; el.insertBefore(cap, el.children[2] || null); }
      const name = (typeof skinName === "function") ? skinName(h, skin) : skin;
      cap.innerHTML = `✨ Скин: <b>${esc(name)}</b>`;
    }
    // лента действий
    let feed = el.querySelector(".action-feed");
    if (!feed) { feed = document.createElement("div"); feed.className = "action-feed"; el.appendChild(feed); }
  });
  // фон сюжета
  const panel = document.getElementById("arenaPanel");
  if (b.story && b.story.battle_bg) {
    panel.classList.add("story-bg");
    panel.style.backgroundImage = `url('${b.story.battle_bg}')`;
  } else {
    panel.classList.remove("story-bg");
    panel.style.backgroundImage = "";
  }
};

// ----- 11: лента + уже есть floatNum -----
const _playLog50 = playLog;
playLog = async function (b) {
  // перехватываем добавление строк — дублируем в ленту бойца
  const box = document.getElementById("log");
  const origAppend = box.appendChild.bind(box);
  box.appendChild = function (div) {
    origAppend(div);
    if (!battle) return div;
    const text = div.textContent || "";
    battle.heroes.forEach((h, i) => {
      if (!text.includes(h.name)) return;
      const el = document.getElementById("f" + i); if (!el) return;
      let feed = el.querySelector(".action-feed");
      if (!feed) { feed = document.createElement("div"); feed.className = "action-feed"; el.appendChild(feed); }
      const row = document.createElement("div");
      row.className = div.className;
      row.textContent = text.length > 90 ? text.slice(0, 87) + "…" : text;
      feed.insertBefore(row, feed.firstChild);
      while (feed.children.length > 4) feed.removeChild(feed.lastChild);
    });
    return div;
  };
  try { await _playLog50(b); } finally { box.appendChild = origAppend; }
};

// ----- 10: кнопка Убить -----
const _rs50 = renderSkills;
renderSkills = function (b) {
  _rs50(b);
  const ctl = document.getElementById("battleCtl");
  const p = currentPlayer();
  if (b.status === "active" && p && p.dev_mode) {
    if (!ctl.innerHTML.includes("killOpp")) {
      ctl.innerHTML += ` <button class="btn small red" onclick="killOpp()">💀 Убить</button>`;
    }
  }
};
async function killOpp() {
  if (!battle || !confirm("Убить соперника? (режим разработчика)")) return;
  const p = currentPlayer();
  const b = await api(`/api/battles/${battle.id}/kill`, "POST", {player_id: p ? p.id : null, hero_id: battle.hero1_id});
  if (b) await update(b);
}

// ----- 2: мини-игра выбора 2 направлений -----
MINIGAMES.dir_pick = function (o, head) {
  const L = o.labels || {up: "⬆️ Вверх", down: "⬇️ Вниз", left: "⬅️ Влево", right: "➡️ Вправо"};
  const need = o.pick_count || 2;
  openBox(head + `<p class="muted">Выберите ${need} направления удара:</p>
    <div id="dpBtns">${(o.dirs || []).map(d => `<button class="btn dodge-btn" data-d="${d}">${esc(L[d] || d)}</button>`).join("")}</div>
    <div class="muted">Выбрано: <b id="dpCnt">0</b>/${need}</div>` + timerBar);
  const picked = [];
  document.querySelectorAll("#dpBtns [data-d]").forEach(btn => btn.onclick = () => {
    const d = btn.dataset.d;
    if (picked.includes(d)) return;
    picked.push(d); btn.disabled = true; btn.style.outline = "2px solid var(--gold)";
    document.getElementById("dpCnt").textContent = picked.length;
    if (picked.length >= need) mgFinish({dirs: picked});
  });
  mgStart(o, () => ({dirs: picked}));
};

// ----- вытащи ногу -----
MINIGAMES.pull_leg = function (o, head) {
  openBox(head + `<p class="muted">Кликай быстро 5 секунд, чтобы вырвать ногу!</p>
    <div class="bar" style="height:22px;margin:12px 0"><div id="plFill" style="width:0%;height:100%;background:#4cd07d"></div></div>
    <button class="btn" id="plBtn" style="font-size:22px;padding:14px 28px">🦵 Вытащить!</button>
    <div class="muted">Прогресс: <b id="plPct">0</b>%</div>` + timerBar);
  let clicks = 0, need = o.clicks || 18;
  mgStart(o, () => ({ratio: Math.min(1, clicks / need)}));
  document.getElementById("plBtn").onpointerdown = () => {
    clicks++;
    const r = Math.min(1, clicks / need);
    document.getElementById("plFill").style.width = (r * 100) + "%";
    document.getElementById("plPct").textContent = Math.round(r * 100);
    if (r >= 1) mgFinish({ratio: 1});
  };
};

// ----- 13: UI лимита героев в режиме разработчика -----
const _lh50 = loadHeroes;
loadHeroes = async function () {
  await _lh50();
  const p = currentPlayer();
  if (p && p.slots) {
    const as = document.getElementById("arenaSlots");
    const si = document.getElementById("slotsInfo");
    if (p.dev_mode || p.slots.max == null) {
      if (as) as.textContent = `(${p.slots.used}/∞ · 🛠 режим разработчика · без лимита героев арены)`;
      if (si) si.textContent = `Ваши герои: ${p.slots.used}/∞ (режим разработчика) · сюжетные: ${p.slots.story_used}/${p.slots.story_max}`;
    } else {
      if (as) as.textContent = `(${p.slots.used}/${p.slots.max} + Совух · нажмите на карточку, чтобы сделать героя активным)`;
      if (si) si.textContent = `Ваши герои: ${p.slots.used}/${p.slots.max} (Совух не занимает слот) · сюжетные: ${p.slots.story_used}/${p.slots.story_max}`;
    }
    const ssh = document.getElementById("storySlotsH");
    if (ssh) ssh.textContent = `(${p.slots.story_used}/${p.slots.story_max} · один герой сюжета)`;
    // кнопка «Создать героя»: у обычных — disabled на лимите; в режиме разработчика всегда доступна
    document.querySelectorAll('button[onclick="createHero()"]').forEach(btn => {
      const atLimit = !p.dev_mode && p.slots.max != null && p.slots.used >= p.slots.max;
      btn.disabled = atLimit;
      btn.title = atLimit ? `Лимит: ${p.slots.max} героев арены` : (p.dev_mode ? "Режим разработчика — без лимита" : "");
    });
  }
};

// ----- 1: ℹ на карточках создания сюжетного героя -----
if (typeof renderStoryClassCards === "function") {
  const _rsc50 = renderStoryClassCards;
  renderStoryClassCards = function () {
    _rsc50();
    document.querySelectorAll("#storyClassCards .class-card").forEach(el => {
      if (el.querySelector(".hero-info-btn")) return;
      const type = (el.getAttribute("onclick") || "").match(/'([^']+)'/);
      if (!type) return;
      const b = document.createElement("button");
      b.className = "hero-info-btn"; b.textContent = "i"; b.title = "Подробнее";
      b.onclick = e => { e.stopPropagation(); openHeroInfo(type[1]); };
      el.style.position = "relative";
      el.appendChild(b);
    });
  };
}

// ----- 5 + сюжетная сумка + карты локаций + кат-сцены с фигурами -----
let storyLocKey = "slums";

const _loadStory50 = loadStory;
loadStory = async function () {
  await loadPlayers();
  const p = currentPlayer(); if (!p) return;
  const heroes = (await api("/api/heroes") || []).filter(h => h.story && h.owner_id === p.id);
  const sel = document.getElementById("storyHero"), old = sel.value;
  sel.innerHTML = heroes.map(h => `<option value="${h.id}">${esc(h.name)} (${h.hero_class}, ур. ${h.level})</option>`).join("")
    || `<option value="">— нет сюжетного героя —</option>`;
  if (old && heroes.some(h => h.id == old)) sel.value = old;
  document.getElementById("storySlots").textContent = `${heroes.length}/1`;
  const create = document.getElementById("storyCreate"), tg = document.getElementById("storyNewToggle");
  if (heroes.length >= 1) { create.style.display = "none"; tg.style.display = "none"; }
  else { create.style.display = ""; tg.style.display = "none"; renderStoryClassCards(); }
  const hid = sel.value;
  storyData = await api("/api/story" + (hid ? `?hero_id=${hid}` : ""));
  if (!storyData) return;
  // текущая (активная) локация сюжета
  const currentLoc = storyData.locations.find(l => l.unlocked && !l.cleared)
            || storyData.locations.filter(l => l.unlocked).pop()
            || storyData.locations[0];
  // если игрок сам выбрал вкладку/пин карты — не сбрасывать на «текущую»
  const preferred = storyData.locations.find(l => l.key === storyLocKey && l.unlocked);
  let loc = (window._storyLocPinned && preferred) ? preferred : currentLoc;
  storyLocKey = loc.key;
  window._storyCurrentLocKey = currentLoc.key;
  renderStoryMap(loc, hid);
  document.getElementById("storyReplay").style.display = hid ? "" : "none";
  const info = document.getElementById("storyInfo");
  if (!hid) {
    info.innerHTML = `<p>${esc(loc.intro)}</p><p class="muted">Создайте сюжетного героя (1 уровень), чтобы начать путь.</p>
      <div class="row" style="margin-top:8px;flex-wrap:wrap">${storyData.locations.map(l =>
        `<button class="btn small ghost ${l.key===loc.key?"active":""}" ${l.unlocked?"":"disabled"} onclick="switchLoc('${l.key}')">${esc(l.title)}</button>`).join("")}</div>`;
    return;
  }
  const h = storyData.hero;
  const xpNeed = h.xp_needed || 100;
  const curKey = window._storyCurrentLocKey || currentLoc.key;
  const backBtn = (window._storyLocPinned && curKey && curKey !== loc.key)
    ? `<button class="btn small" onclick="goCurrentStoryLoc()">▶ К текущей локации</button>` : "";
  info.innerHTML = `<p>${esc(loc.intro)}</p>
    <div class="muted">${esc(h.name)}: ур. ${h.level}, опыт ${h.experience}/${xpNeed} · этапов ${loc.progress}/${loc.stages.length}
      · 🎒 сюжетная сумка: ${Object.keys(storyData.story_bag||{}).length ? Object.entries(storyData.story_bag).map(([k,n])=>`${itemInfo(k)[0]}×${n}`).join(" ") : "пусто"}${loc.cleared?" · 🔒 бои закрыты, кат-сцены доступны":""}</div>
    <div class="row" style="margin-top:8px;flex-wrap:wrap">${storyData.locations.map(l =>
      `<button class="btn small ghost ${l.key===loc.key?"active":""}" ${l.unlocked?"":"disabled" } title="${l.unlocked?"":"Сначала пройдите предыдущую"}"
        onclick="switchLoc('${l.key}')">${esc(l.title)}${l.cleared?" ✅":""}</button>`).join("")}${backBtn}</div>`;
  if (loc.cleared && loc.key === "swamp") {
    info.innerHTML += `<div class="reward-card" style="margin-top:10px"><b>✦ Продолжение следует…</b><div class="muted">Новые локации появятся в следующих обновлениях.</div></div>`;
  }
  const open = loc.stages.find(s => s.status === "open");
  const doneFirst = loc.stages.find(s => s.status === "done");
  if (open) pickStage(open.key);
  else if (doneFirst) pickStage(doneFirst.key);
  if (!(storyData.flags || {}).intro_seen) playIntro(false);
};

function switchLoc(key) {
  if (!storyData) return;
  const loc = storyData.locations.find(l => l.key === key);
  if (!loc || !loc.unlocked) return toast("Локация ещё закрыта");
  window._storyLocPinned = true;
  storyLocKey = key;
  renderStoryMap(loc, document.getElementById("storyHero").value);
  // НЕ вызываем loadStory() — он раньше сбрасывал storyLocKey на текущую локацию (мигание)
  const h = storyData.hero;
  const info = document.getElementById("storyInfo");
  const xpNeed = h ? (h.xp_needed || 100) : 100;
  const curKey = window._storyCurrentLocKey || (storyData.locations.find(l => l.unlocked && !l.cleared) || {}).key;
  const backBtn = (curKey && curKey !== key)
    ? `<button class="btn small" onclick="goCurrentStoryLoc()">▶ К текущей локации</button>` : "";
  info.innerHTML = `<p>${esc(loc.intro)}</p>
    <div class="muted">${h?esc(h.name)+`: ур. ${h.level}, опыт ${h.experience}/${xpNeed}`:""} · этапов ${loc.progress}/${loc.stages.length}${loc.cleared?" · 🔒 бои закрыты, кат-сцены доступны":""}</div>
    <div class="row" style="margin-top:8px;flex-wrap:wrap">${storyData.locations.map(l =>
      `<button class="btn small ghost ${l.key===loc.key?"active":""}" ${l.unlocked?"":"disabled"} onclick="switchLoc('${l.key}')">${esc(l.title)}${l.cleared?" ✅":""}</button>`).join("")}${backBtn}</div>`;
  const open = loc.stages.find(s => s.status === "open");
  const done = loc.stages.find(s => s.status === "done");
  if (open) pickStage(open.key);
  else if (done) pickStage(done.key);
}
function goCurrentStoryLoc() {
  window._storyLocPinned = false;
  const cur = window._storyCurrentLocKey
    || ((storyData.locations || []).find(l => l.unlocked && !l.cleared) || {}).key;
  if (cur) switchLoc(cur);
  window._storyLocPinned = false; // текущая — не «пиним» прошлую
}

function renderStoryMap(loc, hid) {
  document.getElementById("storyTitle").textContent = loc.title + (loc.cleared ? " ✅ пройден" : "");
  const map = document.getElementById("storyMap");
  map.style.background = `url("${loc.image}") center/cover`;
  map.innerHTML = loc.stages.filter(s => !s.secret).map(s => `
    <div class="node ${hid ? s.status : "locked"} ${s.boss ? "boss" : ""} ${s.elite ? "elite" : ""}"
      style="left:${s.x}%;top:${s.y}%" onclick="pickStage('${s.key}')">
      ${s.icon}<label>${esc(s.name || s.title)}${s.boss ? " 👑" : s.elite ? "" : ""}</label></div>`).join("");
}

pickStage = function (key) {
  const hid = document.getElementById("storyHero").value;
  if (!storyData || !hid) return toast("Сначала создайте сюжетного героя");
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  const s = loc.stages.find(x => x.key === key);
  if (!s) return;
  if (s.status === "locked") return toast("🔒 Этап закрыт — победите предыдущего противника");
  storyStage = s;
  const h = storyData.hero;
  const bag = storyData.story_bag || {};
  document.getElementById("storyInfo").innerHTML = `<div class="row" style="align-items:flex-start"><img src="${s.image}" style="width:120px;border-radius:10px">
    <div><h3 style="margin:0;color:var(--gold)">${s.icon} ${esc(s.card_title || s.title)} ${s.status === "done" ? "✅" : ""}</h3>
    <div class="muted">${s.boss ? "Босс локации" : s.elite ? "⭐ Элита" : "Противник"} · ур. ${s.level || "?"} · роль: ${esc(s.role_name || "")}</div>
    <p style="font-style:italic">💬 ${esc(h.name)}: «${esc(s.line)}»</p>
    <div class="muted">Награда: до ${s.xp} опыта и ${s.gold} золота${s.reward_item ? ` · 🎒 ${s.reward_item}` : ""}</div>
    <div class="row" style="margin-top:8px">🎒 Сумка:
      <select id="storyItem"><option value="">— без предмета —</option>${Object.entries(bag).map(([k, n]) =>
        `<option value="${k}">${itemInfo(k)[0]} ${esc(itemInfo(k)[1])} ×${n}</option>`).join("")}</select>
      <button class="btn" onclick="storyFight('${s.key}')">⚔ В бой</button>
      ${s.before && s.before.length ? `<button class="btn ghost" onclick="storyDialogue('${s.key}','before')">💬 Диалог</button>` : ""}
    </div></div></div>`;
};

storyDialogue = function (key, which, then) {
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  const s = loc.stages.find(x => x.key === key);
  const lines = (which === "after" ? s.after : s.before) || [];
  if (!lines.length) return then && then();
  const bg = s.background || loc.cutscene_bg || loc.image;
  const fig = s.figure || null;
  playCutscene(dialogueScene(lines, bg, s.card_title, fig), storyData.hero, then);
};

// расширяем dialogueScene фигурой
const _ds = dialogueScene;
dialogueScene = function (lines, background, title, figure) {
  const scenes = _ds(lines, background, title);
  if (figure) scenes[0].figure = figure;
  return scenes;
};

const _csScene50 = _csScene;
_csScene = function () {
  _csScene50();
  const sc = _cs && _cs.scenes[_cs.si];
  let fig = document.getElementById("csFigure");
  if (!fig) {
    fig = document.createElement("img");
    fig.id = "csFigure"; fig.className = "cs-figure"; fig.alt = "";
    document.getElementById("cutscene").appendChild(fig);
  }
  fig.classList.remove("on", "fairy");
  const src = sc && (sc.figure || (sc.lines && sc.lines[0] && sc.lines[0].figure));
  if (src) {
    fig.src = src;
    if (/dayla|fairy/i.test(src)) fig.classList.add("fairy");
    setTimeout(() => fig.classList.add("on"), 500);
  } else {
    fig.removeAttribute("src");
  }
};
// при смене реплики — фигура говорящего злодея
const _csNext50 = _csNext;
_csNext = function () {
  _csNext50();
  if (!_cs) return;
  const sc = _cs.scenes[_cs.si]; if (!sc) return;
  const line = sc.lines[_cs.li];
  const fig = document.getElementById("csFigure");
  if (fig && line && line.figure && line.speaker !== "hero" && line.speaker !== "narrator") {
    fig.src = line.figure;
    fig.classList.toggle("fairy", line.speaker === "dayla");
    fig.classList.add("on");
  }
};

const _storyFight50 = storyFight;
storyFight = async function (stage) {
  if (busy || (typeof guard === "function" && guard())) return;
  const hid = document.getElementById("storyHero").value;
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  const s = loc.stages.find(x => x.key === stage);
  const itemSel = document.getElementById("storyItem");
  const item = (itemSel && itemSel.value) || null;
  // pre-boss dialogue
  const flag = s && s.boss ? `${loc.key}_boss_before_seen` : null;
  if (s && s.before && s.before.length && flag && !(storyData.flags || {})[flag]) {
    return storyDialogue(stage, "before", async () => {
      await setStoryFlag(hid, flag); storyData.flags[flag] = true;
      await _doStoryFight(hid, loc.key, stage, item);
    });
  }
  // обычный before (не босс) — тоже показать
  if (s && s.before && s.before.length && !s.boss && !(storyData.flags || {})[`seen_${stage}`]) {
    return storyDialogue(stage, "before", async () => {
      storyData.flags[`seen_${stage}`] = true;
      if (stage === "giant_croc") return runPullLegThenFight(hid, loc.key, stage, item);
      await _doStoryFight(hid, loc.key, stage, item);
    });
  }
  if (stage === "giant_croc" && !(storyData.flags || {}).pulled_leg) {
    return runPullLegThenFight(hid, loc.key, stage, item);
  }
  await _doStoryFight(hid, loc.key, stage, item);
};
function runPullLegThenFight(hid, location, stage, item) {
  const head = `<h3>🦵 Вытащи ногу!</h3><p class="muted">Крокодил сомкнул челюсти — кликай быстрее!</p>`;
  const prev = window.mgFinish;
  window.mgFinish = function (choice) {
    window.mgFinish = prev;
    if (typeof closeBox === "function") closeBox();
    storyData.flags = storyData.flags || {};
    storyData.flags.pulled_leg = true;
    const ratio = (choice && choice.ratio) || 0;
    if (ratio < 1) toast("Нога всё ещё в пасти — бой будет тяжелее!", "warn");
    else toast("Нога свободна!", "ok");
    _doStoryFight(hid, location, stage, item);
  };
  MINIGAMES.pull_leg({need: 25, time_ms: 5000}, head);
}
async function _doStoryFight(hid, location, stage, item) {
  const b = await api(`/api/heroes/${hid}/story_battle`, "POST", {location, stage, mode: "manual", item});
  if (!b) return checkActive && checkActive();
  lastStage = stage;
  if (typeof mountPanel === "function") mountPanel("story");
  battle = null; resetArena();
  await update(b, true);
  document.getElementById("arenaPanel").scrollIntoView({behavior: "smooth"});
}

// ----- 5: экран после боя -----
const _sr50 = showResult;
showResult = function (b) {
  _sr50(b);
  if (kindOf(b) !== "story") return;
  const won = b.winner_id === b.hero1_id;
  const s = b.story || {};
  const xp = s.xp_gained != null ? s.xp_gained : (b.xp ? (won ? b.xp[0] : b.xp[1]) : 0);
  const lvlA = s.level_after, lvlB = s.level_before;
  const leveled = lvlA != null && lvlB != null && lvlA > lvlB;
  const h = (b.heroes || [])[0] || {};
  const xpNeed = h.xp_needed || 100;
  const xpNow = h.experience || 0;
  const items = (s.items_gained || []).map(k => `${itemInfo(k)[0]} ${itemInfo(k)[1]}`).join(", ");
  const reward = `<div class="reward-card">
    <div>✨ Опыт: <b>+${xp}</b>${leveled ? ` · <span style="color:var(--gold)">Новый уровень! ${lvlB} → ${lvlA}</span>` : ""}</div>
    <div class="bar"><div style="width:${Math.min(100, 100 * xpNow / xpNeed)}%"></div></div>
    <div class="muted">ур. ${h.level || "?"} · ${xpNow}/${xpNeed}</div>
    <div>💰 Золото: <b>+${s.gold || 0}</b>${items ? ` · 🎒 ${items}` : ""}</div>
    ${s.monk_progress ? `<div class="muted">🔓 Монах: ${s.monk_progress}</div>` : ""}
  </div>`;
  let btns;
  if (won) {
    btns = `${reward}<button class="btn" onclick="storyNext()">Дальше ▶</button>
      <button class="btn small ghost" onclick="storyFight('${s.stage}')">🔁 Реванш</button>
      <button class="btn small ghost" onclick="exitBattle('story');window.scrollTo({top:0,behavior:'smooth'})">🗺 К карте</button>`;
  } else {
    btns = `${reward}<button class="btn" onclick="storyFight('${s.stage}')">Попробовать снова</button>
      <button class="btn ghost" onclick="exitBattle('story');window.scrollTo({top:0,behavior:'smooth'})">🗺 К карте</button>`;
  }
  document.getElementById("skillBox").innerHTML = btns;
  // цепочка — сразу следующий бой
  if (won && s.chain_continue) {
    setTimeout(() => storyFight(s.stage), 800);
  }
  // развилка
  if (won && s.choice && s.choice.options) {
    setTimeout(() => showStoryChoice(s.choice), 1000);
  }
};

async function storyNext() {
  exitBattle("story");
  await loadStory();
  const loc = storyData.locations.find(l => l.key === storyLocKey) || storyData.locations[0];
  const open = loc.stages.find(s => s.status === "open");
  if (open) {
    if (open.boss && open.before && open.before.length) {
      pickStage(open.key);
      storyDialogue(open.key, "before", () => storyFight(open.key));
    } else {
      pickStage(open.key);
      // подсветить узел — уже open
      toast(`Следующий: ${open.name}`, "ok");
      document.querySelector(`#storyMap .node.open`)?.scrollIntoView({behavior: "smooth", block: "center"});
    }
  } else if (loc.cleared) {
    const next = storyData.locations.find(l => l.unlocked && !l.cleared);
    if (next) { switchLoc(next.key); toast(`Открыта локация: ${next.title}`, "event"); }
    else toast("✦ Продолжение следует…", "event");
  }
  window.scrollTo({top: 0, behavior: "smooth"});
}

function showStoryChoice(choice) {
  document.getElementById("modal2Box").innerHTML = `<h3 style="color:var(--gold)">${esc(choice.prompt || "Выбор")}</h3>
    ${choice.options.map(o => `<div style="margin:8px"><button class="btn" style="width:90%" onclick="pickStoryPath('${choice.id}','${o.key}')">${esc(o.label)}</button></div>`).join("")}`;
  document.getElementById("modal2").style.display = "flex";
}
async function pickStoryPath(flag, value) {
  const hid = document.getElementById("storyHero").value;
  await api(`/api/heroes/${hid}/story_flags`, "POST", {flag, value});
  document.getElementById("modal2").style.display = "none";
  toast(value === "light" ? "Выбрана светлая дорога" : "Выбрана тёмная дорога", "ok");
  await loadStory();
}

// пасхалка: клик по портрету рыбака в бою
const _rfImg = renderFighters;
// already wrapped; add click on enemy portrait during fisherman fight
document.addEventListener("click", async e => {
  if (!battle || !battle.story || battle.story.stage !== "fisherman") return;
  const img = e.target.closest("#f1 img");
  if (!img) return;
  const hid = battle.hero1_id;
  const r = await api(`/api/heroes/${hid}/story_secret`, "POST", {secret: "shrek_secret"});
  if (r) {
    toast(r.message || "🎣 Вы открыли секретный бой!", "event");
    const log = document.getElementById("log");
    if (log) {
      const d = document.createElement("div"); d.className = "k-event";
      d.textContent = "🎣 Вы открыли секретный бой!"; log.appendChild(d);
    }
  }
}, true);

// текст создания
const help = document.querySelector("#story .panel p.muted");
if (help && help.textContent.includes("до 3")) {
  help.textContent = "У каждого игрока один сюжетный герой. Он начинает с 1 уровня, растёт на мобах и боссах и не участвует в арене. Спутники присоединятся по ходу истории.";
}
