/* Hero Arena 5.2 — инвентарь/скины сюжета, случайный скин, новая игра, смена персонажа */
// ---------- helpers ----------
function _storyHeroId() {
  const sel = document.getElementById("storyHero");
  return sel && sel.value ? +sel.value : null;
}
function _modal2(html) {
  const box = document.getElementById("modal2Box");
  const m = document.getElementById("modal2");
  if (!box || !m) return;
  box.innerHTML = html;
  m.style.display = "flex";
}
function _closeModal2() {
  const m = document.getElementById("modal2");
  if (m) m.style.display = "none";
}

// ---------- Item 1: кнопки 🎒 / 🎨 рядом с селектором сюжетного героя ----------
function ensureStoryHeroActions() {
  const row = document.getElementById("storyHero") && document.getElementById("storyHero").parentElement;
  if (!row || document.getElementById("storyBagBtn")) return;
  const actions = document.createElement("div");
  actions.className = "row";
  actions.id = "storyHeroActions";
  actions.style.cssText = "margin-top:6px;flex-wrap:wrap;gap:6px";
  actions.innerHTML = `
    <button class="btn small ghost" id="storyBagBtn" onclick="openStoryBag()">🎒 Инвентарь</button>
    <button class="btn small ghost" id="storySkinsBtn" onclick="openStorySkins()">🎨 Скины</button>
    <button class="btn small ghost" id="storyAbandonBtn" onclick="confirmAbandonStory()"
      style="border-color:#c44;color:#f88">Сменить персонажа</button>
    <button class="btn" id="storyNewGameBtn" onclick="confirmNewStoryGame()"
      style="display:none;background:linear-gradient(135deg,#2a5,#183);border-color:#4cd07d">🔄 Новая игра</button>`;
  row.parentElement.insertBefore(actions, row.nextSibling);
  // архив
  if (!document.getElementById("storyArchiveBox")) {
    const arch = document.createElement("div");
    arch.id = "storyArchiveBox";
    arch.className = "muted";
    arch.style.marginTop = "8px";
    row.parentElement.appendChild(arch);
  }
}

async function openStoryBag() {
  const hid = _storyHeroId();
  if (!hid) return toast("Сначала создайте сюжетного героя");
  const data = await api(`/api/heroes/${hid}/story_bag`);
  if (!data) return;
  const pending = data.pending_loot || [];
  const items = data.items || [];
  const slots = `${data.slots_used}/${data.slots_max}`;
  let html = `<h3 style="color:var(--gold);margin-top:0">🎒 Сюжетная сумка — слоты ${slots}</h3>`;
  if (pending.length) {
    html += `<div style="background:#422;border:1px solid #a55;border-radius:8px;padding:8px;margin-bottom:8px">
      ⚠ Сумка была полной — ждёт места: ${pending.map(k => {
        const [ic, nm] = itemInfo(k); return `${ic} ${esc(nm)}`;
      }).join(", ")}
      <div style="margin-top:6px"><button class="btn small" onclick="claimStoryPending()">Забрать свободное</button></div>
    </div>`;
  }
  if (!items.length) html += `<p class="muted">Пусто — награды за бои появятся здесь.</p>`;
  else {
    html += `<div class="inv-grid" style="grid-template-columns:repeat(auto-fill,minmax(110px,1fr))">` +
      items.map(it => `<div class="inv-slot full" style="flex-direction:column;height:auto;padding:8px">
        <div style="font-size:28px">${it.icon || "📦"}</div>
        <b style="font-size:12px">${esc(it.name)}</b>
        <span class="muted">×${it.count}</span>
        <button class="btn small red" style="margin-top:4px" onclick="discardStoryItem('${it.key}', '${esc(it.name)}')">Выбросить</button>
      </div>`).join("") + `</div>`;
  }
  html += `<div style="margin-top:12px"><button class="btn" onclick="_closeModal2()">Закрыть</button></div>`;
  _modal2(html);
}

async function discardStoryItem(key, name) {
  const hid = _storyHeroId();
  if (!hid) return;
  if (!confirm(`Выбросить «${name || key}» из сюжетной сумки?`)) return;
  const r = await api(`/api/heroes/${hid}/story_bag/discard`, "POST", {key, count: 1});
  if (!r) return;
  if ((r.claimed || []).length) toast(`Забрано из ожидания: ${r.claimed.join(", ")}`, "ok");
  else toast("Предмет выброшен", "ok");
  await loadStory();
  openStoryBag();
}

async function claimStoryPending() {
  const hid = _storyHeroId();
  if (!hid) return;
  const r = await api(`/api/heroes/${hid}/story_bag/claim`, "POST", {});
  if (!r) return;
  toast((r.claimed || []).length ? `Забрано: ${r.claimed.join(", ")}` : "Нет места или нечего забирать", "ok");
  await loadStory();
  openStoryBag();
}

async function openStorySkins() {
  const hid = _storyHeroId();
  if (!hid) return toast("Сначала создайте сюжетного героя");
  await ensureShop();
  const h = (allHeroes || []).find(x => x.id == hid) || await api(`/api/heroes/${hid}`);
  if (!h) return;
  const p = currentPlayer();
  const list = [...new Set([...(h.skins || []), ...((typeof ownedSkins === "function") ? ownedSkins(p, h.type) : [])])];
  const opts = [null, ...list]; // обычный + купленные
  const canRandom = opts.length >= 2;
  let html = `<h3 style="color:var(--gold);margin-top:0">🎨 Скины — ${esc(h.name)}</h3>`;
  html += `<label style="display:flex;align-items:center;gap:8px;margin:8px 0;padding:8px;border:1px solid #555;border-radius:8px;${canRandom ? "" : "opacity:.45"}">
    <input type="checkbox" id="rndSkinToggle" ${h.random_skin ? "checked" : ""} ${canRandom ? "" : "disabled"}
      onchange="toggleRandomSkin(${h.id}, this.checked)">
    🎲 Случайный скин ${canRandom ? "" : "<span class='muted'>(нужен хотя бы 1 купленный облик)</span>"}
  </label>`;
  html += `<div class="shop-grid">`;
  html += `<div class="shop-card"><div class="ic">👤</div><b>Обычный</b>
    <button class="btn small ghost" onclick="equipStorySkin(${h.id}, null)">${!h.skin && !h.random_skin ? "Надет" : "Надеть"}</button></div>`;
  const skins = (shop && shop.skins && shop.skins[h.type]) || [];
  list.forEach(k => {
    const meta = skins.find(s => s.skin === k) || {name: (typeof skinName === "function" ? skinName(h, k) : k), rarity: "common"};
    const on = h.skin === k && !h.random_skin;
    html += `<div class="shop-card rar-${meta.rarity || "common"}"><div class="ic">🎨</div><b>${esc(meta.name || k)}</b>
      <div class="muted">${esc(meta.rarity_name || meta.rarity || "")}</div>
      <button class="btn small ghost" onclick="equipStorySkin(${h.id}, '${k}')">${on ? "Надет" : "Надеть"}</button></div>`;
  });
  if (!list.length) html += `<p class="muted">Купите облики в магазине — они появятся здесь.</p>`;
  html += `</div><div style="margin-top:12px"><button class="btn" onclick="_closeModal2()">Закрыть</button></div>`;
  _modal2(html);
}

async function equipStorySkin(heroId, skin) {
  const p = currentPlayer();
  const r = await api(`/api/heroes/${heroId}/skin`, "PUT", {player_id: p ? p.id : null, skin: skin, random_skin: false});
  if (!r) return;
  toast(skin ? `🎨 Облик надет` : `Обычный облик`, "ok");
  await loadHeroes(); await loadStory();
  openStorySkins();
}

async function toggleRandomSkin(heroId, enabled) {
  const p = currentPlayer();
  const r = await api(`/api/heroes/${heroId}/random_skin`, "PUT", {player_id: p ? p.id : null, random_skin: !!enabled});
  if (!r) {
    // revert checkbox
    const cb = document.getElementById("rndSkinToggle");
    if (cb) cb.checked = !enabled;
    return;
  }
  toast(enabled ? "🎲 Случайный скин включён" : "Случайный скин выключен", "ok");
  await loadHeroes();
}

// ---------- Item 4: toggle в селектах обликов арены/сюжета (карточки героев) ----------
function decorateRandomSkinToggles() {
  document.querySelectorAll("#myHeroList .hero, #myStoryList .hero").forEach(el => {
    const id = +el.dataset.id;
    const h = (allHeroes || []).find(x => x.id === id);
    if (!h) return;
    const p = currentPlayer();
    const list = [...new Set([...(h.skins || []), ...((typeof ownedSkins === "function") ? ownedSkins(p, h.type) : [])])];
    const can = list.length >= 1; // обычный + ≥1 скин
    let row = el.querySelector(".rnd-skin-row");
    if (!can) { if (row) row.remove(); return; }
    if (!row) {
      row = document.createElement("div");
      row.className = "row rnd-skin-row";
      row.style.cssText = "margin:4px 0;font-size:13px";
      row.onclick = e => e.stopPropagation();
      const body = el.querySelector(".body");
      const skinrow = el.querySelector(".skinrow");
      if (skinrow) skinrow.after(row); else if (body) body.appendChild(row);
    }
    row.innerHTML = `<label style="cursor:pointer"><input type="checkbox" ${h.random_skin ? "checked" : ""}
      onchange="toggleRandomSkin(${h.id}, this.checked)"> 🎲 Случайный скин</label>`;
  });
}

const _loadHeroes52 = typeof loadHeroes === "function" ? loadHeroes : null;
if (_loadHeroes52) {
  loadHeroes = async function () {
    await _loadHeroes52();
    decorateRandomSkinToggles();
  };
}

// ---------- Item 5 + 6: новая игра / смена персонажа ----------
function renderStoryCompleteUI(data) {
  ensureStoryHeroActions();
  const btn = document.getElementById("storyNewGameBtn");
  const abandon = document.getElementById("storyAbandonBtn");
  const bagBtn = document.getElementById("storyBagBtn");
  const skinBtn = document.getElementById("storySkinsBtn");
  const hid = _storyHeroId();
  const has = !!hid;
  if (bagBtn) bagBtn.style.display = has ? "" : "none";
  if (skinBtn) skinBtn.style.display = has ? "" : "none";
  if (abandon) abandon.style.display = has ? "" : "none";
  if (btn) {
    if (data && data.story_complete && has) {
      btn.style.display = "";
      // сообщение о прохождении
      let msg = document.getElementById("storyCompleteMsg");
      if (!msg) {
        msg = document.createElement("div");
        msg.id = "storyCompleteMsg";
        msg.style.cssText = "margin:8px 0;padding:10px;border-radius:10px;background:#1a3a22;border:1px solid #4cd07d;color:#cfe";
        btn.parentElement.insertBefore(msg, btn);
      }
      msg.innerHTML = `<b>✦ Сюжет пройден!</b> Можно начать <b>🔄 Новую игру</b> — текущий герой уйдёт в «Пройденные герои».`;
    } else {
      btn.style.display = "none";
      const msg = document.getElementById("storyCompleteMsg");
      if (msg) msg.remove();
    }
  }
  const arch = document.getElementById("storyArchiveBox");
  if (arch) {
    const list = (data && data.story_archive) || (currentPlayer() && currentPlayer().story_archive) || [];
    if (list.length) {
      arch.innerHTML = `<div style="margin-top:6px"><b>📜 Пройденные герои</b> <span class="muted">(только просмотр)</span></div>` +
        list.map(e => `<div class="muted">• ${esc(e.name)} — ${esc(e.hero_class)}, ур. ${e.level}${e.archived_at ? ` · ${esc(e.archived_at)}` : ""}</div>`).join("");
    } else arch.innerHTML = "";
  }
}

function confirmNewStoryGame() {
  const hid = _storyHeroId();
  const h = (allHeroes || []).find(x => x.id == hid) || (storyData && storyData.hero);
  const name = h ? h.name : "герой";
  _modal2(`<h3 style="color:var(--gold);margin-top:0">🔄 Новая игра</h3>
    <p>Будет создан <b>новый сюжетный герой</b>, сюжет начнётся со вступления.</p>
    <p>«${esc(name)}» сохранится в списке <b>Пройденные герои</b> (имя, класс, уровень).</p>
    <p class="muted">Золото аккаунта и купленные облики останутся. Секреты и лут снова доступны в новом прохождении.</p>
    <div class="row" style="margin-top:12px;gap:8px;justify-content:center">
      <button class="btn" onclick="doNewStoryGame()">Начать новую игру</button>
      <button class="btn ghost" onclick="_closeModal2()">Отмена</button>
    </div>`);
}

async function doNewStoryGame() {
  const p = currentPlayer(); if (!p) return;
  const hid = _storyHeroId();
  const r = await api(`/api/players/${p.id}/story/new_game`, "POST", {hero_id: hid});
  if (!r) return;
  toast(r.message || "Новая игра", "ok");
  _closeModal2();
  await loadPlayers(); await loadHeroes(); await loadStory();
}

function confirmAbandonStory() {
  const hid = _storyHeroId();
  const h = (allHeroes || []).find(x => x.id == hid) || (storyData && storyData.hero);
  if (!h) return toast("Нет сюжетного героя");
  _modal2(`<h3 style="color:#f66;margin-top:0">⚠ Сменить персонажа</h3>
    <p style="color:#fcc"><b>Весь прогресс сюжета этого героя будет утерян. Продолжить?</b></p>
    <p>Герой <b>${esc(h.name)}</b> будет удалён <u>без</u> архива (в отличие от «Новой игры»).</p>
    <p>Введите имя героя для подтверждения:</p>
    <input id="abandonConfirmName" placeholder="${esc(h.name)}" style="width:100%;font-size:16px;padding:8px">
    <div class="row" style="margin-top:12px;gap:8px;justify-content:center">
      <button class="btn red" onclick="doAbandonStory('${esc(h.name)}')">Удалить и начать заново</button>
      <button class="btn ghost" onclick="_closeModal2()">Отмена</button>
    </div>`);
}

async function doAbandonStory(expected) {
  const p = currentPlayer(); if (!p) return;
  const input = document.getElementById("abandonConfirmName");
  const typed = (input && input.value || "").trim();
  if (typed !== expected) return toast("Имя введено неверно", "err");
  const hid = _storyHeroId();
  const r = await api(`/api/players/${p.id}/story/abandon`, "POST", {hero_id: hid, confirm_name: typed});
  if (!r) return;
  toast(r.message || "Герой удалён", "ok");
  _closeModal2();
  await loadPlayers(); await loadHeroes(); await loadStory();
}

// ---------- wrap loadStory ----------
const _loadStory52 = loadStory;
loadStory = async function () {
  ensureStoryHeroActions();
  await _loadStory52();
  renderStoryCompleteUI(storyData);
};

// bag_full notice after battle
const _showReward52 = typeof showStoryReward === "function" ? showStoryReward : null;
// also hook end-of-battle notices if present
document.addEventListener("DOMContentLoaded", () => ensureStoryHeroActions());
ensureStoryHeroActions();


// ---------- Item 7: секретная арена (только dev_mode) ----------
let _testRoster = null;
function ensureTestArenaUI() {
  const p = currentPlayer();
  let panel = document.getElementById("testArenaPanel");
  if (!p || !p.dev_mode) {
    if (panel) panel.style.display = "none";
    return;
  }
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "testArenaPanel";
    panel.className = "panel";
    panel.innerHTML = `<h2>🧪 Секретная арена <span class="muted">(dev)</span></h2>
      <p class="muted">Все классы, NPC и сюжетные мобы. Без наград и влияния на сюжет.</p>
      <div class="row" style="flex-wrap:wrap;gap:8px;align-items:center">
        <label>A <select id="taA" style="max-width:280px"></select></label>
        <span>vs</span>
        <label>B <select id="taB" style="max-width:280px"></select></label>
        <button class="btn" onclick="startTestArena()">⚔ Бой</button>
        <button class="btn ghost" onclick="loadTestRoster(true)">↻ Список</button>
      </div>
      <div id="taPreview" class="row" style="margin-top:8px;gap:12px"></div>`;
    // вставить в арену или в конец main
    const arena = document.getElementById("arena") || document.querySelector("main");
    if (arena) arena.appendChild(panel);
  }
  panel.style.display = "";
  loadTestRoster(false);
}
async function loadTestRoster(force) {
  const p = currentPlayer(); if (!p || !p.dev_mode) return;
  if (_testRoster && !force) { fillTestSelects(); return; }
  const data = await api(`/api/test_arena/roster?player_id=${p.id}`);
  if (!data) return;
  _testRoster = data.fighters || [];
  fillTestSelects();
}
function fillTestSelects() {
  const opts = (_testRoster || []).map(f =>
    `<option value="${f.key}">${esc(f.label)}</option>`).join("");
  const a = document.getElementById("taA"), b = document.getElementById("taB");
  if (!a) return;
  const va = a.value, vb = b.value;
  a.innerHTML = opts; b.innerHTML = opts;
  if (va) a.value = va; if (vb) b.value = vb;
  if (!a.value && _testRoster[0]) a.value = _testRoster[0].key;
  if (!b.value && _testRoster[1]) b.value = _testRoster[1].key;
  a.onchange = previewTestArena; b.onchange = previewTestArena;
  previewTestArena();
}
function previewTestArena() {
  const box = document.getElementById("taPreview"); if (!box || !_testRoster) return;
  const fa = _testRoster.find(x => x.key === document.getElementById("taA").value);
  const fb = _testRoster.find(x => x.key === document.getElementById("taB").value);
  box.innerHTML = [fa, fb].filter(Boolean).map(f =>
    `<div style="text-align:center"><img src="${f.image}" style="width:72px;height:72px;object-fit:cover;border-radius:8px"
      onerror="this.src='/images/warrior'"><div class="muted">${esc(f.name)}</div></div>`).join('<div style="font-size:28px">⚔</div>');
}
async function startTestArena() {
  const p = currentPlayer(); if (!p) return;
  const body = {
    player_id: p.id,
    fighter1: document.getElementById("taA").value,
    fighter2: document.getElementById("taB").value,
    mode: "manual",
  };
  const b = await api("/api/test_arena/battle", "POST", body);
  if (!b) return;
  toast("🧪 Тестовый бой начат", "ok");
  if (typeof showBattle === "function") showBattle(b);
  else if (typeof openBattle === "function") openBattle(b);
  else { battle = b; if (typeof renderBattle === "function") renderBattle(b); }
}

// показывать панель при загрузке игроков / dev
const _loadPlayers52 = typeof loadPlayers === "function" ? loadPlayers : null;
if (_loadPlayers52) {
  loadPlayers = async function () {
    await _loadPlayers52();
    ensureTestArenaUI();
  };
}
