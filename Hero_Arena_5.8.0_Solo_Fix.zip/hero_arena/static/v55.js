/* Six heroes: physical inputs, targetable undead and source-specific combat states. */
(function(){
 'use strict';
 const style=document.createElement('style');style.textContent=`
 .ritual55{max-width:440px;margin:auto;user-select:none}.ritual55 svg{display:block;width:100%;border:1px solid #77618e;border-radius:14px;background:radial-gradient(ellipse,#33304b,#121420 85%);touch-action:none}
 .ritual55 .help{font-size:13px;color:#c8c0d8;line-height:1.5;margin:10px 0}.ritual55 .status{min-height:30px;margin:8px;text-align:center;color:#ebd48d;font-weight:bold}.ritual55 .actions{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:10px 0}.ritual55 input[type=range]{width:95%;accent-color:#d66170}.ritual55 button{touch-action:manipulation}
 .target55{margin:5px 2px;padding:7px 10px;background:#252235;border:1px solid #6c5c83;border-radius:7px;color:#ddd;cursor:pointer}.target55.selected{border:2px solid #f5b942;color:#ffe2a1}.minion55{border:1px solid #65775c;border-radius:8px;padding:9px;margin:7px 0}.minion55.dead{opacity:.45}.states55{display:flex;justify-content:center;gap:5px;flex-wrap:wrap;margin:7px 0}.states55 span{border:1px solid #786791;border-radius:6px;padding:3px 7px;background:#262036}
 `;document.head.appendChild(style);
 const oldSummon=summon;
 summon=function(h){
   if(!h.summons)return oldSummon(h);
   return h.summons.map(s=>`<div class="summon minion55 ${s.alive?'':'dead'}" data-minion="${esc(s.id)}">${s.image?`<img src="${s.image}" alt="${esc(s.name)}" style="width:54px;height:54px;object-fit:cover;float:left;margin-right:8px;border-radius:7px">`:''}${s.icon} <b>${esc(s.name)}</b> · урон ${s.damage}
    <div class="bar hpbar"><div style="width:${pct(s.hp,s.max_hp)}%"></div><span>❤ ${s.hp}/${s.max_hp}</span></div>
    <span class="muted">${esc(s.about)} · ${s.lifetime} раундов</span></div>`).join('')+`<div class="muted">Призывы: ${h.summons.filter(s=>s.alive).length}/2</div>`;
 };
 window.target55={};let targetBattle=null;
 const oldFighters=renderFighters;
 renderFighters=function(b,snap,hideFx){
   if(targetBattle!==b.id){window.target55={};targetBattle=b.id}
   const adjusted=snap?{...b,heroes:b.heroes.map(h=>({...h,summons:h.summons?.map(s=>snap[s.id]===undefined?s:{...s,hp:snap[s.id]??0,alive:(snap[s.id]??0)>0}).filter(s=>snap[s.id]!==null)}))}:b;
   oldFighters(adjusted,snap,hideFx);
   b.heroes.forEach((h,i)=>{
    const card=document.getElementById('f'+i);if(!card)return;
    const states=[];
    if(h.focus!==undefined)states.push(`👁 Фокус ${h.focus}/4`);
    if(h.combo!==undefined)states.push(`⚔ Комбо ${h.combo}/2`);
    if(h.pending_bombs?.length)states.push(...h.pending_bombs.map(b=>`💣 ${b.target_name}: ${b.power} урона ${b.turns_left?'после следующего хода':'в конце этого хода'}`));
    if(h.confidence!==undefined)states.push(`👑 Уверенность ${h.confidence>0?'+':''}${h.confidence}`);
    if(states.length)card.insertAdjacentHTML('beforeend',`<div class="states55">${states.map(s=>`<span>${s}</span>`).join('')}</div>`);
    for(const s of h.summons||[]){if(snap&&snap[s.id]!==undefined)shownHp[s.id]=snap[s.id];else shownHp[s.id]=s.hp}
    const actor=b.heroes.find(x=>x.id===b.current_hero_id);
    if(!actor||b.pending||b.status!=='active'||b.ai_ids.includes(actor.id))return;
    if(actor.id!==h.id&&window.target55[actor.id]&&window.target55[actor.id]!=='hero'&&!(h.summons||[]).some(s=>s.alive&&s.id===window.target55[actor.id]))window.target55[actor.id]='hero';
    if(actor.id!==h.id&&h.summons?.some(s=>s.alive)){
     const chosen=window.target55[actor.id]||'hero';
     if(chosen!=='hero'&&!h.summons.some(s=>s.alive&&s.id===chosen))window.target55[actor.id]='hero';
     const choose=(label,id,host)=>{
      const button=document.createElement('button');button.className='target55'+((window.target55[actor.id]||'hero')===id?' selected':'');button.textContent=label;
      button.onclick=()=>{if(busy||battle.pending)return;window.target55[actor.id]=id;renderFighters(battle)};host.appendChild(button);
     };
     choose('🎯 Цель: '+h.name,'hero',card);
     for(const s of h.summons.filter(s=>s.alive)){const host=card.querySelector(`[data-minion="${s.id}"]`);if(host)choose('🎯 Атаковать '+s.name,s.id,host)}
    }
    if(actor.id===h.id)for(const s of h.summons||[]){
     if(!s.alive)continue;const host=card.querySelector(`[data-minion="${s.id}"]`);if(!host)continue;
     const btn=document.createElement('button');btn.className='target55';btn.textContent='Рассеять · тратит ход';btn.onclick=()=>turn('dismiss:'+s.slot);host.appendChild(btn);
    }
   });
 };
 const oldHp=applyHp;
 applyHp=function(snap,animated){
   let changed=oldHp(snap,animated);if(!snap||!battle)return changed;
   battle.heroes.forEach((h,i)=>{for(const s of h.summons||[]){
    const value=snap[s.id],old=shownHp[s.id],host=document.getElementById('f'+i)?.querySelector(`[data-minion="${s.id}"]`);
    if(value===undefined||value===null||value===old||!host)continue;
    const bar=host.querySelector('.hpbar');shownHp[s.id]=value;changed=true;
    if(bar){bar.firstElementChild.style.width=pct(value,s.max_hp)+'%';bar.querySelector('span').textContent=`❤ ${value}/${s.max_hp}`}
    host.classList.toggle('dead',value<=0);if(animated&&old!==undefined)floatNum(host,value-old,true);
   }});return changed;
 };
 const circle=(x,y,r,fill,stroke='#d3bfef')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
 const line=(x1,y1,x2,y2,color='#dfc482',width=3)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${width}" stroke-linecap="round"/>`;
 const text=(x,y,s,size=16,color='#f5dc9b')=>`<text x="${x}" y="${y}" text-anchor="middle" fill="${color}" font-size="${size}" font-family="Georgia,serif">${esc(s)}</text>`;
 function interpolate(path,t,step=false){if(!path?.length)return[-999,-999];if(t<=path[0][0])return path[0].slice(1);for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i];if(t<b[0]){const f=step?0:(t-a[0])/(b[0]-a[0]);return[a[1]+f*(b[1]-a[1]),a[2]+f*(b[2]-a[2])]}}return path[path.length-1].slice(1)}
 function setup(o,head,help,actions=''){
   if(mg&&!mg.done){mg.done=true;mg.timers.forEach(t=>{clearTimeout(t);clearInterval(t)});if(mg.raf)cancelAnimationFrame(mg.raf)}
   openBox(head+`<div class="ritual55"><svg id="rStage" viewBox="0 0 360 260" tabindex="0" aria-label="Поле мини-игры"></svg><div id="rStatus" class="status" aria-live="polite"></div>${o.time_limit_ms?timerBar:''}<div class="help">${help}</div><div class="actions">${actions}<button class="btn ghost" id="rFinish">Завершить</button></div></div>`);
   const state={taps:[],points:[],placements:[],nodes:o.nodes?.map(p=>p.slice()),elapsed_ms:0};
   const answer=()=>({...state,elapsed_ms:elapsed()});
   mgStart(o,answer);const session=mg;
   function elapsed(){return o.time_limit_ms?Math.max(0,Math.min(o.time_limit_ms,Math.floor(performance.now()-session.t0))):0}
   const svg=document.getElementById('rStage');
   if(o.hero_type)svg.style.backgroundImage=`linear-gradient(#171525df,#141723f2),url(/static/images/${o.hero_type}.jpg)`;svg.style.backgroundSize='cover';svg.style.backgroundPosition='center';
   const pos=e=>{const box=svg.getBoundingClientRect();return{x:Math.max(0,Math.min(360,(e.clientX-box.left)*360/box.width)),y:Math.max(0,Math.min(260,(e.clientY-box.top)*260/box.height))}};
   const status=s=>{const el=document.getElementById('rStatus');if(el)el.textContent=s};
   const finish=()=>{if(mg===session&&!session.done)mgFinish(answer())};
   document.getElementById('rFinish').onclick=finish;
   let cursor={x:180,y:130},lastSample=-50;
   svg.onpointermove=e=>{cursor=pos(e);if(state.drag!==undefined)state.nodes[state.drag]=[Math.max(20,Math.min(340,cursor.x)),Math.max(20,Math.min(240,cursor.y))]};
   function sample(t){if(t-lastSample<40)return;lastSample=t;state.points.push({t,x:cursor.x,y:cursor.y})}
   function animate(draw){function frame(){if(mg!==session||session.done||!document.getElementById('rStage'))return;const t=elapsed();sample(t);draw(t);session.raf=requestAnimationFrame(frame)}frame()}
   return{o,state,svg,pos,status,finish,elapsed,session,animate,answer,setCursor:p=>{cursor=p},get cursor(){return cursor}};
 }
 window.arenaMiniUI={setup,circle,line,text,interpolate};
 const register=(names,handler)=>names.forEach(name=>MINIGAMES[name]=(o,h)=>handler(o,h));

 register(['dread_flinch','watchful_nogo'],(o,h)=>{
   const r=setup(o,h,'Истинная вспышка — зелёный открытый глаз. Нажимайте на неё. Фиолетовые обманки пропускайте.');
   r.svg.onpointerdown=e=>{e.preventDefault();r.state.taps.push(r.elapsed());if(o.game==='dread_flinch')r.finish()};
   r.animate(t=>{const f=o.flashes.find(f=>t>=f.ms&&t<f.ms+o.window);r.svg.innerHTML=circle(180,120,75,'#1b1a2b',f?.true?'#7be5a0':'#817099')+`<path d="M90 120 Q180 ${f?35:95} 270 120 Q180 ${f?205:145} 90 120" fill="${f?.true?'#365a48':'#35233f'}" stroke="${f?.true?'#8af0b3':'#9d7bbc'}" stroke-width="5"/>`+(f?.true?circle(180,120,26,'#a3e8b4','#fff0ba'):f?text(180,130,'◆',40,'#bc81dd'):'')+text(180,235,f?(f.true?'ИСТИННАЯ ВСПЫШКА':'Обманка'):'Наблюдайте…',18);r.status('Нажатий: '+r.state.taps.length)});
 });
 register(['blood_split'],(o,h)=>{
   const r=setup(o,h,'Распределите силу. Атака усиливает удар, исцеление восстанавливает HP. При доле атаки выше 65% промах вызывает кровавый откат.','<label>Атака ↔ Исцеление<input id="bloodAllocation" type="range" min="0" max="100" value="50"></label>');
   r.state.attack_percent=50;const input=document.getElementById('bloodAllocation');
   function draw(){const p=r.state.attack_percent;r.svg.innerHTML=circle(100,130,52,'#7d2838')+circle(260,130,52,'#285e4b')+line(152,130,208,130)+text(100,125,p+'%',30)+text(100,155,'Атака',16)+text(260,125,(100-p)+'%',30)+text(260,155,'Лечение',16);r.status(p>65?'Риск отката при промахе':'Без атакующего отката')}
   input.oninput=()=>{r.state.attack_percent=+input.value;draw()};draw();
 });
 register(['blood_tide','weakpoint_bar','slit_gaze','execution_charge'],(o,h)=>{
   const charge=o.game==='execution_charge';const r=setup(o,h,charge?'Удерживайте кнопку, поднимая топор. Отпустите в золотой зоне. Ошибка может ранить палача и лишить следующего хода.':'Остановите метку в золотой зоне. Зелёные края дают хороший результат.',charge?'<button class="btn" id="rCharge">Поднять топор</button>':'<button class="btn" id="rStop">Остановить</button>');
   let down=null,held=0;
   if(charge){const btn=document.getElementById('rCharge');btn.onpointerdown=e=>{if(down!==null)return;e.preventDefault();down=r.elapsed();btn.setPointerCapture(e.pointerId)};const release=()=>{if(down===null)return;held=r.elapsed()-down;r.state.stop_ms=held;r.state.held_ms=held;r.finish()};btn.onpointerup=release;btn.onpointercancel=release}
   else document.getElementById('rStop').onclick=()=>{r.state.stop_ms=r.elapsed();r.finish()};
   r.animate(t=>{const at=charge?(down===null?0:t-down):t;const value=charge&&down===null?0:Math.abs(Math.sin(2*Math.PI*(at+o.phase)/o.period));
    r.svg.innerHTML=text(180,48,charge?'ЗАМАХ':o.game==='blood_tide'?'КРОВАВЫЙ ПРИЛИВ':o.game==='weakpoint_bar'?'СЛАБОЕ МЕСТО':'ХОЛОДНЫЙ ВЗГЛЯД',18)+`<rect x="20" y="110" width="320" height="40" rx="8" fill="#121321" stroke="#74667c"/><rect x="${20+320*(.8-o.width-.12)}" y="111" width="${320*(o.width*2+.24)}" height="38" fill="#467653"/><rect x="${20+320*(.8-o.width)}" y="111" width="${320*o.width*2}" height="38" fill="#cfa64b"/>`+line(20+320*value,95,20+320*value,165,'#fff2d8',4)+text(180,212,charge?'Тяжесть требует точности':o.stacks?`Подготовлено меток: ${o.stacks}`:o.missing?`Потеряно HP: ${Math.round(o.missing*100)}%`:'Выберите момент',16);r.status(charge?(down===null?'Топор опущен':'Держите… затем отпустите'):'Золотая зона — идеал')});
   const finish=document.getElementById('rFinish');finish.onclick=()=>{r.state.stop_ms=charge?(down===null?0:r.elapsed()-down):r.elapsed();r.finish()};
 });
 register(['prey_track','fang_drift','sentence_hold'],(o,h)=>{
   const r=setup(o,h,o.game==='prey_track'?'Следуйте прицелом за едва заметным пульсом. Он перемещается рывками. Важна доля удержания после короткого окна перевода прицела.':'Удерживайте курсор в медленно дрейфующем окне. Потеря контакта снижает результат.');
   r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId)};
   let inside=0,total=0,last=-50;
   r.animate(t=>{const[x,y]=interpolate(o.path,t,o.stepped);const c=r.cursor;const close=Math.hypot(c.x-x,c.y-y)<=o.radius;if(t-last>=40){last=t;const at=o.stepped?Math.max(...o.path.filter(p=>p[0]<=t).map(p=>p[0])):0;const grace=o.stepped&&t-at<(o.reaction_grace_ms||0);if(!grace){total++;if(close)inside++}}
    r.svg.innerHTML=`<path d="M180 30 Q135 40 150 90 L125 165 L150 170 L150 240 L170 240 L180 185 L190 240 L210 240 L210 170 L235 165 L210 90 Q225 40 180 30" fill="#48405166" stroke="#78708655"/>`+circle(x,y,o.radius,close?'#6c433f66':'#4b354366','#d8a07f')+circle(x,y,4,'#f4b6ac','#fce5c0')+line(c.x-12,c.y,c.x+12,c.y,'#d3e8d9',2)+line(c.x,c.y-12,c.x,c.y+12,'#d3e8d9',2);r.status(`Удержание: ${Math.round(inside/Math.max(1,total)*100)}%`)});
 });
 register(['scale_pressure'],(o,h)=>{
   const r=setup(o,h,'Быстрые нажатия загоняют копьё глубже. Случайные контртолчки сбивают нажим. Свои метки ослабляют сопротивление.','<button class="btn" id="rTap">Нажим копьём</button>');
   document.getElementById('rTap').onclick=()=>r.state.taps.push(r.elapsed());
   r.animate(t=>{let value=0,best=0,last=0;const events=[...r.state.taps.map(t=>[t,10]),...o.kicks.filter(k=>k[0]<=t).map(([t,p])=>[t,-p])].sort((a,b)=>a[0]-b[0]);for(const[at,d]of events){value=Math.max(0,value-(at-last)*.009)+d;value=Math.max(0,Math.min(100,value));best=Math.max(best,value);last=at}
    r.svg.innerHTML=text(180,40,'ПРОЛОМ ЧЕШУИ',18)+`<path d="M40 80 L100 55 L160 80 L220 55 L300 85 L315 175 L240 200 L160 180 L80 200 L35 160Z" fill="#504d3e" stroke="#8f8365" stroke-width="4"/>`+line(25,130,65+value*2.2,130,'#d7d0a6',10)+text(180,235,`Метки: ${o.stacks} · максимум ${Math.round(best)}%`,17);r.status(`Нажим ${Math.round(value)}%`)});
 });
 register(['horn_streak'],(o,h)=>{
   const r=setup(o,h,'Попадайте в такт вспышкам. С каждым звеном окно уже; ошибка прерывает серию.','<button class="btn" id="rTap">Удар рогом</button>');
   document.getElementById('rTap').onclick=()=>r.state.taps.push(r.elapsed());
   r.animate(t=>{let streak=0,best=0;const used=new Set();for(let i=0;i<o.beats.length;i++){if(t<o.beats[i]+o.windows[i])break;const hit=r.state.taps.findIndex((v,j)=>!used.has(j)&&Math.abs(v-o.beats[i])<=o.windows[i]);if(hit>=0){used.add(hit);best=Math.max(best,++streak)}else streak=0}
    const next=o.beats.find(b=>b>=t)||o.beats[o.beats.length-1],distance=Math.abs(next-t);r.svg.innerHTML=circle(180,125,Math.max(28,Math.min(100,28+distance*.15)),'#181927','#d7ac57')+circle(180,125,35,'#61533c',distance<100?'#fff1b4':'#8c7a58')+text(180,138,'▲',40)+text(180,235,`Лучшая серия ${best}`,20);r.status('Серия: '+streak)});
 });
 register(['stone_balance'],(o,h)=>{
   const r=setup(o,h,'Удерживайте каменное ядро в центре. Двигайте указатель в сторону, противоположную дрейфу; по центру управление нейтрально.');
   r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId)};let position=0,velocity=0,step=0,inside=0,total=0;
   r.animate(t=>{while(step+25<=t){for(const[at,k]of o.kicks)if(step<=at&&at<step+25)velocity+=k;const control=Math.max(-1,Math.min(1,(interpolate(r.state.points.map(p=>[p.t,p.x,p.y]),step)[0]-180)/160));velocity=(velocity+control*.045)*.96;position=Math.max(-1.4,Math.min(1.4,position+velocity*.12));total++;if(Math.abs(position)<.25)inside++;step+=25}
    r.svg.innerHTML=text(180,40,'КАМЕННОЕ РАВНОВЕСИЕ',17)+line(25,135,335,135,'#777577',12)+`<rect x="152" y="115" width="56" height="40" rx="6" fill="#68a48a55"/>`+circle(180+position*100,130,18,'#8d8b82','#ddd3b6')+line(180,180,r.cursor.x,180,'#b6c7e5',3)+text(180,230,'← удерживайте в центре →',16);r.status(`Равновесие: ${Math.round(inside/Math.max(1,total)*100)}%`)});
 });
 register(['blade_orbits'],(o,h)=>{
   const r=setup(o,h,'Два меча движутся по независимым орбитам. Нажмите, когда они окажутся на одном луче. Комбо 2 усиливает двойной удар.','<button class="btn" id="rStop">Свести клинки</button>');
   document.getElementById('rStop').onclick=()=>{r.state.stop_ms=r.elapsed();r.finish()};document.getElementById('rFinish').onclick=document.getElementById('rStop').onclick;
   r.animate(t=>{const a=o.periods.map((p,i)=>2*Math.PI*(t+o.phases[i])/p);r.svg.innerHTML=circle(180,130,85,'none','#9f7b53')+circle(180,130,58,'none','#7385a2')+a.map((v,i)=>{const d=i?58:85;return line(180+Math.cos(v)*(d-18),130+Math.sin(v)*(d-18),180+Math.cos(v)*(d+18),130+Math.sin(v)*(d+18),i?'#e7d3a3':'#b7d9ef',7)}).join('')+text(180,137,'♛',29)+text(180,245,'Синхронизация двух мечей',16);r.status('Дождитесь совпадения направлений')});
 });
 register(['king_risk'],(o,h)=>{
   const r=setup(o,h,'Удерживайте рык, набирая силу, и отпустите до срыва голоса. Риск растёт со временем. Состоявшееся действие сохраняет окно Комбо.','<button class="btn" id="rHold">Начать рык</button>');let down=null;
   const btn=document.getElementById('rHold');btn.onpointerdown=e=>{if(down!==null)return;e.preventDefault();down=r.elapsed();btn.setPointerCapture(e.pointerId)};const release=()=>{if(down===null)return;r.state.held_ms=r.elapsed()-down;r.finish()};btn.onpointerup=release;btn.onpointercancel=release;
   r.animate(t=>{const held=down===null?0:t-down;r.state.held_ms=held;const strength=Math.min(1,held/4500);r.svg.innerHTML=circle(180,125,45+strength*55,'#5d3f2555',held>2500?'#dc775a':'#dfb75a')+circle(180,125,42,'#282233','#e3bd74')+text(180,138,'♛',40)+text(180,230,held>3000?'Голос на пределе…':'Сила нарастает',17);r.status(`Рык: ${(held/1000).toFixed(1)} с · риск ${Math.round(strength*100)}%`)});
 });
 register(['predator_afterimage'],(o,h)=>{
   const r=setup(o,h,'Запомните положение мелькнувшей добычи. После исчезновения нажмите по её послеобразу.');
   r.svg.onpointerdown=e=>{if(r.elapsed()<o.show_ms)return;e.preventDefault();const p=r.pos(e);r.state.x=p.x;r.state.y=p.y;r.finish()};
   r.animate(t=>{const[x,y]=o.target;r.svg.innerHTML=`<path d="M20 230 Q60 150 90 220 Q150 145 180 230 Q260 170 340 220" fill="none" stroke="#534b3d" stroke-width="12"/>`+(t<o.show_ms?circle(x,y,22,'#b79754aa','#e4d3a7')+text(x,y+6,'🐾',21):'')+text(180,35,t<o.show_ms?'Высмотрите добычу':'Где остался след?',19);r.status(t<o.show_ms?'Наблюдайте':'Нажмите по запомненному месту')});
 });
 register(['royal_read'],(o,h)=>{
   const labels=['Левый бок','Корпус','Правый бок'];
   const r=setup(o,h,'Две зоны закрыты клинками — нажмите на третью, открытую. Четыре стойки, по одной попытке на каждую. 4 верных ответа: крит с бонусом добивания; 3: крит следующего удара.',labels.map((s,i)=>`<button class="btn readLane55" data-lane="${i}">${s}</button>`).join(''));
   r.state.attacks=[];let feedback=null;
   function strike(lane){const ms=r.elapsed(),phase=o.stances.findIndex(p=>ms>=p.start&&ms<p.end);if(phase<0||r.state.attacks.some(a=>a.phase===phase))return;
    const correct=lane===o.stances[phase].open;r.state.attacks.push({lane,ms,phase});feedback={phase,correct};
    if(phase===3)r.finish();
   }
   document.querySelectorAll('.readLane55').forEach(b=>b.onclick=()=>strike(+b.dataset.lane));
   r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e);const lane=[80,180,280].findIndex(x=>Math.hypot(p.x-x,p.y-135)<40);if(lane>=0)strike(lane)};
   r.animate(t=>{const phase=o.stances.findIndex(p=>t>=p.start&&t<p.end),p=o.stances[Math.max(0,phase)],used=phase<0||r.state.attacks.some(a=>a.phase===phase);
    document.querySelectorAll('.readLane55').forEach(b=>b.disabled=used);
    const correct=r.state.attacks.filter(a=>a.lane===o.stances[a.phase].open).length;
    let out=text(180,28,phase<0?`ПРИГОТОВЬТЕСЬ ${Math.ceil((o.prepare_ms-t)/1000)}`:`СТОЙКА ${phase+1} / 4`,19)+`<path d="M180 52 C154 52 151 84 165 95 L143 122 L128 203 L232 203 L217 122 L195 95 C209 84 206 52 180 52Z" fill="#595369" stroke="#b0a4b8" stroke-width="2"/>`;
    for(let i=0;i<3;i++){const x=80+i*100,open=i===p.open;out+=circle(x,135,31,open?'#613c3955':'#30394b',open?'#f3c979':'#aab4ca')+(open?text(x,143,'◎',31,'#ffe0a0'):line(x-19,116,x+19,154,'#d1d7e5',6)+line(x-19,154,x+19,116,'#9ba8c5',5))+text(x,190,open?'ОТКРЫТО':'ЗАЩИТА',12,open?'#f2cf8e':'#b2b8ca')}
    out+=`<rect x="40" y="220" width="280" height="7" rx="3" fill="#333044"/><rect x="40" y="220" width="${280*Math.max(0,(p.end-t)/(p.end-p.start))}" height="7" rx="3" fill="#d7b46c"/>`;
    r.svg.innerHTML=out;r.status(phase<0?'После отсчёта нажимайте на открытую зону':feedback?.phase===phase?(feedback.correct?'Верно — дождитесь следующей стойки':'Удар в защиту — следующая стойка даст новый шанс'):`Найдите открытую зону · верно ${correct}/4`);
   });
 });
 register(['flesh_suture'],(o,h)=>{
   const r=setup(o,h,'Зажмите «Стянуть шов». Отпустите, когда игла войдёт в ЗЕЛЁНУЮ зону. Повторите до четырёх раз. Удачный шов лечит каждое живое существо на 4 HP.','<button class="btn" id="rSuture">Зажми: стянуть шов</button>');
   r.state.stitches=[];let down=null,feedback='Зажмите кнопку, чтобы начать';
   const button=document.getElementById('rSuture');
   function release(){if(down===null)return;const up=r.elapsed(),held=(up-down)/o.suture_period,good=held>=o.green[0]&&held<=o.green[1];r.state.stitches.push({down_ms:down,up_ms:up});down=null;feedback=good?'Шов закреплён! Зажмите кнопку для следующего.':'Не попали в зелёную зону. Попробуйте следующий шов.';button.textContent='Зажми: следующий шов';if(r.state.stitches.length===4)r.finish()}
   button.onpointerdown=e=>{if(down!==null||r.state.stitches.length>=4)return;e.preventDefault();button.setPointerCapture(e.pointerId);down=r.elapsed();button.textContent='Отпусти в зелёной зоне'};
   button.onpointerup=release;button.onpointercancel=release;
   r.animate(t=>{const held=down===null?0:(t-down)/o.suture_period;if(held>=1&&down!==null)release();
    const successes=r.state.stitches.filter(a=>{const v=(a.up_ms-a.down_ms)/o.suture_period;return v>=o.green[0]&&v<=o.green[1]}).length;
    const wound=52-successes*10;
    let out=`<path d="M45 55 Q180 20 315 55 L315 155 Q180 183 45 155Z" fill="#59684a" stroke="#99a97c" stroke-width="3"/><path d="M180 55 L${180-wound} 80 L${180+wound} 105 L${180-wound} 130 L180 155" fill="none" stroke="#30212e" stroke-width="${Math.max(5,18-successes*3)}"/>`;
    for(let i=0;i<4;i++){const y=68+i*24;out+=line(140,y,220,y,i<successes?'#b0e4a4':'#59634d',i<successes?3:1)}
    out+=`<rect x="30" y="200" width="300" height="22" rx="7" fill="#443447"/><rect x="${30+300*o.green[0]}" y="200" width="${300*(o.green[1]-o.green[0])}" height="22" fill="#70c78b"/>`+line(30+Math.min(1,held)*300,193,30+Math.min(1,held)*300,229,'#fff0c6',4)+text(218,188,'ОТПУСТИ ЗДЕСЬ',12,'#a5e3b1')+text(180,250,`Удачных швов ${successes}/4 · лечение +${successes*4} HP`,15);
    r.svg.innerHTML=out;r.status(down===null?feedback:held<o.green[0]?'Тяните…':held<=o.green[1]?'Зелёная зона — ОТПУСКАЙТЕ!':'Слишком туго!');
   });
 });
 register(['raise_bones','raise_zombie','build_homunculus'],(o,h)=>{
   const bone=o.game==='raise_bones',stitch=o.game==='flesh_stitch',homunculus=o.game==='build_homunculus';
   const r=setup(o,h,bone?'Соберите три ступени по порядку: костяк → посмертное ядро → магическая печать. Можно завершить после любой готовой ступени.':stitch?'Соединяйте парные края разрывов. Каждый завершённый шов восстанавливает здоровье живой нежити.':homunculus?'Переносите части в сочленения и отпускайте, когда кольцо замка зелёное. Можно выбрать часть, а затем нажать на открытый замок.':'Переносите фрагменты души в отмеченные места. Можно перетащить или выбрать фрагмент и затем его место.');
   let selected=null,drag=null,warningUntil=0;let paint=null;const n=o.parts;
   const slotPos=slot=>stitch?[70+slot*72,105]:n<=5?[[180,45],[110,110],[250,110],[140,172],[220,172]][slot]:[80+(slot%3)*100,40+Math.floor(slot/3)*52];
   const sourcePos=(part,t)=>stitch?[70+part*72,175]:[40+(part%5)*70+(o.game==='raise_zombie'?Math.sin(t/400+part)*10:0),214+Math.floor(part/5)*32];
   const done=part=>r.state.placements.some(p=>p.part===part&&p.slot===o.slots[part]);
   const active=part=>!bone||Math.floor(part/3)===Math.min(2,Math.floor(r.state.placements.length/3));
   function place(part,slot){if(o.slots[part]!==slot)return;const at=r.elapsed();if(o.locks){const[period,phase]=o.locks[part];if(Math.abs(Math.sin(2*Math.PI*(at+phase)/period))>o.lock_width){warningUntil=at+600;return}}r.state.placements=r.state.placements.filter(p=>p.part!==part);r.state.placements.push({part,slot,ms:at});selected=null;if(r.state.placements.length===n){if(paint)paint(at);r.finish()}}
   r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);const p=r.pos(e),t=r.elapsed();const part=Array.from({length:n},(_,i)=>i).find(i=>!done(i)&&active(i)&&Math.hypot(p.x-sourcePos(i,t)[0],p.y-sourcePos(i,t)[1])<23);if(part!==undefined){selected=drag=part;return}if(selected!==null){const slot=Array.from({length:n},(_,i)=>i).find(i=>Math.hypot(p.x-slotPos(i)[0],p.y-slotPos(i)[1])<24);if(slot!==undefined)place(selected,slot)}};
   r.svg.onpointerup=e=>{if(drag===null)return;const p=r.pos(e);const slot=Array.from({length:n},(_,i)=>i).find(i=>Math.hypot(p.x-slotPos(i)[0],p.y-slotPos(i)[1])<26);if(slot!==undefined)place(drag,slot);drag=null};r.svg.onpointercancel=()=>drag=null;
   paint=t=>{let out='';if(homunculus)out+=`<path d="M157 63 L130 83 L95 110 L113 129 L140 109 L142 145 L125 187 L149 197 L180 151 L210 197 L234 187 L216 145 L217 109 L247 129 L265 110 L228 83 L204 63Z" fill="#6e78644d" stroke="#92967b" stroke-width="3"/>`+circle(180,111,13,'#7fb89455','#8bc9a8');
    if(bone)out+=`<path d="M180 65 L180 137 M148 88 L212 88 M145 104 L215 104 M151 121 L209 121 M180 137 L155 166 M180 137 L205 166" stroke="#bfb7a666" stroke-width="9" fill="none"/>`+circle(180,45,22,'#a0a48b44','#a9b7a555');
    for(let slot=0;slot<n;slot++){const p=slotPos(slot),part=o.slots.indexOf(slot),complete=done(part);let open=true,angle=0;if(o.locks){const[period,phase]=o.locks[part];angle=360*(t+phase)/period;open=Math.abs(Math.sin(angle*Math.PI/180))<=o.lock_width}out+=circle(p[0],p[1],21,complete?'#44664d':'#171e25',complete?'#a1d79e':open?'#a6d9b2':'#75617f')+text(p[0],p[1]+6,stitch?(complete?'✓':'⌁'):String(part+1),19);if(o.locks&&!complete)out+=`<circle cx="${p[0]}" cy="${p[1]}" r="26" fill="none" stroke="${open?'#a6edb8':'#9c7c9c'}" stroke-width="3" stroke-dasharray="28 54" transform="rotate(${angle} ${p[0]} ${p[1]})"/>`}
    for(let part=0;part<n;part++){if(done(part)||!active(part))continue;const p=sourcePos(part,t);out+=circle(p[0],p[1],15,selected===part?'#868256':'#334943','#b9d6aa')+text(p[0],p[1]+5,String(part+1),17);if(stitch)out+=line(p[0],p[1]-20,p[0],130,'#af6c7188',3)}
    if(bone)out+=text(180,185,['Костяк','Посмертное ядро','Печать мага'][Math.min(2,Math.floor(r.state.placements.length/3))],15);
    r.svg.innerHTML=out;r.status(t<warningUntil?'Замок закрыт — дождитесь зелёного кольца':stitch?`Закрыто швов ${r.state.placements.length}/4`:bone?`Ступень ${Math.floor(r.state.placements.length/3)}/3 · частей ${r.state.placements.length}/9`:`Собрано ${r.state.placements.length}/${n}`)};r.animate(paint);
 });
 register(['puppet_threads'],(o,h)=>{
   const r=setup(o,h,'Перетаскивайте узлы, распутывая нити. Чем меньше пересечений, тем сильнее следующий удар каждого вашего существа.');
   r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);const p=r.pos(e);const i=r.state.nodes.findIndex(n=>Math.hypot(n[0]-p.x,n[1]-p.y)<22);if(i>=0)r.state.drag=i};r.svg.onpointerup=()=>delete r.state.drag;r.svg.onpointercancel=()=>delete r.state.drag;
   function side(a,b,c){return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])}
   r.animate(()=>{const nodes=r.state.nodes;let count=0;for(let i=0;i<o.edges.length;i++){const[a,b]=o.edges[i];for(const[c,d]of o.edges.slice(i+1)){if(new Set([a,b,c,d]).size<4)continue;const overlap=Math.max(Math.min(nodes[a][0],nodes[b][0]),Math.min(nodes[c][0],nodes[d][0]))<=Math.min(Math.max(nodes[a][0],nodes[b][0]),Math.max(nodes[c][0],nodes[d][0]))+1e-6&&Math.max(Math.min(nodes[a][1],nodes[b][1]),Math.min(nodes[c][1],nodes[d][1]))<=Math.min(Math.max(nodes[a][1],nodes[b][1]),Math.max(nodes[c][1],nodes[d][1]))+1e-6;if(side(nodes[a],nodes[b],nodes[c])*side(nodes[a],nodes[b],nodes[d])<=1e-6&&side(nodes[c],nodes[d],nodes[a])*side(nodes[c],nodes[d],nodes[b])<=1e-6&&overlap)count++}}
    r.svg.innerHTML=o.edges.map(([a,b])=>line(...nodes[a],...nodes[b],count?'#b5a17b':'#91d5a3',3)).join('')+nodes.map((p,i)=>circle(...p,13,'#304c46','#b6d5aa')+text(p[0],p[1]+5,String(i+1),13)).join('');r.status(`Пересечений нитей: ${count}`)});
 });
})();
