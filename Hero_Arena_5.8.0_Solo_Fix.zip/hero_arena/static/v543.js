/* Mage 5.4.3: six spellcraft games. Submitted inputs are replayed by the server. */
(function () {
  'use strict';
  const style = document.createElement('style');
  style.textContent = `
  .spell543{max-width:420px;margin:auto;touch-action:none;user-select:none}
  .spell543 .spell-stage{width:100%;display:block;border:1px solid #7795c266;border-radius:16px;background:radial-gradient(ellipse at 50% 45%,#243e5b,#111523 78%);overflow:hidden}
  .spell543 .spell-status{min-height:30px;margin:8px 0;color:#b8ddff;text-align:center;font-weight:600}
  .spell543 .spell-help{font-size:13px;line-height:1.5;color:#c5c4d5;margin:10px 0}
  .spell543 .spell-actions{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin:10px 0}
  .spell543 button{touch-action:manipulation}.spell543 button:focus-visible{outline:3px solid #fff;outline-offset:3px}
  .spell543 .rune-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
  .spell543 .rune-plate{padding:10px;background:#211c36;border:2px solid #746293;border-radius:14px;color:#c3a4ff;cursor:pointer}
  .spell543 .rune-plate.aligned{border-color:#78e4bb;box-shadow:inset 0 0 20px #78e4bb22}
  .spell543 .rune-model{display:flex;align-items:center;justify-content:center;gap:12px;color:#d3c8e6;font-size:12px}
  .spell543 .rune-big{font:52px Georgia;display:flex;align-items:center;justify-content:center;white-space:nowrap;width:110px;height:110px;margin:8px auto;line-height:1;transition:transform .12s}
  .spell543 .rune-mini{font:22px Georgia;display:inline-flex;align-items:center;justify-content:center;white-space:nowrap;width:48px;height:48px;line-height:1;color:#f0d797}
  .spell543 .rune-compass{width:24px;height:3px;background:#b899eb;margin:13px auto 9px;transform-origin:left center;position:relative}
  .spell543 .rune-compass:after{content:'◆';position:absolute;right:-4px;top:-9px;font-size:14px}
  .spell543 .fire-core{height:190px;position:relative;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse,#642619,#181324 73%);border-radius:16px;overflow:hidden}
  .spell543 .fire-orb{width:95px;height:95px;border-radius:50%;background:radial-gradient(circle at 40% 35%,#fffbc0,#ffb133 28%,#e94818 65%,#6a1833);box-shadow:0 0 38px #f96c1a88;transition:box-shadow .1s}
  .spell543 .fire-cage{position:absolute;width:150px;height:150px;border:3px dashed #ffd08088;border-radius:50%}
  .spell543 .spell-meter{height:18px;position:relative;background:#14131f;border:1px solid #606477;border-radius:6px;overflow:hidden;margin:7px 0}
  .spell543 .spell-meter .zone{position:absolute;height:100%;background:#3d9e7644;border-left:1px solid #67dfa7;border-right:1px solid #67dfa7}
  .spell543 .spell-meter i{display:block;height:100%;background:#f5a947;opacity:.85;width:0}
  .spell543 .circuit-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px;background:#111523;padding:9px;border:1px solid #889ed366;border-radius:14px}
  .spell543 .wire-tile{position:relative;background:#24253b;border:2px solid #53647c;border-radius:8px;padding:0;aspect-ratio:1;cursor:pointer;overflow:hidden;color:#c2d0ec}
  .spell543 .wire-tile.powered{border-color:#b1e6ff;box-shadow:0 0 13px #71beff66;color:#b7f4ff}
  .spell543 .wire-tile.capacitor{background:#3f3251}.spell543 .wire-tile.ground{opacity:.5;cursor:default}
  .spell543 .wire-tile svg{width:100%;height:100%;display:block}.spell543 .wire-label{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:20px;pointer-events:none;text-shadow:0 1px 5px #000}
  .spell543 .spell-legend{display:flex;justify-content:space-between;font-size:12px;color:#b8c7e0;margin:5px 0 9px}
  @media(max-width:450px){.spell543 .rune-big{font-size:42px;width:90px;height:90px}.spell543 .spell-help{font-size:12px}}
  `;
  document.head.appendChild(style);
  const elapsed = session => Math.min(session.o.time_limit_ms, Math.max(0, Math.floor(performance.now() - session.t0)));
  function shell(head, body, help, actions = '') {
    openBox(head + `<div class="spell543">${body}<div class="spell-status" id="spellStatus" aria-live="polite"></div>${timerBar}<div class="spell-help">${help}</div><div class="spell-actions">${actions}</div></div>`);
  }
  function start(o, answer, render) {
    if (mg && !mg.done) {
      mg.done = true;
      mg.timers.forEach(timer => { clearTimeout(timer); clearInterval(timer); });
      if (mg.raf) cancelAnimationFrame(mg.raf);
    }
    mgStart(o, answer);
    const session = mg;
    function frame() {
      if (mg !== session || session.done || !document.getElementById('spellStatus')) return;
      if (render) render(elapsed(session));
      session.raf = requestAnimationFrame(frame);
    }
    if (render) frame();
    return session;
  }
  function status(text) { const node = document.getElementById('spellStatus'); if (node) node.textContent = text; }
  function point(svg, event) {
    const box = svg.getBoundingClientRect();
    return {x: (event.clientX - box.left) * 360 / box.width, y: (event.clientY - box.top) * 320 / box.height};
  }
  function finishButton(id, answer) { document.getElementById(id).onclick = () => mgFinish(answer()); }

  MINIGAMES.mage_rune_weave = function (o, head) {
    const rotations = o.rotations.slice();
    shell(head, `<div class="rune-grid">${o.runes.map((r, i) => `<button class="rune-plate" data-rune="${i}" aria-label="Повернуть руну ${i + 1}"><span class="rune-model">Образец <span class="rune-mini" style="transform:rotate(${o.targets[i]*90}deg)">${esc(r)}➤</span></span><span class="rune-big">${esc(r)}➤</span></button>`).join('')}</div>`,
      `Образцы остаются перед глазами. Каждый клик поворачивает руну на четверть оборота. Совместите все четыре — печать замкнётся. Идеал: ×${o.ideal_mult} сквозь броню и +${o.mana_return} маны.`,
      '<button class="btn" id="runeCast">Замкнуть печать</button>');
    const answer = () => ({rotations: rotations.slice()}); start(o, answer);
    function paint() {
      let correct = 0;
      document.querySelectorAll('[data-rune]').forEach(button => {
        const i = +button.dataset.rune, ready = rotations[i] === o.targets[i];
        button.classList.toggle('aligned', ready); correct += ready;
        button.querySelector('.rune-big').style.transform = `rotate(${rotations[i]*90}deg)`;
      });
      status(`Совмещено ${correct}/4`);
      if (correct === 4) mgFinish(answer());
    }
    document.querySelectorAll('[data-rune]').forEach(button => button.onclick = () => { if (mg.done) return; const i = +button.dataset.rune; rotations[i] = (rotations[i]+1)%4; paint(); });
    finishButton('runeCast', answer); paint();
  };

  MINIGAMES.mage_water_sculpt = function (o, head) {
    const positions = [[180,48],[180,112],[102,139],[258,139],[145,214],[215,214]];
    const symbols = ['◉','◈','❮','❯','↺','≈'];
    const placed = new Map(); let selected = null, drag = null;
    shell(head, '<svg class="spell-stage" id="waterBody" viewBox="0 0 360 320" role="group" aria-label="Сборка водяного духа"></svg>',
      `Перетащите каждую каплю к такому же знаку внутри силуэта. Можно выбрать каплю и затем нажать на её место. Чем больше собрано частей, тем крепче и сильнее дух. Все 6: ${o.ideal_hp} HP и ${o.ideal_rounds} раундов.`,
      '<button class="btn" id="waterCast">Оживить духа</button>');
    const svg = document.getElementById('waterBody');
    const answer = () => ({placements: [...placed].map(([part, slot]) => ({part, slot}))}); start(o, answer);
    function paint() {
      svg.innerHTML = `<defs><linearGradient id="waterGlow" x2="0" y2="1"><stop stop-color="#a7eaff"/><stop offset="1" stop-color="#2779c8"/></linearGradient></defs><path d="M180 21 C140 21 143 82 153 89 L120 100 69 153 90 178 136 146 124 214 144 249 180 230 216 249 237 214 223 146 270 178 291 153 240 100 207 89 C220 56 218 21 180 21Z" fill="#3e91b71c" stroke="#8edfff55" stroke-width="2"/>
      ${positions.map(([x,y], slot) => {const part = o.target_slots.indexOf(slot), done = placed.has(part);return `<g data-slot="${slot}"><circle cx="${x}" cy="${y}" r="23" fill="${done?'url(#waterGlow)':'#143044'}" stroke="${done?'#ccf7ff':'#689dba'}" stroke-width="2" stroke-dasharray="${done?'0':'4 4'}"/><text x="${x}" y="${y+7}" text-anchor="middle" fill="${done?'#153b60':'#acd8ec'}" font-size="24" pointer-events="none">${symbols[part]}</text></g>`}).join('')}
      ${o.parts.map((part, i) => {if(placed.has(i))return '';const x=drag&&drag.part===i?drag.x:40+(o.supply_order||[0,1,2,3,4,5]).indexOf(i)*56,y=drag&&drag.part===i?drag.y:285;return `<g data-part="${i}" tabindex="0" role="button" aria-label="Капля: ${esc(part)}" style="cursor:grab"><path d="M${x} ${y-22} Q${x+28} ${y+14} ${x} ${y+21} Q${x-28} ${y+14} ${x} ${y-22}" fill="url(#waterGlow)" stroke="${selected===i?'#fff':'#75caf0'}" stroke-width="2"/><text x="${x}" y="${y+8}" text-anchor="middle" fill="#11324b" font-size="22" pointer-events="none">${symbols[i]}</text></g>`}).join('')}`;
      status(`Частей духа ${placed.size}/6`);
    }
    function place(part, slot) {
      if (slot !== o.target_slots[part]) { status('Эта капля подходит к другому знаку'); return false; }
      placed.set(part, slot); selected = null; drag = null; paint();
      if (placed.size === 6) mgFinish(answer()); return true;
    }
    svg.onpointerdown = event => {
      if (mg.done) return; event.preventDefault();
      const part = event.target.closest('[data-part]'), slot = event.target.closest('[data-slot]');
      if (part) { selected=+part.dataset.part; const p=point(svg,event);drag={part:selected,...p}; svg.setPointerCapture(event.pointerId); paint(); }
      else if (slot && selected !== null) place(selected,+slot.dataset.slot);
    };
    svg.onpointermove = event => { if (!drag || mg.done) return; Object.assign(drag,point(svg,event)); paint(); };
    svg.onpointerup = event => {
      if (!drag || mg.done) return; const p=point(svg,event),part=drag.part;
      const slot=positions.findIndex(([x,y])=>Math.hypot(x-p.x,y-p.y)<=29);
      drag=null; if(slot>=0&&place(part,slot))return;paint();
    };
    svg.onpointercancel = () => {drag=null;paint()};
    svg.onkeydown = event => { if(event.key==='Enter'||event.key===' '){const part=event.target.closest('[data-part]');if(part){event.preventDefault();selected=+part.dataset.part;paint()}} };
    finishButton('waterCast',answer);paint();
  };

  MINIGAMES.mage_ice_weave = function (o, head) {
    const path=[], expected=o.path;
    const vertices=Array.from({length:6},(_,i)=>{const angle=(-90+i*60+o.angle)*Math.PI/180;return [180+108*Math.cos(angle),154+108*Math.sin(angle)]});
    shell(head,'<svg class="spell-stage" id="iceContour" viewBox="0 0 360 320" aria-label="Ледяной контур"></svg>',
      `Начните с 1, проведите по вершинам 2–6 и вернитесь к 1. Можно вести пальцем или нажимать по очереди. Каждый собранный участок укрепляет щит. Полный контур: ${o.ideal_absorb} поглощения на ${o.ideal_duration} хода.`,
      '<button class="btn" id="iceCast">Поднять щит</button>');
    const svg=document.getElementById('iceContour'),answer=()=>({path:path.slice()});start(o,answer);
    function paint(){
      const points=vertices.map(p=>p.join(',')).join(' '),done=Math.max(0,path.length-1);
      svg.innerHTML=`<polygon points="${points}" fill="#70c9f51b" stroke="#709dc15f" stroke-width="3"/>
       ${Array.from({length:done},(_,i)=>{const a=vertices[i],b=vertices[(i+1)%6];return `<path d="M180 154 L${a.join(' ')} L${b.join(' ')}Z" fill="#81daff50" stroke="#c8f5ff" stroke-width="2"/>`}).join('')}
       ${vertices.map(([x,y],i)=>`<g data-vertex="${i}"><circle cx="${x}" cy="${y}" r="21" fill="${expected[path.length]===i?'#d0f6ff':'#1e415b'}" stroke="#87d5fa" stroke-width="2"/><text x="${x}" y="${y+6}" text-anchor="middle" fill="${expected[path.length]===i?'#13304c':'#d7f5ff'}" font-size="20" pointer-events="none">${i+1}</text></g>`).join('')}
       <text x="180" y="160" text-anchor="middle" fill="#c3f2ff" font-size="36">❄</text>`;
      status(`Сплетено граней ${done}/6`);
    }
    function touch(event){if(mg.done)return;const p=point(svg,event),i=vertices.findIndex(([x,y])=>Math.hypot(x-p.x,y-p.y)<27);if(i>=0&&i===expected[path.length]){path.push(i);paint();if(path.length===7)mgFinish(answer())}}
    let down=false;
    svg.onpointerdown=event=>{event.preventDefault();down=true;svg.setPointerCapture(event.pointerId);touch(event)};
    svg.onpointermove=event=>{if(down)touch(event)};svg.onpointerup=()=>down=false;svg.onpointercancel=()=>down=false;
    finishButton('iceCast',answer);paint();
  };

  function fireState(events, ms, o){
    let heat=o.start_heat,previous=0,down=false,overheated=false;
    for(const event of [...events,{ms,down:false}]){heat+=(event.ms-previous)/1000*(down?o.heat_per_s:-o.cool_per_s);overheated=overheated||heat>=110;heat=Math.max(0,Math.min(120,heat));previous=event.ms;down=event.down}
    return {heat,focus:50+50*Math.sin(2*Math.PI*(ms+o.phase_ms)/o.period_ms),overheated};
  }
  MINIGAMES.mage_fire_core = function(o,head){
    const events=[];let down=false,session;
    shell(head,'<div class="fire-core"><div class="fire-cage" id="fireCage"></div><div class="fire-orb" id="fireOrb"></div></div><div>Жар <span id="heatRead"></span></div><div class="spell-meter"><span class="zone" style="left:60.83%;width:14.17%"></span><i id="heatFill"></i></div><div>Сжатие <span id="focusRead"></span></div><div class="spell-meter"><span class="zone" style="left:70%;width:30%"></span><i id="focusFill" style="background:#95b9ff"></i></div>',
      'Удерживайте «Питать огонь»: жар растёт. Отпустите — остывает. Бросайте, когда жар 73–90 и сжатие ≥70. Перегрев от 110 портит ядро до конца попытки. Шар сильнее поджигает при точной сборке.',
      '<button class="btn" id="fireFuel">🔥 Питать огонь</button><button class="btn" id="fireCast">Бросить шар</button>');
    const answer=()=>({events:events.map(e=>({...e})),elapsed_ms:elapsed(session)});
    session=start(o,answer,ms=>{const s=fireState(events,ms,o);document.getElementById('heatFill').style.width=s.heat/120*100+'%';document.getElementById('focusFill').style.width=s.focus+'%';document.getElementById('heatRead').textContent=Math.round(s.heat);document.getElementById('focusRead').textContent=Math.round(s.focus);document.getElementById('fireOrb').style.transform=`scale(${.55+s.heat/115})`;document.getElementById('fireOrb').style.filter=s.overheated?'grayscale(.9) brightness(.45)':'none';document.getElementById('fireCage').style.transform=`scale(${1.15-s.focus/230}) rotate(${ms/15}deg)`;status(s.overheated?'Перегрев: ядро нестабильно':s.heat>=73&&s.heat<=90&&s.focus>=70?'Стабильное ядро — бросайте!':'Уравновесьте жар и сжатие')});
    function fuel(value){if(mg!==session||session.done||down===value)return;down=value;events.push({ms:elapsed(session),down:value})}
    const button=document.getElementById('fireFuel');
    button.onpointerdown=e=>{e.preventDefault();button.setPointerCapture(e.pointerId);fuel(true)};button.onpointerup=()=>fuel(false);button.onpointercancel=()=>fuel(false);button.onlostpointercapture=()=>fuel(false);
    button.onkeydown=e=>{if(e.key===' '||e.key==='Enter'){e.preventDefault();fuel(true)}};button.onkeyup=e=>{if(e.key===' '||e.key==='Enter'){e.preventDefault();fuel(false)}};
    finishButton('fireCast',answer);
  };

  function stackState(drops,o){
    let left=100,right=260;const layers=[];
    for(let i=0;i<drops.length;i++){const center=180+o.amplitude*Math.sin(2*Math.PI*(drops[i]+o.phases[i])/o.periods[i]),width=right-left;left=Math.max(left,center-width/2);right=Math.min(right,center+width/2);if(right<=left)break;layers.push({left,right})}
    return layers;
  }
  MINIGAMES.mage_golem_stack=function(o,head){
    const drops=[];let session;
    shell(head,'<svg class="spell-stage" id="golemForge" viewBox="0 0 360 320" aria-label="Каменная кладка"></svg>',
      'Сбрасывайте движущийся камень над предыдущим. Края обрезаются: косая кладка делает голема слабее. Для идеала нужны 5 слоёв и минимум 75% ширины. Голем сразу прикрывает первый прямой удар, затем перехватывает часть ударов и иногда оглушает.',
      '<button class="btn" id="golemDrop">🪨 Положить камень</button><button class="btn ghost" id="golemCast">Пробудить сейчас</button>');
    const svg=document.getElementById('golemForge'),answer=()=>({drops:drops.slice()});
    function paint(ms){
      const layers=stackState(drops,o),i=layers.length,width=i?layers[i-1].right-layers[i-1].left:160;
      const center=180+o.amplitude*Math.sin(2*Math.PI*(ms+o.phases[Math.min(i,4)])/o.periods[Math.min(i,4)]),target=i?(layers[i-1].left+layers[i-1].right)/2:180;
      svg.innerHTML=`<path d="M70 297H290" stroke="#948674" stroke-width="9"/><path d="M${target} 75V287" stroke="#d5bd8e55" stroke-dasharray="4 5"/>${layers.map((p,n)=>`<rect x="${p.left}" y="${262-n*31}" width="${p.right-p.left}" height="29" rx="5" fill="${n%2?'#8c8179':'#a39585'}" stroke="#dfceb0"/><path d="M${p.left+8} ${273-n*31}h${Math.max(0,p.right-p.left-16)}" stroke="#514b4d"/>${n===4?`<path d="M${(p.left+p.right)/2-16} ${149}h10m12 0h10" stroke="#9fe7ff" stroke-width="5"/>`:n===2?`<path d="M${(p.left+p.right)/2} 207l7 8-7 8-7-8z" fill="#8ac9ee"/>`:""}`).join('')}${i<5?`<rect x="${center-width/2}" y="${262-i*31}" width="${width}" height="29" rx="5" fill="#b5a389" stroke="#fff0bb" stroke-width="2"/>`:''}<text x="180" y="42" text-anchor="middle" fill="#dacaa6" font-size="17">КАМЕННОЕ СЕРДЦЕ</text>`;
      status(`Слоёв ${i}/5 • ширина ${Math.round(width/160*100)}%`);
    }
    session=start(o,answer,paint);
    function drop(){if(mg!==session||session.done)return;const before=stackState(drops,o).length;drops.push(elapsed(session));const after=stackState(drops,o).length;paint(elapsed(session));if(after<=before||drops.length>=5)mgFinish(answer())}
    document.getElementById('golemDrop').onclick=drop;svg.onpointerdown=e=>{e.preventDefault();drop()};finishButton('golemCast',answer);
  };

  function circuitState(rotations,o){
    let index=o.source,entering=3,caps=0;const seen=[];
    for(let count=0;count<12;count++){
      const cell=o.cells[index],ports=cell.ports.map(p=>(p+rotations[index])%4);
      if(seen.includes(index)||cell.kind==='ground'||!ports.includes(entering))break;
      seen.push(index);if(cell.kind==='capacitor')caps++;const outgoing=ports.find(p=>p!==entering);
      if(index===o.target&&outgoing===1)return {seen,caps,complete:true};
      let row=Math.floor(index/4),col=index%4;const [dr,dc]=[[-1,0],[0,1],[1,0],[0,-1]][outgoing];row+=dr;col+=dc;if(row<0||row>=3||col<0||col>=4)break;index=row*4+col;entering=(outgoing+2)%4;
    }
    return {seen,caps,complete:false};
  }
  MINIGAMES.mage_lightning_circuit=function(o,head){
    const rotations=o.cells.map(c=>c.rotation);
    shell(head,'<div class="spell-legend"><span>⚡ Источник слева сверху</span><span>Цель справа снизу ➜</span></div><div class="circuit-grid" id="lightningBoard"></div>',
      'Поворачивайте проводники на четверть оборота. Ток должен пройти через оба конденсатора ◇ и выйти к цели ➜. Заземление ⊥ обрывает цепь. Полный разряд пробивает броню, выжигает щит и усиливается после духа воды.',
      '<button class="btn" id="lightningCast">Выпустить разряд</button>');
    const answer=()=>({rotations:rotations.slice()});start(o,answer);
    function paint(){
      const state=circuitState(rotations,o),ends=[[30,0],[60,30],[30,60],[0,30]];
      document.getElementById('lightningBoard').innerHTML=o.cells.map((cell,i)=>{
        const paths=cell.ports.map(p=>{const [x,y]=ends[(p+rotations[i])%4];return `<path d="M30 30L${x} ${y}"/>`}).join(''),symbol=cell.kind==='source'?'⚡':cell.kind==='target'?'➜':cell.kind==='capacitor'?'◇':cell.kind==='ground'?'⊥':'';
        return `<button class="wire-tile ${cell.kind} ${state.seen.includes(i)?'powered':''}" data-wire="${i}" ${cell.kind==='ground'?'disabled':''} aria-label="${cell.kind==='capacitor'?'Конденсатор':'Проводник'} ${i+1}: повернуть"><svg viewBox="0 0 60 60"><g stroke="currentColor" stroke-width="5" fill="none">${paths}</g></svg><span class="wire-label">${symbol}</span></button>`
      }).join('');
      document.querySelectorAll('[data-wire]').forEach(button=>button.onclick=()=>{if(mg.done)return;const i=+button.dataset.wire;rotations[i]=(rotations[i]+1)%4;paint()});
      status(`Конденсаторы ${state.caps}/2 • проводников под током ${state.seen.length}`);
      if(state.complete&&state.caps===2)mgFinish(answer());
    }
    finishButton('lightningCast',answer);paint();
  };
})();
