/* Selected physical minigames; existing effect tiers and ordinary kits are retained. */
(function(){
'use strict';
const {setup,circle,line,text,interpolate}=window.arenaMiniUI;
const register=(names,fn)=>names.forEach(n=>MINIGAMES[n]=fn);
const near=(a,b,r)=>Math.hypot(a[0]-b[0],a[1]-b[1])<=r;
const points=r=>r.state.points.map(p=>[p.t,p.x,p.y]);
function exact(r,t,p){r.setCursor(p);const a={t,x:p.x,y:p.y};if(r.state.points.at(-1)?.t===t)r.state.points[r.state.points.length-1]=a;else r.state.points.push(a)}
function ready(r,t){if(t>=r.o.prepare_ms)return true;r.status(`Приготовьтесь: ${Math.max(1,Math.ceil((r.o.prepare_ms-t)/1000))}…`);return false}
function star(x,y,size,color){return `<path d="${Array.from({length:10},(_,i)=>{const a=-Math.PI/2+i*Math.PI/5,d=i%2?size*.43:size;return(i?'L':'M')+(x+Math.cos(a)*d)+' '+(y+Math.sin(a)*d)}).join(' ')}Z" fill="${color}" stroke="#f4e8bb" stroke-width="1.5"/>`}
function moving(o,t){const q=(t-o.prepare_ms)/o.period*2*Math.PI;return o.straight?[180+115*Math.sin(q+o.phase),105+28*Math.sin(q*.5)]:[190+105*Math.sin(q+o.phase),115+65*Math.sin(q*1.6+.4)]}

register(['hunt_lead_56','star_lead_56'],(o,h)=>{
 const elf=o.game==='star_lead_56',r=setup(o,h,elf?'Нажимайте в точку, где окажется звезда после полёта стрелы. Ветер сносит попадание в сторону стрелки. Всего три выстрела.':'Цель движется, а стреле нужно время долететь. Нажимайте с упреждением. Шесть выстрелов.');r.state.shots=[];
 r.svg.onpointerdown=e=>{e.preventDefault();const t=r.elapsed();if(t<o.prepare_ms||r.state.shots.length>=o.count||t-(r.state.shots.at(-1)?.ms??-10000)<250*o.factor)return;
  const p=r.pos(e);r.setCursor(p);r.state.shots.push({ms:t,x:p.x,y:p.y});
  if(r.state.shots.length===o.count)r.session.timers.push(setTimeout(r.finish,o.travel_ms+35));
 };
 r.animate(t=>{const p=moving(o,t),tail=moving(o,t-180);let hits=0;
  let out=line(42,232,r.cursor.x+o.wind,r.cursor.y,'#c6bd9a55',1)+`<path d="M30 210 Q65 232 30 252 M30 210 L30 252" fill="none" stroke="#b69c6d" stroke-width="4"/>`;
  out+=line(...tail,...p,elf?'#c3b4f499':'#bcae7b88',4);
  out+=elf?star(...p,16,'#e4c56f'):`<path d="M${p[0]-23} ${p[1]+9} Q${p[0]} ${p[1]-22} ${p[0]+21} ${p[1]+5} L${p[0]+30} ${p[1]-8} M${p[0]+21} ${p[1]+5} L${p[0]+24} ${p[1]+25} M${p[0]-12} ${p[1]+8} L${p[0]-20} ${p[1]+25}" fill="none" stroke="#d6b17d" stroke-width="6"/>`;
  for(const a of r.state.shots){const f=Math.max(0,Math.min(1,(t-a.ms)/o.travel_ms)),end=[a.x+o.wind,a.y];
   if(f<1)out+=line(42+(end[0]-42)*f-6,232+(end[1]-232)*f+6,42+(end[0]-42)*f,232+(end[1]-232)*f,'#f0d7a6',3);
   else{const hit=near(end,moving(o,a.ms+o.travel_ms),o.radius);hits+=hit;out+=text(...end,hit?'✓':'×',22,hit?'#9bd4b0':'#c97d7d')}
  }
  out+=text(180,25,elf?'ЗВЁЗДНАЯ СТРЕЛА':'СТРЕЛЯЙТЕ С УПРЕЖДЕНИЕМ',16);
  if(elf)out+=text(180,240,`Ветер ${o.wind>0?'→':'←'} ${Math.abs(o.wind)} · полёт ${o.travel_ms} мс`,14);
  r.svg.innerHTML=out;if(ready(r,t))r.status(`Выстрелы ${r.state.shots.length}/${o.count} · попадания ${hits}`);
 });
});

register(['knife_flick_56'],(o,h)=>{
 const r=setup(o,h,'Зажмите нож у руки внизу, проведите к метке и отпустите. Пять бросков; одна метка засчитывается один раз.');r.state.cuts=[];let down=null;const used=new Set();
 r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e);if(r.elapsed()<o.prepare_ms||r.state.cuts.length>=5||!near([p.x,p.y],[180,232],45))return;r.svg.setPointerCapture(e.pointerId);r.setCursor(p);down={ms:r.elapsed(),p}};
 r.svg.onpointerup=e=>{if(!down)return;const p=r.pos(e),t=r.elapsed(),d={down_ms:down.ms,up_ms:t,x0:down.p.x,y0:down.p.y,x1:p.x,y1:p.y};r.state.cuts.push(d);
  if(t-down.ms>=70*o.factor&&t-down.ms<=1300*o.factor)o.targets.forEach((a,i)=>{if(near([p.x,p.y],a,25))used.add(i)});down=null;if(r.state.cuts.length===5)r.finish()};r.svg.onpointercancel=()=>{down=null};
 r.animate(t=>{let out=text(180,24,'РУКА → МЕТКА → ОТПУСТИТЬ',16);
  o.targets.forEach(([x,y],i)=>out+=circle(x,y,22,used.has(i)?'#3a6a4b':'#352b3e',used.has(i)?'#95d5aa':'#b66b73')+line(x-8,y,x+8,y,'#ecb1ac',2)+line(x,y-8,x,y+8,'#ecb1ac',2));
  out+=circle(180,232,24,down?'#806c45':'#41364c','#cfbd91')+`<path d="M176 246 L184 246 L184 234 L190 234 L180 211 L170 234 L176 234Z" fill="#d7d5cd"/>`;
  if(down)out+=line(180,232,r.cursor.x,r.cursor.y,'#e7c88b',3);r.svg.innerHTML=out;if(ready(r,t))r.status(`Ножей брошено ${r.state.cuts.length}/5 · меток ${used.size}/5`);
 });
});

register(['spirit_guide_56'],(o,h)=>{
 const r=setup(o,h,'Перетаскивайте светящихся духов с опушки к дереву в центре. Можно повторить неудачный перенос, пока идёт время.');r.state.drags=[];let drag=null;const used=new Set();
 r.svg.onpointerdown=e=>{e.preventDefault();if(r.elapsed()<o.prepare_ms)return;const p=r.pos(e),i=o.spirits.findIndex((q,i)=>!used.has(i)&&near([p.x,p.y],q,28));if(i<0)return;r.svg.setPointerCapture(e.pointerId);r.setCursor(p);drag={i,ms:r.elapsed(),p}};
 r.svg.onpointerup=e=>{if(!drag)return;const p=r.pos(e);r.state.drags.push({node:drag.i,down_ms:drag.ms,up_ms:r.elapsed(),x0:drag.p.x,y0:drag.p.y,x:p.x,y:p.y});if(near([p.x,p.y],[180,130],30))used.add(drag.i);drag=null;if(used.size===10)r.finish()};r.svg.onpointercancel=()=>{drag=null};
 r.animate(t=>{let out=`<path d="M180 110 L167 190 L193 190 L185 110" fill="#81735b"/>`+circle(180,103,39,'#49654c','#91b18b')+circle(155,120,30,'#405d47','#91b18b')+circle(202,120,30,'#405d47','#91b18b')+circle(180,130,32,'#547d5b66','#b2d2ad');
  o.spirits.forEach((p,i)=>{if(used.has(i))return;const q=drag?.i===i?[r.cursor.x,r.cursor.y]:p;out+=circle(...q,14,'#a3cebd55','#b2dfd0')+circle(...q,4,'#e3f1c1','#e3f1c1')});
  out+=text(180,25,'ДУХ → ДЕРЕВО',17);r.svg.innerHTML=out;if(ready(r,t))r.status(`Вернулось духов ${used.size}/10`);
 });
});

register(['nest_catch_56'],(o,h)=>{
 const r=setup(o,h,'Двигайте гнездо влево и вправо под падающими совятами. Щёлкать по ним не нужно. На телефоне ведите палец по полю.');
 r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);r.setCursor(r.pos(e))};const caught=new Set(),missed=new Set();
 r.animate(t=>{for(let i=0;i<o.birds.length;i++)if(t>=o.birds[i].land&&!caught.has(i)&&!missed.has(i)){const x=interpolate(points(r),o.birds[i].land)[0];(Math.abs(x-o.birds[i].x)<=30?caught:missed).add(i)}
  let out=text(180,25,'ПОДСТАВЬТЕ ГНЕЗДО',17);
  o.birds.forEach((b,i)=>{if(t<b.land-b.fall||t>b.land||caught.has(i)||missed.has(i))return;const y=35+(t-(b.land-b.fall))/b.fall*183;out+=circle(b.x,y,13,'#9e8765','#dbc6a0')+circle(b.x-5,y-3,4,'#efe3c4')+circle(b.x+5,y-3,4,'#efe3c4')+line(b.x-19,y-2,b.x-10,y+6,'#bba17b',4)+line(b.x+10,y+6,b.x+19,y-2,'#bba17b',4)});
  const x=r.cursor.x;out+=`<path d="M${x-30} 218 Q${x} 250 ${x+30} 218Z" fill="#7f6748" stroke="#d9be8c" stroke-width="4"/>`;r.svg.innerHTML=out;if(ready(r,t))r.status(`Поймано совят ${caught.size}/6`);
 });
});

register(['night_focus_56'],(o,h)=>{
 const r=setup(o,h,'Наведитесь на глаза. Подержите прицел, пока кольцо фокуса не станет зелёным, затем нажмите. Три появления во тьме.');r.state.clicks=[];const used=new Set();
 function focused(e,t){const p=points(r),start=Math.max(e.start,t-160*o.factor);return t-e.start>=140*o.factor&&Array.from({length:5},(_,i)=>start+(t-start)*i/4).every(ms=>near(interpolate(p,ms),[e.x,e.y],30))}
 r.svg.onpointerdown=e=>{e.preventDefault();const t=r.elapsed(),p=r.pos(e);r.setCursor(p);const i=o.eyes.findIndex((a,i)=>!used.has(i)&&t>=a.start&&t<a.end&&near([p.x,p.y],[a.x,a.y],27)&&focused(a,t));if(i<0)return;r.state.clicks.push({ms:t,x:p.x,y:p.y});used.add(i);if(used.size===3)r.finish()};
 r.animate(t=>{let out=`<path d="M180 237 L${r.cursor.x-34} ${r.cursor.y-18} Q${r.cursor.x} ${r.cursor.y-45} ${r.cursor.x+34} ${r.cursor.y-18}Z" fill="#cbb47812"/>`+text(180,25,'НАЙТИ → СФОКУСИРОВАТЬ → НАЖАТЬ',13);
  o.eyes.forEach((e,i)=>{if(t<e.start||t>=e.end||used.has(i))return;const lit=near([r.cursor.x,r.cursor.y],[e.x,e.y],30),good=focused(e,t);out+=`<g opacity="${lit?1:.2}">`+circle(e.x-8,e.y,5,'#c0bd77','#eee2a3')+circle(e.x+8,e.y,5,'#c0bd77','#eee2a3')+'</g>'+circle(e.x,e.y,25,'none',good?'#8bd4a1':lit?'#ad9173':'#4a415c')});
  out+=line(r.cursor.x-9,r.cursor.y,r.cursor.x+9,r.cursor.y,'#d3c8a7',1)+line(r.cursor.x,r.cursor.y-9,r.cursor.x,r.cursor.y+9,'#d3c8a7',1);r.svg.innerHTML=out;if(ready(r,t))r.status(`Охота ${used.size}/3 · ждите зелёного фокуса`);
 });
});

register(['soul_tether_56'],(o,h)=>{
 const r=setup(o,h,'Удерживайте луч на светящейся душе. Когда она свяжется, переводите луч на следующую. Нажатия не нужны.');r.svg.onpointerdown=e=>{e.preventDefault();r.svg.setPointerCapture(e.pointerId);r.setCursor(r.pos(e))};
 r.animate(t=>{const path=points(r);let n=0,held=0;for(let ms=o.prepare_ms;ms<t&&n<5;ms+=40){held=near(interpolate(path,ms),o.souls[n],28)?held+40:0;if(held>=o.lock_ms){n++;held=0}}
  let out=text(180,25,'СВЯЖИТЕ ДУШИ ЛУЧОМ',16);
  o.souls.forEach((p,i)=>out+=circle(...p,20,i<n?'#343343':i===n?'#8974b5':'#41394f',i===n?'#dcc7f5':'#665a76')+circle(p[0]-5,p[1]-3,3,'#e7d9f2')+circle(p[0]+5,p[1]-3,3,'#e7d9f2'));
  out+=line(180,250,r.cursor.x,r.cursor.y,'#af8adf',4);r.svg.innerHTML=out;if(ready(r,t))r.status(`Связано душ ${n}/5`);if(n===5)r.finish();
 });
});

register(['stone_stack_56'],(o,h)=>{
 const r=setup(o,h,'Плита движется над панцирем. Нажмите «Сбросить», когда она над выделенным местом. Четыре попытки.','<button class="btn" id="drop56">Сбросить плиту</button>');r.state.clicks=[];
 document.getElementById('drop56').onclick=()=>{if(r.elapsed()<o.prepare_ms||r.state.clicks.length===4)return;r.state.clicks.push({ms:r.elapsed()});if(r.state.clicks.length===4)r.finish()};
 r.animate(t=>{const i=Math.min(3,r.state.clicks.length),slot=o.slots[i],x=180+110*Math.sin(2*Math.PI*(t+o.phases[i])/o.periods[i]);let n=0;
  let out=`<path d="M138 80 Q180 40 222 80 L245 230 L115 230Z" fill="#555661" stroke="#999593" stroke-width="3"/>`+`<rect x="${slot-26}" y="105" width="52" height="80" fill="#a3c5a033" stroke="#a3c5a0" stroke-dasharray="5 5"/>`+`<rect x="${x-24}" y="50" width="48" height="30" rx="5" fill="#8a8886" stroke="#ddd3bb" stroke-width="3"/>`;
  r.state.clicks.forEach((a,j)=>{const hit=Math.abs(180+110*Math.sin(2*Math.PI*(a.ms+o.phases[j])/o.periods[j])-o.slots[j])<=25;n+=hit;out+=`<rect x="${o.slots[j]-22}" y="${120+j*23}" width="44" height="20" rx="4" fill="${hit?'#8d9c82':'#664951'}"/>`});
  out+=text(180,25,`ПЛИТА ${r.state.clicks.length+1}/4`,16);r.svg.innerHTML=out;if(ready(r,t))r.status(`Закреплено плит ${n}/4`);
 });
});

register(['shadow_erase_56'],(o,h)=>{
 const r=setup(o,h,'Зажмите кнопку на поле и сотрите четыре тёмные печати круговыми движениями. Под каждой скрыт череп.');r.state.holds=[];let hold=null;
 r.svg.onpointerdown=e=>{e.preventDefault();if(r.elapsed()<o.prepare_ms)return;r.svg.setPointerCapture(e.pointerId);r.setCursor(r.pos(e));hold={down_ms:r.elapsed(),up_ms:r.elapsed()};r.state.holds.push(hold)};
 r.svg.onpointerup=()=>{if(hold)hold.up_ms=r.elapsed();hold=null};r.svg.onpointercancel=r.svg.onpointerup;
 r.animate(t=>{if(hold)hold.up_ms=t;let n=0,out=text(180,25,'СОТРИТЕ ПЕЧАТИ ТЬМЫ',16);
  for(const[x,y]of o.seals){const cells=new Set();for(const p of r.state.points)if(p.t>=o.prepare_ms&&r.state.holds.some(h=>p.t>=h.down_ms&&p.t<=h.up_ms)&&near([p.x,p.y],[x,y],35))cells.add(`${p.x>=x}:${p.y>=y}`);const open=cells.size>=3;n+=open;
   out+=circle(x,y,35,open?'#817a8b':'#282033',open?'#d8d0cb':'#695777');out+=open?circle(x,y-4,18,'#b8b0ad','#ddd4c9')+circle(x-7,y-6,5,'#352d42')+circle(x+7,y-6,5,'#352d42')+`<rect x="${x-9}" y="${y+9}" width="18" height="12" fill="#b8b0ad"/>`:text(x,y+10,'◇',40,'#a084bf')+circle(x,y,25,'none','#59416c')}
  r.svg.innerHTML=out;if(ready(r,t))r.status(`Открыто черепов ${n}/4 · ведите указателем с зажатой кнопкой`);if(n===4)r.finish();
 });
});

function beam(o,bits){let p=o.start.slice(),d=o.direction.slice(),path=[],seen=new Set(),visited=new Set();for(let n=0;n<40;n++){const k=[...p,...d].join(',');if(seen.has(k))break;seen.add(k);path.push(p.slice());if(p.every((v,i)=>v===o.goal[i]))return{path,ok:visited.size===3};const i=o.mirrors.findIndex(q=>q.every((v,j)=>v===p[j]));if(i>=0){visited.add(i);d=bits[i]?[d[1],d[0]]:[-d[1],-d[0]]}p=p.map((v,i)=>v+d[i]);if(p.some(v=>v<0||v>4))break}return{path,ok:false}}
register(['light_prism_56'],(o,h)=>{
 const r=setup(o,h,'Нажимайте на зеркала: луч должен пройти все три и попасть в звезду. Затем откройте затвор, когда метка в золотой зоне.','<button class="btn" id="gate56">Открыть затвор</button>');r.state.clicks=[];const bits=o.initial.slice(),xy=p=>[60+p[0]*60,35+p[1]*42];
 r.svg.onpointerdown=e=>{e.preventDefault();if(r.elapsed()<o.prepare_ms||r.state.clicks.length>=30)return;const p=r.pos(e),i=o.mirrors.findIndex(q=>near([p.x,p.y],xy(q),25));if(i<0)return;bits[i]^=1;r.state.clicks.push({node:i,ms:r.elapsed()})};
 document.getElementById('gate56').onclick=()=>{if(r.elapsed()<o.prepare_ms)return;r.state.fire_ms=r.elapsed();r.finish()};
 r.animate(t=>{const b=beam(o,bits),f=((t+o.phase)%o.period)/o.period,err=Math.abs(f-.5)*o.period/o.factor;let out='';for(let x=0;x<5;x++)for(let y=0;y<5;y++)out+=circle(...xy([x,y]),3,'#746d85','#746d85');for(let i=1;i<b.path.length;i++)out+=line(...xy(b.path[i-1]),...xy(b.path[i]),b.ok?'#efcf74':'#b49de0',4);
 o.mirrors.forEach((p,i)=>{const[x,y]=xy(p);out+=circle(x,y,22,'#302b44','#aaa0c7')+line(x-13,bits[i]?y-13:y+13,x+13,bits[i]?y+13:y-13,'#d0e8f5',5)});out+=star(...xy(o.goal),17,b.ok?'#ecd477':'#6c607e')+circle(...xy(o.start),8,'#f0d281')+`<rect x="30" y="224" width="300" height="17" rx="6" fill="#141523"/><rect x="${180-300*190*o.factor/o.period}" y="224" width="${600*190*o.factor/o.period}" height="17" fill="#507d63"/><rect x="${180-300*70*o.factor/o.period}" y="224" width="${600*70*o.factor/o.period}" height="17" fill="#cda651"/>`+line(30+300*f,219,30+300*f,246,'#fff2ce',3);
 r.svg.innerHTML=out;if(ready(r,t))r.status((b.ok?'Луч в цели · ':'Разверните зеркала · ')+(err<=70?'ИДЕАЛЬНЫЙ МОМЕНТ':err<=190?'затвор открыт':'дождитесь вспышки'));document.getElementById('gate56').disabled=t<o.prepare_ms;
 });
});
function positions(o,drags,t){return o.nodes.map((p,i)=>{const a=drags.slice().reverse().find(a=>a.node===i&&a.up_ms<=t),base=a?[a.x,a.y]:p,dt=a?Math.max(0,t-a.up_ms-800*o.factor)/1000:0;return base.map((v,j)=>v+o.velocities[i][j]*dt)})}
register(['star_pattern_56'],(o,h)=>{
 const r=setup(o,h,'Перенесите пять пронумерованных звёзд в такие же контуры. Через мгновение они начинают дрейфовать: успейте замкнуть узор.');r.state.drags=[];let drag=null;document.getElementById('rFinish').textContent='Замкнуть узор';
 r.svg.onpointerdown=e=>{e.preventDefault();const t=r.elapsed();if(t<o.prepare_ms||r.state.drags.length>=35)return;const p=r.pos(e),i=positions(o,r.state.drags,t).findIndex(q=>near([p.x,p.y],q,25));if(i<0)return;r.svg.setPointerCapture(e.pointerId);r.setCursor(p);drag={node:i,down_ms:t,x0:p.x,y0:p.y}};
 r.svg.onpointerup=e=>{if(!drag)return;const p=r.pos(e),t=r.elapsed();if(t>drag.down_ms)r.state.drags.push({...drag,up_ms:t,x:p.x,y:p.y});drag=null};r.svg.onpointercancel=()=>{drag=null};
 r.animate(t=>{const p=positions(o,r.state.drags,t);let out='',n=0;for(let i=0;i<5;i++){const a=o.slots[i],b=o.slots[(i+1)%5];out+=line(...a,...b,'#736a8d',2)+circle(...a,21,'none','#aa9fbb')+text(a[0],a[1]+5,i+1,14,'#a69ab8');const q=drag?.node===i?[r.cursor.x,r.cursor.y]:p[i],ok=near(q,a,21);n+=ok;out+=star(...q,15,ok?'#b5d99d':'#e4bf73')+text(q[0],q[1]+5,i+1,13,'#272333')}
 r.svg.innerHTML=out;if(ready(r,t))r.status(`Звёзд на месте ${n}/5 · замкните узор вручную`);
 });
});
register(['dawn_focus_56'],(o,h)=>{
 const r=setup(o,h,'Зажмите луч на светящейся трещине и следуйте за ней. Отпустите при зелёном заряде. Перегрев портит результат.');let down=null;
 r.svg.onpointerdown=e=>{e.preventDefault();if(down!==null||r.elapsed()<o.prepare_ms)return;r.svg.setPointerCapture(e.pointerId);down=r.elapsed();r.state.down_ms=down;exact(r,down,r.pos(e))};
 r.svg.onpointerup=e=>{if(down===null)return;r.state.up_ms=r.elapsed();exact(r,r.state.up_ms,r.pos(e));r.finish()};r.svg.onpointercancel=r.svg.onpointerup;
 r.animate(t=>{let charge=0,inside=0,total=0,over=false;if(down!==null){r.state.up_ms=t;const p=points(r);for(let ms=down;ms<t;ms+=40){const hit=near(interpolate(p,ms),interpolate(o.path,ms),o.radius);inside+=hit;total++;charge=Math.max(0,charge+(hit?40:-72));over||=charge>3600*o.factor}}const q=charge/o.factor,[x,y]=interpolate(o.path,t),ok=!over&&q>=2600&&q<=3300&&inside/Math.max(1,total)>=.9;
 r.svg.innerHTML=`<path d="M180 35 L142 85 L151 144 L130 210 L230 210 L209 144 L218 85Z" fill="#5b4b6444" stroke="#90808d"/>`+circle(x,y,o.radius,'#e6bd6355',ok?'#a9e2a6':'#e6c276')+line(x-10,y-3,x+9,y+4,'#fff0bf',4)+(down!==null?line(180,242,r.cursor.x,r.cursor.y,'#efd9a6',3):'')+`<rect x="30" y="224" width="300" height="15" fill="#222132"/><rect x="${30+300*2600/4000}" y="224" width="${300*700/4000}" height="15" fill="#407955"/><rect x="30" y="224" width="${Math.min(300,300*q/4000)}" height="15" fill="${over?'#cf6666':ok?'#b8e39f':'#dcbb6e'}" fill-opacity=".8"/>`;
 if(ready(r,t))r.status(down===null?'Зажмите луч и следуйте за трещиной':over?'ПЕРЕГРЕВ':ok?'ОТПУСКАЙТЕ — ИДЕАЛ':`Заряд ${Math.round(q)} · фокус ${Math.round(inside/Math.max(1,total)*100)}%`);
 });
});
register(['machete_route_56'],(o,h)=>{
 const r=setup(o,h,'Два броска, затем два перехвата. Нажимайте нужную руку при пересечении золотой линии. Только две попытки каждой рукой; пропущенный возврат отнимает 3% максимальных HP.','<button class="btn blade56" data-hand="0">Левая рука</button><button class="btn blade56" data-hand="1">Правая рука</button>');r.state.actions=[];
 document.querySelectorAll('.blade56').forEach(b=>b.onclick=()=>{const hand=+b.dataset.hand,ms=r.elapsed();if(ms<o.prepare_ms||r.state.actions.filter(a=>a.hand===hand).length>=2)return;r.state.actions.push({hand,ms});if(r.state.actions.length===4)r.finish()});
 r.animate(t=>{let out=text(180,24,'БРОСОК · БРОСОК · ПЕРЕХВАТ · ПЕРЕХВАТ',12);for(let hand=0;hand<2;hand++){const x=hand?260:100,ev=o.events.filter(e=>e.hand===hand),n=r.state.actions.filter(a=>a.hand===hand).length;out+=`<rect x="${x-30}" y="172" width="60" height="36" rx="6" fill="#577d5133"/><rect x="${x-30}" y="183" width="60" height="14" fill="#dab66333"/>`+line(x,45,x,220,'#635c7b',5)+line(x-35,190,x+35,190,'#e8c478',3)+circle(x,226,21,'#574236','#d7b87f')+text(x,252,hand?'ПРАВАЯ':'ЛЕВАЯ',13);for(const e of ev){const delta=t-e.ms;if(Math.abs(delta)<1100*o.factor){const y=190+(e.catch?1:-1)*delta/(1100*o.factor)*140;out+=`<path d="M${x-6} ${y+16} L${x+5} ${y-18} Q${x+25} ${y-28} ${x+16} ${y-1}Z" fill="${Math.abs(delta)<(e.catch?55:65)*o.factor?'#ffef9e':'#b6b8bc'}" stroke="#ded1ae"/>`+text(x+38,Math.max(55,Math.min(200,y)),e.catch?'↓':'↑',20)}}out+=text(x,35,`${n}/2`,13)}
 r.svg.innerHTML=out;if(ready(r,t)){const next=o.events.find(e=>e.ms>=t-130*o.factor);r.status(next?`${next.catch?'ЛОВИТЕ':'БРОСАЙТЕ'} · ${next.hand?'ПРАВАЯ':'ЛЕВАЯ'} РУКА`:'Клинки возвращаются…')}document.querySelectorAll('.blade56').forEach(b=>b.disabled=t<o.prepare_ms||r.state.actions.filter(a=>a.hand===+b.dataset.hand).length>=2);
 });
});
register(['vital_cut_56'],(o,h)=>{
 const r=setup(o,h,'Один разрез: зажмите первую метку, ровно проведите ко второй и отпустите на вспышке сердца. Идеал гарантирует крит. Важны и точность линии, и ритм.');let down=null;
 r.svg.onpointerdown=e=>{e.preventDefault();const p=r.pos(e),t=r.elapsed();if(down!==null||t<o.prepare_ms||!near([p.x,p.y],o.entry,40))return;r.svg.setPointerCapture(e.pointerId);down=t;r.state.down_ms=t;exact(r,t,p)};
 r.svg.onpointerup=e=>{if(down===null)return;r.state.up_ms=r.elapsed();exact(r,r.state.up_ms,r.pos(e));r.finish()};r.svg.onpointercancel=r.svg.onpointerup;
 r.animate(t=>{const err=Math.min(...o.beats.map(b=>Math.abs(t-b)))/o.factor,flash=err<=55;let out=`<path d="M180 26 C150 26 145 70 163 87 L130 127 L118 224 L242 224 L230 127 L197 87 C215 70 210 26 180 26Z" fill="#56465477" stroke="#927a89"/>`+line(...o.entry,...o.exit,'#bf697b',3)+circle(...o.entry,13,'#53664f','#b6dba5')+text(o.entry[0],o.entry[1]+5,'1',15)+circle(...o.exit,13,flash?'#f8df88':'#78474f','#edb7a6')+text(o.exit[0],o.exit[1]+5,'2',15)+text(180,35,flash?'♥':'♡',flash?31:24,flash?'#ffc8a0':'#a16c7a');
 const p=r.state.points.filter(p=>p.t>=down);if(down!==null)for(let i=1;i<p.length;i++)out+=line(p[i-1].x,p[i-1].y,p[i].x,p[i].y,'#ead7b4',3);out+=line(35,245,325,245,'#59526c',4);o.beats.forEach(b=>out+=circle(35+290*b/o.time_limit_ms,245,4,'#cba56f'));out+=circle(35+290*t/o.time_limit_ms,245,6,flash?'#ffdf90':'#bba4c5');r.svg.innerHTML=out;if(ready(r,t))r.status(flash?'ВСПЫШКА — ОТПУСКАЙТЕ':down===null?'Начните разрез от метки 1':'Ровно к метке 2 · отпустите на вспышке');
 });
});
})();
