/* Hero Arena 5.3.5 — tooltips; hide mob cards; battle intro; snappy anims */
(function () {
  const st = document.createElement("style");
  st.id = "v53styles";
  st.textContent = `
  /* 1/B: figures fully opaque — no blend, no fade-through */
  #cutscene .cs-figure,
  #cutscene .cs-figure.on,
  #cutscene .cs-figure-side,
  #cutscene .cs-figure-side.on{
    opacity:1 !important; mix-blend-mode:normal !important;
    -webkit-mask-image:none !important; mask-image:none !important;
    filter:drop-shadow(0 8px 18px #000a) !important;
  }
  #cutscene .cs-figure.cs-loading{opacity:0 !important;visibility:hidden !important}
  #cutscene .cs-figure-side{display:none !important} /* 11: no duplicate left copy */
  #cutscene .cs-shade{opacity:.55 !important; pointer-events:none}
  /* 5: larger story UI — БЕЗ поломки transform узлов карты */
  .story-layout{grid-template-columns:1.35fr 1fr !important;gap:16px !important}
  #storyMap{min-height:520px !important;font-size:15px}
  /* E: сохраняем translate(-50%,-50%) — иначе узлы съезжают; портреты крупные */
  #storyMap .node{
    transform:translate(-50%,-50%) !important;
    width:82px !important;height:82px !important;font-size:34px !important;
    background-size:cover !important;background-position:center !important;
    overflow:visible;
  }
  #storyMap .node .node-portrait{
    overflow:hidden;border-radius:50%;
  }
  #storyMap .node label{
    position:absolute;top:100%;left:50%;transform:translateX(-50%);
    white-space:nowrap;font-size:12px !important;line-height:1.2;
    color:#fff;text-shadow:0 0 4px #000,0 1px 2px #000,0 0 2px #000;
    margin-top:4px;pointer-events:none;z-index:2;
    max-width:120px;overflow:hidden;text-overflow:ellipsis;
    background:#0008;padding:1px 6px;border-radius:6px;
  }
  #storyMap .node.boss{width:100px !important;height:100px !important;font-size:44px !important}
  #storyMap .node.elite{width:90px !important;height:90px !important}
  #storyMap .node .node-portrait{
    position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;
    pointer-events:none;
  }
  #storyMap .node .node-icon{position:relative;z-index:1;text-shadow:0 0 4px #000,0 0 2px #000}
  #storyMap .node.has-portrait .node-icon{font-size:0;opacity:0}
  .story-stage-card{font-size:15.5px !important}
  .story-stage-card h3{font-size:22px !important}
  .story-enemy-desc{font-size:14.5px !important;line-height:1.45}
  .story-fight-btn{font-size:20px !important;padding:16px 22px !important}
  #storyInfo .panel, #story .panel{font-size:15px}
  /* 10: per-figure sizing (logical) */
  #cutscene .cs-figure.fig-bandit{height:min(62vh,520px)!important;bottom:6%!important}
  #cutscene .cs-figure.fig-goblin{height:min(58vh,480px)!important;bottom:8%!important}
  #cutscene{overflow:hidden}
  #cutscene .cs-figure.fig-assassin{height:min(68vh,580px)!important;bottom:4%!important;object-position:center bottom!important}
  #cutscene .cs-figure.on{transform:translateX(-50%) translateY(0) scale(1.02)!important}
  #cutscene .cs-figure.fig-killer{height:min(70vh,600px)!important}
  #cutscene .cs-figure.fig-magician{height:min(65vh,560px)!important}
  #cutscene .cs-figure.fig-karrgall{height:min(78vh,700px)!important;bottom:4%!important}
  #cutscene .cs-figure.fig-wolf{height:min(55vh,460px)!important;bottom:10%!important}
  #cutscene .cs-figure.fig-ghostcat{height:min(50vh,420px)!important;bottom:14%!important}
  #cutscene .cs-figure.fig-bloodbear{height:min(72vh,640px)!important}
  #cutscene .cs-figure.fig-greatdeer{height:min(75vh,660px)!important}
  #cutscene .cs-figure.fig-radogast{height:min(70vh,600px)!important}
  #cutscene .cs-figure.fig-snake{height:min(60vh,520px)!important}
  #cutscene .cs-figure.fig-owlbeast{height:min(68vh,580px)!important}
  #cutscene .cs-figure.fig-satyr{height:min(66vh,560px)!important}
  #cutscene .cs-figure.fig-murloc{height:min(52vh,440px)!important;bottom:12%!important}
  #cutscene .cs-figure.fig-giant_croc{height:min(70vh,600px)!important;bottom:2%!important}
  #cutscene .cs-figure.fig-swamp_monster{height:min(74vh,640px)!important}
  #cutscene .cs-figure.fig-fisherman{height:min(64vh,540px)!important}
  #cutscene .cs-figure.fig-ogre_fisher{height:min(72vh,620px)!important}
  #cutscene .cs-figure.fig-frog{height:min(48vh,400px)!important;bottom:16%!important}
  #cutscene .cs-figure.fig-hydra{height:min(80vh,720px)!important;bottom:0%!important}
  #cutscene .cs-figure.fig-croc{height:min(76vh,680px)!important;bottom:2%!important}
  #cutscene .cs-figure.fig-dayla.fairy, #cutscene .cs-figure.fairy{height:min(36vh,280px)!important}
  /* 12: fork choice modal */
  #modal2.fork-choice .box{
    max-width:min(820px,96vw)!important;padding:0!important;overflow:hidden;
    background:#0d0a12 url("/static/images/story/swamp_fork.jpg") center/cover!important;
    border:2px solid #f5b94288;
  }
  #modal2.fork-choice .fork-inner{
    background:linear-gradient(180deg,#000c 0%,#0008 40%,#000b 100%);
    padding:28px 22px 22px;text-align:center;min-height:280px;
    display:flex;flex-direction:column;justify-content:flex-end;gap:8px;
  }
  #modal2.fork-choice h3{color:var(--gold);font-size:22px;text-shadow:0 2px 8px #000}
  `;
  document.head.appendChild(st);
})();

// ----- 11+1+8+10: cutscene figure logic -----
(function () {
  function figClassFromSrc(src) {
    if (!src) return "";
    const m = String(src).match(/fig_([\w]+)\./);
    return m ? "fig-" + m[1] : "";
  }
  // Patch _csShowFigure if present
  const boot = () => {
    if (!window.__csAntiFlash || !window.__csAntiFlash.show) return false;
    const _show = window.__csAntiFlash.show;
    window.__csAntiFlash.show = function (src, fairy) {
      _show(src, fairy);
      const fig = document.getElementById("csFigure");
      if (!fig) return;
      // strip old fig-* classes
      [...fig.classList].forEach(c => { if (c.startsWith("fig-")) fig.classList.remove(c); });
      const fc = figClassFromSrc(src);
      if (fc) fig.classList.add(fc);
      fig.style.opacity = src ? "1" : "0";
      // never show side duplicate
      const side = document.getElementById("csFigureSide");
      if (side) { side.classList.remove("on"); side.style.display = "none"; side.removeAttribute("src"); }
    };
    return true;
  };
  if (!boot()) {
    const t = setInterval(() => { if (boot()) clearInterval(t); }, 50);
    setTimeout(() => clearInterval(t), 5000);
  }

  const ENEMY_SPEAKERS = new Set(["bandit","magician","gazlow","goblin","killer","altair","assassin",
    "wolf","ghostcat","bloodbear","greatdeer","radogast","druid","snake","wolves","grozokryl",
    "owlbeast","shibek","satyr","murloc","giant_croc","swamp_monster","fisherman","shrek","ogre",
    "frog_king","hydra","hydra_head","croc","croc_boss","karrgall","gnuss","hooded_killer",
    "pack_wolf","giant_snake","frog"]);

  function enemySpeaksIn(lines) {
    return (lines || []).some(l => l && ENEMY_SPEAKERS.has(l.speaker));
  }
  function stripEnemyFigure(sc) {
    if (!sc) return;
    sc.figure = null;
    sc.enemy_figure = null;
    (sc.lines || []).forEach(l => {
      if (!l || !l.figure) return;
      if (/fig_dayla|dayla|fairy/i.test(l.figure)) return;
      if (l.speaker === "dayla") return;
      // убрать фигуру врага с реплик рассказчика/героя после боя
      if (l.speaker === "narrator" || l.speaker === "hero" || l.speaker === "tavern") {
        delete l.figure;
      }
    });
  }

  // C: полностью перехватываем storyDialogue для after — не передаём figure врага
  if (typeof storyDialogue === "function") {
    const _sd0 = storyDialogue;
    storyDialogue = function (key, which, then) {
      if (which !== "after") return _sd0(key, which, then);
      // найти этап
      let s = null, parentLoc = null;
      if (typeof storyData !== "undefined" && storyData) {
        for (const L of (storyData.locations || [])) {
          const hit = (L.stages || []).find(x => x.key === key);
          if (hit) { s = hit; parentLoc = L; break; }
        }
      }
      if (!s) return _sd0(key, which, then);
      const canAfter = s.replay_after != null ? s.replay_after : (s.status === "done");
      if (!canAfter) {
        toast("🔒 Кат-сцена после боя откроется, когда победите этого противника", "warn");
        return then && then();
      }
      const lines = s.after || [];
      if (!lines.length) return then && then();
      const bg = s.after_background || s.background || (parentLoc && (parentLoc.cutscene_bg || parentLoc.image));
      const title = (parentLoc && parentLoc.title) || "";
      const keepFig = enemySpeaksIn(lines) ? (s.figure || null) : null;
      const beforeBg = s.background || bg;
      const afterBg = s.after_background || bg;
      // 5.3.3: разбить after — пока враг говорит (бой/ворота), потом лор на after_background без фигуры
      const NON = new Set(["dayla", "hero", "narrator", "tavern"]);
      let lastEnemy = -1;
      lines.forEach((l, i) => { if (l && !NON.has(l.speaker)) lastEnemy = i; });
      let scenes;
      if (keepFig && lastEnemy >= 0 && afterBg && afterBg !== beforeBg && lastEnemy < lines.length - 1) {
        const part1 = lines.slice(0, lastEnemy + 1);
        const part2 = lines.slice(lastEnemy + 1);
        scenes = [
          { lines: part1, background: beforeBg, title, figure: keepFig, enemy_figure: keepFig, _v53_after: true },
          { lines: part2, background: afterBg, title, figure: null, enemy_figure: null, _v53_after: true, hide_enemy_unless_speaks: true },
        ];
        stripEnemyFigure(scenes[1]);
      } else {
        scenes = (typeof dialogueScene === "function")
          ? dialogueScene(lines, bg, title, keepFig)
          : [{ lines, background: bg, title, figure: keepFig }];
        (Array.isArray(scenes) ? scenes : [scenes]).forEach(sc => {
          if (!sc) return;
          sc._v53_after = true;
          sc.hide_enemy_unless_speaks = true;
          if (!keepFig) stripEnemyFigure(sc);
          else { sc.figure = keepFig; sc.enemy_figure = keepFig; }
        });
      }
      return playCutscene(scenes, storyData && storyData.hero, then);
    };
  }

  if (typeof playCutscene === "function") {
    const _pc = playCutscene;
    playCutscene = function (scenes, hero, onDone) {
      const list = Array.isArray(scenes) ? scenes : [scenes];
      list.forEach(sc => {
        if (!sc) return;
        const isAfter = !!(sc.after_mode || sc.which === "after" || sc._v53_after || sc.hide_enemy_unless_speaks);
        if (isAfter && !enemySpeaksIn(sc.lines)) stripEnemyFigure(sc);
      });
      return _pc(list, hero, onDone);
    };
  }

  // Патч системного _csApplySpeakerFigure: в after без реплик врага не показывать врага
  (function patchApply() {
    const tryPatch = () => {
      // v51 держит логику внутри IIFE; перехватываем через обёртку _csShowFigure уже есть.
      // Дополнительно: при after-режиме чистим фигуру на narrator, если sc без figure.
      if (typeof window.__csAntiFlash === "undefined") return false;
      return true;
    };
    if (!tryPatch()) {
      const t = setInterval(() => { if (tryPatch()) clearInterval(t); }, 50);
      setTimeout(() => clearInterval(t), 4000);
    }
  })();

  // 11: dayla should NOT also summon side figure — patch by hiding side always (CSS) + clear on show
  // When dayla speaks with enemy present: show ONLY enemy center OR only dayla — user asked one scene figure
  // Prefer: speaking character as the scene figure (dayla when she speaks; enemy when enemy speaks)
  // 5.3.1: без MutationObserver — .cs-figure-side скрыт CSS; разовая зачистка
  const obs = setInterval(() => {
    const side = document.getElementById("csFigureSide");
    if (!side && typeof window.__csAntiFlash === "undefined") return;
    clearInterval(obs);
    if (side) { side.classList.remove("on"); side.style.display = "none"; side.removeAttribute("src"); }
  }, 100);
})();

// ----- 12: fork choice UI with swamp_fork background -----
(function () {
  if (typeof showStoryChoice !== "function") return;
  const _ch = showStoryChoice;
  showStoryChoice = function (choice) {
    const bg = (choice && choice.background) || "/static/images/story/swamp_fork.jpg";
    const modal = document.getElementById("modal2");
    const box = document.getElementById("modal2Box");
    if (!modal || !box) return _ch(choice);
    modal.classList.add("fork-choice");
    box.style.backgroundImage = `url("${bg}")`;
    box.innerHTML = `<div class="fork-inner">
      <h3>${esc(choice.prompt || "Выбор")}</h3>
      ${(choice.options || []).map(o =>
        `<div><button class="btn" style="width:min(420px,90%);font-size:16px;padding:12px"
          onclick="pickStoryPath('${choice.id}','${o.key}');document.getElementById('modal2').classList.remove('fork-choice')">
          ${esc(o.label)}</button></div>`).join("")}
      </div>`;
    modal.style.display = "flex";
  };
})();

// ----- 2 / A: убрать тестовую арену; мобы — обычные герои через /api/classes в,dev -----
(function () {
  const kill = () => {
    const p = document.getElementById("testArenaPanel");
    if (p) p.remove();
  };
  kill();
  window.ensureTestArenaUI = function () { kill(); };
  window.startTestArena = async function () {
    toast("В режиме разработчика мобы создаются как обычные герои", "ok");
  };
  // больше НЕ инжектим test: опции и НЕ перехватываем startBattle
})();

// ----- 3: random skin — never default (null) -----
// Server also patched; UI hint
(function () {
  const _toggle = window.toggleRandomSkin;
  if (_toggle) {
    window.toggleRandomSkin = async function (heroId, enabled) {
      return _toggle(heroId, enabled);
    };
  }
})();

// ----- 4: единая сумка сюжета = инвентарь 5 кг / 10 слотов -----
window.openStoryBag = async function () {
  const hid = (typeof _storyHeroId === "function" ? _storyHeroId() : null)
    || (document.getElementById("storyHero") || {}).value;
  if (!hid) return toast("Сначала создайте сюжетного героя");
  const data = await api(`/api/heroes/${hid}/story_bag`);
  if (!data) return;
  const inv = data.inventory || {items: [], total_weight: 0, max_weight: 5, max_slots: 10};
  const pending = data.pending_loot || [];
  const w = inv.total_weight || 0;
  const mw = inv.max_weight || 5;
  const items = inv.items || [];
  let html = `<h3 style="color:var(--gold);margin-top:0">🎒 Инвентарь — ${(w).toFixed(1)}/${mw} кг · ${items.length}/${inv.max_slots || 10} слотов</h3>`;
  html += `<div class="bar wbar" style="height:16px;margin-bottom:10px"><div style="width:${Math.min(100, 100 * w / mw)}%"></div><span style="line-height:16px">⚖ ${w.toFixed(1)} / ${mw} кг</span></div>`;
  if (pending.length) {
    html += `<div style="background:#422;border:1px solid #a55;border-radius:8px;padding:8px;margin-bottom:8px">
      ⚠ Нет места — ждёт: ${pending.map(k => {
        const info = (typeof itemInfo === "function") ? itemInfo(k) : ["📦", k];
        return `${info[0]} ${esc(info[1] || k)}`;
      }).join(", ")}
      <div style="margin-top:6px"><button class="btn small" onclick="claimStoryPending()">Забрать свободное</button></div>
    </div>`;
  }
  if (!items.length) html += `<p class="muted">Пусто — награды за бои появятся здесь.</p>`;
  else {
    html += `<div class="inv-grid" style="grid-template-columns:repeat(auto-fill,minmax(110px,1fr))">` +
      items.map(it => {
        const key = it.key || "";
        return `<div class="inv-slot full" style="flex-direction:column;height:auto;padding:8px">
        <div style="font-size:28px">${it.icon || "📦"}</div>
        <b style="font-size:12px">${esc(it.name || key)}</b>
        <span class="muted">${(it.weight != null ? it.weight : "?")} кг</span>
        ${key ? `<button class="btn small red" style="margin-top:4px" onclick="discardStoryItem('${key}', '${esc(it.name || key)}')">Выбросить</button>` : ""}
      </div>`;
      }).join("") + `</div>`;
  }
  html += `<div style="margin-top:12px"><button class="btn" onclick="_closeModal2()">Закрыть</button></div>`;
  if (typeof _modal2 === "function") _modal2(html);
  else if (typeof openInventory === "function") await openInventory(+hid, false);
};

// ----- 7: split action feeds — my card = enemy→me; enemy card = me→enemy -----
(function () {
  function install() {
    if (!window.__actionFeed) return false;
    const push = window.__actionFeed.push;
    const rebuild = window.__actionFeed.rebuild;
    window.__actionFeed.ingestSplit = function (b, e) {
      if (!b || !e || !e.text || !b.heroes || b.heroes.length < 2) return;
      const me = b.heroes.find(h => !(b.ai_ids || []).includes(h.id)) || b.heroes[0];
      const foe = b.heroes.find(h => h.id !== me.id) || b.heroes[1];
      const text = e.text;
      const kind = e.kind || "info";
      const roundish = /^— Раунд|инициатива|Бой:|🧪|🏆|Ничья|Раунд \d+/.test(text) || kind === "info" && /Раунд/.test(text);
      if (roundish || kind === "win") {
        push(b, me.id, text, kind);
        push(b, foe.id, text, kind);
        return;
      }
      // Under MY card: what enemy did to me
      // Under ENEMY card: what I did to them
      const aboutMe = text.includes(me.name);
      const aboutFoe = text.includes(foe.name);
      const actorIsMe = e.actor_id === me.id || (aboutMe && /^(⚔|💥|🌀|⚡|🗡|✨|🔥|🩸)/.test(text) === false && text.indexOf(me.name) < (text.indexOf(foe.name) + 1));
      // Heuristic: if line mentions foe as target of damage from me → enemy feed
      // if line mentions me taking damage / effects → my feed
      const dmgToFoe = aboutFoe && (aboutMe || true) && /(урон|крит|накладывает|кровотечение|яд|ожог|замедл|оглуш|контратак)/i.test(text) && text.indexOf(foe.name) > 0;
      const dmgToMe = aboutMe && /(урон|крит|накладывает|кровотечение|яд|ожог|замедл|оглуш|получает)/i.test(text);

      // Prefer actor_id when present
      if (e.actor_id != null) {
        if (e.actor_id === me.id) push(b, foe.id, text, kind);      // my actions → under enemy
        else if (e.actor_id === foe.id) push(b, me.id, text, kind); // enemy actions → under me
        else { push(b, me.id, text, kind); push(b, foe.id, text, kind); }
        return;
      }
      if (aboutFoe && !aboutMe) { push(b, foe.id, text, kind); return; }
      if (aboutMe && !aboutFoe) { push(b, me.id, text, kind); return; }
      if (aboutMe && aboutFoe) {
        // "X — skill: N урона по Y" → feed of Y (target)
        const m = text.match(/по\s+([^!.]+)/);
        if (m) {
          const tgt = m[1].trim();
          if (tgt.includes(foe.name)) push(b, foe.id, text, kind);
          else if (tgt.includes(me.name)) push(b, me.id, text, kind);
          else { push(b, me.id, text, kind); push(b, foe.id, text, kind); }
        } else {
          push(b, me.id, text, kind);
          push(b, foe.id, text, kind);
        }
        return;
      }
      push(b, me.id, text, kind);
      push(b, foe.id, text, kind);
    };

    // Replace rebuildFromLog / observer path by wrapping playLog already using ingest
    const _pl = playLog;
    playLog = async function (b) {
      // temporarily replace heroes.forEach name match with split ingest
      const bagClear = window.__actionFeed;
      const origPush = bagClear.push;
      // monkeypatch during playLog: MutationObserver in v51 pushes by name — override pushActionFeed via wrap
      const feeds = window._actionFeeds;
      // Use wrapper on window.__actionFeed.push called from observer — observer calls pushActionFeed directly
      return _pl(b);
    };
    return true;
  }
  if (!install()) {
    const t = setInterval(() => { if (install()) clearInterval(t); }, 100);
    setTimeout(() => clearInterval(t), 5000);
  }
})();

// Stronger feed split: replace v51 ingest by patching after load
(function () {
  function patchFeeds() {
    if (!window.__actionFeed || !window.__actionFeed.rebuild) return false;
    const MAX_FEED = 4;
    function ensure(b) {
      const id = b && b.id != null ? String(b.id) : "active";
      if (!window._actionFeeds[id]) window._actionFeeds[id] = {};
      return window._actionFeeds[id];
    }
    function push(b, heroId, text, kind) {
      if (!b || heroId == null || !text) return;
      const bag = ensure(b);
      const k = String(heroId);
      if (!bag[k]) bag[k] = [];
      const line = String(text).length > 90 ? String(text).slice(0, 87) + "…" : String(text);
      if (bag[k][0] && bag[k][0].text === line) return;
      bag[k].unshift({ text: line, kind: kind || "info" });
      if (bag[k].length > MAX_FEED) bag[k].length = MAX_FEED;
    }
    function splitIngest(b, e) {
      if (!b || !e || !e.text || !b.heroes || b.heroes.length < 2) return;
      const text = e.text, kind = e.kind || "info";
      const me = b.heroes.find(h => !(b.ai_ids || []).includes(h.id)) || b.heroes[0];
      const foe = b.heroes.find(h => h.id !== me.id) || b.heroes[1];
      if (/^— Раунд|инициатива|Бой:|🧪 Тест|🏆|Ничья|устали/.test(text) || kind === "win") {
        push(b, me.id, text, kind); push(b, foe.id, text, kind); return;
      }
      if (e.actor_id === me.id) { push(b, foe.id, text, kind); return; }
      if (e.actor_id === foe.id) { push(b, me.id, text, kind); return; }
      const m = text.match(/по\s+([^!.]+)/);
      if (m) {
        const tgt = m[1];
        if (tgt.includes(foe.name)) { push(b, foe.id, text, kind); return; }
        if (tgt.includes(me.name)) { push(b, me.id, text, kind); return; }
      }
      // effect on someone
      if (text.includes(foe.name) && !text.includes(me.name)) { push(b, foe.id, text, kind); return; }
      if (text.includes(me.name) && !text.includes(foe.name)) { push(b, me.id, text, kind); return; }
      if (text.includes(me.name) && text.includes(foe.name)) {
        // default: show under target mentioned after "по" else both
        push(b, foe.id, text, kind);
        return;
      }
      push(b, me.id, text, kind); push(b, foe.id, text, kind);
    }
    window.__actionFeed.rebuild = function (b, upto) {
      if (!b) return;
      const id = b.id != null ? String(b.id) : "active";
      window._actionFeeds[id] = {};
      if (!b.log) return;
      const end = Math.min(upto == null ? b.log.length : upto, b.log.length);
      const start = Math.max(0, end - 24);
      for (let i = start; i < end; i++) splitIngest(b, b.log[i]);
    };
    // Patch playLog observer by wrapping playLog
    const _pl = playLog;
    playLog = async function (b) {
      if (!b) return _pl(b);
      window.__actionFeed.rebuild(b, typeof shownLog === "number" ? shownLog : 0);
      window.__actionFeed.paint(b);
      const box = document.getElementById("log");
      const mo = new MutationObserver(muts => {
        if (!battle) return;
        muts.forEach(m => m.addedNodes.forEach(node => {
          if (!node || node.nodeType !== 1) return;
          const text = node.textContent || "";
          if (!text) return;
          const kind = (node.className || "").toString().replace(/^k-/, "") || "info";
          splitIngest(battle, { text, kind });
          window.__actionFeed.paint(battle);
        }));
      });
      if (box) mo.observe(box, { childList: true });
      try { await _pl(b); }
      finally { mo.disconnect(); }
      window.__actionFeed.rebuild(b, typeof shownLog === "number" ? shownLog : (b.log || []).length);
      window.__actionFeed.paint(b || battle);
    };
    return true;
  }
  if (!patchFeeds()) {
    const t = setInterval(() => { if (patchFeeds()) clearInterval(t); }, 100);
    setTimeout(() => clearInterval(t), 8000);
  }
})();

// ----- E: портреты на узлах карты (все локации) -----
(function () {
  if (typeof renderStoryMap !== "function") return;
  const _rsm = renderStoryMap;
  renderStoryMap = function (loc, hid) {
    _rsm(loc, hid);
    const map = document.getElementById("storyMap");
    if (!map || !loc) return;
    // Перерисуем узлы с портретами, сохраняя позиции x/y
    const stages = (loc.stages || []).filter(s => !s.hidden && (!s.secret || s.status !== "locked"));
    map.innerHTML = stages.map(s => {
      const st = hid ? s.status : "locked";
      const img = s.image ? `<img class="node-portrait" src="${s.image}" alt="" onerror="this.remove();this.parentNode.classList.remove('has-portrait')">` : "";
      const has = s.image ? "has-portrait" : "";
      return `<div class="node ${st} ${s.boss ? "boss" : ""} ${s.elite ? "elite" : ""} ${s.secret ? "secret" : ""} ${has}"
        style="left:${s.x}%;top:${s.y}%" onclick="pickStage('${s.key}')">
        ${img}<span class="node-icon">${s.icon || ""}</span>
        <label>${esc(s.name || s.title)}${s.boss ? " 👑" : s.elite ? " ⭐" : ""}</label></div>`;
    }).join("");
  };
})();

// ----- F: случайный соперник -----
window.pickRandomOpponent = function () {
  const s1 = document.getElementById("h1");
  const s2 = document.getElementById("h2");
  if (!s2) return;
  const mine = s1 ? String(s1.value) : "";
  const opts = [...s2.options].filter(o => o.value && String(o.value) !== mine);
  if (!opts.length) return toast("Нет доступных соперников", "warn");
  const pick = opts[Math.floor(Math.random() * opts.length)];
  s2.value = pick.value;
  s2.dispatchEvent(new Event("change"));
  toast("🎲 Соперник: " + pick.textContent.trim(), "ok");
};

// Кнопка рядом с #h2
(function () {
  function ensureBtn() {
    if (document.getElementById("randOppBtn")) return;
    const s2 = document.getElementById("h2");
    if (!s2 || !s2.parentNode) return;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.id = "randOppBtn";
    btn.className = "btn small ghost";
    btn.textContent = "🎲 Случайный соперник";
    btn.title = "Выбрать случайного соперника из списка";
    btn.onclick = () => pickRandomOpponent();
    s2.insertAdjacentElement("afterend", btn);
  }
  ensureBtn();
  document.addEventListener("DOMContentLoaded", ensureBtn);
  setTimeout(ensureBtn, 300);
})();


// C: страховка для v43 showResult — не показывать врага после боя без его реплик
(function () {
  if (typeof showResult !== "function") return;
  const _sr = showResult;
  const ALLY = new Set(["dayla","hero","narrator","tavern"]);
  showResult = function (b) {
    if (b && b.story && Array.isArray(b.story.after)) {
      const enemySpeaks = b.story.after.some(l => l && l.speaker && !ALLY.has(l.speaker));
      if (!enemySpeaks) {
        b.story.after_figure = null;
        b.story.figure = null;
      } else if (b.story.after_figure == null && b.story.figure) {
        b.story.after_figure = b.story.figure;
      }
    }
    return _sr(b);
  };
})();

console.log("[v53.5] loaded");


// ----- 5.3.3/5.3.5: heal already in v40; role tooltips (opaque floating); sort;dev-mobs only in battle selects -----
(function () {
  const ROLE_DESC = {
    tank: "Танк: много HP и брони, сильные защитные умения (щиты, регенерация, снижение урона). Медленнее бьёт, зато долго держится в бою.",
    warrior: "Воин: сбалансированный боец ближнего боя — крепкий корпус, хороший урон и надёжные боевые навыки без крайностей танка или ловкача.",
    light: "Лёгкий: меньше HP, зато высокая скорость, дистанция или магия. Сильные умения с ресурсом (мана/энергия), часто бьёт через броню или с эффектами.",
    trickster: "Ловкач: мало HP, много уклонения и критических ударов. Ставка на хитрость, яды, скрытность и серии быстрых атак.",
  };
  const ROLE_ORDER = {tank: 0, warrior: 1, light: 2, trickster: 3};

  // Улучшенный бейдж роли с подсказкой
  const _rb = window.roleBadge;
  window.roleBadge = function (h) {
    if (!h || !h.role) return "";
    const tip = ROLE_DESC[h.role] || ("Роль: " + (h.role_name || h.role));
    const ic = (typeof ROLE_ICON !== "undefined" && ROLE_ICON[h.role]) || "";
    return `<span class="badge role-${h.role} role-tip" tabindex="0" data-role="${h.role}" data-tip="${tip.replace(/"/g, "&quot;")}" title="">${ic} ${esc(h.role_name)}</span>`;
  };

  // 5.3.5: непрозрачная плавающая подсказка в body (не клипится overflow модалки)
  const st = document.createElement("style");
  st.id = "v533roles";
  st.textContent = `
  .badge.role-tip{cursor:help;position:relative}
  #roleTipFloat{
    position:fixed;display:none;z-index:10000;pointer-events:none;
    background:#16101f;color:#f5e6c8;border:1px solid #f5b942;border-radius:8px;
    padding:10px 12px;width:min(280px,calc(100vw - 24px));max-width:280px;
    white-space:normal;font-size:13px;line-height:1.4;font-weight:500;
    box-shadow:0 8px 24px #000c;text-align:left;opacity:1;
  }
  #heroSort{margin-left:4px}
  /* не дублировать ⭐ из v50 ::before — бейдж уже в тексте label */
  #storyMap .node.elite label::before{content:none !important}
  `;
  document.head.appendChild(st);

  let floatTip = document.getElementById("roleTipFloat");
  if (!floatTip) {
    floatTip = document.createElement("div");
    floatTip.id = "roleTipFloat";
    document.body.appendChild(floatTip);
  }
  let pinnedTip = null;

  function placeRoleTip(badge) {
    const text = badge.getAttribute("data-tip") || "";
    if (!text) { hideRoleTip(); return; }
    floatTip.textContent = text;
    floatTip.style.display = "block";
    floatTip.style.left = "0px";
    floatTip.style.top = "0px";
    const r = badge.getBoundingClientRect();
    const tw = floatTip.offsetWidth;
    const th = floatTip.offsetHeight;
    const gap = 8;
    const pad = 8;
    let top = r.top - th - gap;
    if (top < pad) top = r.bottom + gap;
    if (top + th > window.innerHeight - pad) top = Math.max(pad, window.innerHeight - th - pad);
    let left = r.left + r.width / 2 - tw / 2;
    if (left < pad) left = pad;
    if (left + tw > window.innerWidth - pad) left = Math.max(pad, window.innerWidth - tw - pad);
    floatTip.style.left = left + "px";
    floatTip.style.top = top + "px";
  }
  function hideRoleTip() {
    floatTip.style.display = "none";
    floatTip.textContent = "";
  }
  function showHoverTip(badge) {
    if (pinnedTip && pinnedTip !== badge) return;
    placeRoleTip(badge);
  }

  document.addEventListener("mouseover", e => {
    const tip = e.target.closest && e.target.closest(".badge.role-tip");
    if (tip) showHoverTip(tip);
  });
  document.addEventListener("mouseout", e => {
    const tip = e.target.closest && e.target.closest(".badge.role-tip");
    if (!tip) return;
    const to = e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest(".badge.role-tip");
    if (to === tip) return;
    if (pinnedTip !== tip) hideRoleTip();
  });
  document.addEventListener("focusin", e => {
    const tip = e.target.closest && e.target.closest(".badge.role-tip");
    if (tip) showHoverTip(tip);
  });
  document.addEventListener("focusout", e => {
    const tip = e.target.closest && e.target.closest(".badge.role-tip");
    if (tip && pinnedTip !== tip) hideRoleTip();
  });
  document.addEventListener("click", e => {
    const tip = e.target.closest && e.target.closest(".badge.role-tip");
    document.querySelectorAll(".badge.role-tip.tip-on").forEach(el => { if (el !== tip) el.classList.remove("tip-on"); });
    if (tip) {
      e.preventDefault();
      e.stopPropagation();
      const on = tip.classList.toggle("tip-on");
      pinnedTip = on ? tip : null;
      if (on) placeRoleTip(tip); else hideRoleTip();
    } else {
      pinnedTip = null;
      hideRoleTip();
    }
  }, true);
  window.addEventListener("scroll", () => { if (pinnedTip) placeRoleTip(pinnedTip); else hideRoleTip(); }, true);
  window.addEventListener("resize", () => { if (pinnedTip) placeRoleTip(pinnedTip); else hideRoleTip(); });

  function sortHeroes(list) {
    const mode = (document.getElementById("heroSort") || {}).value || "default";
    const arr = list.slice();
    if (mode === "role") {
      arr.sort((a, b) => (ROLE_ORDER[a.role] ?? 9) - (ROLE_ORDER[b.role] ?? 9)
        || String(a.hero_class).localeCompare(String(b.hero_class), "ru")
        || String(a.name).localeCompare(String(b.name), "ru"));
    } else if (mode === "class") {
      arr.sort((a, b) => String(a.hero_class).localeCompare(String(b.hero_class), "ru")
        || String(a.name).localeCompare(String(b.name), "ru"));

    } else if (mode === "name") {
      arr.sort((a, b) => String(a.name).localeCompare(String(b.name), "ru"));
    }
    return arr;
  }
  function isDevMob(h) {
    return !!(h && (h.dev_mob || h.mob));
  }

  const _lh533 = loadHeroes;
  loadHeroes = async function () {
    await _lh533();
    const p = currentPlayer();
    const inDev = !!(p && p.dev_mode);

    // Пересобрать списки героев: скрыть мобов из карточек, если не,dev; при,dev показать как соперников арены
    const boxMine = document.getElementById("myHeroList");
    const boxOther = document.getElementById("heroList");
    if (boxMine && typeof allHeroes !== "undefined") {
      // owned non-story non-dev_mob (owneddev_mobs should be purged; still filter)
      // rebuild via existing card HTML is hard — instead filter DOM and re-sort
      // Проще: патчим отображение через перерисовку селекторов и скрытие карточек мобов
      // 5.3.5: мобы НИКОГДА не в карточках героев (ни своих, ни «соперников арены»).
      // Только в селекторах «Настройка боя» при режиме разработчика.
      document.querySelectorAll("#myHeroList .hero, #heroList .hero").forEach(el => {
        const id = +el.dataset.id;
        const h = allHeroes.find(x => x.id === id);
        if (h && isDevMob(h)) el.remove();
      });
      // сортировка карточек
      const sortBox = (box) => {
        if (!box) return;
        const cards = [...box.querySelectorAll(".hero")];
        if (!cards.length) return;
        const keyed = cards.map(el => {
          const id = +el.dataset.id;
          return {el, h: allHeroes.find(x => x.id === id) || {name: "", hero_class: "", role: "", level: 0}};
        });
        const sorted = sortHeroes(keyed.map(k => k.h));
        const byId = new Map(keyed.map(k => [k.h.id, k.el]));
        sorted.forEach(h => { const el = byId.get(h.id); if (el) box.appendChild(el); });
      };
      sortBox(boxMine);
      sortBox(boxOther);
    }

    // Селекторы боя: в,dev — мобы как готовые бойцы (🛠👾); без,dev — скрыть
    const s1 = document.getElementById("h1");
    const s2 = document.getElementById("h2");
    if (s1 && inDev && typeof allHeroes !== "undefined") {
      const v1 = s1.value;
      const mine = allHeroes.filter(h => !h.story && (h.owner_id === p.id || h.npc || isDevMob(h)));
      // уникальные / предпочесть owned + npc +dev_mob
      const seen = new Set();
      const opts = [];
      for (const h of sortHeroes(mine)) {
        if (seen.has(h.id)) continue;
        seen.add(h.id);
        const mark = isDevMob(h) ? "🛠👾" : (h.npc ? "🛠🤖" : "👑");
        opts.push(`<option value="${h.id}">${mark} ${esc(h.name)} (${h.hero_class})</option>`);
      }
      s1.innerHTML = opts.join("");
      if (v1 && mine.some(h => h.id == v1)) s1.value = v1;
      if (typeof loadOpponents === "function") await loadOpponents();
      // добить мобов в h2, если API/scrub их не добавил
      if (s2) {
        const have = new Set([...s2.options].map(o => o.value));
        for (const h of sortHeroes(allHeroes.filter(isDevMob))) {
          if (have.has(String(h.id)) || String(h.id) === String(s1.value)) continue;
          const o = document.createElement("option");
          o.value = h.id;
          o.textContent = `🛠👾 ${h.name} (${h.hero_class})`;
          s2.appendChild(o);
        }
      }
    } else if (s1 && !inDev && typeof allHeroes !== "undefined") {
      // убрать мобов из селекторов, если остались
      [...s1.options].forEach(o => {
        const h = allHeroes.find(x => x.id == o.value);
        if (h && isDevMob(h)) o.remove();
      });
      if (s2) {
        [...s2.options].forEach(o => {
          const h = allHeroes.find(x => x.id == o.value);
          if (h && isDevMob(h)) o.remove();
        });
      }
    }
  };

})();


// ----- 5.3.5: пауза «Бой начат!» + плавные быстрые анимации боя -----
(function () {
  const INTRO_MS = 2500;
  const T = {
    round: 40,
    windup: 80,
    base: 160,
    event: 320,
    moved: 180,
    anim: 280,
    float: 450,
    hitDelay: 70,
    dodgeDelay: 60,
  };
  // BEFORE (index.html playLog/anim/float): windup 140, base 300, event 600, moved +420,
  //   anim remove 400, float 1150, hitDelay 150, round 80
  //   ≈ attack with HP change: 140+300+420 = 860 ms block
  // AFTER: ≈ 80+160+180 = 420 ms block; float/anim CSS 280–450 ms ease

  const st = document.createElement("style");
  st.id = "v535battle";
  st.textContent = `
  #battleIntro{
    position:absolute;inset:0;z-index:40;display:none;align-items:center;justify-content:center;
    pointer-events:none;background:radial-gradient(ellipse at center,#0008 0%,#0005 55%,#0000 75%);
  }
  #battleIntro .bi-text{
    font-size:clamp(42px,7vw,72px);font-weight:900;color:var(--gold,#f5b942);
    text-shadow:0 0 24px #f5b942cc,0 4px 0 #5a3a08,0 0 2px #000;
    letter-spacing:.04em;transform:scale(.6);opacity:0;
    animation:biPop .55s cubic-bezier(.2,.9,.3,1.15) forwards;
  }
  #battleIntro .bi-text.bi-count{font-size:clamp(56px,9vw,96px);color:#fff;text-shadow:0 0 28px #f5b942aa,0 0 2px #000}
  @keyframes biPop{
    0%{opacity:0;transform:scale(.55)}
    55%{opacity:1;transform:scale(1.08)}
    100%{opacity:1;transform:scale(1)}
  }
  /* snappy fighter motion — transform/opacity only */
  .fighter.lunge-r{animation:lungeR535 .28s cubic-bezier(.2,.8,.3,1) !important}
  .fighter.lunge-l{animation:lungeL535 .28s cubic-bezier(.2,.8,.3,1) !important}
  .fighter.hit{animation:shake535 .28s cubic-bezier(.2,.7,.3,1) !important}
  .fighter.dodge-l{animation:dodgeL535 .3s cubic-bezier(.2,.8,.3,1) !important}
  .fighter.dodge-r{animation:dodgeR535 .3s cubic-bezier(.2,.8,.3,1) !important}
  .fighter.hit::after,.fighter.glow-g::after,.fighter.glow-b::after{animation:flash535 .28s ease-out !important}
  .fighter.glow-g{animation:none}
  @keyframes lungeR535{0%{transform:translate3d(0,0,0)}40%{transform:translate3d(28px,-10px,0)}100%{transform:translate3d(0,0,0)}}
  @keyframes lungeL535{0%{transform:translate3d(0,0,0)}40%{transform:translate3d(-28px,-10px,0)}100%{transform:translate3d(0,0,0)}}
  @keyframes shake535{0%,100%{transform:translate3d(0,0,0)}30%{transform:translate3d(-5px,0,0)}70%{transform:translate3d(5px,0,0)}}
  @keyframes dodgeL535{0%,100%{transform:translate3d(0,0,0)}50%{transform:translate3d(-22px,0,0)}}
  @keyframes dodgeR535{0%,100%{transform:translate3d(0,0,0)}50%{transform:translate3d(22px,0,0)}}
  @keyframes flash535{from{opacity:.9}to{opacity:0}}
  .float{animation:floatUp535 .45s cubic-bezier(.2,.8,.2,1) forwards !important}
  @keyframes floatUp535{
    0%{opacity:0;transform:translate3d(-50%,8px,0) scale(.75)}
    18%{opacity:1;transform:translate3d(-50%,0,0) scale(1.08)}
    100%{opacity:0;transform:translate3d(-50%,-42px,0) scale(1)}
  }
  .bar>div,.hpbar>div,.enbar>div{transition:width .28s cubic-bezier(.2,.8,.2,1) !important}
  `;
  document.head.appendChild(st);

  function ensureIntroEl() {
    const panel = document.getElementById("arenaPanel");
    if (!panel) return null;
    if (getComputedStyle(panel).position === "static") panel.style.position = "relative";
    let el = document.getElementById("battleIntro");
    if (!el) {
      el = document.createElement("div");
      el.id = "battleIntro";
      el.innerHTML = `<div class="bi-text"></div>`;
      panel.appendChild(el);
    }
    return el;
  }

  async function showBattleIntro() {
    const el = ensureIntroEl();
    if (!el) { await sleep(INTRO_MS); return; }
    const panel = document.getElementById("arenaPanel");
    if (panel) {
      panel.style.display = "block";
      try { panel.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e) {}
    }
    const label = el.querySelector(".bi-text");
    el.style.display = "flex";
    const steps = [
      { t: "3", cls: "bi-text bi-count", ms: 550 },
      { t: "2", cls: "bi-text bi-count", ms: 550 },
      { t: "1", cls: "bi-text bi-count", ms: 550 },
      { t: "⚔ Бой начат!", cls: "bi-text", ms: 850 },
    ];
    for (const s of steps) {
      label.className = s.cls;
      label.textContent = s.t;
      // restart pop animation
      label.style.animation = "none";
      void label.offsetWidth;
      label.style.animation = "";
      await sleep(s.ms);
    }
    el.style.display = "none";
    label.textContent = "";
  }

  // Intro before first playLog of a new fight (first===true, not resume/fast)
  if (typeof update === "function") {
    const _upd = update;
    update = async function (b, first = false) {
      if (first && b && !fast) {
        battle = b;
        busy = true;
        const panel = document.getElementById("arenaPanel");
        if (panel) panel.style.display = "block";
        const prev = shownLog > 0 ? b.log[shownLog - 1] : (b.log && b.log[0]);
        try {
          renderFighters(b, prev && prev.hp_after, true);
        } catch (e) {}
        try {
          renderSkills({ ...b, status: "busy" });
        } catch (e) {}
        const box = document.getElementById("skillBox");
        if (box) box.innerHTML = "";
        const ctl = document.getElementById("battleCtl");
        if (ctl) ctl.innerHTML = "";
        const ri = document.getElementById("roundInfo");
        if (ri) ri.textContent = "Приготовьтесь…";
        await showBattleIntro();
        // busy stays true until _upd finishes
      }
      return _upd(b, first);
    };
  }

  // Snappy anim / float durations
  if (typeof anim === "function") {
    anim = function (el, cls) {
      if (!el) return;
      el.classList.remove(cls);
      void el.offsetWidth;
      el.classList.add(cls);
      setTimeout(() => el.classList.remove(cls), T.anim);
    };
  }
  if (typeof floatNum === "function") {
    floatNum = function (el, delta, small) {
      const f = document.createElement("div");
      f.className = "float " + (delta > 0 ? "heal" : "dmg") + (small ? " small" : "");
      f.textContent = delta > 0 ? `+${delta} HP` : `−${-delta}`;
      el.appendChild(f);
      setTimeout(() => f.remove(), T.float);
    };
  }
  if (typeof animate === "function") {
    animate = function (e) {
      const a = cardOf(e.actor_id), t = cardOf(e.target_id);
      const aIdx = a ? (a.id === "f0" ? 0 : 1) : null;
      switch (e.kind) {
        case "attack": case "crit":
          if (a && t && a !== t) {
            anim(a, aIdx === 0 ? "lunge-r" : "lunge-l");
            setTimeout(() => anim(t, "hit"), T.hitDelay);
          } else anim(subjectCard(e.text), "hit");
          break;
        case "miss":
          if (a) anim(a, aIdx === 0 ? "lunge-r" : "lunge-l");
          if (t) setTimeout(() => anim(t, aIdx === 0 ? "dodge-r" : "dodge-l"), T.dodgeDelay);
          break;
        case "dot": anim(subjectCard(e.text) || a, "hit"); break;
        case "heal": anim(subjectCard(e.text) || a, "glow-g"); break;
        case "shield": anim(subjectCard(e.text.replace(/^.*?Щит /, "")) || a, "glow-b"); break;
        case "stun": anim(subjectCard(e.text), "hit"); break;
        case "event": toast(e.text, "event"); break;
      }
    };
  }

  // Fast playLog — same events/info, shorter waits; keep action feeds
  playLog = async function (b) {
    if (!b) return;
    if (window.__actionFeed && typeof window.__actionFeed.rebuild === "function") {
      try {
        window.__actionFeed.rebuild(b, typeof shownLog === "number" ? shownLog : 0);
        window.__actionFeed.paint(b);
      } catch (e) {}
    }
    const box = document.getElementById("log");
    for (; shownLog < b.log.length; shownLog++) {
      const e = b.log[shownLog];
      const div = document.createElement("div");
      div.className = "k-" + e.kind;
      div.textContent = e.text;
      box.appendChild(div);
      box.scrollTop = box.scrollHeight;
      if (window.__actionFeed) {
        try {
          if (typeof window.__actionFeed.ingestSplit === "function")
            window.__actionFeed.ingestSplit(b, e);
          else if (typeof window.__actionFeed.rebuild === "function")
            window.__actionFeed.rebuild(b, shownLog + 1);
          window.__actionFeed.paint(b);
        } catch (err) {}
      }
      if (fast) {
        applyHp(e.hp_after, false);
        if (e.kind === "event") toast(e.text, "event");
        continue;
      }
      if (e.kind === "round" || e.kind === "info") {
        applyHp(e.hp_after, false);
        await sleep(T.round);
        continue;
      }
      animate(e);
      await sleep(T.windup);
      const moved = applyHp(e.hp_after, true);
      await sleep((e.kind === "event" ? T.event : T.base) + (moved ? T.moved : 0));
    }
    if (window.__actionFeed) {
      try {
        window.__actionFeed.rebuild(b, (b.log || []).length);
        window.__actionFeed.paint(b || battle);
      } catch (e) {}
    }
  };

  // expose timings for verify
  window.__v535BattleTiming = {
    before: { windup: 140, base: 300, event: 600, moved: 420, round: 80, anim: 400, float: 1150, hitDelay: 150,
              attackBlockMs: 140 + 300 + 420, eventBlockMs: 140 + 600 + 420 },
    after: { ...T, attackBlockMs: T.windup + T.base + T.moved, eventBlockMs: T.windup + T.event + T.moved, introMs: INTRO_MS },
  };
})();
