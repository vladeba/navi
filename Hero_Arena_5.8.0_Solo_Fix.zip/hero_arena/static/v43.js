// ===================== 4.3: сюжет — создание героя по карточкам, вступительный ролик, диалоги =====================
(function () {
  const css = `
  .class-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:8px;margin-top:8px;max-height:340px;overflow:auto;padding:2px}
  .class-card{background:var(--panel2,#221c2b);border:2px solid #ffffff1a;border-radius:10px;padding:6px;cursor:pointer;text-align:center;transition:transform .15s,border-color .15s,box-shadow .15s}
  .class-card:hover{transform:translateY(-2px);border-color:#f5b94288}
  .class-card.sel{border-color:var(--gold,#f5b942);box-shadow:0 0 14px #f5b94288}
  .class-card img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;display:block}
  .class-card b{display:block;font-size:13px;margin-top:4px}
  .class-card small{color:#bbb;font-size:11px}
  #cutscene{position:fixed;inset:0;z-index:80;background:#000;display:none;overflow:hidden;font-family:inherit}
  #cutscene .cs-bg{position:absolute;inset:0;background-size:cover;background-position:center;opacity:0;transition:opacity 1.2s ease;transform:scale(1.06);animation:csZoom 18s linear infinite alternate}
  #cutscene .cs-bg.on{opacity:1}
  @keyframes csZoom{from{transform:scale(1.02)}to{transform:scale(1.12)}}
  #cutscene .cs-shade{position:absolute;inset:0;background:linear-gradient(to top,#000e 0%,#0008 38%,#0000 70%)}
  #cutscene .cs-title{position:absolute;top:26px;left:0;right:0;text-align:center;color:#f5b942;font-size:30px;letter-spacing:2px;text-shadow:0 2px 12px #000;opacity:0;transition:opacity 1s}
  #cutscene .cs-title.on{opacity:1}
  #cutscene .cs-box{position:absolute;left:50%;bottom:34px;transform:translateX(-50%);width:min(900px,92vw);display:flex;gap:18px;align-items:flex-end;opacity:0;transition:opacity .6s}
  #cutscene .cs-box.on{opacity:1}
  #cutscene .cs-portrait{width:170px;height:170px;border-radius:14px;object-fit:cover;border:3px solid #f5b942;box-shadow:0 0 30px #f5b94266;flex:none;transition:opacity .5s}
  #cutscene .cs-portrait.fairy{border-radius:50%;width:130px;height:130px;animation:csFly 2.4s ease-in-out infinite;box-shadow:0 0 40px #fff6b0}
  #cutscene .cs-portrait.demon{border-color:#ff4a1c;box-shadow:0 0 40px #ff3a0088;width:200px;height:200px}
  @keyframes csFly{0%,100%{transform:translateY(0)}50%{transform:translateY(-14px)}}
  #cutscene .cs-text{flex:1;background:#0d0a12dd;border:1px solid #f5b94255;border-radius:12px;padding:14px 18px;min-height:96px;color:#eee;font-size:18px;line-height:1.45}
  #cutscene .cs-name{color:#f5b942;font-weight:bold;margin-bottom:4px;font-size:15px}
  #cutscene .cs-btns{position:absolute;top:18px;right:18px;display:flex;gap:8px;z-index:2}
  #cutscene .cs-next{position:absolute;right:24px;bottom:8px;color:#f5b942aa;font-size:13px;animation:csBlink 1.2s infinite}
  @keyframes csBlink{50%{opacity:.3}}
  #cutscene .cs-fade{position:absolute;inset:0;background:#000;opacity:1;transition:opacity .9s;pointer-events:none}
  #cutscene .cs-fade.off{opacity:0}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
  const cs = document.createElement("div"); cs.id = "cutscene";
  cs.innerHTML = `<div class="cs-bg" id="csBg"></div><div class="cs-shade"></div><div class="cs-title" id="csTitle"></div>
    <div class="cs-btns"><button class="btn ghost" id="csSkip">⏭ Пропустить</button></div>
    <div class="cs-box" id="csBox"><img class="cs-portrait" id="csPortrait" alt=""><div class="cs-text"><div class="cs-name" id="csName"></div><div id="csLine"></div></div></div>
    <div class="cs-next">▶ нажмите, чтобы продолжить</div><div class="cs-fade" id="csFade"></div>`;
  document.body.appendChild(cs);
})();

const STORY_SPEAKER_CLASS = {dayla: "fairy", karrgall: "demon"};
let _cs = null;   // {scenes, si, li, hero, done, typing}

function _csFill(text, hero) { return String(text || "").replaceAll("{hero}", hero ? hero.name : "герой"); }

// Показ сцен: [{background, title, portrait, lines:[{speaker,name,image,text}]}]
function playCutscene(scenes, hero, onDone) {
  _cs = {scenes, si: 0, li: -1, hero, done: onDone, timer: null};
  const el = document.getElementById("cutscene");
  el.style.display = "block";
  document.getElementById("csFade").classList.remove("off");
  _csScene();
}
function _csScene() {
  const sc = _cs.scenes[_cs.si];
  const bg = document.getElementById("csBg"), title = document.getElementById("csTitle"), box = document.getElementById("csBox");
  const fade = document.getElementById("csFade");
  fade.classList.remove("off"); bg.classList.remove("on"); title.classList.remove("on"); box.classList.remove("on");
  setTimeout(() => {
    bg.style.backgroundImage = `url('${sc.background}')`;
    title.textContent = sc.title || "";
    fade.classList.add("off"); bg.classList.add("on");
    setTimeout(() => title.classList.add("on"), 400);
    _cs.li = -1; setTimeout(_csNext, 900);
  }, _cs.si === 0 ? 50 : 800);
}
function _csNext() {
  if (!_cs) return;
  const sc = _cs.scenes[_cs.si];
  if (_cs.timer) {   // текст ещё печатается — показать целиком
    clearInterval(_cs.timer); _cs.timer = null;
    document.getElementById("csLine").textContent = _csFill(sc.lines[_cs.li].text, _cs.hero); return;
  }
  _cs.li++;
  if (_cs.li >= sc.lines.length) {
    _cs.si++;
    if (_cs.si >= _cs.scenes.length) return _csEnd();
    return _csScene();
  }
  const line = sc.lines[_cs.li], box = document.getElementById("csBox"), img = document.getElementById("csPortrait");
  let src = line.image, name = line.name;
  if (line.speaker === "hero" || (line.speaker === "narrator" && sc.portrait === "hero")) { src = _cs.hero && _cs.hero.image; name = line.speaker === "hero" ? (_cs.hero && _cs.hero.name) : null; }
  else if (line.speaker === "narrator") { const p = sc.portrait; src = p === "karrgall" ? "/static/images/story/karrgall.jpg" : p === "dayla" ? "/static/images/story/dayla.jpg" : null; }
  else if (line.speaker === "tavern") src = _cs.hero && _cs.hero.image;
  img.className = "cs-portrait " + (STORY_SPEAKER_CLASS[line.speaker] || (line.speaker === "narrator" ? STORY_SPEAKER_CLASS[sc.portrait] || "" : ""));
  img.style.display = src ? "" : "none"; if (src) img.src = src;
  document.getElementById("csName").textContent = name || "";
  box.classList.add("on");
  const full = _csFill(line.text, _cs.hero), out = document.getElementById("csLine");
  out.textContent = ""; let i = 0;
  _cs.timer = setInterval(() => {
    out.textContent = full.slice(0, ++i);
    if (i >= full.length) { clearInterval(_cs.timer); _cs.timer = null; }
  }, 22);
}
function _csEnd() {
  const done = _cs && _cs.done;
  if (_cs && _cs.timer) clearInterval(_cs.timer);
  _cs = null;
  const fade = document.getElementById("csFade"); fade.classList.remove("off");
  setTimeout(() => { document.getElementById("cutscene").style.display = "none"; if (done) done(); }, 700);
}
document.getElementById("cutscene").addEventListener("click", e => { if (e.target.id !== "csSkip") _csNext(); });
document.getElementById("csSkip").addEventListener("click", e => { e.stopPropagation(); _csEnd(); });
document.addEventListener("keydown", e => { if (_cs && (e.key === " " || e.key === "Enter")) { e.preventDefault(); _csNext(); } if (_cs && e.key === "Escape") _csEnd(); });

function dialogueScene(lines, background, title) {
  return [{background: background || "/static/images/story/slums_street.jpg", title: title || "", portrait: null, lines}];
}
async function setStoryFlag(hid, flag, value = true) {
  return api(`/api/heroes/${hid}/story_flags`, "POST", {flag, value});
}

// ---------- создание сюжетного героя: карточки классов ----------
let storyPickedClass = null;
function renderStoryClassCards() {
  const box = document.getElementById("storyClassCards"); if (!box) return;
  // 5.1: Монах в сюжете всегда доступен (арена по-прежнему за 7 побед)
  const list = classes.filter(c => c.creatable !== false && !c.mob && (!c.required_wins || c.type === "monk" || c.story_free));
  if (!storyPickedClass && list.length) storyPickedClass = list[0].type;
  box.innerHTML = list.map(c => `<div class="class-card ${c.type === storyPickedClass ? "sel" : ""}" onclick="pickStoryClass('${c.type}')" title="${esc(c.about || "")}">
    <img src="${c.image || "/images/" + c.type}" alt="" loading="lazy"><b>${esc(c.hero_class)}</b><small>${esc(c.role_name || "")} · ❤ ${c.max_hp}</small></div>`).join("");
  document.getElementById("storyType").value = storyPickedClass || "";
  const c = list.find(x => x.type === storyPickedClass);
  document.getElementById("storyClassAbout").textContent = c ? `${c.hero_class} (${c.role_name}): ${c.about || ""}` : "";
}
function toggleStoryCreate() {
  const c = document.getElementById("storyCreate"); const open = c.style.display === "none";
  c.style.display = open ? "" : "none"; c.dataset.open = open ? "1" : "";
}
function pickStoryClass(type) { storyPickedClass = type; renderStoryClassCards(); }

loadStory = async function () {
  await loadPlayers();
  const p = currentPlayer(); if (!p) return;
  const heroes = (await api("/api/heroes") || []).filter(h => h.story && h.owner_id === p.id);
  const sel = document.getElementById("storyHero"), old = sel.value;
  sel.innerHTML = heroes.map(h => `<option value="${h.id}">${esc(h.name)} (${h.hero_class}, ур. ${h.level})</option>`).join("") || `<option value="">— нет сюжетных героев —</option>`;
  if (old && heroes.some(h => h.id == old)) sel.value = old;
  document.getElementById("storySlots").textContent = `${heroes.length}/1`;
  // карточки классов раскрыты, пока нет героев; дальше — по кнопке «➕ Новый герой»
  const create = document.getElementById("storyCreate"), tg = document.getElementById("storyNewToggle");
  if (heroes.length >= 3) { create.style.display = "none"; tg.style.display = "none"; }
  else if (!heroes.length) { create.style.display = ""; tg.style.display = "none"; }
  else { tg.style.display = ""; if (!create.dataset.open) create.style.display = "none"; }
  renderStoryClassCards();
  const hid = sel.value;
  storyData = await api("/api/story" + (hid ? `?hero_id=${hid}` : ""));
  if (!storyData) return;
  const loc = storyData.locations[0];
  document.getElementById("storyTitle").textContent = loc.title + (loc.cleared ? " ✅ пройден" : "");
  document.getElementById("storyMap").innerHTML = loc.stages.map(s => `
    <div class="node ${hid ? s.status : "locked"} ${s.boss ? "boss" : ""}" style="left:${s.x}%;top:${s.y}%" onclick="pickStage('${s.key}')">
      ${s.icon}<label>${esc(s.name || s.title)}${s.boss ? " 👑" : ""}</label></div>`).join("");
  document.getElementById("storyReplay").style.display = hid ? "" : "none";
  const info = document.getElementById("storyInfo");
  if (!hid) { info.innerHTML = `<p>${esc(loc.intro)}</p><p class="muted">Создайте сюжетного героя (1 уровень), чтобы отправиться в лес.</p>`; return; }
  const h = storyData.hero;
  info.innerHTML = `<p>${esc(loc.intro)}</p><div class="muted">${esc(h.name)}: ур. ${h.level}, опыт ${h.experience}/100 · пройдено этапов ${loc.progress}/${loc.stages.length}</div>`;
  const open = loc.stages.find(s => s.status === "open");
  if (open) pickStage(open.key);
  if (!(storyData.flags || {}).intro_seen) playIntro(false);
};
function playIntro(replay) {
  if (!storyData || !storyData.hero) return;
  const h = storyData.hero;
  playCutscene(storyData.intro, h, async () => {
    if (!replay) { await setStoryFlag(h.id, "intro_seen"); storyData.flags = Object.assign(storyData.flags || {}, {intro_seen: true}); }
  });
}
pickStage = function (key) {
  const hid = document.getElementById("storyHero").value;
  if (!storyData || !hid) return toast("Сначала создайте сюжетного героя");
  const loc = storyData.locations[0], s = loc.stages.find(x => x.key === key);
  if (s.status === "locked") return toast("🔒 Этап закрыт — победите предыдущего противника");
  storyStage = s;
  const h = storyData.hero;
  document.getElementById("storyInfo").innerHTML = `<div class="row" style="align-items:flex-start"><img src="${s.image}" style="width:120px;border-radius:10px">
    <div><h3 style="margin:0;color:var(--gold)">${s.icon} ${esc(s.card_title || s.title)} ${s.status === "done" ? "✅" : ""}</h3>
    <div class="muted">${s.boss ? "Босс локации" : "Обитатель леса"} · роль: ${esc(s.role_name || "")}</div>
    <p style="font-style:italic">💬 ${esc(h.name)}: «${esc(s.line)}»</p>
    <div class="muted">Награда: до ${s.xp} опыта и ${s.gold} золота (меньше, если герой сильнее моба)</div>
    <div class="row" style="margin-top:8px">🎒 <select id="storyItem"><option value="">— без предмета —</option>${Object.entries(h.consumables || {}).map(([k, n]) => `<option value="${k}">${itemInfo(k)[0]} ${esc(itemInfo(k)[1])} ×${n}</option>`).join("")}</select>
    <button class="btn" onclick="storyFight('${s.key}')">⚔ В бой</button>
    ${s.before && s.before.length ? `<button class="btn ghost" onclick="storyDialogue('${s.key}','before')">💬 Диалог</button>` : ""}</div></div></div>`;
};
function storyDialogue(key, which, then) {
  const loc = storyData.locations[0], s = loc.stages.find(x => x.key === key);
  const lines = (which === "after" ? s.after : s.before) || [];
  if (!lines.length) return then && then();
  playCutscene(dialogueScene(lines, (s.background || (storyData.locations[0]||{}).cutscene_bg || "/static/images/story/slums_street.jpg"), s.card_title), storyData.hero, then);
}
const _storyFight43 = storyFight;
storyFight = function (stage) {
  const s = storyData && storyData.locations[0].stages.find(x => x.key === stage);
  const hid = document.getElementById("storyHero").value;
  const flag = s && s.boss ? `${storyData.locations[0].key}_boss_before_seen` : null;
  if (s && s.before && s.before.length && flag && !(storyData.flags || {})[flag]) {
    const item = document.getElementById("storyItem") ? document.getElementById("storyItem").value : "";
    return storyDialogue(stage, "before", async () => {
      await setStoryFlag(hid, flag); storyData.flags[flag] = true;
      const sel = document.getElementById("storyItem"); if (sel) sel.value = item;
      _storyFight43(stage);
    });
  }
  return _storyFight43(stage);
};
createStoryHero = async function () {
  const p = currentPlayer(); if (!p) return;
  const type = document.getElementById("storyType").value;
  if (!type) return toast("Выберите класс героя");
  const h = await api(`/api/players/${p.id}/story_heroes`, "POST", {name: document.getElementById("storyName").value, type});
  if (h) {
    toast(`📖 ${h.name} начинает свой путь!`, "ok"); document.getElementById("storyName").value = "";
    document.getElementById("storyCreate").dataset.open = "";
    document.getElementById("storyHero").innerHTML = `<option value="${h.id}"></option>`;
    await loadStory();   // у нового героя intro_seen = false → сразу ролик
  }
};
// после победы — диалог (один раз); 5.1: фон локации, без ложного «босс»
// 5.4.1: first-win after must SPLIT like replay (v53 storyDialogue after):
//   part1 — реплики врага на background боя + фигура; part2 — лор на after_background БЕЗ фигуры.
// Bug: single dialogueScene(after_bg, fig) left Альтаир stuck on city_bridge during Дейла lore.
const _showResult43 = showResult, _afterShown = new Set();
function _buildAfterWinScenes(b) {
  const lines = b.story.after || [];
  const title = b.story.after_title || (typeof storyData !== "undefined" && storyData && (storyData.locations.find(l => l.key === b.story.location) || {}).title) || "";
  const locBg = (typeof storyData !== "undefined" && storyData && (storyData.locations.find(l => l.key === b.story.location) || {}).cutscene_bg) || "/static/images/story/slums_street.jpg";
  const beforeBg = b.story.background || b.story.cutscene_bg || b.story.battle_bg || locBg;
  const afterBg = b.story.after_background || beforeBg;
  const fig = b.story.after_figure || b.story.figure || null;
  const ALLY = new Set(["dayla", "hero", "narrator", "tavern"]);
  let lastEnemy = -1;
  lines.forEach((l, i) => { if (l && l.speaker && !ALLY.has(l.speaker)) lastEnemy = i; });
  if (fig && lastEnemy >= 0 && afterBg && afterBg !== beforeBg && lastEnemy < lines.length - 1) {
    const part1 = lines.slice(0, lastEnemy + 1);
    const part2 = lines.slice(lastEnemy + 1);
    return [
      { lines: part1, background: beforeBg, title, figure: fig, enemy_figure: fig, _v53_after: true },
      { lines: part2, background: afterBg, title, figure: null, enemy_figure: null, _v53_after: true, hide_enemy_unless_speaks: true },
    ];
  }
  // no bg change / no enemy lines — single scene (figure only if enemy speaks)
  const keepFig = (lastEnemy >= 0) ? fig : null;
  const scenes = (typeof dialogueScene === "function")
    ? dialogueScene(lines, afterBg || beforeBg, title, keepFig)
    : [{ lines, background: afterBg || beforeBg, title, figure: keepFig }];
  return Array.isArray(scenes) ? scenes : [scenes];
}
showResult = function (b) {
  _showResult43(b);
  if (b.story && b.story.after && b.winner_id === b.hero1_id && !_afterShown.has(b.id)) {
    _afterShown.add(b.id);
    const flag = `${b.story.location}_boss_after_seen`;
    const hero = (b.heroes || [])[0] || {}; const h = {name: hero.name, image: hero.image || `/images/${hero.type}`};
    const scenes = _buildAfterWinScenes(b);
    setTimeout(() => playCutscene(scenes, h, () => {
      if (b.story.boss) api(`/api/heroes/${b.hero1_id}/story_flags`, "POST", {flag});
      if (typeof maybeStartShrek === "function") maybeStartShrek(b);
    }), 1200);
  }
};
// export for tests
if (typeof window !== "undefined") window._buildAfterWinScenes = _buildAfterWinScenes;
