const {chromium}=require('playwright');const fs=require('fs');
const ROOT=process.env.MAGE_REPORT_DIR||'.',BASE=process.env.MAGE_BASE_URL||'http://127.0.0.1:5000';
const assert=(x,m)=>{if(!x)throw Error(m)};
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1050}});const errors=[],payloads=[],results=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
 page.on('request',r=>{if(r.url().endsWith('/react'))payloads.push(r.postDataJSON())});
 async function api(path,method='GET',data){const r=await page.request.fetch(BASE+path,{method,data});assert(r.ok(),`${path}:${r.status()} ${await r.text()}`);return r.json()}
 const clock=()=>page.evaluate(()=>Math.floor(performance.now()-mg.t0));
 async function until(ms){await page.waitForFunction(t=>performance.now()-mg.t0>=t,ms,{polling:'raf'})}
 try{
  await page.goto(BASE,{waitUntil:'networkidle'});await page.evaluate(()=>{skipWelcome();window.__spellUpdates=0;const previous=update;update=async function(){window.__spellUpdates++;try{return await previous.apply(this,arguments)}finally{window.__spellUpdates--}}});
  const player=await api('/api/players','POST',{username:'mage543_'+Date.now(),password:require('crypto').randomUUID()});
  await page.evaluate(()=>loadPlayers());await page.selectOption('#player',String(player.id));
  const mage=await api('/api/heroes','POST',{type:'mage',name:'Ремесло мага',player_id:player.id});
  const enemies=await api('/api/heroes');const foe=enemies.find(h=>h.npc&&h.type==='paladin');
  async function pending(key){
   let b=await api('/api/battles','POST',{hero1_id:mage.id,hero2_id:foe.id,mode:'manual',vs_ai:true,force:true});
   b=await api(`/api/battles/${b.id}/turn`,'POST',{skill:key});
   assert(b.pending?.options.game.startsWith('mage_'),'Expected mage minigame');
   await page.evaluate(async b=>{fast=true;await update(b);fast=false},b);
   await page.locator('.spell543').waitFor({state:'visible'});
   return b;
  }
  const keys=process.env.MAGE_TEST_KEYS?.split(',')||['rune_seal','water_spirit','ice_shield','fireball','stone_golem','lightning'];
  for(const key of keys){
   const b=await pending(key),o=b.pending.options;
   const response=page.waitForResponse(r=>r.url().endsWith(`/api/battles/${b.id}/react`));
   await page.locator('#modalBox').screenshot({path:ROOT+`/game_${key}.png`});
   if(key==='rune_seal'){
    assert(!/запом|памят/i.test(await page.locator('#modalBox').innerText()),'Memory instruction remains');
    for(let i=0;i<4;i++)for(let k=0;k<(o.targets[i]-o.rotations[i]+4)%4;k++)await page.locator(`[data-rune="${i}"]`).click();
   }else if(key==='water_spirit'){
    const box=await page.locator('#waterBody').boundingBox();const xy=(x,y)=>({x:box.x+x/360*box.width,y:box.y+y/320*box.height});
    const slots=[[180,48],[180,112],[102,139],[258,139],[145,214],[215,214]];
    for(let i=0;i<6;i++){const a=xy(40+(o.supply_order||[0,1,2,3,4,5]).indexOf(i)*56,285),t=xy(...slots[o.target_slots[i]]);await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(t.x,t.y,{steps:6});await page.mouse.up();console.log("water",i,await page.locator("#spellStatus").textContent())}
   }else if(key==='ice_shield'){
    const box=await page.locator('#iceContour').boundingBox();const xy=(x,y)=>({x:box.x+x/360*box.width,y:box.y+y/320*box.height});
    for(let i=0;i<7;i++){const angle=(-90+(i%6)*60+o.angle)*Math.PI/180,p=xy(180+108*Math.cos(angle),154+108*Math.sin(angle));await page.mouse.move(p.x,p.y,{steps:4});if(i===0)await page.mouse.down()}
    await page.mouse.up();
   }else if(key==='fireball'){
    const now=await clock(),P=o.period_ms;let peak=P/4-o.phase_ms;
    while(peak<Math.max(2400,now+2300))peak+=P;
    assert(peak<4850,'Not enough time for fire core');
    const down=peak<3333.333?.75*peak-1500:peak-84/36*1000;
    const fuel=await page.locator('#fireFuel').boundingBox();await page.mouse.move(fuel.x+fuel.width/2,fuel.y+fuel.height/2);
    await until(Math.max(now,down-7));await page.mouse.down();
    await until(peak-8);
    await page.mouse.up();await page.evaluate(()=>document.getElementById('fireCast').click());
   }else if(key==='stone_golem'){
    let left=100,right=260;
    for(let i=0;i<5;i++){
     const now=await clock(),center=(left+right)/2;
     let target=now+25;
     while(target<6400&&Math.abs(180+o.amplitude*Math.sin(2*Math.PI*(target+o.phases[i])/o.periods[i])-center)>1)target++;
     assert(target<6400,'No golem placement window');await until(target-7);
     const t=await page.evaluate(()=>{const ms=Math.floor(performance.now()-mg.t0);document.getElementById('golemDrop').click();return ms});
     const x=180+o.amplitude*Math.sin(2*Math.PI*(t+o.phases[i])/o.periods[i]),width=right-left;
     left=Math.max(left,x-width/2);right=Math.min(right,x+width/2);
    }
   }else if(key==='lightning'){
    assert(await page.locator('[data-wire]').count()===12,'Circuit board size');
    for(let i=0;i<12;i++){
     if(o.cells[i].kind==='ground')continue;
     for(let k=0;k<(4-o.cells[i].rotation)%4;k++){
      if(await page.evaluate(()=>mg.done))break;
      await page.locator(`[data-wire="${i}"]`).click();
     }
    }
   }
   const reply=await response;console.log(key,reply.request().postDataJSON());assert(reply.ok(),`React ${key}: ${reply.status()} ${await reply.text()}`);const after=await reply.json();
   const log=after.log.filter(x=>x.actor_id===mage.id).map(x=>x.text).join('\n');
   assert(log.includes('Идеал'),`${key} did not produce ideal result: ${log.slice(-1600)}`);
   const hero=after.heroes.find(h=>h.id===mage.id);
   if(key==='water_spirit'){assert(hero.summon?.max_hp===85,'Perfect spirit HP');assert(hero.summon?.lifetime_unit==='round','Spirit round lifetime');assert(hero.skills.find(s=>s.key==='stone_golem').available===false,'Golem not locked')}
   if(key==='stone_golem'){assert(hero.summon?.max_hp===100,'Perfect golem HP');assert(hero.skills.find(s=>s.key==='water_spirit').available===false,'Water spirit not locked')}
   results.push({key,game:o.game,ideal:true,round:after.round});
   await page.waitForTimeout(350);
   await page.waitForFunction(()=>window.__spellUpdates===0&&!busy);
  }
  // The server must reject the alternate summon through the actual battle API.
  let b=await pending('water_spirit');const input={placements:b.pending.options.target_slots.map((slot,part)=>({part,slot}))};
  b=await api(`/api/battles/${b.id}/react`,'POST',{choice:input});
  const denied=await page.request.post(BASE+`/api/battles/${b.id}/turn`,{data:{skill:'stone_golem'}});assert(denied.status()===400,'Server allowed two companions');
  await api(`/api/battles/${b.id}/cancel`,'POST',{});
  // Narrow layout still exposes all circuit buttons without horizontal clipping.
  await page.setViewportSize({width:390,height:844});b=await pending('lightning');
  const box=await page.locator('.spell543').boundingBox();assert(box.x>=0&&box.x+box.width<=390,'Mobile spell board clips horizontally');
  await page.locator('#modalBox').screenshot({path:ROOT+'/game_lightning_mobile.png'});
  await api(`/api/battles/${b.id}/cancel`,'POST',{});
  assert(errors.length===0,'JS errors: '+errors.join(';'));
  const output={results,mutual_exclusion:true,mobile_width:390,errors,payloads};fs.writeFileSync(ROOT+'/browser_spellcraft.json',JSON.stringify(output,null,2));console.log(JSON.stringify({results,errors},null,2));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
