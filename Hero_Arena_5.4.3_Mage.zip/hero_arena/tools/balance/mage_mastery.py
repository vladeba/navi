"""Mage: normal AI vs perfect minigame execution, same AI action chooser.

Both seat positions, all36 other classes, fixed arena baseline, noitems, N100 per seat.
This is not a solver for optimal manual decision-making.
"""
from concurrent.futures import ProcessPoolExecutor,as_completed
import json,math,random,time,argparse
from pathlib import Path
import run_matrix as r

ROOT=Path(__file__).parent
PROJECT=None
N=100
SEED=20542

def fight(a,b,seed,perfect):
    random.seed(seed);r.Character._next_id=r.Battle._next_id=1
    h1,h2=r.HERO_CLASSES[a]('A'),r.HERO_CLASSES[b]('B')
    caster=h1 if a=='mage' else h2
    caster.perfect=perfect
    battle=r.Battle(h1,h2);winner=battle.fight()
    return 1 if winner is caster else .5 if winner is None else 0

def job(args):
    enemy,N,SEED=args
    result={'enemy':enemy,'normal':[],'perfect':[],'seats':[]}
    for a,b in (('mage',enemy),(enemy,'mage')):
        first=r.pair_seed(a,b,SEED)
        normal=[fight(a,b,first+i,False) for i in range(N)]
        perfect=[fight(a,b,first+i,True) for i in range(N)]
        result['normal']+=normal;result['perfect']+=perfect
        result['seats'].append({'a':a,'b':b,'normal':normal,'perfect':perfect})
    return result

def summarize(rows,key):
    total=sum(sum(row[key]) for row in rows);count=sum(len(row[key]) for row in rows)
    variance=0
    for row in rows:
        scores=row[key];mean=sum(scores)/len(scores)
        variance+=sum((x-mean)**2 for x in scores)/(len(scores)-1)*len(scores)
    return {'wr':100*total/count,'fights':count,'stratified_95_half_width_pp':196*math.sqrt(variance)/count}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',required=True)
    parser.add_argument('--matrix',required=True)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    baseline=json.loads(Path(args.matrix).read_text())
    PROJECT=args.project
    N=baseline['config']['n'];SEED=baseline['config']['seed']
    r.init(PROJECT,True);enemies=[k for k in r.HERO_CLASSES if k!='mage'];rows=[];start=time.monotonic()
    with ProcessPoolExecutor(4,initializer=r.init,initargs=(PROJECT,True)) as pool:
        futures=[pool.submit(job,(k,N,SEED)) for k in enemies]
        for future in as_completed(futures):
            row=future.result();rows.append(row)
            print(len(rows),'/36',row['enemy'],'elapsed',round(time.monotonic()-start,1),flush=True)
    pairs={(x['a'],x['b']):x['outcomes'] for x in baseline['rows']}
    for row in rows:
        for seat in row['seats']:
            expected=pairs[seat['a'],seat['b']]
            if seat['a']!='mage':expected=[1-v for v in expected]
            assert seat['normal']==expected,('Normal control differs from final matrix',seat['a'],seat['b'])
    data={'definition':'Perfect minigame tier for Mage only; ordinary AI opponents; unchanged AI action chooser. Not optimal manual play.',
          'n_per_seat':N,'seed':SEED,'arena_levels':False,'items':False,'opponents':36,
          'normal':summarize(rows,'normal'),'perfect':summarize(rows,'perfect'),
          'normal_control_matches_final_matrix_exactly':True,'rows':rows,'seconds':time.monotonic()-start}
    Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    Path(args.out).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in data.items() if k!='rows'},ensure_ascii=False,indent=2),flush=True)
