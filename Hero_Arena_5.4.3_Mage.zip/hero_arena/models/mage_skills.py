"""Mage 5.4.3: six different spellcraft games and a shared companion slot."""
import math
import random

from .effects import Announcement, Effect, Shield, Burn, Stun, Antiheal
from .skills import MiniGameSkill, scale_effect
from .summons import Summon, WaterSpirit


def integer(value, default=-1, low=0, high=100000):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    if not math.isfinite(value) or int(value) != value or not low <= value <= high:
        return default
    return int(value)


def sequence(choice, key, limit=64):
    value = choice.get(key, []) if isinstance(choice, dict) else []
    return value[:limit] if isinstance(value, list) else []


def count_tier(count, bands):
    return next((i for i, minimum in enumerate(bands) if count >= minimum), len(bands)-1)


class Conductive(Effect):
    name, icon = "Проводимость: следующая молния +25%", "⚡"


class RoundCompanion:
    """New mage companions expire by battle round, even when the mage is stunned."""
    expires_round = None

    def tick_life(self):
        return False if self.expires_round is not None else super().tick_life()

    def to_dict(self):
        return {**super().to_dict(), "lifetime_unit": "round", "quality": self.quality,
                "expires_round": self.expires_round,
                "stun_chance": getattr(self, "stun_chance", 0),
                "opening_guard": getattr(self, "opening_guard", False)}


class CraftedWaterSpirit(RoundCompanion, WaterSpirit):
    """Offensive companion; exactly 85 HP and seven rounds at best, before campaign scaling."""
    IGNORE_ARMOR = True
    STATS = [[85, 5, 7], [72, 4, 6], [55, 3, 4], [30, 2, 3]]

    def __init__(self, owner, tier=0):
        hp, damage, life = self.STATS[tier]
        Summon.__init__(self, owner, hp, damage, dodge=.15, intercept_chance=.15)
        self.lifetime = life
        self.quality = tier
        self.about = f"Урон сквозь броню; {life} раундов; намокшая цель проводит молнию (+25%)"

    def attack(self, target):
        logs = super().attack(target)
        if target.is_alive():
            target.add_effect(Conductive(3, 25))
            logs.append("⚡ Вода оставляет проводящий след: следующая молния сильнее на 25%.")
        return logs


class StoneGolem(RoundCompanion, Summon):
    name, icon = "Каменный голем", "🗿"
    # HP, damage, armor, interception, stun chance, lifespan
    STATS = [[100, 4, 2, 0.5, 0.2, 5], [85, 3, 1, 0.45, 0.15, 4],
     [60, 2, 1, 0.35, 0.1, 3], [30, 1, 0, 0.2, 0, 2]]

    def __init__(self, owner, tier=0):
        hp, damage, armor, interception, self.stun_chance, life = self.STATS[tier]
        super().__init__(owner, hp, damage, armor=armor, intercept_chance=interception)
        self.lifetime = life
        self.quality = tier
        self.opening_guard = True
        self.about = (f"Первый прямой удар прикрывает гарантированно (учитывается обход призыва); затем перехватывает {round(interception*100)}% прямых ударов; "
                      f"при попадании {round(self.stun_chance*100)}% оглушить на ход; {life} раундов")

    @property
    def intercept_chance(self):
        return 1.0 if getattr(self, 'opening_guard', False) else self.sustained_interception

    @intercept_chance.setter
    def intercept_chance(self, value):
        self.sustained_interception = value

    def on_intercept(self):
        self.opening_guard = False

    def attack(self, target):
        before = target.hp
        logs = super().attack(target)
        if target.is_alive() and target.hp < before and random.random() < self.stun_chance:
            if target.add_effect(Stun(1)):
                logs.append(Announcement(f"🗿 Голем оглушает {target.name} на 1 ход!"))
        return logs


class Spellcraft(MiniGameSkill):
    deals_damage = True
    TIERS = ("Идеал", "Хорошо", "Частично", "Срыв")
    AI_WEIGHTS = [30, 45, 20, 5]
    MG_ACCENT = "#96bfff"

    def describe_for(self, user):
        if self.deals_damage:
            mult = self.TIER_VALUE[0]
            return f"Урон при идеале ~{round(user.get_damage()*mult)} ({mult:g}× силы) · {self.description}"
        return self.description


class RuneWeaveSkill(Spellcraft):
    """The reference remains visible: align four glyphs, no memorization."""
    AI_WEIGHTS = [35, 45, 18, 2]
    game, prompt = "mage_rune_weave", "Поверните четыре руны по видимому образцу и замкните печать!"
    TIME_LIMIT_MS = 5500
    TIER_VALUE = [3.2, 2.6, 1.5, 0.5]
    MANA = [15, 10, 4, 0]
    RUNES = ("ᚠ", "ᚢ", "ᚦ", "ᚨ", "ᚱ", "ᚲ", "ᚷ", "ᛉ")

    def game_params(self, user, target):
        targets = [random.randrange(4) for _ in range(4)]
        return {"ideal_mult": self.TIER_VALUE[0], "mana_return": self.MANA[0], "runes": random.sample(self.RUNES, 4), "targets": targets,
                "rotations": [(x+random.randint(1, 3)) % 4 for x in targets]}

    def tier_from(self, choice, options):
        rotations = sequence(choice, "rotations", 4)
        if len(rotations) != 4:
            return 3
        count = sum(integer(a, high=3) == b for a, b in zip(rotations, options["targets"]))
        return count_tier(count, (4, 3, 2, 0))

    def apply(self, user, target, tier, data):
        logs, _ = self.strike(user, target, self.TIER_VALUE[tier],
                              ignore_armor=tier == 0, pierce=.4 if tier == 1 else 0)
        mana = min(self.MANA[tier], user.max_energy-user.energy)
        user.restore_energy(self.MANA[tier])
        return [Announcement(f"ᚱ {user.name} замыкает печать: {self.TIERS[tier]}, +{mana} маны.")] + logs

    def ai_score(self, user, target):
        from .ai import strike_value, tier_average, resource_price
        return tier_average(self, user, [strike_value(user, target, mult, force=True,
            ignore_armor=i == 0, pierce=.4 if i == 1 else 0) +
            min(self.MANA[i], user.max_energy-user.energy+self.cost)*resource_price(user)
            for i, mult in enumerate(self.TIER_VALUE)])


class CompanionCraft(Spellcraft):
    exclusive_slot = "mage_companion"
    deals_damage = False
    TIER_VALUE = (1, 1, 1, 1)
    companion = None

    def is_available(self, user):
        return super().is_available(user) and not (user.summon and user.summon.is_alive())

    def pay(self, user):
        # Recheck before spending mana, including direct API/model callers.
        if user.summon and user.summon.is_alive():
            raise ValueError("У мага уже есть призыв: дух воды и голем занимают один слот")
        super().pay(user)

    def apply(self, user, target, tier, data):
        if user.summon and user.summon.is_alive():
            raise ValueError("Одновременно можно поддерживать только одного призванного спутника")
        user.summon = self.companion(user, tier).scale_to(user)
        s = user.summon
        s.hp = s.max_hp  # A new entity must replace the dead companion in HP animation snapshots.
        battle = getattr(user, "_battle", None)
        if battle is not None:
            s.expires_round = battle.round+s.lifetime
        return [Announcement(f"{s.icon} {user.name} собирает: {s.name} — {self.TIERS[tier]}! "
                             f"HP {s.max_hp}, урон {s.damage}, {s.lifetime} раундов. {s.about}")]

    def describe_for(self, user):
        values = self.companion.STATS[0]
        hp = int(values[0]*user.power_scale())
        damage = max(1, round(values[1]*user.power_scale()))
        if self.companion is CraftedWaterSpirit:
            return f"Мини-игра сборки из капель: идеал {hp} HP, {damage} урона сквозь броню, {values[2]} раундов. Проводимость +25% к следующей молнии. Один слот с големом"
        return f"Мини-игра кладки: идеал {hp} HP, урон {damage}, броня {values[2]}; первый прямой удар прикрывает, далее перехват {round(values[3]*100)}%, оглушение {round(values[4]*100)}% при попадании; {values[5]} раундов. Один слот с духом воды"

    def ai_score(self, user, target):
        from .ai import tier_average, horizon, threat, effect_value
        if not self.is_available(user):
            return 0
        values = []
        incoming = threat(target, user)
        for tier in range(4):
            s = self.companion(user, tier)
            ignore = 1-getattr(target, "INTERCEPT_IGNORE", 0)
            interception = getattr(s, "sustained_interception", s.intercept_chance)*ignore
            turns = min(horizon(user, target, 4), s.lifetime,
                        s.max_hp*user.power_scale()/max(1, incoming*interception))
            damage = max(1, s.damage*user.power_scale()-(0 if getattr(s, "IGNORE_ARMOR", False) else target.armor_total()))
            hit = 1 if getattr(s, "IGNORE_ARMOR", False) else max(.1, s.accuracy-target.get_dodge())
            own_shield = sum(e.power for e in user.get_effects() if isinstance(e, Shield))
            exposed = max(0, incoming*turns-own_shield)
            opening = min(incoming, exposed)*(1-getattr(s, "sustained_interception", s.intercept_chance))*ignore if getattr(s, "opening_guard", False) else 0
            protection = min(s.max_hp*user.power_scale(), exposed*interception+opening)
            if isinstance(s, StoneGolem):
                protection *= 1.3-.8*user.hp/user.max_hp
            target_shield = sum(e.power for e in target.get_effects() if isinstance(e, Shield))
            hits_to_health = max(0, hit*turns-target_shield/max(1, damage))
            stun = getattr(s, "stun_chance", 0)*effect_value(user, target, Stun(1))*hits_to_health
            values.append(damage*hit*turns+protection+stun)
        value = tier_average(self, user, values)
        if self.companion is StoneGolem:
            # A defensive summon consumes a turn and the offensive summon slot.
            # Do not reserve half the mana pool for protection that is not needed
            # in the next two enemy attacks.
            barrier = sum(e.power for e in user.get_effects() if isinstance(e, Shield))
            value *= min(1.0, 2*incoming/max(1, user.hp+barrier))
        return value


class WaterSculptSkill(CompanionCraft):
    game, prompt = "mage_water_sculpt", "Соберите тело духа: перетащите капли в отмеченные части силуэта!"
    TIME_LIMIT_MS = 7000
    companion = CraftedWaterSpirit

    def game_params(self, user, target):
        return {"ideal_hp": int(self.companion.STATS[0][0]*(user.power_scale() if user is not None else 1)), "ideal_rounds": self.companion.STATS[0][2], "target_slots": [1, 0, 2, 3, 4, 5], "supply_order": random.sample(range(6), 6), "parts": ["Ядро", "Голова", "Левая рука", "Правая рука", "Вихрь", "Основание"]}

    def tier_from(self, choice, options):
        correct = set()
        for placement in sequence(choice, "placements", 12):
            if not isinstance(placement, dict):
                continue
            part = integer(placement.get("part"), high=5)
            slot = integer(placement.get("slot"), high=5)
            if part >= 0 and slot == options["target_slots"][part]:
                correct.add(part)
        return count_tier(len(correct), (6, 4, 2, 0))


class IceAssemblySkill(Spellcraft):
    AI_WEIGHTS = [35, 45, 18, 2]
    deals_damage = False
    game, prompt = "mage_ice_weave", "Сплетите щит по ледяному контуру: соедините вершины 1–6 и замкните круг!"
    TIME_LIMIT_MS = 6000
    TIER_VALUE = (1, 1, 1, 1)
    ABSORB = [36, 32, 24, 12]
    DURATION = [3, 3, 3, 2]

    def game_params(self, user, target):
        return {"ideal_absorb": round(self.ABSORB[0]*(user.power_scale() if user is not None else 1)), "ideal_duration": self.DURATION[0], "angle": random.randint(-25, 25), "path": [0, 1, 2, 3, 4, 5, 0]}

    def tier_from(self, choice, options):
        count = 0
        for a, b in zip(sequence(choice, "path", 7), options["path"]):
            if integer(a, high=5) != b:
                break
            count += 1
        return count_tier(max(0, count-1), (6, 4, 2, 0))

    def describe_for(self, user):
        amounts = '/'.join(str(round(x*user.power_scale())) for x in self.ABSORB)
        return f"Мини-игра плетения контура: щит {amounts} поглощения; идеал держится {self.DURATION[0]} хода"

    def apply(self, user, target, tier, data):
        shield = scale_effect(Shield(self.DURATION[tier], self.ABSORB[tier]), user)
        user.add_effect(shield)
        return [Announcement(f"❄ {user.name} собирает ледяной щит: {self.TIERS[tier]}, "
                             f"{shield.power} поглощения на {shield.duration} хода.")]

    def ai_score(self, user, target):
        from .ai import threat, horizon, tier_average
        old = max((e.power for e in user.get_effects() if isinstance(e, Shield)), default=0)
        if old:
            return 0
        incoming = threat(target, user)
        cut = .5 if user.has_effect(Antiheal) else 1
        values = [min(power*user.power_scale()*cut,
                      incoming*horizon(user, target, duration)) for power, duration in zip(self.ABSORB, self.DURATION)]
        if incoming >= user.hp:
            values = [v*1.3 for v in values]
        return tier_average(self, user, values)


class FireballCraftSkill(Spellcraft):
    game, prompt = "mage_fire_core", "Разогрейте ядро и бросьте шар, когда жар и сжатие в зелёных зонах!"
    TIME_LIMIT_MS = 5000
    TIER_VALUE = [2.8, 2.4, 1.4, 0.5]
    BURN = [[2, 4], [2, 4], [1, 3], [0, 0]]

    def game_params(self, user, target):
        return {"period_ms": random.randint(1400, 1800), "phase_ms": random.randint(0, 1400),
                "start_heat": 12, "heat_per_s": 36, "cool_per_s": 12}

    @staticmethod
    def heat_state(choice, options):
        elapsed = integer(choice.get("elapsed_ms"), high=5000) if isinstance(choice, dict) else -1
        if elapsed < 0:
            return None
        heat = options["start_heat"]; previous = 0; down = False; overheated = False
        events = sequence(choice, "events", 40)
        for event in events + [{"ms": elapsed, "down": False}]:
            if not isinstance(event, dict) or not isinstance(event.get("down"), bool):
                return None
            ms = integer(event.get("ms"), high=5000)
            if ms < previous or ms > elapsed:
                return None
            heat += (ms-previous)/1000*(options["heat_per_s"] if down else -options["cool_per_s"])
            overheated = overheated or heat >= 110
            heat = min(120, max(0, heat)); previous = ms; down = event["down"]
        focus = 50+50*math.sin(2*math.pi*(elapsed+options["phase_ms"])/options["period_ms"])
        return heat, focus, overheated

    def tier_from(self, choice, options):
        state = self.heat_state(choice, options)
        if state is None or state[2]:
            return 3
        heat, focus, _ = state
        return 0 if 73 <= heat <= 90 and focus >= 70 else 1 if 55 <= heat <= 100 and focus >= 40 else 2 if heat >= 30 else 3

    def apply(self, user, target, tier, data):
        logs, damage = self.strike(user, target, self.TIER_VALUE[tier])
        turns, power = self.BURN[tier]
        if damage > 0 and target.is_alive() and turns:
            effect = scale_effect(Burn(turns, power), user)
            target.add_effect(effect)
            logs.append(f"🔥 {target.name} горит: {effect.power} урона, {turns} хода.")
        return [Announcement(f"🔥 {user.name} выпускает огненный шар: {self.TIERS[tier]}!")] + logs

    def ai_score(self, user, target):
        from .ai import strike_value, effect_value, tier_average
        return tier_average(self, user, [strike_value(user, target, mult, force=True)+
            (effect_value(user, target, Burn(*self.BURN[i])) if self.BURN[i][0] else 0)
            for i, mult in enumerate(self.TIER_VALUE)])


class GolemStackSkill(CompanionCraft):
    AI_WEIGHTS = [20, 45, 30, 5]
    game, prompt = "mage_golem_stack", "Сложите голема: сбрасывайте камни над опорой. Точная кладка даёт больше защиты!"
    TIME_LIMIT_MS = 6500
    companion = StoneGolem

    def game_params(self, user, target):
        return {"periods": [random.randint(950, 1450) for _ in range(5)],
                "phases": [random.randint(0, 1000) for _ in range(5)],
                "width": 160, "amplitude": 90}

    @staticmethod
    def stack(choice, options):
        left, right, previous, layers = 100.0, 260.0, -1, []
        for i, value in enumerate(sequence(choice, "drops", 5)):
            ms = integer(value, high=6500)
            if ms < previous or ms < 0:
                break
            center = 180+options["amplitude"]*math.sin(2*math.pi*(ms+options["phases"][i])/options["periods"][i])
            width = right-left
            left, right = max(left, center-width/2), min(right, center+width/2)
            if right <= left:
                break
            layers.append({"left": left, "right": right}); previous = ms
        return layers

    def tier_from(self, choice, options):
        layers = self.stack(choice, options)
        width = layers[-1]["right"]-layers[-1]["left"] if layers else 0
        return 0 if len(layers) == 5 and width >= 120 else 1 if len(layers) >= 4 and width >= 65 else 2 if len(layers) >= 2 else 3


class CircuitLightningSkill(Spellcraft):
    game, prompt = "mage_lightning_circuit", "Проведите ток от источника к цели через два конденсатора. Поворачивайте проводники!"
    TIME_LIMIT_MS = 8500
    TIER_VALUE = [2.8, 2.5, 1.3, 0.4]
    SHIELD_BREAK = [15, 12, 6, 0]
    PATHS = ((0, 1, 5, 6, 10, 11), (0, 4, 5, 9, 10, 11), (0, 1, 2, 6, 5, 9, 10, 11))

    def game_params(self, user, target):
        path = random.choice(self.PATHS)
        caps = (path[2], path[-2])
        cells = []
        def direction(a, b):
            return { -4: 0, 1: 1, 4: 2, -1: 3 }[b-a]
        for index in range(12):
            if index in path:
                i = path.index(index)
                ports = [3 if i == 0 else direction(index, path[i-1]),
                         1 if i == len(path)-1 else direction(index, path[i+1])]
                kind = "source" if i == 0 else "target" if i == len(path)-1 else "capacitor" if index in caps else "wire"
            else:
                ports, kind = random.choice(([0, 1], [0, 2])), "ground"
            cells.append({"ports": ports, "rotation": random.randint(1, 3), "kind": kind})
        return {"cols": 4, "rows": 3, "cells": cells, "source": 0, "target": 11}

    @staticmethod
    def circuit(choice, options):
        rotations = sequence(choice, "rotations", 12)
        if len(rotations) != 12 or any(integer(v, high=3) < 0 for v in rotations):
            return [], 0, False
        seen, caps, index, entering = [], 0, options["source"], 3
        for _ in range(12):
            cell = options["cells"][index]
            ports = [(p+rotations[index]) % 4 for p in cell["ports"]]
            if index in seen or cell["kind"] == "ground" or entering not in ports:
                break
            seen.append(index); caps += cell["kind"] == "capacitor"
            outgoing = next(p for p in ports if p != entering)
            if index == options["target"] and outgoing == 1:
                return seen, caps, True
            row, col = divmod(index, 4)
            dr, dc = ((-1, 0), (0, 1), (1, 0), (0, -1))[outgoing]
            row += dr; col += dc
            if not 0 <= row < 3 or not 0 <= col < 4:
                break
            index, entering = row*4+col, (outgoing+2) % 4
        return seen, caps, False

    def tier_from(self, choice, options):
        seen, caps, complete = self.circuit(choice, options)
        return 0 if complete and caps == 2 else 1 if caps >= 1 and len(seen) >= 4 else 2 if len(seen) >= 2 else 3

    def apply(self, user, target, tier, data):
        logs = []
        break_power = int(round(self.SHIELD_BREAK[tier]*user.power_scale()))
        for effect in target.get_effects():
            if isinstance(effect, Shield) and effect.power > 0 and break_power:
                destroyed = min(effect.power, break_power); effect.power -= destroyed; break_power -= destroyed
                if not effect.power:
                    effect.duration = 0
                logs.append(f"⚡ Разряд выжигает {destroyed} единиц щита {target.name}.")
        wet = next((e for e in target.get_effects() if isinstance(e, Conductive)), None)
        bonus = 1.25 if wet and tier < 3 else 1
        if bonus > 1:
            target._effects.remove(wet)
            logs.append("💧 Проводящий след усиливает молнию на 25%!")
        part, _ = self.strike(user, target, self.TIER_VALUE[tier]*bonus, ignore_armor=True)
        return [Announcement(f"⚡ {user.name} замыкает цепь: {self.TIERS[tier]}!")] + logs + part

    def ai_score(self, user, target):
        from .ai import strike_value, tier_average
        shield = sum(e.power for e in target.get_effects() if isinstance(e, Shield))
        wet = target.has_effect(Conductive)
        return tier_average(self, user, [strike_value(user, target, mult*(1.25 if wet and i < 3 else 1),
            ignore_armor=True, force=True)+min(shield, self.SHIELD_BREAK[i]*user.power_scale())
            for i, mult in enumerate(self.TIER_VALUE)])
