"""Игрок — владелец героев."""
import hashlib


class Player:
    """Аккаунт игрока: логин, пароль (приватный), золото (приватное), герои."""

    _next_id = 1

    def __init__(self, username, password, gold=100):
        if not username or len(str(username)) < 3:
            raise ValueError("Логин должен быть не короче 3 символов")
        self.id = Player._next_id
        Player._next_id += 1
        self.username = str(username)
        self.__password_hash = self.__hash(password)  # пароль не хранится открыто
        self.__gold = 0
        self.gold = gold  # проходит через сеттер с проверкой
        self.heroes = []
        self.wins = 0
        self.active_hero_id = None    # 4.0: активный игровой персонаж (клик по своей карточке)
        self.unlocked_classes = []    # 4.0: о каких открытых классах уже сообщили («Вы открыли новый класс»)
        self.owned_skins = set()      # 4.1: облики принадлежат АККАУНТУ: "класс:облик" — надеть на любого героя класса
        self.dev_mode = False         # 4.1: режим разработчика (3 клика по логотипу)
        self.arena_background = "classic"
        self.arena_welcomed = False
        self.animations_enabled = True
        self.story_archive = []     # 5.2: пройденные сюжетные герои (снимок)
        self.columns = {"version": 1, "progress": {}, "run": None}

    def owns_skin(self, hero_type, skin):
        return f"{hero_type}:{skin}" in self.owned_skins

    def add_skin(self, hero_type, skin):
        self.owned_skins.add(f"{hero_type}:{skin}")

    @staticmethod
    def __hash(password):
        if not password or len(str(password)) < 4:
            raise ValueError("Пароль должен быть не короче 4 символов")
        return hashlib.sha256(str(password).encode()).hexdigest()

    def check_password(self, password):
        return self.__password_hash == hashlib.sha256(str(password).encode()).hexdigest()

    def change_password(self, old, new):
        if not self.check_password(old):
            raise ValueError("Старый пароль неверный")
        self.__password_hash = self.__hash(new)

    @property
    def gold(self):
        return self.__gold

    @gold.setter
    def gold(self, value):
        if not isinstance(value, int) or value < 0:
            raise ValueError("Золото должно быть целым неотрицательным числом")
        self.__gold = value

    def add_gold(self, amount):
        self.gold = self.__gold + amount

    def buy_item(self, item, hero):
        """Купить предмет и положить в инвентарь героя."""
        if hero not in self.heroes:
            raise ValueError("Это не ваш герой")
        if item.price > self.__gold:
            raise ValueError("Недостаточно золота")
        hero.inventory.add_item(item)
        self.gold = self.__gold - item.price

    def add_hero(self, hero):
        if hero not in self.heroes:
            self.heroes.append(hero)

    def archive_story_hero(self, hero):
        """5.2: снимок пройденного сюжетного героя; убрать из активных слотов."""
        from datetime import datetime, timezone
        entry = {
            "id": hero.id, "name": hero.name, "hero_class": hero.hero_class,
            "type": hero.type_key, "level": hero.level,
            "image": hero.image, "skin": hero.skin,
            "archived_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
        }
        self.story_archive.append(entry)
        if hero in self.heroes:
            self.heroes.remove(hero)
        if self.active_hero_id == hero.id:
            self.active_hero_id = None
        return entry

    MAX_HEROES = 5        # 4.0: максимум своих героев (Совух — бонусный шестой)
    MAX_STORY_HEROES = 1  # 5.0: в сюжете только один герой (спутники присоединятся позже)

    def arena_heroes(self):
        """Свои герои арены, которые занимают слоты (без Совуха и сюжетных)."""
        return [h for h in self.heroes if not getattr(h, "story", False) and not h.protected]

    def story_heroes(self):
        return [h for h in self.heroes if getattr(h, "story", False) and not getattr(h, "story_archived", False)]

    def to_dict(self):
        return {"id": self.id, "username": self.username, "gold": self.__gold,
                "wins": self.wins, "heroes": [h.id for h in self.heroes],
                "active_hero_id": self.active_hero_id, "unlocked_classes": list(self.unlocked_classes),
                "owned_skins": sorted(self.owned_skins), "dev_mode": self.dev_mode,
                "story_archive": list(self.story_archive), "columns": self.columns, "arena_background": self.arena_background, "arena_welcomed": self.arena_welcomed, "animations_enabled": self.animations_enabled,
                "slots": {"used": len(self.arena_heroes()),
                          "max": None if self.dev_mode else self.MAX_HEROES,  # 5.0: в режиме разработчика лимита нет
                          "story_used": len(self.story_heroes()), "story_max": self.MAX_STORY_HEROES}}

    def to_save_dict(self):
        """Данные для сохранения в файл (вместе с хэшем пароля, но не самим паролем)."""
        data = self.to_dict()
        data["password_hash"] = self.__password_hash
        return data

    @classmethod
    def from_save_dict(cls, data):
        """Восстановить игрока из сохранения."""
        player = cls(data["username"], "временный", data.get("gold", 0))
        player.__password_hash = data["password_hash"]
        player.id = data["id"]
        player.wins = data.get("wins", 0)
        player.active_hero_id = data.get("active_hero_id")
        player.unlocked_classes = list(data.get("unlocked_classes", []))
        player.owned_skins = set(data.get("owned_skins", []))
        player.arena_background = data.get("arena_background", "classic") if data.get("arena_background") in ("classic","pit","volcano","snow","ruins") else "classic"
        player.arena_welcomed = bool(data.get("arena_welcomed",False))
        player.animations_enabled = data.get("animations_enabled", True) is not False
        player.dev_mode = bool(data.get("dev_mode", False))
        player.story_archive = list(data.get("story_archive", []) or [])
        columns = data.get("columns", {"version": 1, "progress": {}, "run": None})
        if not isinstance(columns, dict) or not isinstance(columns.get("progress", {}), dict):
            raise ValueError("Повреждён прогресс столбов")
        for key, completed in columns.get("progress", {}).items():
            if not isinstance(key,str) or not isinstance(completed,list) or any(type(n) is not int or not 1<=n<=5 for n in completed):
                raise ValueError("Повреждён список пройденных столбов")
        run=columns.get('run')
        if run is not None:
            if not isinstance(run,dict) or type(run.get('column')) is not int or not 1<=run['column']<=5:
                raise ValueError('Повреждено сохранение забега')
            size=(4,6,8,10,15)[run['column']-1]
            if not isinstance(run.get('opponents'),list) or len(run['opponents'])!=size or any(not isinstance(x,dict) or not isinstance(x.get('key'),str) for x in run['opponents']):
                raise ValueError('Повреждён состав столба')
            if any(type(run.get(k)) is not int for k in ('cursor','lives','life_cap')) or not 1<=run['cursor']<=size+1 or not 0<=run['lives']<=7 or not 0<=run['life_cap']<=7:
                raise ValueError('Повреждены ступень или жизни забега')
            from . import HERO_CLASSES
            from .tower_data import BOSSES,portrait
            from .lore import NAMES
            if run.get('hero') not in HERO_CLASSES or not isinstance(run.get('id'),str) or run.get('status') not in ('ready','active','won','lost','abandoned'):
                raise ValueError('Повреждён герой или статус забега')
            run['name']=NAMES.get(run['hero'],run['hero'])
            for entry in run['opponents']:
                key=entry['key'];special=entry.get('special',False)
                if key not in (BOSSES if special else HERO_CLASSES):raise ValueError('Неизвестный соперник столба')
                entry['name']=BOSSES[key]['name'] if special else NAMES.get(key,key)
                entry['image']=portrait(key) if special and key!='gnuss' else '/static/images/story/gnuss.jpg' if key=='gnuss' else '/images/'+key
            run['player_id']=player.id
            if run.get('status')=='active':run['status']='ready';run['battle_id']=None
        player.columns = columns

        return player

    def __str__(self):
        return f"Игрок {self.username}: {self.__gold} зол., героев {len(self.heroes)}"
