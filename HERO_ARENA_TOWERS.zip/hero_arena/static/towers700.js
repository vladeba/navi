/* Columns live beside the arena; hero lore is intentionally deferred. */
(function(){'use strict';
let menu=null,selected='warrior',garrison='archers',shownScene=null,lastSpeech='',loading=false;
const nav=document.querySelector('nav'),button=document.createElement('button');button.dataset.tab='towers';button.textContent='♜ Столбы';nav.append(button);
const header=document.querySelector('body>header');new ResizeObserver(()=>document.documentElement.style.setProperty('--tower-header-height',header.offsetHeight+'px')).observe(header);
const tab=document.createElement('section');tab.id='towers';tab.className='tab';tab.innerHTML='<div class="tower-page"><div id="towerMenu"></div><div id="towerBattleSlot"></div></div>';document.querySelector('.tab').parentElement.append(tab);
KIND_NAME.tower='бой столба';BS.tower=null;
const originalMount=mountPanel;mountPanel=function(kind){if(kind==='tower'){document.getElementById('towerBattleSlot').after(document.getElementById('arenaPanel'));viewKind='tower';return}return originalMount(kind)};
const originalActive=activeBattle;activeBattle=function(){return BS.tower?.status==='active'?BS.tower:originalActive()};
function enter(){document.body.classList.add('towers-view');document.querySelectorAll('nav button,.tab').forEach(e=>e.classList.remove('active'));button.classList.add('active');tab.classList.add('active');}
nav.addEventListener('click',e=>{const b=e.target.closest('button');if(b&&b.dataset.tab!=='towers')document.body.classList.remove('towers-view')});
button.onclick=async()=>{enter();window.scrollTo({top:0,behavior:'instant'});await loadTower();};
const homeCard=document.createElement('button');homeCard.className='mode-card605';homeCard.dataset.open605='towers';homeCard.innerHTML='<span class="mode-icon605">♜</span><h3>Столбы арены</h3><p>Пять вершин, смена героев и испытания боссов. Прогресс сохраняется в аккаунте.</p><span class="mode-link605">НАЧАТЬ ВОСХОЖДЕНИЕ →</span>';homeCard.onclick=()=>button.click();document.querySelector('.mode-grid605').append(homeCard);
const beforeApi=api;api=function(url,method='GET',data=null){
 const match=url.match(/^\/api\/battles\/(\d+)\/(turn|react|surrender|cancel|kill)$/);
 if(match&&battle?.tower&&Number(match[1])===battle.id){url='/api/towers/battles/'+match[1]+'/'+match[2];data={...(data||{}),player_id:currentPlayer()?.id};}
 return beforeApi(url,method,data);
};
function identity(){return currentPlayer()?.id;}
function roman(i){return ['I','II','III','IV','V'][i-1]}
function progress(h){return [1,2,3,4,5].map(n=>`<span class="${h.completed.includes(n)?'done':''}" title="Столб ${n}">${roman(n)}</span>`).join('')}
async function loadTower(){
 const host=document.getElementById('towerMenu');host.hidden=false;
 if(!identity()){host.innerHTML='<div class="tower-title"><h1>Столбы арены</h1></div><div class="tower-rules"><p>Создай или загрузи аккаунт, чтобы начать восхождение.</p><button class="btn" id="towerAccount">Аккаунты</button></div>';document.getElementById('towerAccount').onclick=accountMenu606;return;}
 menu=await api('/api/towers?player_id='+identity());if(!menu)return;if(menu.run?.hero)selected=menu.run.hero;
 if(menu.run?.battle_id&&menu.run.status==='active'){
  const r=await api('/api/towers/battles/'+menu.run.battle_id+'?player_id='+identity());
  if(r){mountPanel('tower');resetArena();await update(r);return;}
 }
 if(!menu.heroes.some(h=>h.key===selected))selected=menu.heroes[0].key;
 drawMenu();
}
function heroOptions(value,column){return menu.heroes.map(x=>`<option value="${x.key}" ${x.key===value?'selected':''} ${column===5&&!x.fifth_unlocked?'disabled':''}>${esc(x.name)}${column===5&&!x.fifth_unlocked?' · нужны I–IV':''}</option>`).join('')}
async function switchHero(hero,skin=null){const r=await api('/api/towers/hero','POST',{player_id:identity(),hero,skin});if(!r)return false;menu=r;selected=r.run.hero;return true}
function drawMenu(){
 const host=document.getElementById('towerMenu'),h=menu.heroes.find(h=>h.key===selected),r=menu.run;
 const ongoing=r&&['ready','active'].includes(r.status),finished=r&&['won','lost'].includes(r.status),next=ongoing?r.opponents[r.cursor-1]:null;
 host.innerHTML=`<div class="tower-title"><div><div class="eyebrow605">ПЯТЬ ВЕРШИН · ОДНА АРЕНА</div><h1>Столбы арены</h1><p>Меняй героя между боями. Победа в столбе засчитывается герою, который одолел босса.</p></div><button class="btn ghost" id="towerRules">Правила</button></div>
 <div class="tower-selector"><img src="${h.image}" alt="${esc(h.name)}"><div class="tower-pickers"><label>Герой <select id="towerHero">${heroOptions(selected,ongoing?r.column:0)}</select></label><label>Облик <select id="towerSkin"><option value="">Базовый</option>${h.skins.map(s=>`<option value="${esc(s)}" ${r?.hero===selected&&r.skin===s?'selected':''}>${esc(skinTitle(selected,s))}</option>`).join('')}</select></label></div><div class="tower-progress"><b>${esc(h.name)} · пройдено ${h.completed.length}/5</b><div>${progress(h)}</div></div></div>
 ${ongoing?`<div class="tower-resume"><div><b>Столб ${roman(r.column)} · бой ${r.cursor}/${r.opponents.length}</b><span>♥ ${r.lives}/${r.life_cap} · Далее: ${esc(next.name)}</span></div><button class="btn" id="towerContinue">Продолжить</button><details class="tower-run-options"><summary aria-label="Управление забегом">⋯</summary><button class="btn ghost" id="towerAbandon">Завершить забег</button></details></div>`:''}
 ${finished?`<div class="tower-finished"><b>${r.status==='won'?'Столб пройден!':'Вы проиграли'}</b> ${esc(r.message)}</div>`:''}
 <p class="tower-save-note">✓ Прогресс столбов сохраняется в аккаунте автоматически. Предметы и автобой отключены.</p>
 <div class="tower-columns">${menu.columns.map(c=>columnCard(c,h,r)).join('')}</div>`;
 document.getElementById('towerHero').onchange=async e=>{const key=e.target.value;if(ongoing){if(await switchHero(key))drawMenu();else e.target.value=selected;}else{selected=key;drawMenu()}};
 document.getElementById('towerSkin').onchange=async e=>{if(ongoing&&!await switchHero(selected,e.target.value||null))drawMenu()};
 document.getElementById('towerRules').onclick=showRules;
 host.querySelectorAll('[data-column]').forEach(b=>b.onclick=()=>startColumn(+b.dataset.column));
 document.getElementById('towerContinue')?.addEventListener('click',briefing);
 document.getElementById('towerAbandon')?.addEventListener('click',async()=>{if(confirm('Завершить забег? Победы героев сохранятся.')){menu=await api('/api/towers/leave','POST',{player_id:identity()});if(menu)drawMenu()}});
 document.getElementById('arenaPanel').style.display='none';
}
function skinTitle(type,key){return menu?.heroes.find(h=>h.key===type)?.skin_names?.[key]||key.replaceAll('_',' ')}
function columnCard(c,h,r){
 const locked=c.number===5&&!h.fifth_unlocked,active=r&&r.column===c.number&&['ready','active'].includes(r.status),bosses={1:{4:['Эурон','euron']},2:{6:['Заферон','zaferon']},3:{7:['Дейрон-рыцарь','deyron_knight'],8:['Демонический Дейрон','deyron_demon']},4:{9:['Любительница боли','succubus'],10:['Гаррарат','garrarat']},5:{13:['Тассирион','tassirion'],14:['Гнусс','gnuss'],15:['Горр-Галл','gorr_gall']}};
 const rows=Array.from({length:c.size},(_,i)=>{const n=i+1,s=bosses[c.number][n],op=active?r.opponents[i]:null,name=op?.name||s?.[0]||'Соперник',src=op?.image||(s? s[1]==='gnuss'?'/static/images/story/gnuss.jpg':'/static/images/towers/'+s[1]+'.jpg':null);return `<div class="tower-step ${s?'boss':''} ${active&&n===r.cursor?'current':''} ${active&&n<r.cursor?'passed':''}"><span>${n}</span>${src?`<img src="${src}" alt="">`:'<span style="display:grid;place-items:center;width:34px;height:34px;background:#1d202a">?</span>'}<b>${esc(name)}</b></div>`}).join('');
 return `<article class="tower-column ${locked?'locked':''} ${active?'active-run':''}"><div class="tower-column-head"><h2>${roman(c.number)} · ${c.size} боёв ${h.completed.includes(c.number)?'✓':''}</h2><p>${esc(c.title)}</p>${active?'<span class="tower-current-label">Текущий забег</span>':`<button class="btn ${locked?'ghost':''}" data-column="${c.number}" ${locked?'disabled':''}>${locked?'🔒 Нужны победы I–IV':'Начать'}</button>`}</div><div class="tower-steps">${rows}</div><p class="tower-life-rule">${c.number<=2?'♥ 5 · при потере — к началу':c.number===3?'♥ 5 · откат на 3 боя':c.number===4?'♥ 5 · откат на 3 боя, запас уменьшается':'♥ 7 · откат на 5 боёв, запас уменьшается'}</p></article>`;
}
async function startColumn(column){
 if(loading)return;if(menu.run&&['ready','active'].includes(menu.run.status)&&!confirm('Начать новый забег вместо текущего?'))return;
 loading=true;try{const r=await api('/api/towers/start','POST',{player_id:identity(),hero:selected,column,skin:document.getElementById('towerSkin').value||null});if(!r)return;menu=r;drawMenu();await briefing()}finally{loading=false}
}
async function briefing(){
 const r=menu.run,op=r.opponents[r.cursor-1],boss=op.special&&!['deyron_knight','succubus'].includes(op.key);
 garrison=r.garrison||garrison;
 openBox(`<div class="guide606"><h2>${esc(op.name)}</h2><p>Столб ${roman(r.column)} · ступень ${r.cursor}/${r.opponents.length} · жизни ${r.lives}/${r.life_cap}</p><div class="tower-brief-hero"><img src="${menu.heroes.find(h=>h.key===r.hero).image}" alt=""><label>Кто вступит в бой<select id="towerFightHero">${heroOptions(r.hero,r.column)}</select></label></div><p>Здоровье и ресурс будут полными. Победа над боссом засчитается выбранному герою.</p>${r.checkpoint?'<p>Контрольная точка: продолжение со второй стадии.</p>':''}${boss?`<h3>Выбери гарнизон</h3><div class="tower-garrisons">${Object.entries(menu.garrisons).map(([k,g])=>`<button class="tower-garrison ${k===garrison?'selected':''}" data-garrison="${k}"><img src="/static/images/towers/icons/${k}.svg" alt=""><span><b>${g.name}</b><p>${g.description}</p><small>Каждые ${g.period} раундов</small></span></button>`).join('')}</div><p>Усталость отключена. Зелье арены каждые 10 раундов: 18% максимального HP.</p>`:'<p>Предметы и автоматический выбор приёма недоступны.</p>'}<div class="tower-actions"><button class="btn" id="towerFight">В бой!</button><button class="btn ghost" id="towerBack">Назад</button></div></div>`);
 document.querySelectorAll('[data-garrison]').forEach(b=>b.onclick=()=>{garrison=b.dataset.garrison;document.querySelectorAll('[data-garrison]').forEach(x=>x.classList.toggle('selected',x===b))});
 document.getElementById('towerFightHero').onchange=async e=>{if(await switchHero(e.target.value)){drawMenu();await briefing()}else e.target.value=r.hero};
 document.getElementById('towerBack').onclick=hideModal;
 document.getElementById('towerFight').onclick=async e=>{e.currentTarget.disabled=true;const r=await api('/api/towers/fight','POST',{player_id:identity(),garrison});if(!r){document.getElementById('towerFight')?.removeAttribute('disabled');return}hideModal();mountPanel('tower');battle=null;BS.tower=null;resetArena();shownScene=null;lastSpeech='';await update(r,true);document.getElementById('arenaPanel').scrollIntoView({block:'start',behavior:'smooth'});};
}
function showRules(){openBox(`<div class="guide606"><h2>Столбы арены</h2><div class="tower-rules"><p>Первые четыре столба доступны в любом порядке. Пятый открывается отдельно для каждого героя после побед в первых четырёх. Повтор одного столба не заменяет прохождение другого.</p><p>После поражения расходуется жизнь. Пока жизни есть, повторяется та же встреча. Состав противников сохраняется весь забег.</p><p>I–II: при потере всех жизней возврат к первому бою, снова 5 жизней.<br>III: откат на 3 ступени, снова 5 жизней.<br>IV–V: откат на 3/5 ступеней; запас уменьшается на одну жизнь. Когда последняя попытка потеряна — «Вы проиграли», новый забег с начала.</p><p>Героя можно менять перед каждым боем. Победу в столбе получает герой, победивший босса. Прогресс автоматически сохраняется в аккаунт; при загрузке аккаунта забег можно продолжить. Личные истории и финальные сцены героев будут добавлены в следующем обновлении.</p></div><button class="btn" onclick="hideModal()">Понятно</button></div>`)}
const oldRender=renderFighters;renderFighters=function(b,...args){oldRender(b,...args);const panel=document.getElementById('arenaPanel');panel.classList.toggle('tower-mode',!!b.tower);panel.classList.toggle('tower-boss',!!b.tower?.boss);let hud=document.getElementById('towerHUD');let quote=document.getElementById('towerQuote');if(!b.tower){if(hud)hud.hidden=true;if(quote)quote.hidden=true;return}
 panel.style.setProperty('--scene-bg607',`url("${b.tower.background}")`);
 if(!hud){hud=document.createElement('div');hud.id='towerHUD';hud.className='tower-hud';document.getElementById('battleToolbar607').after(hud)}hud.hidden=false;
 const t=b.tower,r=b.tower_run||menu?.run,next=r?.opponents?.[t.step];hud.innerHTML=`<b>Столб ${roman(t.column)} · ${t.step}/${r?.opponents?.length||[4,6,8,10,15][t.column-1]} · ♥ ${r?.lives??''}/${r?.life_cap??''}</b><span>${next?'Следующий: '+esc(next.name):'Вершина столба'}</span>${t.garrison?`<span class="support-line"><img class="support-icon" src="/static/images/towers/icons/${t.garrison}.svg" alt="">${({archers:'Лучники',infantry:'Пехотинцы',shields:'Щитоносцы',healers:'Эльфы-целители'})[t.garrison]} через ${t.garrison_in} р. · зелье через ${t.potion_in} р.</span>`:''}${t.boss_key==='gorr_gall'?`<span>Печать власти: ${t.seal}/6</span>`:''}`;
 if(!quote){quote=document.createElement('div');quote.id='towerQuote';quote.className='tower-quote';hud.after(quote)}const notice=b.log.filter(e=>['speech','support'].includes(e.kind)).at(-1);quote.hidden=!notice;quote.textContent=notice?(notice.kind==='speech'?(notice.speaker||b.hero2)+' — «'+notice.text+'»':notice.text):'';
 for(const s of b.heroes[1].summons||[]){const el=document.querySelector(`[data-minion="${s.id}"]`);if(!el)continue;const target=el.querySelector('.target55');el.title=s.about+' · до победы над слугой';el.innerHTML=`<b style="display:block;font-size:10px;line-height:1.15;min-height:24px">${esc(s.name)}</b><div class="bar hpbar" style="height:12px;margin:5px 0"><div style="width:${Math.max(0,100*s.hp/s.max_hp)}%"></div><span>${s.hp}/${s.max_hp}</span></div>`;if(target){target.textContent='🎯 Атаковать';target.style.cssText='font-size:9px;min-height:23px;padding:3px!important;margin:2px 0;width:100%';el.append(target)}else el.insertAdjacentHTML('beforeend','<small>Повержен</small>');}
 const bossTarget=document.querySelector('#f1>.target55');if(bossTarget&&t.boss_key==='gorr_gall')bossTarget.textContent='🎯 Цель: Горр-Галл';
};
const oldSkills=renderSkills;renderSkills=function(b){const commands=document.getElementById('commands606');if(!b.tower||commands.dataset.towerBattle!==String(b.id)){commands.style.minHeight='';commands.style.boxSizing='';delete commands.dataset.towerHeight;}commands.dataset.towerBattle=b.tower?String(b.id):'';oldSkills(b);if(!b.tower)return;const ctl=document.getElementById('battleCtl');if(b.status==='active'){
 ctl.innerHTML=`<button class="btn small ghost" id="towerSurrender">Сдаться · −1 жизнь</button>${currentPlayer()?.dev_mode?'<button class="btn small red" onclick="killOpp()">💀 Убить</button>':''}`;document.getElementById('towerSurrender').onclick=async()=>{if(!confirm('Сдаться и потерять одну жизнь?'))return;const r=await api('/api/towers/battles/'+b.id+'/surrender','POST',{player_id:identity()});if(r)await update(r)};
 if(b.tower.mark_kind==='gnuss'&&b.tower.mark&&!b.pending&&!b.tower.scene){const box=document.getElementById('skillBox');box.innerHTML='<div class="tower-opening"><b>🎯 Пробить защиту</b><p>Выбери любую атакующую мини-игру героя. Бесплатно, без таймера и расхода основного действия.</p><button class="btn" id="towerCounterOpen">Нажать на метку</button></div>';document.getElementById('towerCounterOpen').onclick=()=>chooseCounter(b)}
 if(b.tower.scene)document.getElementById('skillBox').innerHTML='<div class="tower-opening"><b>Смена сцены</b><button class="btn" id="towerSceneResume">Продолжить</button></div>';
 document.getElementById('towerSceneResume')?.addEventListener('click',()=>showScene(b));
 }if(b.status==='active'&&!b.pending&&!b.tower.scene){const height=Math.max(Number(commands.dataset.towerHeight)||0,commands.offsetHeight);commands.dataset.towerHeight=String(height);commands.style.boxSizing='border-box';commands.style.minHeight=height+'px';}};
function chooseCounter(b){openBox(`<div class="guide606"><h2>Пробить защиту Гнусса</h2><p>Результат выбранной игры определяет дополнительный урон.</p><div class="tower-counter-list">${b.tower.counter_choices.map(s=>`<button class="btn ghost" data-counter="${esc(s.key)}">${s.icon} ${esc(s.name)}</button>`).join('')}</div></div>`);document.querySelectorAll('[data-counter]').forEach(btn=>btn.onclick=async()=>{btn.disabled=true;const r=await api('/api/towers/battles/'+b.id+'/counter','POST',{player_id:identity(),skill:btn.dataset.counter});if(r){hideModal();await update(r)}})}
function showScene(b){
 const scene=b.tower.scene;if(!scene)return;shownScene=b.id+':'+scene.id;const frames=scene.frames||[scene];let frame=0;
 const finish=async()=>{document.querySelectorAll('.scene-controls button').forEach(x=>x.disabled=true);const r=await api('/api/towers/battles/'+b.id+'/scene','POST',{player_id:identity(),scene_id:scene.id});if(r){hideModal();await update(r)}};
 function paint(){const s=frames[frame];openBox(`<div class="tower-scene ${battleAnimations607.enabled?'motion':''}" style="background-image:url('${s.background}')">${s.image?`<img src="${s.image}" alt="${esc(b.hero2)}">`:''}<div class="scene-copy"><div class="eyebrow605">${scene.kind==='intro'?'НАЧАЛО ВСТРЕЧИ':'СЦЕНА БОЯ'}${frames.length>1?' · '+(frame+1)+'/'+frames.length:''}</div><h2>${esc(s.title)}</h2><p>${esc(s.text)}</p>${s.quote?`<blockquote>«${esc(s.quote)}»</blockquote>`:''}</div><div class="scene-controls"><button class="btn" id="towerSceneGo">${frame<frames.length-1?'Далее':'Продолжить'}</button><button class="btn ghost" id="towerSceneSkip">Пропустить сцену</button></div></div>`);document.getElementById('towerSceneGo').onclick=()=>{if(frame<frames.length-1){frame++;paint()}else finish()};document.getElementById('towerSceneSkip').onclick=finish;}
 paint();
}
const oldUpdate=update;update=async function(b,first=false){if(b.tower){enter();document.getElementById('towerMenu').hidden=true;if(b.tower_run&&menu)menu.run=b.tower_run;}
 const r=await oldUpdate(b,first);if(b.tower?.scene)showScene(b);return r;};
const oldResult=showResult;showResult=function(b){if(!b.tower)return oldResult(b);const r=b.tower_run;document.getElementById('banner').style.display='none';document.getElementById('recap605')?.remove();document.getElementById('battleCtl').innerHTML='';document.getElementById('skillBox').innerHTML=`<div class="tower-result"><h3>${r?.status==='lost'?'Вы проиграли':b.winner_id===b.hero1_id?'Победа!':'Поражение'}</h3><p>${esc(r?.message||'')}</p><p>Жизни: ${r?.lives}/${r?.life_cap} · ступень ${Math.min(r?.cursor||1,r?.opponents.length||1)}/${r?.opponents.length}</p><div class="tower-actions"><button class="btn" id="towerResultMenu">К столбам</button><small class="tower-saved">✓ Сохранено в аккаунте</small></div></div>`;
 document.getElementById('towerResultMenu').onclick=async()=>{BS.tower=null;battle=null;document.getElementById('arenaPanel').style.display='none';document.getElementById('towerMenu').hidden=false;await loadTower()};};
const oldPlayer=onPlayer;onPlayer=function(...args){const r=oldPlayer(...args);menu=null;BS.tower=null;if(button.classList.contains('active'))loadTower();return r};
window.towerUI={open:async()=>{enter();await loadTower()},load:loadTower};
})();
